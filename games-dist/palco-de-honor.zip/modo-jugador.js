/* ====== Palco de Honor · MODO JUGADOR v2 · «El túnel morado» ======
   Carrera completa de un futbolista: creación, cantera, partidos con decisiones, entrenamiento, vestuario,
   contratos y agente, selección, premios, vida fuera del campo, noticias con decisiones, rivales de generación
   y modo leyenda. Usa los datos y utilidades del juego (CLUBS, LG, crest, esc, modal, money, render…).
   La media máxima de la carrera queda siempre entre 83 y 94: la fijan las decisiones (lp, oculto). */
(()=>{
'use strict';
/* Interruptor: true = el modo Jugador está disponible para todo el mundo (false lo deja «En desarrollo»). */
/* Acceso de prueba: abrir el juego con #probar-429d9da35498 lo activa en ese navegador (y #salir-pruebas lo desactiva). */
const TESTER_KEY='pdh-tester',TESTER_HASH='#probar-429d9da35498';
try{if(location.hash===TESTER_HASH)localStorage.setItem(TESTER_KEY,'1');if(location.hash==='#salir-pruebas')localStorage.removeItem(TESTER_KEY);}catch(e){}
const PLAYER_MODE_ON=true||(()=>{try{return localStorage.getItem(TESTER_KEY)==='1';}catch(e){return false;}})();
const KEY='pdh-player2',HALL='pdh-hall2';
const AT=['rit','tir','pas','reg','def','fis'];
const AN={rit:'Ritmo',tir:'Tiro',pas:'Pase',reg:'Regate',def:'Defensa',fis:'Físico'};
const ANP={...AN,def:'Paradas',rit:'Reflejos',tir:'Saque'};
const W={POR:[.15,0,.1,0,.55,.2],DEF:[.15,0,.1,.05,.45,.25],MED:[.1,.1,.35,.25,.1,.1],EXT:[.3,.15,.15,.3,0,.1],DEL:[.15,.35,.1,.2,0,.2]};
const POS={POR:'Portero',DEF:'Defensa',MED:'Centrocampista',EXT:'Extremo',DEL:'Delantero'};
const PERS={Líder:'Arrastra al vestuario. Más química y opciones de capitanía.',Humilde:'Cae bien a todos. Menos polémicas, menos focos.',Ambicioso:'Quiere más, siempre. Crece rápido, choca con el banquillo.',Rebelde:'Talento y carácter. Polémicas y momentos de genio.',Profesional:'Cuida cada detalle. Menos lesiones, carrera larga.'};
const STY={Regateador:'reg',Organizador:'pas',Goleador:'tir',Velocista:'rit',Todoterreno:'*'};
const ORIG={Cantera:'Academia de un club. Técnica y táctica, menos físico.','Equipo pequeño':'Un club humilde te vio crecer. Constancia y físico.','Fútbol callejero':'Barrio y cemento. Regate alto, táctica por pulir.','Promesa internacional':'Todos te conocen. Techo alto y presión máxima.'};
const DREAMS={champions:'Ganar la Champions',balon:'Ganar el Balón de Oro',capitan:'Ser capitán de mi club',mundial:'Ganar el Mundial',record:'Superar los 400 goles de carrera'};
const NAT={'España':[88,'UEFA'],'Argentina':[88,'CONMEBOL'],'Brasil':[87,'CONMEBOL'],'Francia':[89,'UEFA'],'Inglaterra':[87,'UEFA'],'Portugal':[86,'UEFA'],'Alemania':[86,'UEFA'],'Italia':[85,'UEFA'],'Países Bajos':[85,'UEFA'],'Bélgica':[83,'UEFA'],'Croacia':[82,'UEFA'],'Uruguay':[82,'CONMEBOL'],'Colombia':[81,'CONMEBOL'],'Marruecos':[81,'CAF'],'Senegal':[80,'CAF'],'México':[79,'CONCACAF'],'Estados Unidos':[78,'CONCACAF'],'Japón':[79,'AFC'],'Chile':[76,'CONMEBOL'],'Arabia Saudí':[72,'AFC']};
const CONT={UEFA:'Eurocopa',CONMEBOL:'Copa América',CONCACAF:'Copa Oro',CAF:'Copa África',AFC:'Copa Asiática'};
const SKIN=['#F6DCC8','#EBC0A0','#D4A07A','#B07850','#8A5A3B','#5E3B26','#3E271B'],HAIR=['Fade texturizado','Buzz cut','Rizos con fade','Melena','Man bun','Mohicano','Calvo','Crop francés','Tupé','Raya al lado','Edgar','Mullet','Trenzas','Rastas','Twists','Afro'],
HAIRC=['#16101C','#3B2416','#6E4424','#B07A3E','#D9B26A','#A8321E','#D9D4CC','#B57BFF'],BEARD=['Sin barba','Perilla','Barba corta','Barba poblada'],BOOTS=['#B57BFF','#F1E9FF','#FF5DA2','#3DE0C2','#FFD24A','#141414','#E8352E','#2F6BFF','#39D353','#FF8A1F','#C0C0C8','#00B8D9'],ACC=['Nada','Cinta','Muñequera','Mangas largas','Guantes','Gafas deportivas','Pendientes','Cadena','Cuello térmico','Máscara protectora','Vendaje en las manos','Rodilleras','Diadema'],
SOCKS=['Normales','Altas','Bajas'],BOOTM=['Clásica','Caña alta','Velocidad','Retro','Élite dorada'];
const FIRSTN=['Leo','Marco','Iker','Tomás','Nico','Joao','Hugo','Rafa','Enzo','Kai','Luca','Theo','Ilyas','Mateo','Bruno','Ansu','Dani','Ruben'];
const LASTN=['Ferreira','Moreau','Okafor','Lindqvist','Barros','Kovač','Santoro','Haddad','Müller','Ibarra','Dembélé','Rojas','Novak','Costa','Achraf','Vidal','Navarro','Gómez'];
const CUPW=[7,15,23,29,35],CUPN=['Dieciseisavos','Octavos','Cuartos','Semifinal','Final'];
const EURW=[4,9,13,26,32,37],EURN=['Fase de liga','Fase de liga','Fase de liga','Octavos','Semifinal','Final'];
const NATW=[10,20,30];

let P=null;try{P=JSON.parse(localStorage.getItem(KEY));if(P&&P.v!==2)P=null;}catch(e){P=null;}
if(P&&P.assets&&P.assets.includes('coche')){P.assets=P.assets.filter(a=>a!=='coche');P.cars=(P.cars||[]).concat('gt');}
const save=()=>{if(P&&P.st&&!save.busy){save.busy=1;try{achCheck();}catch(e){}save.busy=0;}try{localStorage.setItem(KEY,JSON.stringify(P));}catch(e){}};
const hall=()=>{try{return JSON.parse(localStorage.getItem(HALL))||[];}catch(e){return[];}};

const R=(a,b)=>a+Math.floor(Math.random()*(b-a+1)),pk=a=>a[R(0,a.length-1)],ch=p=>Math.random()<p;
const avg=a=>a.length?a.reduce((x,y)=>x+y,0)/a.length:0;
const f1=v=>(Math.round(v*10)/10).toFixed(1);
const eur=v=>v>=1e6?(v/1e6).toFixed(v>=1e7?0:1).replace('.',',')+' M€':v>=1e3?Math.round(v/1e3)+' K€':Math.round(v)+' €';
/* goles esperados: la diferencia de nivel cuenta, pero sin marcadores imposibles */
const xg=d=>1.3*Math.exp(clamp(d,-22,22)/20);
const poisson=l=>{let L=Math.exp(-l),k=0,p=1;do{k++;p*=Math.random();}while(p>L);return k-1;};
const club=id=>CLUBS[id];
const divOf=k=>k?(typeof divLabel==='function'?divLabel(k.league,k.tier):LG[k.league].name):'';
/* solo clubes de las ligas jugables (el juego añade clubes UEFA sin liga propia) */
let _all=null;const ALL=()=>_all||(_all=Object.values(CLUBS).filter(k=>LG[k.league]&&LG[k.league].pyr&&(LG[k.league].pyr[k.tier]||[]).includes(k.id)));
const cname=id=>CLUBS[id]?CLUBS[id].name:'Sin club';
const clubStr=id=>CLUBS[id]?CLUBS[id].base:55;
const ovr=(p=P)=>Math.round(AT.reduce((s,k,i)=>s+p.at[k]*W[p.pos][i],0));
const ceil=()=>83+Math.round(11*clamp(P.lp,0,100)/100);
const natLevel=()=>P.age<17?'Sub-17':P.age<19?'Sub-19':P.age<21?'Sub-21':'Absoluta';
const country=id=>LG[CLUBS[id].league].country;
const reduced=()=>matchMedia('(prefers-reduced-motion: reduce)').matches;

/* ---------- creación ---------- */
UI.jc=UI.jc||{name:'',last:'',nat:'España',age:17,day:14,month:3,height:180,foot:'Derecha',pos:'DEL',pos2:'EXT',num:9,pers:'Ambicioso',style:'Goleador',origin:'Cantera',dream:'balon',skin:2,hair:0,hairc:0,beard:0,boots:0,acc:0,accs:[],socks:0,bootm:0};
UI.jt=UI.jt||'despacho';UI.jobj=UI.jobj||'auto';
function build(c){
  const base={Cantera:{pas:3,def:2,fis:-3},'Equipo pequeño':{fis:4,rit:1,reg:-2},'Fútbol callejero':{reg:6,def:-4,pas:-1},'Promesa internacional':{tir:2,reg:2,rit:2}}[c.origin];
  const posB={POR:{def:12,fis:4,rit:4},DEF:{def:10,fis:5},MED:{pas:8,reg:2},EXT:{rit:7,reg:5},DEL:{tir:8,rit:2}}[c.pos];
  const at={};AT.forEach(k=>{at[k]=clamp(54+(base[k]||0)+(posB[k]||0)+(STY[c.style]==='*'?3:STY[c.style]===k?8:0)+(c.age-17)*2,40,82);});
  if(c.height>=190){at.fis+=3;at.rit-=2;}else if(c.height<=170){at.reg+=3;at.fis-=2;}
  const lp0={Profesional:58,Humilde:53,Líder:52,Ambicioso:50,Rebelde:45}[c.pers];
  const p={v:2,...c,at,startAge:+c.age,lp:lp0,wf:c.origin==='Fútbol callejero'?3:2,sk:c.style==='Regateador'?3:2,xp:{},
    season:2026,week:1,squad:null,club:null,origin0:null,loan:null,contract:null,form:55,fat:10,mor:72,tru:45,fame:c.origin==='Promesa internacional'?22:6,chem:50,adapt:100,
    kit:'local',celeb:0,money:15000,assets:[],sponsors:[],followers:0,rep:{humilde:0,polemico:0,lider:0,mediatico:0},inj:0,focus:STY[c.style]==='*'?'fis':STY[c.style],intensity:'normal',free:'descanso',firstTrain:false,
    offers:[],news:[],pending:[],evCool:0,cal:[],cupAlive:true,eurAlive:true,pts:0,pld:0,
    st:{pj:0,tit:0,sup:0,g:0,a:0,cs:0,rt:[]},sea:null,hist:[],titles:[],awards:[],moves:[],sel:{caps:0,g:0,lvl:'',called:false,captain:false},
    rivals:[],captain:false,peak:0,dreamDone:false,retired:false,yearsAt:0,miniDone:false,promise:null,log:[]};
  /* media inicial fija: 60 */
  const ord=AT.filter((k,i)=>W[p.pos][i]>0).sort((a,b)=>W[p.pos][AT.indexOf(b)]-W[p.pos][AT.indexOf(a)]);let g=0;
  while(ovr(p)!==60&&g<400){const k=ord[g++%ord.length];p.at[k]=clamp(p.at[k]+(ovr(p)<60?1:-1),35,85);}
  return p;
}
function newSeason(){
  P.sea={club:P.club,pj:0,tit:0,sup:0,g:0,a:0,cs:0,rt:[],min:0,cup:'',eur:'',finalBest:0};
  P.pts=0;P.pld=0;P.cupAlive=true;P.eurAlive=eurQualified();P.week=1;P.miniDone=false;P.promise=null;
  P.cal=buildCal();P.fx=0;P.summer=false;P.eurAlive=!!(P.comp.ucl||P.comp.uel||P.comp.uecl||P.comp.lib||P.comp.ccc||P.comp.acl);
}
const eurQualified=()=>{const c=club(P.club);return c.tier===0&&c.base>=78;};
function genRivals(){const used=new Set();P.rivals=[0,1,2].map(i=>{let n;do{n=pk(FIRSTN)+' '+pk(LASTN);}while(used.has(n));used.add(n);
  const natN=pk(Object.keys(NAT).filter(x=>x!==P.nat)),pos=pk(['DEL','EXT','MED','DEL']);
  const pool=ALL().filter(k=>k.tier<=1&&k.base<74).map(k=>k.id);
  return{name:n,nat:natN,pos,ovr:ovr()+R(-3,3),ceil:R(84,95),club:pk(pool),g:0,seaG:0,awards:[],titles:0};});}

/* ---------- utilidades de estado ---------- */
function news(t,kind){if(news.q)return;P.news.unshift({s:P.season,w:P.week,t,k:kind||''});P.news=P.news.slice(0,40);}
function grow(k,n=1){for(let i=0;i<n;i++){if(P.at[k]>=99)return;P.at[k]++;if(ovr()>ceil()){P.at[k]--;return;}}}
function role(){
  if(P.inj>0)return'Lesionado';if(P.ban>0)return'Sancionado';
  if(P.squad==='cantera')return'Cantera';
  const c=club(P.club),d=ovr()-(c.base-4)+(P.tru-50)/10-P.fat/25+(P.promise==='minutos'?3:0)+coachFit();
  if(P.captain&&d>=0)return'Capitán';
  return d>=2?'Titular':d>=-4?'Rotación':d>=-12||P.tru>=25?'Suplente':'Descartado';
}
const wageWeek=()=>P.contract?P.contract.wage:0;
function contractFor(cid,squad,extra={}){const b=clubStr(cid),o=ovr();
  const wage=Math.round(Math.max(squad==='cantera'?600:1500,Math.pow(Math.max(o-45,4),2.15)*(b/70)*6)/100)*100;
  return{club:cid,years:squad==='cantera'?3:R(2,5),wage,bonus:Math.round(wage*.3),clause:Math.round(wage*52*(squad==='cantera'?8:R(10,30))),promise:null,...extra};}
function rep(){const r=P.rep,k=Object.keys(r).sort((a,b)=>r[b]-r[a])[0];return r[k]<3?'Por definir':{humilde:'Humilde',polemico:'Polémico',lider:'Líder',mediatico:'Estrella mediática'}[k];}
function potText(){const s=P.hist.length,lo=83,hi=94,c=ceil();if(s===0)return'¿?';const spread=Math.max(0,5-s);return spread===0?String(c):`${clamp(c-spread,lo,hi)}–${clamp(c+spread,lo,hi)}`;}

/* ---------- vista: creación ---------- */
/* peinados actuales por vóxeles: la misma definición alimenta la figura 3D y el avatar 2D.
   Cada estilo dice qué celdas de una rejilla de 12 vóxeles por lado de cabeza llevan pelo (capa L, cara top/front/side/back,
   altura t de 0 a 1 sobre la cabeza) y qué degradado lleva el cuero cabelludo (fade). */
const HSTY=[
  {fade:'mid',hl:3,f:c=>c.top?c.L<=2+(c.r>.55)+(c.w>.3&&c.cr>.5):c.front?c.t>.9&&c.L===1&&c.r>.3:c.t>.82&&c.L===1},
  {fade:'buzz',hl:3},
  {fade:'high',hl:2,f:c=>c.top?c.L<=3+(c.cr>.5)+(c.r>.7):c.front?c.t>.76&&c.cr>.35&&c.L<=1+(c.r>.6):c.t>.8&&c.L===1},
  {fade:'full',hl:3,f:c=>c.top?c.L<=2+(c.r>.8):c.front?c.t>.86&&c.u>-.2&&c.L===1:c.side?c.t>-.15&&c.L<=(c.t>.35?2:1):c.t>-.55&&c.L<=2},
  {fade:'low',hl:3,bun:1,f:c=>c.top?c.L===1:c.front?false:c.t>(c.back?.3:.5)&&c.L===1},
  {fade:'skin',hl:0,hlc:1,f:c=>Math.abs(c.x)<2*c.v&&(c.top?c.L<=2+Math.round((c.w+1)*1.2)+(c.r>.6):c.back?c.t>.55&&c.L===1:false)},
  {fade:'bald',hl:0},
  {fade:'skin',hl:2,f:c=>c.top?c.L<=2+(c.r>.75):c.front?c.t>.8&&c.L===1&&c.r>.2:c.t>.9&&c.L===1},
  {fade:'mid',hl:2,f:c=>c.top?c.L<=1+Math.round((c.w+1)*1.6)+(c.r>.7):c.front?false:c.t>.8&&c.L===1},
  {fade:'low',hl:3,f:c=>c.top?(c.ix===-3?false:c.ix<-3?c.L===1:c.L<=2+(c.w>.4&&c.r>.5)):c.front?c.t>.9&&c.ix>-3&&c.L===1&&c.r>.25:c.t>.65&&c.L===1},
  {fade:'skin',hl:2,f:c=>c.top?c.L<=2:c.front?c.t>.73&&c.L===1:c.t>.9&&c.L===1},
  {fade:'mid',hl:3,f:c=>c.top?c.L<=2+(c.r>.6):c.front?c.t>.85&&c.L===1&&c.r>.4:c.side?c.t>.7&&c.L===1:c.t>-.45&&c.L<=(c.t<.4?2:1)&&Math.abs(c.u)<.85},
  {fade:'scalp',hl:2,shade:c=>(c.iz&1?.06:-.04),f:c=>c.L===1&&(c.top?(c.ix&1)===0:c.back?(c.ix&1)===0&&c.t>.1:c.side?(c.iz&1)===0&&c.t>.6:false)},
  {fade:'full',hl:2,shade:c=>((c.iy&1)?.05:-.03),f:c=>c.top?c.L<=2:c.front?c.t>.8&&(c.ix&1)===0&&c.L===1:c.side?(c.iz&1)===0&&c.t>-.15&&c.L===1:(c.ix&1)===0&&c.t>-.55&&c.L===1},
  {fade:'high',hl:2,shade:c=>(c.L>1?(c.iy&1?.06:-.02):-.05),f:c=>c.top?c.L===1||(((c.ix^c.iz)&1)===0&&c.L<=2+Math.floor(c.cr2*3)):c.front?c.t>.86&&(c.ix&1)===0&&c.L===1:c.t>.85&&c.L===1},
  {fade:'low',hl:2,afro:1,f:c=>{if(c.front&&c.t<.86||c.t<.38)return false;const v=c.v,e=(c.x/(c.hw+3.2*v))**2+((c.y-.12*c.hs)/(c.hh+3.6*v))**2+((c.z+.4*v)/(c.hd+3.2*v))**2;return e<=1&&!(e>.86&&c.r<.3);}}
];
function hairVox(style,hs){const S=HSTY[style]||HSTY[0];if(!S.f&&!S.bun)return [];
  const v=hs/12,hw=hs/2,hd=hs*.47,hh=hs/2,out=[];
  const hr=(a,b,c)=>{let h=(a*73856093)^(b*19349663)^(c*83492791);h=Math.imul(h^(h>>>13),1274126177);return ((h^(h>>>16))>>>0)/4294967296;};
  for(let ix=-9;ix<9;ix++)for(let iy=-14;iy<13;iy++)for(let iz=-9;iz<9;iz++){
    const x=(ix+.5)*v,y=(iy+.5)*v,z=(iz+.5)*v;
    const ex=Math.max(0,Math.abs(x)-hw)/v,ez=Math.max(0,Math.abs(z)-hd)/v,ey=Math.max(0,y-hh)/v,o=Math.max(ex,ey,ez);if(o<=0)continue;
    const top=ey>0&&ex===0&&ez===0,bun=S.bun&&Math.hypot(x,y-hh-2.2*v,z+hd-.4*v)<2.5*v;if(ey>0&&!top&&!S.afro&&!bun)continue;
    const L=Math.ceil(o-1e-6)+(top&&Math.max(Math.abs(x)/hw,Math.abs(z)/hd)>.8?1:0);
    const c={L,u:Math.max(-1,Math.min(1,x/hw)),w:Math.max(-1,Math.min(1,z/hd)),t:(y+hh)/hs,ix,iy,iz,x,y,z,v,hw,hd,hh,hs,top,
      front:!top&&z>hd&&ez>=ex,back:!top&&z<-hd&&ez>=ex,side:!top&&Math.abs(x)>hw&&ex>ez,r:hr(ix,iy,iz),cr:hr(ix>>1,3,iz>>1),cr2:hr(ix,11,iz)};
    if(bun||(S.f&&S.f(c)))out.push({x,y,z,L,r:c.r,k:(S.shade?S.shade(c):0)+(c.r-.5)*.1-(L===1?.04:0)+(top&&L>2?.03:0)+(bun?.03:0),ix,iy});}
  return out;}
/* aclara u oscurece un color hex (k en -1..1) */
function shadeHex(h,k){const n=parseInt(h.slice(1),16),f=x=>Math.max(0,Math.min(255,Math.round(k<0?x*(1+k):x+(255-x)*k)));
  return '#'+[n>>16,(n>>8)&255,n&255].map(f).map(x=>x.toString(16).padStart(2,'0')).join('');}
/* degradado del cuero cabelludo (fade) en píxeles con tramado ordenado */
const BAYER4=[0,8,2,10,12,4,14,6,3,11,1,9,15,7,13,5];
function fadeAt(S,t,px,py){const R={low:[.04,.3],mid:[.22,.58],high:[.42,.78],skin:[.56,.86],full:[-1,-.5],buzz:[-1,-.5],scalp:[-1,-.5],bald:[2,3]}[S.fade]||[2,3];
  const cov=Math.max(0,Math.min(1,(t-R[0])/(R[1]-R[0])));return cov>(BAYER4[(py&3)*4+(px&3)]+.5)/16;}
function accsOf(L){return Array.isArray(L&&L.accs)?L.accs.map(Number).filter(x=>x>0):(L&&+L.acc?[+L.acc]:[]);}
const hasAcc=(L,i)=>accsOf(L).includes(i);
function avatar(p,size=120){const sk=SKIN[p.skin]??SKIN[2],K=kitOf(p),c={c1:K.s,c2:K.t},st=+p.hair||0,S=HSTY[st]||HSTY[0],hc=HAIRC[p.hairc||0],bd=+p.beard||0;
  const r=(x,y,w,h,f,o='')=>`<rect x="${x}" y="${y}" width="${w}" height="${h}" fill="${f}"${o}/>`;
  /* vista frontal de los mismos vóxeles del modelo 3D: solo lo que asoma por delante o fuera de la silueta de la cabeza */
  const k=52/.54,vs=k*.54/12,fr=new Map();hairVox(st,.54).forEach(q=>{if(!(q.z>.2538||Math.abs(q.x)>.27||q.y>.27))return;const id=q.ix+','+q.iy,o=fr.get(id);if(!o||q.z>o.z)fr.set(id,q);});
  const hair=[...fr.values()].sort((a,b)=>a.z-b.z).map(q=>r((60+q.x*k-vs/2).toFixed(1),(51-q.y*k-vs/2).toFixed(1),(vs+.4).toFixed(1),(vs+.4).toFixed(1),shadeHex(hc,q.k*2.2-(q.L>1?0:.04)))).join('');
  const line=S.hl?(S.hlc?r(53,25,14,S.hl*1.6+2,hc):r(34,25,52,S.hl*1.6,hc)+r(34,25,5,S.hl*1.6+3,hc)+r(81,25,5,S.hl*1.6+3,hc)):'';
  const beard=['',r(54,66,12,6,hc),r(36,62,48,10,hc,' opacity=".85"'),r(34,58,52,18,hc)][bd];
  return `<svg viewBox="0 0 120 120" width="${size}" height="${size}" role="img" aria-label="Aspecto del jugador"><rect x="2" y="2" width="116" height="116" rx="14" fill="#1a0c33"/>
  ${r(26,84,68,34,c.c1)}${r(26,84,68,5,c.c2)}${r(52,84,16,8,c.c2)}<text x="60" y="113" text-anchor="middle" font-family="Big Shoulders Display,Impact,sans-serif" font-weight="900" font-size="20" fill="${c.c2}">${p.num||9}</text>
  ${r(50,72,20,14,sk)}${r(34,25,52,52,sk)}${r(30,44,5,10,sk)}${r(85,44,5,10,sk)}${line}
  ${r(41,42,9,3,hc)}${r(70,42,9,3,hc)}${r(42,47,8,8,'#fff')}${r(70,47,8,8,'#fff')}${r(45,48,5,7,'#1b1430')}${r(73,48,5,7,'#1b1430')}
  ${r(58,56,4,6,'rgba(0,0,0,.18)')}${r(50,65,20,3,'#5a2430')}${r(48,63,3,2,'#5a2430')}${r(69,63,3,2,'#5a2430')}
  ${hasAcc(p,8)?r(48,77,24,9,'#151515'):''}${hasAcc(p,7)?r(50,86,20,2,'#E8B83A')+r(58,88,4,4,'#E8B83A'):''}${hair}${beard}${hasAcc(p,1)?r(30,33,60,6,'#B57BFF'):''}${hasAcc(p,12)?r(34,22,52,4,'#F1E9FF'):''}
  ${hasAcc(p,6)?r(28,55,4,4,'#E8B83A')+r(88,55,4,4,'#E8B83A'):''}${hasAcc(p,9)?r(38,43,44,3,'#111')+r(38,57,44,3,'#111')+r(57,43,6,17,'#111'):''}${hasAcc(p,5)?r(37,45,46,3,'#151515')+r(40,46,16,8,'#3DE0C2',' opacity=".8"')+r(64,46,16,8,'#3DE0C2',' opacity=".8"'):''}</svg>`;}
function card(p,big){const o=ovr(p),cl=club(p.club);
  return `<div class="j-card${big?' big':''}" style="--boot:${BOOTS[p.boots]||BOOTS[0]}"><div class="j-sheen" aria-hidden="true"></div><div class="j-dorsal" aria-hidden="true">${p.num}</div>
  <div class="j-ovr"><b class="num">${o}</b><span>${p.pos}</span></div><div class="j-cl">${cl?crest(cl,34):'<span class="j-free">LIBRE</span>'}</div>
  <div class="j-av">${avatar(p,big?132:96)}</div>
  <div class="j-nm"><small>${esc(p.name||'Nombre')}</small><h3>${esc(p.last||'Apellido')}</h3></div>
  <div class="j-six">${AT.map(k=>`<div><b class="num">${p.at[k]}</b><small>${(p.pos==='POR'?ANP:AN)[k].slice(0,3)}</small></div>`).join('')}</div></div>`;}
function vCreate(){const c=UI.jc,chip=(k,arr,lab)=>`<div class="j-chips" role="radiogroup" aria-label="${lab}">${arr.map(v=>`<button class="j-chip${String(c[k])===String(v)?' on':''}" role="radio" aria-checked="${String(c[k])===String(v)}" data-act="jcf" data-k="${k}" data-v="${v}">${k==='pos'||k==='pos2'?POS[v]:v}</button>`).join('')}</div>`;
  const sw=(k,arr,lab)=>`<div class="j-sw" role="radiogroup" aria-label="${lab}">${arr.map((col,i)=>`<button class="${c[k]===i?'on':''}" role="radio" aria-checked="${c[k]===i}" aria-label="${lab} ${i+1}" data-act="jcf" data-k="${k}" data-v="${i}" data-n="1" style="background:${col}"></button>`).join('')}</div>`;
  const by=2026-c.age;
  return `<section class="screen wrap j-create"><button class="back" data-act="jExit">← Modos</button>
  <div class="j-cgrid"><div class="j-form">
   <div><div class="j-eyebrow">Modo Jugador · Ficha de alta</div><h2 class="j-h">Crea tu futbolista</h2><p class="muted" style="max-width:56ch">Empiezas entre los 16 y los 18 años con una media de 60. Tu techo está escondido: lo irán marcando tus decisiones, dentro y fuera del campo.</p></div>
   <fieldset class="j-fs"><legend>Identidad</legend>
    <div class="j-row2"><label>Nombre<input value="${esc(c.name)}" maxlength="14" autocomplete="off" data-in="name"></label><label>Apellido<input value="${esc(c.last)}" maxlength="16" autocomplete="off" data-in="last"></label></div>
    <div class="j-row2">
     <label>Nacimiento<span class="j-date"><input type="number" min="1" max="28" value="${c.day}" data-in="day" aria-label="Día">/<input type="number" min="1" max="12" value="${c.month}" data-in="month" aria-label="Mes">/<b class="num">${by}</b></span></label>
     <label>Dorsal<input type="number" min="1" max="99" value="${c.num}" data-in="num"></label></div>
    <div class="j-grp"><h4>Edad de inicio</h4>${chip('age',[16,17,18],'Edad')}</div></fieldset>
   ${natPanel(c)}
   <fieldset class="j-fs"><legend>Físico y posición</legend>
    <label class="j-range">Altura <b class="num">${c.height} cm</b><input type="range" min="160" max="200" value="${c.height}" data-in="height"></label>
    <div class="j-grp"><h4>Pierna dominante</h4>${chip('foot',['Derecha','Izquierda'],'Pierna')}</div>
    <div class="j-grp"><h4>Posición principal</h4>${chip('pos',Object.keys(POS),'Posición principal')}</div>
    <div class="j-grp"><h4>Posición secundaria</h4>${chip('pos2',Object.keys(POS),'Posición secundaria')}</div></fieldset>
   <fieldset class="j-fs"><legend>Carácter</legend>
    <div class="j-grp"><h4>Personalidad</h4>${chip('pers',Object.keys(PERS),'Personalidad')}<p class="j-hint">${PERS[c.pers]}</p></div>
    <div class="j-grp"><h4>Estilo de juego</h4>${chip('style',Object.keys(STY),'Estilo')}</div>
    <div class="j-grp"><h4>Historia de origen</h4>${chip('origin',Object.keys(ORIG),'Origen')}<p class="j-hint">${ORIG[c.origin]}</p></div>
    <div class="j-grp"><h4>Tu sueño</h4><div class="j-chips" role="radiogroup" aria-label="Sueño">${Object.entries(DREAMS).map(([k,v])=>`<button class="j-chip${c.dream===k?' on':''}" role="radio" aria-checked="${c.dream===k}" data-act="jcf" data-k="dream" data-v="${k}">${v}</button>`).join('')}</div></div></fieldset>
   <button class="btn primary j-go" data-act="jFound">Firmar la ficha y buscar club →</button></div>
  <div class="j-stage"><div id="jc-prev">${card({...build(c),club:null},true)}</div>${lookPanel(c,false)}</div></div></section>`;}

/* ---------- vista: juego ---------- */
const TABS=[['despacho','Despacho'],['jugador','Mi jugador'],['entreno','Entrenamiento'],['calendario','Calendario'],['comp','Competiciones'],['agente','Agente y contratos'],['stats','Estadísticas'],['vida','Noticias y vida'],['familia','Familia y patrimonio'],['ciudad','Ciudad'],['palmares','Palmarés'],['album','Álbum de cartas']];
function meter(l,v,warn){v=clamp(v,0,100);return `<div class="j-m"><span>${l}</span><i><u style="width:${v}%" class="${warn&&v<35?'lo':''}"></u></i><b class="num">${Math.round(v)}</b></div>`;}
function hud(){const c=club(P.club);
  return `<header class="j-hud"><div class="j-hud-in">
   <button class="back" data-act="jExit">← Modos</button>
   <div class="j-brand">PALCO<span>JUGADOR</span></div>
   <div class="j-ind"><div class="j-big"><b class="num">${ovr()}</b><small>Media</small></div>
    <div><small>Forma</small><b class="num">${Math.round(P.form)}</b></div><div><small>Energía</small><b class="num ${P.fat>70?'bad':''}">${Math.round(100-P.fat)}</b></div>
    <div><small>Moral</small><b class="num">${Math.round(P.mor)}</b></div><div><small>Confianza</small><b class="num">${Math.round(P.tru)}</b></div>
    <div><small>Fama</small><b class="num">${Math.round(P.fame)}</b></div><div><small>Ahorros</small><b class="num">${eur(P.money)}</b></div></div>
   <div class="j-hclub">${c?crest(c,28):''}<span>${c?esc(c.name):'Sin club'}<small class="num">${seasonLabel(P.season)} · Semana ${P.week}</small></span></div></div></header>`;}
function rail(){return `<nav class="j-rail" aria-label="Secciones del modo Jugador">${TABS.map(([k,l],i)=>`<button class="j-rl${UI.jt===k?' on':''}" data-act="jTab" data-id="${k}" ${UI.jt===k?'aria-current="page"':''}><span class="num">${String(i+1).padStart(2,'0')}</span>${l}${k==='vida'&&P.pending.length?`<em class="j-dot" aria-label="${P.pending.length} decisiones pendientes">${P.pending.length}</em>`:''}${k==='agente'&&P.offers.length?`<em class="j-dot">${P.offers.length}</em>`:''}</button>`).join('')}<button class="j-rl j-reset" data-act="jResetAsk"><span class="num" aria-hidden="true">↺</span>Reiniciar partida</button></nav>`;}
function vGame(){if(P.retired)return P.coach&&!P.coach.done?vCoach():vLegend();
  const body=!P.club?vTrial():({despacho:vDesp,jugador:vJug,entreno:vEnt,calendario:vCal,comp:vComp,agente:vAgent,stats:vStats,vida:vVida,ciudad:vCiudad,palmares:vPalm,familia:vFam,album:vAlbum})[UI.jt]();
  return hud()+`<div class="j-shell">${P.club?rail():''}<main class="j-main" id="jmain" tabindex="-1">${body}</main></div>`;}
function vTrial(){return `<div class="j-eyebrow">Semana de pruebas</div><h2 class="j-h">Tres clubes quieren verte</h2><p class="muted" style="max-width:60ch">Cada club ofrece un camino distinto. En un grande empiezas en la cantera y tendrás que ganarte el debut; en uno pequeño juegas antes, pero la vitrina queda lejos.</p>
  <div class="j-offers">${P.offers.map((o,i)=>`<button class="j-offer" data-act="jSign" data-i="${i}">${crest(club(o.club),58)}<div><h3>${esc(cname(o.club))}</h3><p class="muted">${esc(divOf(club(o.club)))} · ${esc(LG[club(o.club).league].country)} · ${o.squad==='cantera'?'Cantera · juvenil A':'Primer equipo'} · ${esc(o.note)}</p></div><div class="j-offer-r"><b class="num">${eur(o.wage)}</b><small>por semana · ${o.years} años</small></div></button>`).join('')}</div>`;}
const OBJ={auto:'Que decida el míster',marcar:'Marcar',asistir:'Dar una asistencia',recuperar:'Recuperar balones',posicion:'Mantener la posición'};
function nextEv(){if(P.fx==null&&P.cal&&P.cal.length&&P.club)migrateCal();const e=P.cal?P.cal[P.fx==null?P.week-1:P.fx]:null;if(e)drawOpp(e);return e;}
const isMatch=e=>!!e&&!e.skip&&(e.type==='liga'||(P.squad!=='cantera'&&['copa','eur','cwc','sup'].includes(e.type)));
function evLabel(e){if(!e)return'';if(e.type==='liga')return P.squad==='cantera'?'Liga juvenil':divOf(club(P.club));const C=e.comp&&P.comp&&P.comp[e.comp];if(C)return C.name+' · '+stName(e);return e.type==='sel'?'Ventana de selecciones':'Semana sin partido';}
function vDesp(){const e=nextEv(),r=role(),c=club(P.club);
  const opp=e&&e.opp?club(e.opp):null;const youth=P.squad==='cantera'&&e&&e.type==='liga';
  let match='';
  if(P.inj>0)match=`<div class="j-next j-inj"><h3>Lesionado</h3><p>Te quedan <b class="num">${P.inj}</b> semana${P.inj>1?'s':''} de recuperación. Sigue el plan del fisio.</p><button class="btn primary" data-act="jWeek">Avanzar semana</button></div>`;
  else if(P.ban>0&&isMatch(e))match=`<div class="j-next j-inj"><h3>Sancionado</h3><p>Te quedan <b class="num">${P.ban}</b> partido${P.ban>1?'s':''} de sanción. Esta semana lo ves desde la grada.</p><button class="btn primary" data-act="jWeek">Avanzar semana</button></div>`;
  else if(!isMatch(e))match=`<div class="j-next"><div class="j-eyebrow">${e&&isNat(e)?evLabel(e):'Semana sin partido para ti'}</div><h3>${e&&isNat(e)?(P.sel.called?'Convocado con '+esc(P.nat_)+'':'Semana de entrenamiento'):'Semana de entrenamiento'}</h3><p class="muted">${e&&isNat(e)&&P.sel.called?'Juegas con la selección esta semana.':'Sin partido para ti: el trabajo de la semana cuenta igual.'}</p><div class="j-acts"><button class="btn primary" data-act="${e&&isNat(e)&&P.sel.called?'jNat':'jWeek'}">${e&&isNat(e)&&P.sel.called?'Jugar con la selección':'Avanzar semana'}</button>${e&&isNat(e)&&P.sel.called?'<button class="btn" data-act="jConv">Ver convocatoria</button>':''}</div></div>`;
  else match=`<div class="j-next"><div class="j-eyebrow">${evLabel(e)} · ${e.home?'En casa':'Fuera'}</div>
    <div class="j-vs">${crest(c,64)}<b>VS</b>${youth?`<span class="j-yt">Juvenil<br>${esc(opp.short)}</span>`:crest(opp,64)}</div><h3>${youth?'Juvenil A':esc(c.short)} – ${youth?'Juvenil ':''}${esc(opp.name)}</h3>
    <p class="j-role">Tu rol · <b>${r}</b>${P.squad==='cantera'?'':` · ${r==='Titular'||r==='Capitán'?'sales de inicio':r==='Rotación'?'puedes salir de inicio':r==='Suplente'?'saldrás desde el banquillo si hay hueco':'no entras en la convocatoria'}`}</p>
    <div class="j-grp"><h4>Objetivo personal</h4><div class="j-chips">${Object.entries(OBJ).map(([k,v])=>`<button class="j-chip${UI.jobj===k?' on':''}" data-act="jObj" data-k="${k}">${v}</button>`).join('')}</div></div>
    <div class="j-acts"><button class="btn primary" data-act="jPlay">Jugar el partido</button><button class="btn" data-act="jSim">Simular</button></div></div>`;
  const dream=DREAMS[P.dream],tbl=table().slice(0,5);
  return `<div class="j-dg"><div class="j-hero">${card(P,true)}<p class="j-cap">${r==='Capitán'?'Capitán del equipo':r}${P.loan?` · cedido por ${esc(cname(P.loan.from))}`:''}</p></div>
  <div class="j-col">${match}${lockerPanel()}${misterPanel()}
   <div class="j-panel"><h3>Estado</h3>${meter('Forma',P.form)}${meter('Energía',100-P.fat,1)}${meter('Moral',P.mor,1)}${meter('Confianza del míster',P.tru,1)}${meter('Química con el vestuario',P.chem,1)}${P.adapt<100?meter('Adaptación al país',P.adapt,1):''}</div>
   ${P.pending.length?`<div class="j-panel j-alert"><h3>Tienes ${P.pending.length} decisión${P.pending.length>1?'es':''} pendiente${P.pending.length>1?'s':''}</h3><button class="btn primary" data-act="jEvent">Decidir ahora</button></div>`:''}
   <div class="j-panel"><h3>Tu sueño</h3><p>${dream}${P.dreamDone?' · <b class="j-neon">cumplido</b>':''}</p></div>
   ${P.squad!=='cantera'?`<div class="j-panel"><h3>${esc(divOf(c))} · ${c.tier===0?'1ª':c.tier+1+'ª'} categoría <button class="btn small" data-act="jTab" data-id="comp">Tabla completa</button></h3><table class="j-t"><tbody>${tbl.map((t,i)=>`<tr class="${t.me?'me':''}"><td class="num">${i+1}</td><td>${esc(t.name)}</td><td class="num">${t.pts}</td></tr>`).join('')}</tbody></table></div>`:''}
   <div class="j-panel"><h3>Últimas noticias</h3>${P.news.slice(0,4).map(n=>`<p class="j-n"><b class="num">S${n.w}</b>${esc(n.t)}</p>`).join('')||'<p class="muted">Aún no hablan de ti.</p>'}</div>
  </div></div>`;}
function table(){const L=lgEnsure();if(!L)return[];
  return Object.entries(L.rows).filter(([id])=>CLUBS[id]).map(([id,r])=>({id,name:club(id).name,pts:id===P.club?P.pts:r.p,p:r.w+r.d+r.l,w:r.w,d:r.d,l:r.l,gf:r.gf,ga:r.ga,gd:r.gf-r.ga,f:r.f||[],me:id===P.club}))
    .sort((a,b)=>b.pts-a.pts||b.gd-a.gd||b.gf-a.gf||a.name.localeCompare(b.name));}
/* clasificación completa: tus resultados reales y, en cada jornada tuya, el resto de partidos de la categoría simulados */
function lgEnsure(done){const c=club(P.club);if(!c||P.squad==='cantera'||!LG[c.league])return null;const key=P.season+'|'+P.club+'|'+c.league+'|'+c.tier;
  if(P.lg&&P.lg.key===key)return P.lg;
  const rows={};LG[c.league].pyr[c.tier].filter(id=>CLUBS[id]).forEach(id=>rows[id]={p:0,w:0,d:0,l:0,gf:0,ga:0,f:[]});
  const L=P.lg={key,rows,n:0};const k=done==null?P.pld:done;
  if(k>0&&rows[P.club]){const m=rows[P.club],pts=P.pts,w=Math.min(k,Math.floor(pts/3)),d=Math.min(k-w,pts-3*w);Object.assign(m,{p:pts,w,d,l:Math.max(0,k-w-d),gf:w*2+d,ga:Math.max(0,k-w-d)*2+d});
    for(let i=0;i<k;i++){const o=pk(Object.keys(rows).filter(x=>x!==P.club)),r=o&&rows[o];if(r){const x=R(0,2);if(x===0){r.w++;r.p+=3;r.gf+=2;}else if(x===1){r.d++;r.p++;r.gf++;r.ga++;}else{r.l++;r.ga+=2;}}lgRound(o);}}
  return L;}
function lgAdd(id,gf,ga){const r=P.lg&&P.lg.rows[id];if(!r)return;r.gf+=gf;r.ga+=ga;const x=gf>ga?'V':gf===ga?'E':'D';if(x==='V'){r.w++;r.p+=3;}else if(x==='E'){r.d++;r.p++;}else r.l++;r.f=(r.f||[]).concat(x).slice(-5);}
function lgRound(opp){const L=P.lg;if(!L)return;const ids=Object.keys(L.rows).filter(id=>id!==P.club&&id!==opp&&CLUBS[id]).sort();if(ids.length<2){L.n++;return;}
  if(ids.length%2)ids.push(null);const n=ids.length,r=L.n%(n-1),rest=ids.slice(1),a=[ids[0],...rest.slice(rest.length-r),...rest.slice(0,rest.length-r)];
  for(let i=0;i<n/2;i++){let x=a[i],y=a[n-1-i];if(!x||!y)continue;if((L.n+i)%2){const t=x;x=y;y=t;}const[g1,g2]=simPair(x,y,false);lgAdd(x,g1,g2);lgAdd(y,g2,g1);}
  L.n++;}
function lgRec(e,gf,ga){if(!lgEnsure(P.pld-1))return;lgAdd(P.club,gf,ga);if(e.opp)lgAdd(e.opp,ga,gf);lgRound(e.opp);}
function lgZones(c,n){const ctry=LG[c.league].country;if(c.tier>0)return{up:2,rel:c.tier<LG[c.league].pyr.length-1?Math.min(3,Math.floor(n/6)):0,top:[]};
  const top=TOP5.includes(ctry)?[[4,'Champions','zcl'],[5,'Europa League','zel'],[6,'Conference','zco']]:UEFAC(ctry)?[[1,'Champions','zcl'],[2,'Europa League','zel'],[3,'Conference','zco']]:CONTL[c.league]?[[CONTL[c.league][1],CN[CONTL[c.league][0]]||'Continental','zcl']]:[];
  return{up:0,rel:LG[c.league].pyr.length>1?Math.min(3,Math.floor(n/6)):0,top};}
function fullTable(){const c=club(P.club),tb=table(),n=tb.length;if(!n)return'';const z=lgZones(c,n);
  const zone=i=>{if(z.up&&i<z.up)return['zup','Ascenso'];for(const[k,l,cl]of z.top){if(i<k)return[cl,l];}if(z.rel&&i>=n-z.rel)return['zrel','Descenso'];return['',''];};
  const leg=[...(z.up?[['zup','Ascenso']]:[]),...z.top.map(([k,l,cl])=>[cl,l]),...(z.rel?[['zrel','Descenso']]:[])];
  return `<div class="j-tblw"><table class="j-t j-full"><thead><tr><th></th><th class="num">#</th><th class="l">Club</th><th class="num">PJ</th><th class="num">G</th><th class="num">E</th><th class="num">P</th><th class="num j-gcol">GF</th><th class="num j-gcol">GC</th><th class="num">DG</th><th class="num">Pts</th><th class="l j-fcol">Forma</th></tr></thead><tbody>
  ${tb.map((t,i)=>{const[zc,zl]=zone(i);return `<tr class="${t.me?'me':''}"><td class="j-z ${zc}" title="${zl}"></td><td class="num">${i+1}</td><td class="l"><span class="j-tc">${crest(club(t.id),16)}${esc(t.name)}</span></td><td class="num">${t.p}</td><td class="num">${t.w}</td><td class="num">${t.d}</td><td class="num">${t.l}</td><td class="num j-gcol">${t.gf}</td><td class="num j-gcol">${t.ga}</td><td class="num">${t.gd>0?'+':''}${t.gd}</td><td class="num"><b>${t.pts}</b></td><td class="l j-fcol"><span class="j-fm">${t.f.map(x=>`<i class="${x}">${x}</i>`).join('')}</span></td></tr>`;}).join('')}
  </tbody></table></div>${leg.length?`<div class="j-zl">${leg.map(([c2,l])=>`<span><i class="j-z ${c2}"></i>${esc(l)}</span>`).join('')}</div>`:''}`;}
const _ab={};function avgBase(ids){const k=ids.join();return _ab[k]??(_ab[k]=avg(ids.map(clubStr)));}
function skills(){const s=[];const a=P.at;
  if(a.tir>=80&&P.st.g>=30)s.push(['Disparo lejano','Tus tiros desde fuera del área entran más.']);
  if(a.pas>=80&&P.st.a>=25)s.push(['Pase al hueco','Ves líneas de pase que nadie ve.']);
  if(a.reg>=80&&P.sk>=4)s.push(['Regate en carrera','Superas rivales sin perder velocidad.']);
  if(a.def>=80)s.push([P.pos==='POR'?'Reflejos felinos':'Muro','Pocas cosas pasan por tu zona.']);
  if(a.fis>=80)s.push(['Pulmón','Te cansas menos en cada partido.']);
  if(a.rit>=85)s.push(['Bala','Tu arrancada rompe defensas.']);
  if(P.captain)s.push(['Brazalete','Tu voz pesa en el vestuario.']);
  if(P.st.pj>=150)s.push(['Veteranía','Lees el partido antes que los demás.']);
  return s;}
function stars(n){return '<span class="j-stars" aria-label="'+n+' de 5">'+[1,2,3,4,5].map(i=>`<i class="${i<=n?'on':''}"></i>`).join('')+'</span>';}
function radar(a,sz=240){const c=100,r=70,pt=(i,v)=>{const g=-Math.PI/2+i*Math.PI/3;return[(c+Math.cos(g)*r*v/99).toFixed(1),(c+Math.sin(g)*r*v/99).toFixed(1)];};const N=P.pos==='POR'?ANP:AN;
  const ring=v=>`<polygon points="${AT.map((k,i)=>pt(i,v).join(',')).join(' ')}" fill="none" stroke="rgba(214,190,255,.16)"/>`;
  return `<svg viewBox="0 0 200 200" width="${sz}" height="${sz}" role="img" aria-label="Radar de atributos">${[33,66,99].map(ring).join('')}${AT.map((k,i)=>{const e=pt(i,99),l=pt(i,118);return `<line x1="100" y1="100" x2="${e[0]}" y2="${e[1]}" stroke="rgba(214,190,255,.12)"/><text x="${l[0]}" y="${l[1]}" text-anchor="middle" dominant-baseline="middle" fill="#C9B4EE" font-size="9" font-family="JetBrains Mono,monospace">${N[k].slice(0,3).toUpperCase()}</text>`;}).join('')}<polygon class="j-rad" points="${AT.map((k,i)=>pt(i,a[k]).join(',')).join(' ')}" fill="rgba(181,123,255,.32)" stroke="#D2A8FF" stroke-width="2" stroke-linejoin="round"/></svg>`;}
function vJug(){const N=P.pos==='POR'?ANP:AN,sk=skills();
  return `<div class="j-dg"><div class="j-hero">${card(P,true)}</div><div class="j-col">
   <div><div class="j-eyebrow">${POS[P.pos]} · secundaria ${POS[P.pos2]}</div><h2 class="j-h">${esc(P.name)} ${esc(P.last)}</h2>
   <p class="muted">${P.age} años · nacido el ${P.day}/${P.month}/${2026-P.startAge} · ${esc(P.nat)} · ${P.height} cm · pierna ${P.foot.toLowerCase()} · ${P.style} · ${P.pers} · ${P.origin}</p></div>
   <div class="j-panel j-radar">${radar(P.at,250)}<div class="j-attrs">${AT.map(k=>meter(N[k],P.at[k])).join('')}</div></div>
   <div class="j-panel j-kv"><div><small>Pierna mala</small>${stars(P.wf)}</div><div><small>Filigranas</small>${stars(P.sk)}</div><div><small>Potencial</small><b class="num j-neon">${potText()}</b></div><div><small>Reputación</small><b>${rep()}</b></div></div>
   ${lookPanel(P,true)}${traitPanel()}${posPanel()}${chemPanel()}
   <div class="j-panel"><h3>Habilidades especiales</h3>${sk.length?`<div class="j-skills">${sk.map(s=>`<div><b>${s[0]}</b><small>${s[1]}</small></div>`).join('')}</div>`:'<p class="muted">Se desbloquean con experiencia: goles, asistencias, partidos y atributos por encima de 80.</p>'}</div>
  </div></div>`;}
const FOCUS={rit:['Velocidad','Ritmo'],fis:['Fuerza y resistencia','Físico'],tir:['Finalización','Tiro'],pas:['Técnica y pase','Pase'],reg:['Regate','Regate'],def:['Táctica y defensa','Defensa'],wf:['Pierna mala','Estrellas de pierna mala'],sk:['Filigranas','Estrellas de filigranas']};
const MINI={pases:['Pases','pas'],libres:['Tiros libres','tir'],penaltis:['Penaltis','tir'],regates:['Regates','reg']};
function vEnt(){const c=P.squad==='cantera';
  return `<div class="j-eyebrow">Plan de la semana</div><h2 class="j-h">Entrenamiento</h2><p class="muted" style="max-width:62ch">El foco y la intensidad se aplican cada semana. Entrenar fuerte acelera la mejora, pero la fatiga acumulada baja tu rendimiento y dispara el riesgo de lesión.</p>
  ${trainPanel()}${routinePanel()}<div class="j-two"><div class="j-panel"><h3>Foco</h3><div class="j-foc">${Object.entries(FOCUS).map(([k,[l,s]])=>`<button class="j-fo${P.focus===k?' on':''}" data-act="jFocus" data-k="${k}"><span>${l}</span><b class="num">${k==='wf'?P.wf+'★':k==='sk'?P.sk+'★':P.at[k]}</b><i><u style="width:${k==='wf'||k==='sk'?(P[k]/5*100):P.at[k]}%"></u></i></button>`).join('')}</div></div>
  <div class="j-col"><div class="j-panel"><h3>Intensidad</h3><div class="j-chips">${['suave','normal','intensa'].map(v=>`<button class="j-chip${P.intensity===v?' on':''}" data-act="jInt" data-k="${v}">${v[0].toUpperCase()+v.slice(1)}</button>`).join('')}</div>
   ${c?`<label class="j-check"><input type="checkbox" data-in="firstTrain" ${P.firstTrain?'checked':''}> Entrenar con el primer equipo (más confianza, más fatiga)</label>`:''}
   <div style="margin-top:14px">${meter('Fatiga acumulada',P.fat)}</div></div>
   <div class="j-panel"><h3>Minijuego de la semana</h3><p class="muted">Un intento por semana. Para el marcador dentro de la zona: cuanto más centrado, más experiencia.</p><div class="j-chips">${Object.entries(MINI).map(([k,[l]])=>`<button class="j-chip" data-act="jMini" data-k="${k}" ${P.miniDone?'disabled':''}>${l}</button>`).join('')}</div>${P.miniDone?'<p class="j-hint">Ya has hecho el minijuego esta semana.</p>':''}</div></div></div>`;}
function vCal(){const i0=P.fx==null?P.week-1:P.fx,rows=P.cal.slice(i0,i0+16);
  return `<div class="j-eyebrow">${seasonLabel(P.season)}</div><h2 class="j-h">Calendario</h2><div class="j-cal">${rows.map((e,i)=>{if(!e.ko||i===0)drawOpp(e);const o=e.opp&&club(e.opp);
   return `<div class="j-cr${i?'':' now'}"><b class="num">S${e.w}</b><span class="j-tag t-${e.type}">${calTag(e)}</span>${o&&!e.skip?crest(o,26):e.oppN&&!e.skip?flagI(e.oppN):'<i></i>'}<span>${e.skip?(e.bye?'Exento: pasas directo a octavos':'Eliminado'):o?(P.squad==='cantera'&&e.type==='liga'?'Juvenil '+esc(o.short):esc(o.name)):e.oppN?esc(P.nat)+' – '+esc(e.oppN):'Rival por sortear'}</span><em>${e.type==='liga'?(e.home?'Local':'Visitante'):esc(stName(e))}${e.neutral?' · campo neutral':''}</em></div>`;}).join('')}</div>`;}
function vAgent(){const k=P.contract;
  return `<div class="j-eyebrow">Tu agente: ${esc(P.agent||'Sin agente')}</div><h2 class="j-h">Agente y contratos</h2>
  <div class="j-two"><div class="j-panel"><h3>Contrato actual</h3>${k?`<div class="j-kv"><div><small>Club</small><b>${esc(cname(k.club))}</b></div><div><small>Años restantes</small><b class="num">${k.years}</b></div><div><small>Salario</small><b class="num">${eur(k.wage)}/sem</b></div><div><small>Prima por gol/asist.</small><b class="num">${eur(k.bonus)}</b></div><div><small>Cláusula</small><b class="num">${eur(k.clause)}</b></div><div><small>Promesa</small><b>${k.promise?{minutos:'Minutos',posicion:'Tu posición',titular:'Titularidad'}[k.promise]:'Ninguna'}</b></div></div>`:'<p class="muted">Sin contrato.</p>'}
   <div class="j-acts" style="margin-top:16px">${!P.agent?'<button class="btn" data-act="jAgent">Contratar un agente (10 % del salario)</button>':''}${P.squad!=='cantera'&&!P.loan?'<button class="btn" data-act="jLeave">Pedir salir del club</button>':''}<button class="btn" data-act="jTalk">Reunión con el entrenador</button></div></div>
  <div class="j-panel"><h3>Ofertas sobre la mesa</h3>${P.offers.length?P.offers.map((o,i)=>`<div class="j-of">${crest(club(o.club),44)}<div><b>${esc(cname(o.club))}</b><small>${o.loan?'Cesión de una temporada':o.renew?'Renovación':'Traspaso'} · ${esc(divOf(club(o.club)))} (${esc(LG[club(o.club).league].country)}) · rol ${o.role}${eurQualifiedId(o.club)?' · juega Champions':''}</small><small class="num">${eur(o.wage)}/sem · ${o.years} año${o.years>1?'s':''}${o.promise?' · promete '+{minutos:'minutos',posicion:'tu posición',titular:'titularidad'}[o.promise]:''}</small></div><div class="j-ofb"><button class="btn primary small" data-act="jAccept" data-i="${i}">Aceptar</button>${!o.neg?`<button class="btn small" data-act="jNeg" data-i="${i}">${P.agent?'Que negocie mi agente':'Negociar'}</button>`:''}<button class="btn small" data-act="jReject" data-i="${i}">Rechazar</button></div></div>`).join(''):'<p class="muted">No hay ofertas ahora. Llegan en las ventanas (semana 19 y fin de temporada) según tu nivel y tu fama.</p>'}</div></div>
  <div class="j-panel"><h3>Historial de traspasos</h3>${P.moves.length?`<table class="j-t"><thead><tr><th>Temporada</th><th>De</th><th>A</th><th>Tipo</th><th>Salario</th></tr></thead><tbody>${P.moves.map(m=>`<tr><td class="num">${m.s}</td><td>${esc(m.from)}</td><td>${esc(m.to)}</td><td>${m.t}</td><td class="num">${eur(m.wage)}/sem</td></tr>`).join('')}</tbody></table>`:'<p class="muted">Aún no has cambiado de club.</p>'}</div>`;}
const eurQualifiedId=id=>{const k=club(id);return k.tier===0&&k.base>=78;};
function vStats(){const s=P.st,av=s.rt.length?f1(avg(s.rt)):'—',best=P.hist.slice().sort((a,b)=>(b.g+b.a+b.n*3)-(a.g+a.a+a.n*3))[0];
  return `<div class="j-eyebrow">Carrera</div><h2 class="j-h">Estadísticas</h2>
  <div class="j-bigs"><div><b class="num">${s.pj}</b>partidos</div><div><b class="num">${s.g}</b>goles</div><div><b class="num">${s.a}</b>asistencias</div><div><b class="num">${av}</b>nota media</div><div><b class="num">${s.tit}</b>de titular</div><div><b class="num">${P.sel.caps}</b>internacional</div></div>
  <div class="j-two"><div class="j-panel"><h3>Últimas notas</h3><svg class="j-bars" viewBox="0 0 300 96" role="img" aria-label="Notas de los últimos partidos">${s.rt.slice(-12).map((v,i)=>`<rect x="${i*25+3}" y="${92-v*8.4}" width="19" height="${v*8.4}" rx="2" fill="${v>=7.5?'#D2A8FF':v>=6.5?'#9A63E8':'#4A2F86'}"/><text x="${i*25+12.5}" y="${86-v*8.4}" text-anchor="middle" font-size="8" fill="#E5D6FF" font-family="JetBrains Mono,monospace">${f1(v)}</text>`).join('')||'<text x="8" y="44" fill="#9C88C4" font-size="11">Sin partidos todavía</text>'}</svg></div>
  <div class="j-panel"><h3>Temporada actual</h3><div class="j-kv"><div><small>Partidos</small><b class="num">${P.sea.pj}</b></div><div><small>Goles</small><b class="num">${P.sea.g}</b></div><div><small>Asistencias</small><b class="num">${P.sea.a}</b></div><div><small>Nota</small><b class="num">${P.sea.rt.length?f1(avg(P.sea.rt)):'—'}</b></div><div><small>Minutos</small><b class="num">${P.sea.min}</b></div><div><small>Tarjetas</small><b class="num">${P.sea.yel||0} A · ${P.sea.red||0} R</b></div>${P.pos==='POR'?`<div><small>Porterías a cero</small><b class="num">${P.sea.cs}</b></div>`:''}</div></div></div>
  <div class="j-panel"><h3>Temporada a temporada</h3>${P.hist.length?`<table class="j-t"><thead><tr><th>Temporada</th><th>Club</th><th>Media</th><th>PJ</th><th>Tit.</th><th>Sup.</th><th>G</th><th>A</th><th>Nota</th></tr></thead><tbody>${P.hist.map(h=>`<tr class="${best===h?'me':''}"><td class="num">${h.s}</td><td>${esc(h.c)}</td><td class="num">${h.o}</td><td class="num">${h.pj}</td><td class="num">${h.tit}</td><td class="num">${h.sup}</td><td class="num">${h.g}</td><td class="num">${h.a}</td><td class="num">${h.n}</td></tr>`).join('')}</tbody></table>${best?`<p class="j-hint">Mejor temporada: ${best.s} en ${esc(best.c)}.</p>`:''}`:'<p class="muted">La primera temporada todavía no ha terminado.</p>'}</div>`;}
const SHOP=[['piso','Piso en la ciudad',60000,4],['casa','Casa con jardín',450000,6],['mansion','Mansión',2500000,8],['yate','Yate',6000000,5]];
const FREE={descanso:'Descansar',familia:'Familia y amigos',idioma:'Clases de idioma',benefico:'Evento benéfico',fiesta:'Salir de fiesta'};
function vVida(){return `<div class="j-eyebrow">Fuera del campo</div><h2 class="j-h">Noticias y vida</h2>
  ${P.pending.length?`<div class="j-panel j-alert"><h3>${P.pending.length} decisión${P.pending.length>1?'es':''} pendiente${P.pending.length>1?'s':''}</h3><button class="btn primary" data-act="jEvent">Decidir ahora</button></div>`:''}
  <div class="j-two"><div class="j-panel"><h3>Prensa y redes</h3><div class="j-kv"><div><small>Seguidores</small><b class="num">${P.followers.toLocaleString('es-ES')}</b></div><div><small>Fama</small><b class="num">${Math.round(P.fame)}</b></div><div><small>Reputación</small><b>${rep()}</b></div></div>
   <div class="j-feed">${P.news.slice(0,12).map(n=>`<p class="j-n ${n.k}"><b class="num">${seasonLabel(n.s).slice(2)} · S${n.w}</b>${esc(n.t)}</p>`).join('')||'<p class="muted">Sin noticias.</p>'}</div>${postsBlock()}</div>
  <div class="j-col"><div class="j-panel"><h3>Tiempo libre</h3><div class="j-chips">${Object.entries(FREE).map(([k,v])=>`<button class="j-chip${P.free===k?' on':''}" data-act="jFree" data-k="${k}">${v}</button>`).join('')}</div><p class="j-hint">${{descanso:'Recuperas más energía.',familia:'Sube la moral.',idioma:'Te adaptas antes si juegas fuera de tu país.',benefico:'Sube tu fama y tu imagen.',fiesta:'Subidón de moral… y de fatiga. El míster se entera.'}[P.free]}</p></div>
   <div class="j-panel"><h3>Patrocinadores</h3>${P.sponsors.length?P.sponsors.map(s=>`<p class="j-n"><b>${esc(s.brand)}</b>${eur(s.pay)}/temporada</p>`).join(''):'<p class="muted">Las marcas llegan con la fama.</p>'}</div>
   <div class="j-panel"><h3>Ahorros: <span class="num">${eur(P.money)}</span></h3><div class="j-shop">${SHOP.map(([k,l,price])=>`<button class="j-buy" data-act="jBuy" data-k="${k}" ${P.assets.includes(k)||P.money<price?'disabled':''}><span>${l}</span><b class="num">${P.assets.includes(k)?'Tuyo':eur(price)}</b></button>`).join('')}</div></div></div></div>`;}
const TROPHY='<svg viewBox="0 0 40 48" width="40" height="48" aria-hidden="true"><path d="M10 4h20v10a10 10 0 0 1-20 0z" fill="currentColor"/><path d="M10 7H4a6 6 0 0 0 6 8M30 7h6a6 6 0 0 1-6 8" stroke="currentColor" stroke-width="2.5" fill="none"/><rect x="17" y="24" width="6" height="10" fill="currentColor"/><rect x="11" y="34" width="18" height="6" rx="1" fill="currentColor"/></svg>';
function vPalm(){const T=P.titles,A=P.awards;
  return `<div class="j-eyebrow">Legado</div><h2 class="j-h">Palmarés</h2>
  <div class="j-bigs"><div><b class="num">${T.length}</b>títulos</div><div><b class="num">${A.length}</b>premios</div><div><b class="num">${P.peak||ovr()}</b>media máxima</div><div><b class="num">${P.sel.g}</b>goles con ${esc(P.nat_||P.nat)}</div></div>
  <div class="j-panel"><h3>Vitrina</h3>${T.length||A.length?`<div class="j-gal">${[...T.map(t=>({n:t.n,s:t.s,c:t.c,k:'t'})),...A.map(a=>({n:a.n,s:a.s,c:'',k:'a'}))].map(x=>`<div class="j-tro ${x.k}">${TROPHY}<b>${esc(x.n)}</b><small>${x.s}${x.c?' · '+esc(x.c):''}</small></div>`).join('')}</div>`:'<p class="muted">La vitrina espera su primer trofeo.</p>'}</div>
  ${worldPanel()}${trophyPanel()}${achPanel()}<div class="j-two"><div class="j-panel"><h3>Récords</h3>${records().map(r=>`<p class="j-n"><b>${r[0]}</b>${r[1]}</p>`).join('')}</div>
  <div class="j-panel"><h3>Rivales de tu generación</h3>${P.rivals.map(r=>`<div class="j-riv">${crest(club(r.club),30)}<div><b>${esc(r.name)}</b><small>${esc(r.nat)} · ${r.pos} · ${esc(cname(r.club))}</small></div><b class="num">${Math.round(r.ovr)}</b></div>`).join('')}</div></div>
  <div class="j-acts">${P.age>=33?'<button class="btn" data-act="jRetire">Anunciar la retirada</button>':''}</div>`;}
function records(){const r=[];const bySeason=P.hist.slice().sort((a,b)=>b.g-a.g)[0];
  r.push(['Máximo goleador de una temporada',bySeason?`${bySeason.g} goles (${bySeason.s})`:'—']);
  const clubs={};P.hist.forEach(h=>{clubs[h.c]=(clubs[h.c]||0)+h.g;});const top=Object.entries(clubs).sort((a,b)=>b[1]-a[1])[0];
  r.push(['Club donde más has marcado',top?`${esc(top[0])} · ${top[1]} goles`:'—']);
  r.push(['Partidos internacionales',`${P.sel.caps} (${P.sel.g} goles)`]);
  if(P.st.g>=200)r.push(['Leyenda goleadora','Más de 200 goles en tu carrera']);
  return r;}
function vLegend(){const H=hall();
  return `<section class="screen wrap j-legend"><div class="j-eyebrow">Modo leyenda</div><h2 class="j-h">${esc(P.name)} ${esc(P.last)}</h2>
  <p class="muted" style="max-width:60ch">Colgaste las botas a los ${P.retAge||P.age} años. Tu media máxima fue <b class="j-neon num">${P.peak}</b>.</p>
  <div class="j-bigs"><div><b class="num">${P.st.pj}</b>partidos</div><div><b class="num">${P.st.g}</b>goles</div><div><b class="num">${P.st.a}</b>asistencias</div><div><b class="num">${P.titles.length}</b>títulos</div><div><b class="num">${P.awards.length}</b>premios</div></div>
  <div class="j-two"><div class="j-panel"><h3>Lo que dejaste atrás</h3>${(P.after||[]).map(a=>`<p class="j-n">${esc(a)}</p>`).join('')}</div>
  <div class="j-panel"><h3>Salón de leyendas</h3>${H.map(h=>`<p class="j-n"><b class="num">${h.peak}</b>${esc(h.name)} · ${h.g} goles · ${h.t} títulos</p>`).join('')}</div></div>
  ${legendExtra()}<div class="j-acts"><button class="btn" data-act="jDoc" data-i="0">Ver el documental de tu carrera</button>${!P.coach?'<button class="btn primary" data-act="jCoachStart">Empezar como entrenador</button>':''}<button class="btn${P.coach?' primary':''}" data-act="jNew">Empezar otra carrera</button><button class="btn" data-act="jExit">Volver a los modos</button></div></section>`;}

/* ---------- partido ---------- */
function minutesFor(r,e){if(r==='Lesionado'||r==='Descartado'||r==='Sancionado')return 0;
  if(P.squad==='cantera')return e.type==='liga'?(ovr()>=62?R(75,90):R(30,90)):0;
  if(r==='Titular'||r==='Capitán')return 90;if(r==='Rotación')return ch(.55)?90:R(15,35);return ch(.4)?R(5,25):0;}
function chanceP(k,bonus=0){const a=P.at[k],opp=UI.jm?UI.jm.oppS:65;return clamp(.3+(a-opp)/110+(P.form-50)/320-P.fat/650+bonus+xBonus(k)-(100-P.adapt)/400,.06,.72);}
function makeMoments(n){const out=[],att=P.pos!=='DEF'&&P.pos!=='POR',ms=[];for(let i=0;i<n;i++)ms.push(R(4,88));ms.sort((a,b)=>a-b);
  ms.forEach(m=>{const def=P.pos==='POR'||P.pos==='DEF'||(P.pos==='MED'&&ch(.4))||(!att&&ch(.7));
    const fm=fpMoment(m,att&&!def);if(fm){out.push(fm);return;}
    if(P.pos==='POR')out.push({m,kind:'gk',text:pk(['Mano a mano: el delantero rival se planta solo.','Disparo raso y potente desde la frontal.','Centro bombeado al segundo palo.']),opts:[['Estirada','def',0],['Salir a por ella','rit',-.04],['Aguantar de pie','def',.05]]});
    else if(def)out.push({m,kind:'def',text:pk(['El rival conduce hacia tu zona.','Contra rápida por tu banda.','Balón dividido en el centro del campo.']),opts:[['Entrada','def',.04],['Temporizar','def',.08],['Anticipar','rit',0]]});
    else out.push({m,kind:'att',text:pk(['Recibes de espaldas en la frontal.','Te quedas solo en la banda con espacio.','Rechace en el área: el balón cae a tus pies.','Contraataque: vas lanzado hacia la portería.']),opts:[['Chutar','tir',0],['Pasar','pas',.12],['Regatear','reg',.02]]});});
  return out;}
function startMatch(interactive){const e=nextEv(),r=role(),opp=club(e.opp),youth=P.squad==='cantera';
  const min=minutesFor(r,e),oppS=youth?clamp(opp.base-14,40,70):opp.base;
  const n=min?clamp(Math.round(min/90*({POR:3,DEF:2,MED:2,EXT:3,DEL:3}[P.pos])+R(0,1)),1,4):0;
  UI.jm={e,r,min,oppS,youth,interactive,mom:makeMoments(n),i:0,res:{g:0,a:0,ok:0,ko:0,saves:0,log:[]}};
  if(!interactive||!n){UI.jm.mom.forEach(mo=>{if(UI.jm.res.redMin)return;const pref={DEL:{Chutar:1,Pasar:.55,Regatear:.75},EXT:{Chutar:.7,Pasar:.95,Regatear:.95},MED:{Chutar:.5,Pasar:1.15,Regatear:.7},DEF:{},POR:{}}[P.pos];
    const best=mo.opts.map((o,j)=>[j,chanceP(o[1],o[2])*(pref[o[0]]??1)*(.85+Math.random()*.3)]).sort((a,b)=>b[1]-a[1])[0][0];resolveMoment(mo,best);});finishMatch();}
  else showMoment();}
function resolveMoment(mo,j){const R0=UI.jm.res,g0=R0.g;if(mo.kind==='fp')return fpResolve(mo,R0);const o=mo.opts[j],p=chanceP(o[1],o[2]),ok=Math.random()<p;
  let t='';
  if(mo.kind==='att'){if(o[0]==='Chutar'){if(ok&&ch(.5)){R0.g++;t=`¡GOL! ${P.last} define con la ${P.foot==='Derecha'?'derecha':'izquierda'}.`;}else if(ok){R0.ok++;t='Disparo a puerta: el portero la saca con una gran parada.';}else{R0.ko+=.5;t='El disparo se marcha fuera por poco.';}}
    else if(o[0]==='Pasar'){if(ok&&ch(.5)){R0.a++;const mt=pickMate();mt.c=clamp(mt.c+6,0,100);R0.mate=mt.n;t=`Pase de gol: ${mt.n} solo tiene que empujarla.`;}else if(ok){R0.ok++;t='Buen pase, la jugada sigue viva.';}else{R0.ko++;t='Pase interceptado.';}}
    else{if(ok){R0.ok++;if(Math.random()<chanceP('tir',.06)*.55){R0.g++;t='Regate, recorte y gol. Golazo.';}else t='Te quitas a dos, pero el portero tapa el remate.';}else{R0.ko++;t='Te roban el balón en la conducción.';}}}
  else if(mo.kind==='def'){if(ok){R0.ok++;t=o[0]==='Entrada'?'Entrada limpia: balón recuperado.':o[0]==='Anticipar'?'Lees el pase y lo cortas.':'Temporizas y el rival se queda sin opciones.';}else{R0.ko++;if(o[0]==='Entrada'&&ch(.35)){if(ch(.04+Math.min(8,P.rep.polemico)/200)){R0.redMin=mo.m;t='Entrada a destiempo: ¡tarjeta roja directa!';}else{R0.yel=(R0.yel||0)+1;if(R0.yel>=2){R0.redMin=mo.m;t='Llegas tarde otra vez: segunda amarilla y a la calle.';}else t='Llegas tarde: tarjeta amarilla.';}}else t='El rival se te escapa.';}}
  else{if(ok){R0.saves++;R0.ok++;t='¡Paradón!';}else{R0.ko++;t='No llegas: gol del rival.';R0.conc=(R0.conc||0)+1;}}
  if(R0.g>g0)t+=` Lo celebra: ${celebName()}.`;
  R0.log.push(`${mo.m}' ${t}`);return{ok,t};}
function showMoment(){const M=UI.jm,mo=M.mom[M.i];
  if(mo.kind==='fp'){modal(`<div class="hd j-mhd"><h3>${evLabel(M.e)} · minuto ${mo.m}'</h3></div><div class="bd"><p class="j-sit">${mo.text}</p><div id="fpbox"></div></div>`);startFp(document.getElementById('fpbox'),mo.fk,out=>{mo.out=out;ACT.jMo({j:0});});return;}
  modal(`<div class="hd j-mhd"><h3>${evLabel(M.e)} · minuto ${mo.m}'</h3></div><div class="bd"><p class="j-sit">${mo.text}</p>
   <div class="j-opts">${mo.opts.map((o,j)=>`<button class="j-op" data-act="jMo" data-j="${j}"><b>${o[0]}</b><small>${(P.pos==='POR'?ANP:AN)[o[1]]} · ${Math.round(chanceP(o[1],o[2])*100)} %</small></button>`).join('')}</div>
   <p class="j-hint">Momento ${M.i+1} de ${M.mom.length}. Controlas solo a tu futbolista.</p>${M.last?`<p class="j-last">${M.last}</p>`:''}</div>`);}
function finishMatch(){const M=UI.jm,e=M.e,c=club(P.club),opp=club(e.opp),R0=M.res,youth=M.youth;
  let min=M.min;if(R0.redMin)min=Math.max(1,Math.min(M.min,R0.redMin-(90-M.min)));const own=(youth?clamp(c.base-14,40,72):c.base)+(min?(ovr()-c.base)*.07*min/90:0)+(e.home?2:-1),oS=M.oppS;
  let gf=Math.max(poisson(xg(own-oS)),R0.g+R0.a),ga=poisson(xg(oS-own));if(P.pos==='POR')ga=Math.max(ga-R0.saves+(R0.conc||0),R0.conc||0);if(M.pre){gf=M.pre.gf;ga=M.pre.ga;}
  let rt=0,obj=UI.jobj,met=false,sub=0;
  if(min){rt=6+R0.g*1.1+R0.a*.75+R0.ok*.3-R0.ko*.28+(gf>ga?.3:gf<ga?-.3:0)+(P.form-50)/100+(P.chem-50)/150-(100-P.adapt)/170+(Math.random()-.5)*.8;
    if(P.pos==='POR')rt+=ga===0?.8:-ga*.3;if(P.pos==='DEF'&&ga===0)rt+=.4;
    if(obj==='auto')obj=P.pos==='DEL'?'marcar':P.pos==='MED'||P.pos==='EXT'?'asistir':'recuperar';
    met=obj==='marcar'?R0.g>0:obj==='asistir'?R0.a>0:obj==='recuperar'?R0.ok>=2:R0.ko===0&&min>=60;rt+=met?.5:-.2;if(R0.redMin)rt-=1.6;rt=clamp(rt,1,10);
    if(min===90&&(rt<5.2||P.fat>80)&&!youth&&ch(.7)){sub=R(58,72);min=sub;}}
  const knock=!!e.ko&&e.leg!==1;let et='',pens=null;const tie=()=>gf+(e.aggF||0)===ga+(e.aggA||0);
  if(knock&&tie()){et=' (prórroga)';if(ch(.5)){if(ch(.5))gf++;else ga++;}if(tie())pens={me:min>0};}
  const stop=R(1,6);
  UI.jm.final={gf,ga,rt:+f1(rt),min,met,obj,sub,stop,et,pens,knock};
  if(pens){showPens();return;}
  applyMatch();}
function showPens(){const F=UI.jm.final;
  if(!F.pens.me){F.won=ch(.5);applyMatch();return;}
  modal(`<div class="hd j-mhd"><h3>Tanda de penaltis</h3></div><div class="bd"><p class="j-sit">Te toca tirar el quinto. Todo depende de ti.</p><div id="fpbox"></div></div>`);
  startFp(document.getElementById('fpbox'),'pen',out=>{const scored=out==='goal';if(scored)flag('pen');F.won=ch(scored?.62:.32);UI.jm.res.log.push(scored?'Tu penalti en la tanda: ¡dentro!':'Tu penalti en la tanda: fallado.');applyMatch();});}
function applyMatch(){const M=UI.jm,F=M.final,e=M.e,R0=M.res,c=club(P.club),opp=club(e.opp);
  const won=F.pens?F.won:F.gf>F.ga,draw=!F.pens&&F.gf===F.ga,res=won?'V':draw?'E':'D';
  if(F.min){P.st.pj++;P.sea.pj++;P.sea.min+=F.min;P.st.rt.push(F.rt);P.sea.rt.push(F.rt);P.st.g+=R0.g;P.sea.g+=R0.g;P.st.a+=R0.a;P.sea.a+=R0.a;
    if(M.min===90){P.st.tit++;P.sea.tit++;}else{P.st.sup++;P.sea.sup++;}if(F.ga===0&&(P.pos==='POR'||P.pos==='DEF')){P.st.cs++;P.sea.cs++;}
    P.money+=(R0.g+R0.a)*(P.contract?P.contract.bonus:0);}
  if(e.type==='liga'&&!M.youth){P.pld++;P.pts+=won?3:draw?1:0;lgRec(e,F.gf,F.ga);}
  compAfter(e,F.gf,F.ga,F.pens?F.won:null,F.min?F.rt:0);e.done=true;if(!M.youth)e.tsim=1;
  cardsAfter(R0);misterMatch(F,R0);if(R0.g>=3)flag('hat');if(F.min&&F.rt>=9.5)flag('perfect');
  if(F.min){chemAfterMatch();if(e.type!=='liga'&&!M.youth)(P.sea.big=P.sea.big||[]).push(F.rt);if(R0.g>0)celebFx(e);}
  // efectos personales
  const k=F.min?F.rt-6.2:0;
  P.form=clamp(P.form+(F.min?k*5*(hasT('irregular')?1.6:1):-2),10,99);P.mor=clamp(P.mor+(F.min?(F.rt>=7?4:F.rt<5.5?-4:1):-3)+(won?2:draw?0:-1),5,100);
  P.tru=clamp(P.tru+(F.min?(F.rt>=7?3:F.rt<5.5?-3:1)+(F.met?2:0):-1),0,100);P.fame=clamp(P.fame+(F.min?Math.max(0,F.rt-6.5)*(M.youth?.3:1)+R0.g*.6:0)+(e.type==='eur'?.5:0),0,100);
  P.fat=clamp(P.fat+F.min/90*14,0,100);
  xp(P.focus,F.min?(F.min/90*1.2+(F.rt-6)*.8):0);
  if(M.youth&&F.min&&F.rt>=7.5)P.tru=clamp(P.tru+2,0,100);
  const lines=[...R0.log];if(F.sub)lines.push(`${F.sub}' El entrenador te sustituye${P.fat>80?' por cansancio':''}.`);lines.push(`90+${F.stop}' Final${F.et}.`);
  const verdict=!F.min?'No has jugado':F.rt>=8.5?'Actuación de leyenda':F.rt>=7.5?'Partidazo':F.rt>=6.5?'Buen partido':F.rt>=5.5?'Cumples sin brillar':'Noche para olvidar';
  const comment=!F.min?'Te quedas en el banquillo. El míster espera más de ti en los entrenamientos.':F.rt>=8?`La prensa habla de ti: ${P.last} fue el mejor sobre el césped.`:F.rt<5.5?'Partido gris. Toca levantarse el lunes.':'Partido correcto. Sigues sumando.';
  if(F.min&&F.rt>=8.5)news(`Exhibición de ${P.last} ante ${opp.name}: nota ${f1(F.rt)}.`,'hot');if(R0.g>=3)news(`¡Hat-trick de ${P.last}!`,'hot');
  const passes=F.min?Math.round(F.min/90*(18+P.at.pas/3)):0,acc=F.min?clamp(Math.round(60+P.at.pas/3+R(-6,6)),40,98):0;
  modal(`<div class="hd j-mhd"><h3>${({V:'Victoria',E:'Empate',D:'Derrota'})[res]} · ${M.youth?'Juvenil':esc(c.short)} ${F.gf}-${F.ga} ${esc(opp.short)}${F.pens?` · ${F.won?'gana':'pierde'} en penaltis`:''}</h3></div><div class="bd">
   <div class="j-note"><b class="num" id="j-rt">${F.min?f1(F.rt):'–'}</b><span>${verdict}${F.min?`<small>${F.met?'Objetivo cumplido':'Objetivo no cumplido'}: ${OBJ[F.obj]}</small>`:''}</span></div>
   <div class="j-kv"><div><small>Minutos</small><b class="num">${F.min}</b></div><div><small>Goles</small><b class="num">${R0.g}</b></div><div><small>Asistencias</small><b class="num">${R0.a}</b></div><div><small>Pases</small><b class="num">${passes} · ${acc} %</b></div><div><small>Duelos ganados</small><b class="num">${R0.ok}</b></div><div><small>Errores</small><b class="num">${Math.round(R0.ko)}</b></div></div>
   <div class="j-log">${lines.map(l=>`<p>${esc(l)}</p>`).join('')}</div><p class="j-hint">${comment}</p>${socialBlock(F,won)}
   <div style="margin-top:14px"><button class="btn primary" data-act="jAfter" data-focus>Seguir</button></div></div>`);
  const el=document.getElementById('j-rt');if(el&&F.min&&!reduced()){const t0=performance.now(),go=t=>{const q=Math.min(1,(t-t0)/900);el.textContent=f1(F.rt*(1-Math.pow(1-q,4)));if(q<1)requestAnimationFrame(go);};requestAnimationFrame(go);}
  UI.jm.done=true;}

/* ---------- semana, temporada ---------- */
function xp(k,amt){if(amt<=0)return;const ageF=P.age<20?1.35:P.age<24?1.1:P.age<28?.8:.45;P.xp[k]=(P.xp[k]||0)+amt*ageF;
  const need=k==='wf'||k==='sk'?40:10;while(P.xp[k]>=need){P.xp[k]-=need;if(k==='wf'||k==='sk'){if(P[k]<5){P[k]++;news(`${P.last} mejora ${k==='wf'?'su pierna mala':'sus filigranas'}: ${P[k]} estrellas.`);}}else grow(k);}}
function week(){
  if(weekFx())return;
  const mult={suave:.6,normal:1,intensa:1.5}[P.intensity];
  {const e0=nextEv();if(P.banNew)P.banNew=false;else if(P.ban>0&&isMatch(e0))P.ban--;}if(P.intensity==='intensa')P.sea.hard=(P.sea.hard||0)+1;if(P.free==='fiesta')P.sea.party=(P.sea.party||0)+1;petWeek();routineWeek();misterWeek();
  if(P.inj>0){P.inj--;P.fat=clamp(P.fat-15,0,100);if(!P.inj)news(`${P.last} recibe el alta médica.`);}
  else{const fk=P.focus;xp(fk,2.2*mult);if(fk!=='wf'&&fk!=='sk'&&ch(.3))xp(pk(AT),1);
    P.fat=clamp(P.fat+{suave:3,normal:8,intensa:15}[P.intensity]+(P.firstTrain?5:0)-(P.free==='descanso'?17:12)-(P.at.fis>=80?3:0)-(hasT('pulmon')?3:0),0,100);
    if(P.firstTrain&&P.squad==='cantera')P.tru=clamp(P.tru+2,0,100);
    if(P.intensity==='normal')P.lp+=.03;
    const risk=(P.fat>72?(P.fat-70)/120*(P.pers==='Profesional'?.6:1):0)*(hasT('cristal')?1.6:1)+(hasT('cristal')?.008:0);const riskF=1-.15*Math.min(P._fisio||0,3);
    if(ch(risk*riskF)){P.sea.inj=(P.sea.inj||0)+1;P.inj=R(1,6)+(P.fat>90?3:0);P.fat=40;P.mor-=8;if(P.intensity==='intensa')P.lp-=2;news(`Una lesión apartará a ${P.last} ${P.inj} semanas de los terrenos de juego.`,'bad');
      event('lesion');}}
  // tiempo libre
  ({familia:()=>{P.mor=clamp(P.mor+3+(fam().partner||fam().kids.length?2:0),0,100);P.lp+=.04;},idioma:()=>{P.adapt=clamp(P.adapt+10,0,100);P.lp+=.03;},benefico:()=>{P.fame=clamp(P.fame+.8,0,100);P.rep.humilde+=.3;P.lp+=.05;},fiesta:()=>{P.mor=clamp(P.mor+5,0,100);P.fat=clamp(P.fat+8,0,100);P.lp-=1;P.rep.polemico+=.4;if(ch(.25)){P.tru=clamp(P.tru-6,0,100);news(`Polémica: ${P.last} fotografiado de fiesta a dos días del partido.`,'bad');}},descanso:()=>{P.lp+=.02;}})[P.free]();
  P.adapt=clamp(P.adapt+6,0,100);
  {const f=posF();f[P.pos]=Math.min(100,f[P.pos]+1.5);if(P.learn&&P.learn!==P.pos){f[P.learn]=Math.min(100,(f[P.learn]||20)+3);if(f[P.learn]>=100){news(`${P.last} ya domina la posición de ${POS[P.learn].toLowerCase()}.`);P.learn=null;}}}
  if(fam().partner)P.mor=clamp(P.mor+.15,0,100);
  if(hasHome()){P.mor=clamp(P.mor+.3+homeLevel(P.home)*.04,0,100);P.fat=clamp(P.fat-homeLevel(P.home)*.08,0,100);}else if(P.club&&P.week>4)P.mor=clamp(P.mor-.4,0,100);
  const sal=wageWeek()*(P.agent?.9:1),spend=P.assets.reduce((s,a)=>s+(SHOP.find(x=>x[0]===a)||[0,0,0])[2]*.002,0)+(P.cars||[]).reduce((s,k)=>s+(CARS.find(c=>c[0]===k)||[0,0,0])[2]*.002,0);P.money+=sal-spend;
  if(P.money<0){P.mor=clamp(P.mor-5,0,100);P.lp-=.5;}
  P.followers=Math.round(800*Math.pow(1.095,P.fame));
  P.sponsors.forEach(s=>{P.money+=s.pay/38*(hasT('mediatico')?1.2:1);});
  // ascenso desde la cantera
  if(P.squad==='cantera'&&P.week>=6&&ovr()>=club(P.club).base-13&&P.tru>=58){P.squad='primer';simPastTeam((P.fx==null?P.week-1:P.fx)+1);news(`${P.name} ${P.last} debuta en la convocatoria del primer equipo de ${cname(P.club)}.`,'hot');P.tru=50;P.lp+=1;}
  if(P.squad==='cantera'&&P.week===2&&!P.offers.length)news(`«La joven promesa ${P.last} podría debutar pronto», dicen en la ciudad deportiva.`);
  // selección
  const e=nextEv();
  // ventana de invierno
  if(P.week===19)window_(false);
  if(P.evCool>0)P.evCool--;else if(ch(.3))randomEvent();
  P.miniDone=false;weekEnd();
  checkCallup();save();}
function checkCallup(){const e=nextEv();P.sel.called=false;if(!e||!isNat(e))return;if(e.type!=='sel'){const C=P.comp&&P.comp[e.comp];if(C&&C.called&&P.inj===0&&!(P.ban>0)){P.sel.called=true;P.sel.lvl='Absoluta';P.nat_=P.nat;}return;}
  const lvl=natLevel(),need={'Sub-17':62,'Sub-19':66,'Sub-21':72,'Absoluta':NAT[P.nat][0]-12}[lvl];
  if(ovr()+P.form/20-2>=need&&P.inj===0){P.sel.called=true;P.sel.lvl=lvl;P.nat_=`${P.nat} ${lvl==='Absoluta'?'':lvl}`.trim();if(!e.sl)news(`${P.last} entra en la convocatoria de la selección ${lvl==='Absoluta'?'absoluta':lvl} de ${P.nat}.`,'hot');
    if(P.fat>65&&!e.sl)P.pending.push({id:'cansado-sel'});}}
function natMatchQuick(){const e=nextEv(),lvl=P.sel.lvl,abs=lvl==='Absoluta',fx=e&&e.comp&&abs?e:null;if(e&&e.comp&&!abs&&!e.done)simNatFx(e);const oppN=fx&&fx.oppN?fx.oppN:pk(Object.keys(NAT).filter(x=>x!==P.nat));const st=lvl==='Absoluta'?NAT[P.nat][0]:NAT[P.nat][0]-14,os=lvl==='Absoluta'?NAT[oppN][0]:NAT[oppN][0]-14;
  const play=ovr()>=st-6?R(60,90):R(10,30),g=ch(chanceP('tir')*(P.pos==='DEL'?.7:P.pos==='EXT'?.45:.2))?1:0,gf=Math.max(poisson(xg(st-os)),g),ga=poisson(xg(os-st));
  const rt=+f1(clamp(6.2+g+(gf>ga?.3:-.2)+(Math.random()-.5),3,10));
  if(fx&&!fx.done){compAfter(fx,gf,ga,fx.ko&&gf===ga?ch(.5+(P.at.tir-70)/400):null,rt);fx.done=true;}
  if(lvl==='Absoluta'){P.sel.caps++;P.sel.g+=g;if(P.sel.caps===1)news(`Debut con la selección absoluta de ${P.nat}.`,'hot');if(P.sel.caps>=40&&ovr()>=85&&!P.sel.captain){P.sel.captain=true;news(`${P.last} es el nuevo capitán de ${P.nat}.`,'hot');}}
  P.fat=clamp(P.fat+play/90*12,0,100);P.fame=clamp(P.fame+(lvl==='Absoluta'?1.5:.6)+g,0,100);
  modal(`<div class="hd j-mhd"><h3>${esc(P.nat)} ${lvl==='Absoluta'?'':lvl} ${gf}-${ga} ${esc(oppN)}</h3>${fx?`<p class="j-hint" style="margin:4px 0 0">${esc(evLabel(fx))}</p>`:''}</div><div class="bd"><div class="j-note"><b class="num">${f1(rt)}</b><span>${play} minutos${g?' · ¡gol con tu país!':''}</span></div><p class="j-hint">Partidos internacionales: ${P.sel.caps} · Goles: ${P.sel.g}</p><div style="margin-top:14px"><button class="btn primary" data-act="jAfterNat" data-focus>Seguir</button></div></div>`);}
function window_(summer){
  const o=ovr(),pool=ALL().filter(k=>Math.abs(k.base-(o+2+P.fame/25))<=6&&k.id!==P.club);
  const n=clamp(Math.round((P.fame/30)+(o>=75?1:0)+(P.sea&&avg(P.sea.rt)>=7?1:0)),0,4);
  for(let i=0;i<n&&pool.length;i++){const k=pool.splice(R(0,pool.length-1),1)[0],r=k.base<=o-2?'Titular':k.base<=o+3?'Rotación':'Suplente';
    P.offers.push({...contractFor(k.id,'primer'),role:r,promise:ch(.35)?pk(['minutos','posicion','titular']):null});}
  const r=role();
  if((r==='Suplente'||r==='Descartado'||P.squad==='cantera')&&P.age<23&&!P.loan&&ch(.7)){const lpool=ALL().filter(k=>k.base<clubStr(P.club)-4&&k.base>=ovr()-6).map(k=>k.id);if(lpool.length){const lid=pk(lpool);P.offers.push({...contractFor(lid,'primer'),loan:true,years:1,role:'Titular',promise:'minutos'});news(`${cname(lid)} pregunta por la cesión de ${P.last}.`);}}
  if(n)news(n>=3?`Tres grandes clubes siguen los pasos de ${P.last}.`:`${pool.length?'Llegan ofertas':'Hay interés'} por ${P.last}.`,'hot');
  P.offers=P.offers.slice(-5);}
function title(n){if(news.q)return;P.titles.push({n,s:seasonLabel(P.season),c:cname(P.club)});news(`¡${cname(P.club)} gana la ${n}!`,'hot');P.fame=clamp(P.fame+6,0,100);}
function award(n){if(news.q)return;P.awards.push({n,s:seasonLabel(P.season)});news(`${P.last} gana: ${n}.`,'hot');P.fame=clamp(P.fame+5,0,100);P.lp+=.5;}
function dream(){if(news.q)return;if(!P.dreamDone){P.dreamDone=true;news(`Sueño cumplido: ${DREAMS[P.dream]}.`,'hot');P.mor=100;}}
/* resumen mundial de la temporada (como la asamblea del modo Clubes): Balón de Oro, Bota de Oro, Champions y campeón de cada liga */
const lgHash=(id,s)=>([...id+s].reduce((x,ch)=>(x*31+ch.charCodeAt(0))>>>0,7)%1000)/1000-.5;
function lgChamp(key){const ids=LG[key].pyr[0];if(!ids||!ids.length)return null;const k=club(P.club);
  if(k&&k.league===key&&k.tier===0&&P.squad!=='cantera'&&P.pld&&P.sea.pos===1)return P.club;
  return ids.filter(id=>id!==P.club&&CLUBS[id]).map(id=>({id,v:(clubStr(id)-avgBase(ids))*.05+lgHash(id,P.season)*.55})).sort((a,b)=>b.v-a.v)[0]?.id||null;}
function uclChamp(){const U=P.comp&&P.comp.ucl;if(U&&U.won)return P.club;
  const f=U&&U.res.find(r=>r.st==='f');if(f&&f.opp&&CLUBS[f.opp])return f.opp;
  const pool=ALL().filter(k=>k.tier===0&&k.id!==P.club&&UEFAC(LG[k.league].country)).sort((a,b)=>b.base-a.base).slice(0,16);if(!pool.length)return null;
  const w=pool.map(k=>Math.pow(Math.max(1,k.base-70),3)),t=w.reduce((a,b)=>a+b,0);let r=Math.random()*t;for(let i=0;i<pool.length;i++){r-=w[i];if(r<=0)return pool[i].id;}return pool[0].id;}
function worldSeason(){const sl=seasonLabel(P.season),mine=n=>P.awards.some(a=>a.n===n&&a.s===sl),Rv=P.rivals;
  const br=Rv.length?Rv.reduce((a,r)=>r.score>a.score?r:a):null,bg=Rv.length?Rv.reduce((a,r)=>r.seaG>a.seaG?r:a):null;
  if(br&&!mine('Balón de Oro')&&!br.awards.includes('Balón de Oro '+sl))br.awards.push('Balón de Oro '+sl);
  const w={s:sl,
    balon:mine('Balón de Oro')?{n:P.name,c:P.club,me:1}:br?{n:br.name,c:br.club}:null,
    bota:mine('Bota de Oro')?{n:P.name,c:P.club,g:P.sea.g,me:1}:bg?{n:bg.name,c:bg.club,g:bg.seaG}:null,
    ucl:uclChamp(),ligas:Object.keys(LG).filter(key=>LG[key].pyr&&LG[key].pyr[0]&&LG[key].pyr[0].length).map(key=>[key,lgChamp(key)]).filter(x=>x[1])};
  const k=club(P.club);if(k)w.ligas.sort((a,b)=>(b[0]===k.league)-(a[0]===k.league));
  (P.world||(P.world=[])).push(w);P.pending.unshift({id:'resumen'});}
function worldRows(w){const who=(x,extra)=>x?`<span>${CLUBS[x.c]?crest(CLUBS[x.c],16)+' ':''}${x.me?'<b>'+esc(x.n)+'</b>':esc(x.n)}${CLUBS[x.c]?' · '+esc(cname(x.c)):''}${extra||''}</span>`:'<span class="muted">—</span>';
  const cl=id=>`<span>${crest(CLUBS[id],16)} ${id===P.club?'<b>'+esc(cname(id))+'</b>':esc(cname(id))}</span>`;
  return `<div class="list">${[['Balón de Oro',who(w.balon)],['Bota de Oro',who(w.bota,w.bota?` · ${w.bota.g} goles`:'')],['Champions League',w.ucl&&CLUBS[w.ucl]?cl(w.ucl):'<span class="muted">—</span>'],
    ...w.ligas.filter(x=>CLUBS[x[1]]).map(([key,id])=>[divOf({league:key,tier:0}),cl(id)])].map(([n,v])=>`<div class="row"><span style="flex:1">${esc(n)}</span>${v}</div>`).join('')}</div>`;}
function showWorld(){const w=(P.world||[])[P.world.length-1];if(!w){P.pending.shift();showEvent();return;}
  modal(`<div class="hd j-mhd"><div class="eyebrow">Fin de temporada · ${w.s}</div><h3>Campeones de la temporada</h3></div><div class="bd">${worldRows(w)}<p class="j-hint">Lo tienes guardado en Palmarés → Historial de temporadas.</p></div><div class="ft"><button class="btn primary" data-act="jDecide" data-j="0" data-focus>Continuar</button></div>`);}
function worldPanel(){const W=P.world||[];if(!W.length)return '';
  return `<div class="j-panel"><h3>Historial de temporadas</h3>${W.slice().reverse().map((w,i)=>`<details${i?'':' open'}><summary><b class="num">${w.s}</b> · Balón de Oro: ${w.balon?esc(w.balon.n):'—'} · Champions: ${w.ucl&&CLUBS[w.ucl]?esc(cname(w.ucl)):'—'}</summary>${worldRows(w)}</details>`).join('')}</div>`;}
function endSeason(){const c=club(P.club),n=P.sea.rt.length?+f1(avg(P.sea.rt)):0,o=ovr();
  // liga
  const SP=P.sumPrev&&P.sumPrev.s===P.season&&CLUBS[P.sumPrev.club]?P.sumPrev:null;
  if(SP){const oc=club(SP.club);P.sea.pos=SP.pos;if(SP.pos===1){P.titles.push({n:divOf(oc),s:seasonLabel(P.season),c:oc.name});news(`¡${oc.name} gana la ${divOf(oc)}!`,'hot');}else if(oc.tier>0&&SP.pos<=2)news(`${oc.name} asciende de categoría.`,'hot');}
  else if(P.squad!=='cantera'&&P.pld){const tb=table(),pos=tb.findIndex(t=>t.me)+1;P.sea.pos=pos;
    if(pos===1)title(divOf(c));else if(c.tier>0&&pos<=2)news(`${c.name} asciende de categoría.`,'hot');}
  P.sumPrev=null;P.lgPrevClub=null;
  P.hist.push({s:seasonLabel(P.season),c:SP?cname(SP.club):c.name,o,pj:P.sea.pj,tit:P.sea.tit,sup:P.sea.sup,g:P.sea.g,a:P.sea.a,n:n?f1(n):'—'});
  // premios
  const score=n*10+P.sea.g*1.2+P.sea.a*.8+(o-70)*1.5+P.titles.filter(t=>t.s===seasonLabel(P.season)).length*8;
  P.rivals.forEach(r=>{r.seaG=Math.round((r.pos==='DEL'?18:r.pos==='EXT'?11:6)*(r.ovr/80)+R(-4,6));r.g+=r.seaG;r.score=(r.ovr-70)*3+r.seaG*1.2+R(0,40)+60;});
  const bestRival=Math.max(...P.rivals.map(r=>r.score));
  if(o>=88&&n>=7.5&&c.tier===0&&score>bestRival+8&&score>=155&&ch(.6)){award('Balón de Oro');if(P.dream==='balon')dream();}
  else if(P.rivals.some(r=>r.ovr>=88&&r.score===bestRival&&ch(.6))){const r=P.rivals.find(x=>x.score===bestRival);r.awards.push('Balón de Oro '+seasonLabel(P.season));news(`${r.name}, rival de tu generación, gana el Balón de Oro.`);}
  if(P.sea.g>=Math.max(32,...P.rivals.map(r=>r.seaG+4))&&c.tier===0&&ch(.7))award('Bota de Oro');
  if(n>=7.4&&o>=80&&P.squad!=='cantera')award(`Mejor jugador de ${divOf(c)}`);
  if(P.age<=21&&n>=7&&P.sea.pj>=15)award('Mejor joven de la temporada');
  if(n>=7.4&&c.tier===0&&P.sea.pj>=24)award('Once ideal de la temporada');
  if(P.pos==='POR'&&P.sea.cs>=14&&c.tier===0)award('Guante de Oro');
  worldSeason();
  traitsTick();seasonCard(n,o);lockerVotes(n);misterSeason();if(P.sea.pj>=30&&!P.sea.yel&&!P.sea.red)flag('clean');
  // decisiones de la temporada → techo
  if(n>=7.2)P.lp+=3;else if(n&&n<6.2)P.lp-=2;
  if(P.sea.tit>=20)P.lp+=2;if(P.squad!=='cantera'&&P.sea.pj<8&&P.age>=20)P.lp-=2;
  P.lp=clamp(P.lp,0,100);
  // plazas europeas para la temporada siguiente
  P.qual=null;if(P.squad!=='cantera'&&P.sea.pos){const k=club(P.club),ctry=LG[k.league].country;if(k.tier===0&&UEFAC(ctry)){const r=P.sea.pos;let q=TOP5.includes(ctry)?(r<=4?'ucl':r===5?'uel':r===6?'uecl':null):(r===1?'ucl':r===2?'uel':r===3?'uecl':null);
    if(!q&&P.comp&&P.comp.copa&&P.comp.copa.won)q='uel';if(P.comp&&P.comp.ucl&&P.comp.ucl.won)q='ucl';if(q){P.qual={s:P.season+1,club:P.club,comp:q};news(`${k.name} jugará la ${CN[q]} la próxima temporada.`,'hot');}}
    else if(k.tier===0&&CONTL[k.league]){const [q,n]=CONTL[k.league],won=P.comp&&P.comp[q]&&P.comp[q].won;if(P.sea.pos<=n||won){P.qual={s:P.season+1,club:P.club,comp:q};news(`${k.name} jugará la ${CN[q]} la próxima temporada.`,'hot');}}}
  {const cp=P.comp&&P.comp.copa;P.prevS={s:P.season+1,club:P.club,pos:P.squad!=='cantera'&&P.sea.pos?P.sea.pos:(tier0By(club(P.club).league).indexOf(P.club)+1||99),cupW:!!(cp&&cp.won),cupF:!!(cp&&cp.out==='Final'),ucl:!!(P.comp&&P.comp.ucl&&P.comp.ucl.won)};}
  if(P.dream==='record'&&P.st.g>=400)dream();
  // edad y evolución: la media máxima acaba entre 83 y 94 (techo = ceil())
  P.age++;P.yearsAt++;const cap=ceil();
  if(P.age<=27){const t=P.startAge,exp=Math.round(P.at0+(cap-P.at0)*Math.min(1,(P.age-t)/(27-t)));let guard=0;while(ovr()<exp-(P.age<27?2:0)&&guard++<300)grow(pk(AT));}
  else if(P.age>=31){const hard=P.age>=34?2:1;AT.forEach(k=>{if(k==='rit'||k==='fis')P.at[k]-=R(1,2)*hard;else if(ch(.45))P.at[k]-=hard;});if(ch(.4))grow(pk(['pas','def']));}
  P.peak=Math.max(P.peak||0,ovr());
  // rivales
  P.rivals.forEach(r=>{r.ovr=Math.min(r.ceil,r.ovr+(P.age<=27?R(1,4):P.age>=32?-R(1,3):0));if(r.ovr>clubStr(r.club)+3){const up=ALL().filter(k=>k.base>=r.ovr-3&&k.base<=r.ovr+4&&k.id!==r.club);if(up.length){r.club=pk(up).id;news(`${r.name} ficha por ${cname(r.club)}.`);}}});
  // capitanía
  if(!P.captain&&P.yearsAt>=3&&o>=clubStr(P.club)&&P.squad!=='cantera')P.pending.push({id:'capitan'});
  // contrato
  if(P.contract){P.contract.years--;if(P.contract.years===1&&!P.loan)P.offers.push({...contractFor(P.club,'primer'),renew:true,role:role(),promise:null});
    if(P.contract.years<=0&&!P.loan){news(`${P.last} acaba contrato con ${cname(P.club)} y queda libre.`,'bad');P.contract=null;}}
  if(P.loan){const back=P.loan.from;P.moves.push({s:seasonLabel(P.season),from:cname(P.club),to:cname(back),t:'Vuelta de cesión',wage:P.loan.wage});P.club=back;P.contract=P.loan.contract;P.loan=null;P.squad='primer';news(`${P.last} vuelve a ${cname(back)} tras la cesión.`);}
  if(P.age>=31&&P.origin0&&P.club!==P.origin0&&ch(.35))P.pending.push({id:'casa'});
  window_(true);if(!P.contract&&!P.offers.length){P.offers.push({...contractFor(pk(ALL().filter(k=>k.base<=ovr()).map(k=>k.id)),'primer'),role:'Rotación'});}
  if(P.squad==='cantera'&&P.age>=19)P.squad='primer';
  P.season++;newSeason();familyTick();investTick();
  if(P.age>=39||(P.age>=34&&ovr()<76)){retire();return;}
  news(`Arranca la temporada ${seasonLabel(P.season)}. ${P.name} cumple ${P.age} años.`);
  P.pending.push({id:'pretemporada'});
  UI.jEnd=true;}
function retire(){P.retired=true;const after=[];P.rivals.forEach(r=>{const extra=R(1,4);after.push(`${r.name} juega ${extra} temporada${extra>1?'s':''} más y se retira con ${Math.round(r.ovr)} de media y ${r.g+extra*R(5,15)} goles.`);});
  const clubs=[...new Set(P.hist.map(h=>h.c))];clubs.slice(-3).forEach(c=>after.push(`${c} ${pk(['pelea por el título los años siguientes','vive una reconstrucción','retira tu dorsal en tu honor','pone tu nombre a una grada'])}.`));
  P.after=after;const H=hall();H.unshift({name:`${P.name} ${P.last}`,peak:P.peak,g:P.st.g,t:P.titles.length});try{localStorage.setItem(HALL,JSON.stringify(H.slice(0,12)));}catch(e){}
  P.retAge=P.age;addCard('icono','Retirada');news(`${P.name} ${P.last} anuncia su retirada.`);save();}

/* ---------- eventos con decisión ---------- */
const EV={
  resumen:{t:()=>'',o:[['Continuar',()=>{}]]},
  confianza:{t:()=>`«El entrenador pierde la confianza en ${P.last}», titula la prensa local.`,o:[['Pedir una reunión',()=>{P.tru+=P.pers==='Líder'||P.pers==='Humilde'?9:5;P.lp+=1;P.rep.lider+=1;}],['Quejarse ante los medios',()=>{P.tru-=14;P.fame+=3;P.lp-=2;P.rep.polemico+=2;}],['Entrenar el doble y callar',()=>{P.tru+=4;P.fat+=12;P.lp+=1.5;P.rep.humilde+=1;}]]},
  aficion:{t:()=>`«La afición pide más minutos para ${P.last}».`,o:[['Agradecer el apoyo con humildad',()=>{P.tru+=3;P.rep.humilde+=1;P.lp+=.5;}],['Pedir públicamente más minutos',()=>{P.tru-=8;P.fame+=3;P.rep.polemico+=1;P.lp-=1;}],['Mantener silencio',()=>{P.lp+=.3;}]]},
  oferta:{t:()=>`«El club rechaza una oferta millonaria por ${P.last}».`,o:[['Aceptar la decisión del club',()=>{P.tru+=6;P.lp+=1;P.rep.humilde+=1;}],['Pedir que te dejen salir',()=>{P.tru-=12;P.mor-=4;P.lp-=1.5;window_(false);}],['Pedir una mejora de contrato',()=>{if(P.contract)P.contract.wage=Math.round(P.contract.wage*1.25);P.tru-=3;}]]},
  rueda:{t:()=>`Rueda de prensa tras el partido. Te preguntan por tus aspiraciones.`,o:[['«Solo pienso en el equipo»',()=>{P.rep.humilde+=1;P.tru+=2;P.lp+=.5;}],['«Quiero ganarlo todo, aquí o fuera»',()=>{P.rep.mediatico+=1;P.fame+=3;P.tru-=3;}],['Responder a una crítica del rival',()=>{P.rep.polemico+=2;P.fame+=4;P.lp-=1;P.tru-=4;}]]},
  redes:{t:()=>`Polémica en redes: un vídeo tuyo se saca de contexto y se hace viral.`,o:[['Pedir disculpas',()=>{P.rep.humilde+=1;P.fame-=1;P.lp+=.5;}],['Responder con ironía',()=>{P.rep.polemico+=2;P.fame+=4;P.lp-=1;}],['Ignorarlo',()=>{P.mor-=3;}]]},
  marca:{t:()=>`Una marca de botas quiere que seas su imagen.`,o:[['Firmar el contrato',()=>{const pay=Math.round(20000+P.fame*P.fame*120);P.sponsors.push({brand:pk(['Volta','Nexo','Kairo','Prisma','Lumen']),pay});P.rep.mediatico+=1;P.fat+=4;}],['Rechazarlo para centrarte',()=>{P.lp+=1;}]]},
  fiesta:{t:()=>`Un compañero te invita a una fiesta la víspera de un partido.`,o:[['Ir un rato',()=>{P.mor+=6;P.fat+=10;P.lp-=2;P.rep.polemico+=1;if(ch(.4)){P.tru-=10;news('El míster se entera de la fiesta. Multa y banquillo.','bad');}}],['Quedarte en casa',()=>{P.lp+=1;P.chem-=2;}]]},
  benefico:{t:()=>`Te proponen protagonizar una campaña benéfica.`,o:[['Aceptar',()=>{P.fame+=4;P.rep.humilde+=1;P.lp+=1;P.fat+=3;}],['No tienes tiempo',()=>{}]]},
  vestuario:{t:()=>`Bronca en el vestuario entre dos veteranos.`,o:[['Mediar entre ellos',()=>{P.chem+=10;P.rep.lider+=2;P.lp+=1;}],['Ponerte de un lado',()=>{P.chem-=8;P.rep.polemico+=1;}],['No meterte',()=>{}]]},
  fichaje:{t:()=>`Llega un fichaje joven que no habla el idioma.`,o:[['Ayudarle a integrarse',()=>{P.chem+=8;P.rep.lider+=1;P.lp+=.5;}],['Verlo como competencia',()=>{P.chem-=5;P.mor+=2;}]]},
  tactica:{t:()=>`El entrenador te pide jugar más abierto a banda y presionar arriba.`,o:[['Aceptar el plan',()=>{P.tru+=6;P.at.rit<99&&xp('rit',4);P.lp+=1;}],['Pedir jugar por dentro',()=>{P.tru-=4;xp('pas',3);}]]},
  posicion:{t:()=>`El míster te propone cambiar de posición a ${POS[P.pos2]}.`,o:[['Aceptar el cambio',()=>{const a=P.pos;P.pos=P.pos2;P.pos2=a;P.tru+=8;P.lp+=1;}],['Seguir en tu posición',()=>{P.tru-=3;}]]},
  promesa:{t:()=>`Reunión con el entrenador: te ofrece un rol de suplente esta temporada.`,o:[['Aceptar el rol y esperar tu momento',()=>{P.tru+=8;P.lp+=1.5;P.rep.humilde+=1;}],['Exigir protagonismo',()=>{if(ovr()>=clubStr(P.club)-2){P.promise='minutos';P.tru+=2;}else{P.tru-=10;P.lp-=1;}P.rep.lider+=1;}]]},
  lesion:{t:()=>`Lesión: el fisio propone dos caminos.`,o:[['Rehabilitación completa',()=>{P.inj+=1;P.lp+=1.5;P.at.fis<99&&xp('fis',3);}],['Forzar la vuelta',()=>{P.inj=Math.max(1,P.inj-2);P.lp-=2;if(ch(.35)){P.inj+=4;news('Recaída: la lesión se complica.','bad');}}]]},
  capitan:{t:()=>`«El vestuario elige a su nuevo capitán»: tu nombre suena con fuerza.`,o:[['Aceptar el brazalete',()=>{P.captain=true;P.lp+=2;P.rep.lider+=2;news(`${P.last}, nuevo capitán de ${cname(P.club)}.`,'hot');if(P.dream==='capitan')dream();}],['Cederlo a un veterano',()=>{P.chem+=6;P.rep.humilde+=1;}]]},
  casa:{t:()=>`${cname(P.origin0)}, tu primer club, te ofrece volver a casa.`,o:[['Volver a casa',()=>{move(P.origin0,{...contractFor(P.origin0,'primer'),years:2},'Vuelta a casa');P.captain=true;P.lp+=2;news(`${P.last} vuelve a casa: será capitán y mentor en ${cname(P.origin0)}.`,'hot');}],['Seguir donde estás',()=>{}]]},
  'cansado-sel':{t:()=>`Te llama la selección, pero llegas muy cansado.`,o:[['Acudir igualmente',()=>{if(ch(.3)){P.inj=R(2,4);P.lp-=1;news('Te lesionas con la selección por la sobrecarga.','bad');}}],['Pedir descanso',()=>{P.sel.called=false;P.fame-=2;P.fat-=15;}]]},
};
function event(id){if(!EV[id])return;P.pending.push({id});}
function randomEvent(){const r=role(),cands=['rueda','redes','marca','fiesta','benefico','vestuario','fichaje','tactica'];
  if(P.tru<38&&P.squad!=='cantera')cands.push('confianza','confianza');if((r==='Suplente'||r==='Rotación')&&P.sea.rt.length&&avg(P.sea.rt)>=6.8)cands.push('aficion','aficion');
  if(P.fame>=35)cands.push('oferta');if(P.pos2!==P.pos&&P.squad!=='cantera')cands.push('posicion');if(P.week<6&&P.squad!=='cantera'&&!P.promise)cands.push('promesa');
  if(P.fame<12)cands.splice(cands.indexOf('marca'),1);
  famCands(cands);P.pending.push(mkEv(pk(cands)));P.evCool=3;}
function showEvent(){const ev=P.pending[0];if(!ev){closeModal();return;}if(ev.id==='resumen'){showWorld();return;}const E=EV[ev.id];if(!E){P.pending.shift();showEvent();return;}const EO=typeof E.o==='function'?E.o(ev):E.o;
  modal(`<div class="hd j-mhd"><h3>Decisión</h3></div><div class="bd"><p class="j-sit">${esc(E.t(ev))}</p><div class="j-opts col">${EO.map((o,j)=>`<button class="j-op" data-act="jDecide" data-j="${j}"><b>${o[0]}</b></button>`).join('')}</div><p class="j-hint">Cada decisión cuenta para tu carrera, aunque no siempre lo veas al momento.</p></div>`);}
function move(cid,k,t){if(P.summer&&P.squad!=='cantera'&&P.pld){const tb=table();P.lgPrevClub={s:P.season,club:P.club,pos:tb.findIndex(t=>t.me)+1};}
  if(P.home&&P.home.club!==cid)sellHome('cambio de equipo');P.moves.push({s:seasonLabel(P.season),from:cname(P.club),to:cname(cid),t,wage:k.wage});
  if(P.club&&country(P.club)!==country(cid)){P.adapt=P.free==='idioma'?55:35;if(fam().partner||fam().kids.length)P.pending.push({id:'mudanza'});}
  P.club=cid;P.contract={...k,club:cid};P.squad='primer';P.tru=45;P.chem=45;P.yearsAt=0;P.captain=false;if(P.cal&&P.cal.length)newSeasonKeep();}
/* partidos del primer equipo que se jugaron sin ti (fichaje a mitad de temporada o subida desde la cantera): se simulan sin noticias ni títulos */
function simPastTeam(upto){news.q=1;try{P.cal.slice(0,upto).forEach(e=>{if(!e.tsim&&!e.skip&&teamFx(e))simTeam(e);e.done=true;});}finally{news.q=0;}}
function newSeasonKeep(){const w=P.week,s={...P.sea},oldCal=P.cal||[],oldComp=P.comp||{};
  /* verano: la temporada del club anterior ya está jugada; se guarda su puesto y solo se anula lo ligado al club (Mundial de Clubes) */
  if(P.summer){if(P.sumPrev==null||P.sumPrev.s!==P.season){const prev=P.lgPrevClub;P.sumPrev=prev&&prev.s===P.season?prev:null;}
    P.cal.forEach((e,i)=>{if(i>=P.fx&&!e.done&&e.type==='cwc')e.skip=true;});if(P.comp&&P.comp.cwc&&!P.comp.cwc.won)P.comp.cwc.alive=false;return;}
  newSeason();
  /* la selección no cambia por fichar: se conservan la Nations League y sus partidos */
  if(oldComp.nl)P.comp.nl=oldComp.nl;
  P.cal.forEach(e=>{if(e.type==='sel'){const o=oldCal.find(x=>x.type==='sel'&&x.w===e.w&&x.sl===e.sl);if(o)Object.assign(e,o);}});
  const i=P.cal.findIndex(x=>x.w>=w);P.fx=i<0?P.cal.length-1:i;P.week=P.cal[P.fx].w;
  /* lo que el club nuevo ya jugó antes de que llegaras: liga, copa y Europa se simulan sin ti */
  simPastTeam(P.fx);
  P.sea=s;P.sea.club=P.club;}

/* ---------- minijuego ---------- */
function mini(k){const [l,attr]=MINI[k],zone=clamp(10+P.at[attr]/7,12,26);UI.jmini={k,attr,zone,tries:0,score:0,center:R(30,70)};
  modal(`<div class="hd j-mhd"><h3>Minijuego · ${l}</h3></div><div class="bd"><p class="j-sit">Pulsa <b>¡Ya!</b> cuando el marcador esté dentro de la zona morada. Tres intentos.</p>
   <div class="j-bar" id="jbar"><i class="z" style="left:${UI.jmini.center-zone/2}%;width:${zone}%"></i><i class="c" style="left:${UI.jmini.center}%"></i><span id="jmk" style="--dur:${clamp(1.6-P.at[attr]/150,.8,1.4)}s"></span></div>
   <p class="j-hint" id="jmres">Intento 1 de 3</p><div class="j-acts"><button class="btn primary" data-act="jMiniHit" data-focus>¡Ya!</button></div></div>`);}
function miniHit(){const M=UI.jmini,bar=document.getElementById('jbar'),mk=document.getElementById('jmk');if(!bar||!mk)return;
  const b=bar.getBoundingClientRect(),m=mk.getBoundingClientRect(),pos=(m.left+m.width/2-b.left)/b.width*100,d=Math.abs(pos-M.center),pts=d<=M.zone/2?Math.round(10*(1-d/(M.zone/2)))+2:0;
  M.tries++;M.score+=pts;const res=document.getElementById('jmres');
  if(M.tries<3){res.textContent=`${pts?'¡Dentro! +'+pts:'Fuera'} · intento ${M.tries+1} de 3`;mk.style.animationDuration=(parseFloat(getComputedStyle(mk).animationDuration)*.85)+'s';return;}
  P.miniDone=true;xp(M.attr,M.score/3);P.lp+=M.score>=20?.5:0;save();
  modal(`<div class="hd j-mhd"><h3>Resultado</h3></div><div class="bd"><div class="j-note"><b class="num">${M.score}</b><span>puntos de 36<small>${M.score>=24?'Sesión brillante':M.score>=12?'Buena sesión':'Hoy no era tu día'}</small></span></div><p class="j-hint">Has sumado experiencia en ${AN[M.attr]}.</p><button class="btn primary" data-act="jClose" data-focus>Seguir</button></div>`);}

/* ---------- aspecto: panel y modelo 3D ---------- */
const LOOK=['skin','hairc','hair','beard','boots','acc','accs','socks','bootm'];
function lookPanel(src,isP){const act=isP?'jLook':'jcf';
  const sw=(k,arr,lab)=>`<div class="j-sw sm" role="radiogroup" aria-label="${lab}">${arr.map((col,i)=>`<button class="${(src[k]||0)===i?'on':''}" role="radio" aria-checked="${(src[k]||0)===i}" aria-label="${lab} ${i+1}" data-act="${act}" data-k="${k}" data-v="${i}" style="background:${col}"></button>`).join('')}</div>`;
  const chips=(k,arr,lab)=>`<div class="j-chips" role="radiogroup" aria-label="${lab}">${arr.map((t,i)=>`<button class="j-chip${(+src[k]||0)===i?' on':''}" role="radio" aria-checked="${(+src[k]||0)===i}" data-act="${act}" data-k="${k}" data-v="${i}">${t}</button>`).join('')}</div>`;
  return `<section class="j-aspect" aria-labelledby="asp-${isP?'p':'c'}"><div class="j-asp-h"><h3 id="asp-${isP?'p':'c'}">Aspecto</h3><small>Arrastra para girar</small></div>
  <div class="j-3d"><canvas id="j3d" role="img" aria-label="Modelo 3D de tu futbolista"></canvas><div class="j-3d-fb" hidden>${avatar(src,170)}</div></div>
  <div class="j-asp-c"><div class="j-asp-row"><div class="j-grp"><h4>Tono de piel</h4>${sw('skin',SKIN,'Tono de piel')}</div><div class="j-grp"><h4>Color de pelo</h4>${sw('hairc',HAIRC,'Color de pelo')}</div></div>
   <div class="j-grp"><h4>Peinado</h4>${chips('hair',HAIR,'Peinado')}</div>
   <div class="j-grp"><h4>Barba</h4>${chips('beard',BEARD,'Barba')}</div>
   <div class="j-grp"><h4>Botas · color</h4>${sw('boots',BOOTS,'Color de botas')}</div>
   <div class="j-asp-row"><div class="j-grp"><h4>Botas · modelo</h4>${chips('bootm',BOOTM,'Modelo de botas')}</div><div class="j-grp"><h4>Medias</h4>${chips('socks',SOCKS,'Medias')}</div></div>
   <div class="j-grp"><h4>Accesorios <small class="j-hint" style="font-weight:400;text-transform:none;letter-spacing:0">· puedes llevar varios</small></h4>${(()=>{const a=accsOf(src);return `<div class="j-chips j-acc" role="group" aria-label="Accesorios"><button class="j-chip${a.length?'':' on'}" aria-pressed="${!a.length}" data-act="${act}" data-k="accs" data-v="0">Ninguno</button>${ACC.slice(1).map((t,j)=>`<button class="j-chip${a.includes(j+1)?' on':''}" aria-pressed="${a.includes(j+1)}" data-act="${act}" data-k="accs" data-v="${j+1}">${t}</button>`).join('')}</div>`;})()}</div>${isP?lookExtra(src):''}</div></section>`;}
function setLook(obj,d,el){
  if(d.k==='accs'){const v=+d.v;let a=accsOf(obj);a=v===0?[]:a.includes(v)?a.filter(x=>x!==v):[...a,v];obj.accs=a;obj.acc=a[0]||0;
    const g=el&&el.closest('.j-acc');if(g)g.querySelectorAll('button').forEach(b=>{const bv=+b.dataset.v,on=bv===0?!a.length:a.includes(bv);b.classList.toggle('on',on);b.setAttribute('aria-pressed',String(on));});}
  else{obj[d.k]=+d.v;
  const g=el&&el.closest('[role=radiogroup]');if(g)g.querySelectorAll('[role=radio]').forEach(b=>{const on=b===el;b.classList.toggle('on',on);b.setAttribute('aria-checked',String(on));});}
  const prev=document.getElementById('jc-prev');if(prev&&obj===UI.jc)prev.innerHTML=card({...build(UI.jc),club:null},true);
  const fb=document.querySelector('.j-3d-fb');if(fb)fb.innerHTML=avatar(obj,170);
  if(G3D)G3D.rebuild();}

let G3D=null;
function unmount3D(){if(!G3D)return;cancelAnimationFrame(G3D.raf);G3D.ro&&G3D.ro.disconnect();
  G3D.scene.traverse(o=>{o.geometry&&o.geometry.dispose();if(o.material){(Array.isArray(o.material)?o.material:[o.material]).forEach(m=>{m.map&&m.map.dispose();m.dispose();});}});
  G3D.r.dispose();try{G3D.r.forceContextLoss();}catch(e){}G3D=null;}
function mountAspect(){const cv=document.getElementById('j3d');
  if(!cv){unmount3D();return;}if(G3D&&G3D.cv===cv)return;unmount3D();
  const fb=()=>{const f=cv.parentElement.querySelector('.j-3d-fb');if(f){f.hidden=false;cv.hidden=true;}};
  if(typeof loadThree!=='function'){fb();return;}
  loadThree().then(ok=>{if(!ok||!window.THREE||!document.body.contains(cv)){fb();return;}try{init3D(cv);}catch(e){console.error(e);fb();}});}
function lookSrc(){return UI.screen==='jcreate'?UI.jc:P;}
function init3D(cv){const T=window.THREE,box=cv.parentElement;
  const r=new T.WebGLRenderer({canvas:cv,antialias:true,alpha:true});r.setPixelRatio(Math.min(devicePixelRatio||1,2));
  if('outputEncoding' in r)r.outputEncoding=T.sRGBEncoding;
  const scene=new T.Scene(),cam=new T.PerspectiveCamera(30,1,.1,50);cam.position.set(0,1.2,3.55);cam.lookAt(0,1.02,0);
  scene.add(new T.HemisphereLight(0xEDE2FF,0x1A0C33,.85));
  const key=new T.DirectionalLight(0xffffff,.95);key.position.set(2.2,3.2,2.6);scene.add(key);
  const rim=new T.DirectionalLight(0xB57BFF,1.6);rim.position.set(-2.4,2.2,-2.6);scene.add(rim);
  const rim2=new T.DirectionalLight(0x8A4FE6,.7);rim2.position.set(2.6,1,-2);scene.add(rim2);
  // plataforma con anillo de neón
  const disc=new T.Mesh(new T.CircleGeometry(.62,48),new T.MeshStandardMaterial({color:0x1A0D33,roughness:.5,metalness:.2}));disc.rotation.x=-Math.PI/2;scene.add(disc);
  const ring=new T.Mesh(new T.RingGeometry(.6,.645,64),new T.MeshBasicMaterial({color:0xC99BFF,transparent:true,opacity:.95,side:T.DoubleSide}));ring.rotation.x=-Math.PI/2;ring.position.y=.002;scene.add(ring);
  const glow=new T.Mesh(new T.RingGeometry(.645,.8,64),new T.MeshBasicMaterial({color:0x9D62F2,transparent:true,opacity:.22,side:T.DoubleSide}));glow.rotation.x=-Math.PI/2;glow.position.y=.001;scene.add(glow);
  const fig=new T.Group();scene.add(fig);
  const G={cv,r,scene,cam,fig,raf:0,rotY:.45,drag:null,t0:performance.now()};G3D=G;
  G.rebuild=()=>{while(fig.children.length){const o=fig.children.pop();o.traverse(x=>{x.geometry&&x.geometry.dispose();if(x.material)(Array.isArray(x.material)?x.material:[x.material]).forEach(m=>{m.map&&m.map.dispose();m.dispose();});});}buildFigure(T,fig,lookSrc());};
  G.rebuild();
  const size=()=>{const w=box.clientWidth||300,h=box.clientHeight||340;r.setSize(w,h,false);cam.aspect=w/h;cam.updateProjectionMatrix();};size();
  if(window.ResizeObserver){G.ro=new ResizeObserver(size);G.ro.observe(box);}
  box.addEventListener('pointerdown',e=>{G.drag={x:e.clientX,r:G.rotY};box.setPointerCapture(e.pointerId);});
  box.addEventListener('pointermove',e=>{if(G.drag)G.rotY=G.drag.r+(e.clientX-G.drag.x)*.012;});
  const up=()=>{G.drag=null;};box.addEventListener('pointerup',up);box.addEventListener('pointercancel',up);
  const calm=reduced();
  const loop=t=>{if(G3D!==G)return;G.raf=requestAnimationFrame(loop);
    const tz=G.celeb?4.9:3.55;cam.position.z+=(tz-cam.position.z)*.08;cam.position.y+=((G.celeb?1.35:1.2)-cam.position.y)*.08;cam.lookAt(0,G.celeb?1.25:1.02,0);
    if(G.celeb){const u=(t-G.celeb.t0)/1000;if(u>3.2){G.celeb=null;fig.position.set(0,0,0);fig.rotation.set(0,G.rotY,0);}else{celebPose(G,fig,G.celeb.id,u);fig.rotation.y=G.rotY;r.render(scene,cam);return;}}
    if(!G.drag&&!calm)G.rotY+=.005;fig.rotation.y=G.rotY;
    const k=(t-G.t0)/1000;if(!calm){fig.position.y=Math.sin(k*1.6)*.006;const ch=fig.getObjectByName('chest');if(ch)ch.scale.set(1,1+Math.sin(k*1.6)*.012,1+Math.sin(k*1.6)*.02);const aL=fig.getObjectByName('armL'),aR=fig.getObjectByName('armR');if(aL){aL.rotation.x=Math.sin(k*1.6)*.07;aL.rotation.z=-.05;}if(aR){aR.rotation.x=-Math.sin(k*1.6)*.07;aR.rotation.z=.05;}ring.material.opacity=.75+Math.sin(k*2.2)*.2;}
    r.render(scene,cam);};
  G.raf=requestAnimationFrame(loop);}
/* futbolista cúbico (estilo bloques): cabeza con cara dibujada, camiseta con dorsal y apellido, pelo por bloques */
function pixTex(T,w_,h,draw){const c=document.createElement('canvas');c.width=w_;c.height=h;const g=c.getContext('2d');g.imageSmoothingEnabled=false;draw(g,w_,h);
  const t=new T.CanvasTexture(c);t.magFilter=T.NearestFilter;t.minFilter=T.LinearMipMapLinearFilter;if('encoding' in t)t.encoding=T.sRGBEncoding;return t;}
function buildFigure(T,fig,L){
  const K=kitOf(L),shirtC=K.s,trimC=K.t,shortsC=K.p,sockC=K.m;
  const skinC=SKIN[L.skin]??SKIN[2],hairC=HAIRC[L.hairc||0],bootC=BOOTS[L.boots||0];
  const M=(col,o={})=>new T.MeshStandardMaterial({color:new T.Color(col),roughness:.55,metalness:0,...o});
  const skin=M(skinC,{roughness:.6}),hair=M(hairC,{roughness:.75}),shirt=M(shirtC),shorts=M(shortsC),sock=M(sockC),boot=M(bootC,{roughness:.3,metalness:.1,emissive:new T.Color(bootC),emissiveIntensity:.12}),dark=M('#17111f',{roughness:.4});
  const neon=new T.MeshStandardMaterial({color:new T.Color('#C99BFF'),emissive:new T.Color('#B57BFF'),emissiveIntensity:.9,roughness:.3});
  const box=(par,w_,h,d,mat,x,y,z,name)=>{const m=new T.Mesh(new T.BoxGeometry(w_,h,d),mat);m.position.set(x,y,z);if(name)m.name=name;par.add(m);return m;};
  const long=hasAcc(L,3),gloves=hasAcc(L,4),last=(L.last||'').toUpperCase().slice(0,10),num=String(L.num||9);
  /* piernas: bota, media, rodilla y muslo con el pantalón */
  const sks=+L.socks||0,bm=+L.bootm||0,gold=M('#E8B83A',{metalness:.6,roughness:.3});
  [-1,1].forEach(sd=>{const x=sd*.13;
    /* botas: clásica, caña alta, velocidad, retro (negra con bandas) y élite (suela dorada) */
    if(bm===2){box(fig,.23,.1,.34,boot,x,.05,.04);box(fig,.012,.05,.26,M(hexLum(bootC)>.6?'#141414':'#ffffff'),x+sd*.118,.06,.04);}
    else if(bm===3){box(fig,.24,.12,.34,M('#141414',{roughness:.4}),x,.06,.04);[-.07,0,.07].forEach(dz=>box(fig,.012,.09,.035,boot,x+sd*.123,.07,.04+dz));}
    else box(fig,.24,.12,.34,boot,x,.06,.04);
    if(bm===0)box(fig,.235,.05,.05,M('#ffffff'),x,.1,.215);
    if(bm===1)box(fig,.235,.08,.255,M('#1b1b1f',{roughness:.9}),x,.15,0);
    if(bm===4){box(fig,.245,.03,.35,gold,x,.015,.04);box(fig,.235,.04,.05,gold,x,.1,.215);}
    /* medias: normales, altas (tapan la rodilla) o bajas (espinillera a la vista) */
    if(sks===1){box(fig,.225,.5,.245,sock,x,.37,0);box(fig,.23,.05,.25,M(trimC),x,.6,0);}
    else if(sks===2){box(fig,.22,.12,.24,sock,x,.18,0);box(fig,.225,.04,.245,M(trimC),x,.235,0);box(fig,.2,.36,.22,skin,x,.42,0);box(fig,.16,.2,.02,M('#E9E4DA',{roughness:.8}),x,.36,.115);}
    else{box(fig,.22,.36,.24,sock,x,.3,0);box(fig,.225,.06,.245,M(trimC),x,.45,0);box(fig,.22,.12,.24,skin,x,.54,0);}
    if(hasAcc(L,11))box(fig,.235,.11,.255,M('#1b1b1f',{roughness:.8}),x,sks===1?.56:.54,0);
    box(fig,.24,.22,.26,shorts,x,.71,0);});
  box(fig,.5,.14,.28,shorts,0,.86,0);
  /* torso con textura: escudo, cuello en V y franja delante; dorsal y apellido detrás */
  const front=pixTex(T,128,128,(g,W,H)=>{g.fillStyle=shirtC;g.fillRect(0,0,W,H);g.fillStyle=trimC;g.fillRect(0,0,W,10);g.beginPath();g.moveTo(44,0);g.lineTo(64,26);g.lineTo(84,0);g.fill();
    g.fillStyle=shirtC;g.beginPath();g.moveTo(52,0);g.lineTo(64,16);g.lineTo(76,0);g.fill();g.fillStyle=trimC;g.fillRect(18,40,18,22);g.fillStyle=shirtC;g.fillRect(22,44,10,14);g.globalAlpha=.25;g.fillStyle=trimC;g.fillRect(0,92,W,8);g.globalAlpha=1;});
  const back=pixTex(T,128,128,(g,W,H)=>{g.fillStyle=shirtC;g.fillRect(0,0,W,H);g.fillStyle=trimC;g.fillRect(0,0,W,8);g.font=`900 ${last.length>7?13:16}px Impact,"Big Shoulders Display",sans-serif`;g.textAlign='center';g.fillText(last,64,30);
    g.font='900 74px Impact,"Big Shoulders Display",sans-serif';g.fillText(num,64,108);});
  const torsoMats=[shirt,shirt,shirt,shirt,M('#ffffff',{map:front}),M('#ffffff',{map:back})];
  const torso=new T.Mesh(new T.BoxGeometry(.52,.6,.3),torsoMats);torso.position.set(0,1.23,0);torso.name='chest';fig.add(torso);
  box(fig,.22,.08,.2,skin,0,1.565,0);
  if(hasAcc(L,8))box(fig,.25,.11,.23,M('#151515',{roughness:.8}),0,1.57,0);
  if(hasAcc(L,7)){const g=M('#E8B83A',{metalness:.6,roughness:.3});box(fig,.2,.02,.012,g,0,1.5,.153);box(fig,.045,.05,.012,g,0,1.47,.156);}
  /* brazos: hombro con manga, antebrazo y mano; pivotan en el hombro para animarlos */
  [-1,1].forEach(sd=>{const arm=new T.Group();arm.position.set(sd*.37,1.5,0);arm.name=sd<0?'armL':'armR';fig.add(arm);
    box(arm,.2,.26,.24,shirt,0,-.12,0);box(arm,.205,.04,.245,M(trimC),0,-.245,0);box(arm,.18,.28,.2,long?shirt:skin,0,-.39,0);
    box(arm,.19,.13,.2,gloves?dark:skin,0,-.6,0);if(hasAcc(L,2))box(arm,.2,.06,.21,neon,0,-.5,0);if(hasAcc(L,10)&&!gloves)box(arm,.2,.07,.21,M('#F2F2F2',{roughness:.9}),0,-.565,0);});
  /* cabeza: cara en píxeles con el nacimiento del pelo y cuero cabelludo con el degradado (fade) del corte */
  const H=1.86,hs=.54,hw=hs/2,hdp=hs*.47,st=+L.hair||0,HS=HSTY[st]||HSTY[0],hasHair=HS.fade!=='bald';
  const face=pixTex(T,32,32,(g)=>{g.fillStyle=skinC;g.fillRect(0,0,32,32);g.fillStyle=hairC;g.fillRect(7,10,6,2);g.fillRect(19,10,6,2);
    g.fillStyle='#ffffff';g.fillRect(8,13,5,5);g.fillRect(19,13,5,5);g.fillStyle='#1b1430';g.fillRect(10,14,3,4);g.fillRect(21,14,3,4);
    g.fillStyle='rgba(0,0,0,.18)';g.fillRect(15,18,2,4);g.fillStyle='#5a2430';g.fillRect(11,24,10,2);g.fillRect(10,23,2,1);g.fillRect(20,23,2,1);
    g.fillStyle='rgba(255,120,120,.25)';g.fillRect(6,20,4,2);g.fillRect(22,20,4,2);
    if(HS.hl){g.fillStyle=hairC;if(HS.hlc)g.fillRect(12,0,8,HS.hl+2);else{g.fillRect(0,0,32,HS.hl);g.fillRect(0,HS.hl,3,3);g.fillRect(29,HS.hl,3,3);}}});
  const stubC=shadeHex(hairC,HS.fade==='scalp'?-.3:-.08);
  const scalp=(isTop)=>pixTex(T,16,16,(g)=>{for(let py=0;py<16;py++)for(let px=0;px<16;px++){const t=isTop?(HS.hlc&&(px<5||px>10)?.7:1):1-(py+.5)/16;
    g.fillStyle=hasHair&&fadeAt(HS,t,px,py)?((px*7+py*3)%5?stubC:hairC):skinC;g.fillRect(px,py,1,1);}});
  const sideM=M('#ffffff',{map:scalp(false),roughness:.7}),topM=M('#ffffff',{map:scalp(true),roughness:.7});
  const headMats=[sideM,sideM,topM,skin,M('#ffffff',{map:face,roughness:.6}),sideM];
  const head=new T.Mesh(new T.BoxGeometry(hs,hs,hs*.94),headMats);head.position.set(0,H,0);fig.add(head);
  [-1,1].forEach(sd=>box(fig,.05,.1,.08,skin,sd*(hs/2+.02),H-.01,0));
  /* pelo: un vóxel instanciado por celda con su propio matiz para que se lea la textura del corte */
  const vx=hairVox(st,hs);
  if(vx.length){const v=hs/12,im=new T.InstancedMesh(new T.BoxGeometry(v,v,v),new T.MeshStandardMaterial({color:0xffffff,roughness:.78}),vx.length),m4=new T.Matrix4(),col=new T.Color();
    vx.forEach((q,i)=>{m4.makeTranslation(q.x,H+q.y,q.z);im.setMatrixAt(i,m4);col.set(hairC).offsetHSL(0,0,q.k);im.setColorAt(i,col);});
    im.instanceMatrix.needsUpdate=true;if(im.instanceColor)im.instanceColor.needsUpdate=true;fig.add(im);}
  /* barba */
  const bd=+L.beard||0,fz=hdp+.012;
  if(bd===1)box(fig,.12,.08,.04,hair,0,H-.17,fz);
  else if(bd===2){box(fig,hs+.01,.1,.04,M(hairC,{roughness:.9,transparent:true,opacity:.85}),0,H-.16,fz);[-1,1].forEach(sd=>box(fig,.04,.16,.2,hair,sd*(hw+.005),H-.12,.08));}
  else if(bd===3){box(fig,hs+.02,.16,.05,hair,0,H-.14,fz);box(fig,.2,.06,.05,hair,0,H-.06,fz+.005);[-1,1].forEach(sd=>box(fig,.05,.26,.24,hair,sd*(hw+.01),H-.08,.06));}
  /* cinta */
  if(hasAcc(L,1))box(fig,hs+.11,.05,hs*.94+.11,neon,0,H+.1,0);
  if(hasAcc(L,12)){const w=M('#F1E9FF',{roughness:.5});box(fig,hs+.04,.04,.07,w,0,H+.285,.04);[-1,1].forEach(sd=>box(fig,.03,.2,.07,w,sd*(hw+.025),H+.18,.04));}
  if(hasAcc(L,5)){const fr=M('#151515',{metalness:.3,roughness:.4}),ln=new T.MeshStandardMaterial({color:new T.Color('#3DE0C2'),emissive:new T.Color('#3DE0C2'),emissiveIntensity:.35,roughness:.2,transparent:true,opacity:.85});
    box(fig,hs+.05,.035,.03,fr,0,H+.05,hdp+.02);[-1,1].forEach(sd=>{box(fig,.15,.075,.015,ln,sd*.12,H+.005,hdp+.03);box(fig,.02,.03,.26,fr,sd*(hw+.015),H+.03,hdp-.12);});}
  if(hasAcc(L,9)){const mk=M('#111111',{roughness:.35});box(fig,.36,.04,.025,mk,0,H+.075,hdp+.02);box(fig,.36,.04,.025,mk,0,H-.065,hdp+.02);box(fig,.06,.18,.03,mk,0,H+.005,hdp+.024);[-1,1].forEach(sd=>box(fig,.04,.18,.025,mk,sd*.17,H+.005,hdp+.02));}
  if(hasAcc(L,6)){const g=M('#E8B83A',{metalness:.6,roughness:.3});[-1,1].forEach(sd=>box(fig,.035,.05,.035,g,sd*(hw+.02),H-.07,.02));}
  const h=(+L.height||180)/180;fig.scale.set(.96+(h-1)*.6,h,.96+(h-1)*.6);}
/* ---------- partido en directo: motor 3D del modo Clubes + estrella sobre tu futbolista ---------- */
const MYIDX={POR:0,DEF:2,MED:6,EXT:8,DEL:9};
function squadNames(id,exclude){if(CLUBS[id]&&CLUBS[id].natN)return natNames(CLUBS[id].natN,exclude);const n=SEED.filter(p=>p.club===id&&p.pos!=='POR').map(p=>p.name).filter(x=>x!==exclude);return n.length?n:['un compañero'];}
function liveMatch(){
  const e=nextEv(),r=role(),opp=club(e.opp),youth=P.squad==='cantera',c=club(P.club);
  const min=minutesFor(r,e),oppS=youth?clamp(opp.base-14,40,70):opp.base,from=min&&min<90?90-min:0;
  const n=min?clamp(Math.round(min/90*({POR:3,DEF:2,MED:2,EXT:3,DEL:3}[P.pos])+R(0,1)),1,4):0;
  const mom=makeMoments(n).map(m=>({...m,m:clamp(from+Math.round((m.m/90)*(90-from)),from+1,89)})).sort((a,b)=>a.m-b.m);
  UI.jm={e,r,min,oppS,youth,interactive:true,mom,i:0,res:{g:0,a:0,ok:0,ko:0,saves:0,log:[]}};
  const mySide=e.home?'h':'a',hId=e.home?P.club:e.opp,aId=e.home?e.opp:P.club,H=club(hId),A=club(aId);
  const own=(youth?clamp(c.base-14,40,72):c.base)+(min?(ovr()-c.base)*.07*min/90:0)+(e.home?2:-1);
  // goles que no dependen de tu decisión: compañeros y rival
  const ev=[];const mates=squadNames(P.club),rivals=squadNames(e.opp);
  const other=poisson(xg(own-oppS)*.72),conc=poisson(xg(oppS-own));
  for(let i=0;i<other;i++)ev.push({m:R(3,89),kind:'goal',side:mySide,n:youth?'un compañero del juvenil':pk(mates)});
  for(let i=0;i<conc;i++)ev.push({m:R(3,89),kind:'goal',side:mySide==='h'?'a':'h',n:youth?'un juvenil rival':pk(rivals)});
  for(let i=0;i<R(2,5);i++)ev.push({m:R(3,89),kind:'chance',side:ch(.5)?'h':'a'});
  mom.forEach(m=>ev.push({m:m.m,kind:'moment',mo:m}));if(P.captain&&min>0)ev.push({m:R(Math.max(from+5,30),80),kind:'cap'});
  if(from)ev.push({m:from,kind:'enter'});
  ev.sort((a,b)=>a.m-b.m||(a.kind==='moment'?1:-1));
  const L={ev,mySide,hId,aId,hg:0,ag:0,m:0,speed:1,timer:null,paused:false,M:null,on:min>0&&!from,stop:R(1,5)};UI.jl=L;
  const use3d=typeof hasGL15==='function'&&hasGL15()&&!!window.THREE&&!reduced();
  modal(`<div class="hd j-mhd"><h3>${evLabel(e)}</h3><p class="j-hint" style="margin:4px 0 0">${e.home?'En casa':'Fuera'} · ${esc(H.stadium||'')}</p></div>
   <div class="bd"><div class="scoreboard${use3d?' sb-3d':''}"><div class="t">${crest(H,48)}<b>${youth?'Juvenil ':''}${esc(H.name)}</b></div><div><div class="digits" id="sc">0-0</div><div class="clock" id="clk">0'</div></div><div class="t">${crest(A,48)}<b>${youth?'Juvenil ':''}${esc(A.name)}</b></div></div>
   ${use3d?`<div class="bc15" id="bc15"><div class="bc15-slot" id="bc15-slot"></div><div class="bc15-bug" aria-hidden="true"><span class="bug-t" style="--k:${H.c1}">${esc(H.short)}</span><span class="bug-s" id="bc-sc">0–0</span><span class="bug-t" style="--k:${A.c1}">${esc(A.short)}</span><span class="bug-c" id="bc-clk">0'</span></div><div class="bc15-side" aria-hidden="true"><span class="bc15-live">Directo</span><span class="j-star-k">★ ${esc(P.last)}</span></div><button type="button" class="bc15-rep" id="bc-rep" data-act="skipRep" hidden>Repetición <small>Saltar</small></button><div class="bc15-l3" id="bc-l3" hidden></div><div class="j-dec j-dec-3d" id="jdec" hidden></div></div>`:'<div class="j-dec" id="jdec" hidden></div>'}
   <div class="feed" id="feed" aria-live="polite"></div></div>
   <div class="ft"><button class="btn" data-act="jLiveSpeed" id="jspd">Velocidad ×2</button><button class="btn" data-act="jLiveSim">Simular el resto</button></div>`);
  const mr=document.querySelector('#modal-root .modal');if(mr&&use3d)mr.classList.add('m15');
  if(use3d){const prevS=S;try{S={club:'__jugador__',season:P.season,week:P.week,cap:0};
      L.M=match3D15(document.getElementById('bc15-slot'),{r:{h:hId,a:aId},home:e.home,cup:e.type!=='liga'});}catch(err){console.error(err);L.M=null;}finally{S=prevS;}
    UI.m15=L.M;if(L.M)addStar(L.M);else{const b=document.getElementById('bc15');if(b)b.remove();}}
  feed(`Arranca el partido${from?'. Empiezas en el banquillo':r==='Titular'||r==='Capitán'?'. Sales de titular':''}.`);
  liveRun();}
/* los muñecos del motor miden ~0,46 y tu futbolista cúbico ~0,65 (2,18 × 0,3): en tus partidos todos se dibujan a tu escala */
const FIG_K=2.18*.3/.46;
function bigFigures(M){const F=M&&M.F;if(!F||F.big||!F.sh||!F.sh.parent)return;F.big=1;const k=FIG_K,ch=F.sh.parent.children,i0=ch.indexOf(F.sh);
  /* las piezas de los muñecos son mallas instanciadas seguidas (torso, piernas, brazos, cabeza…): se agrandan y las posiciones se dividen por lo mismo */
  for(let j=i0;j>=0&&j<ch.length&&ch[j].isInstancedMesh&&ch[j].count===F.n;j++)ch[j].scale.setScalar(k);
  const set=F.set;F.set=function(i,x,z,ry,run,t){return set.call(F,i,x/k,z/k,ry,run,t);};}
function addStar(M){bigFigures(M);const w=M.w,T=w.T,idx=MYIDX[P.pos]+(UI.jl.mySide==='h'?0:11);
  const cv=document.createElement('canvas');cv.width=cv.height=128;const g=cv.getContext('2d');
  const star=(r1,r2)=>{g.beginPath();for(let i=0;i<10;i++){const a=-Math.PI/2+i*Math.PI/5,r=i%2?r2:r1;g.lineTo(64+Math.cos(a)*r,64+Math.sin(a)*r);}g.closePath();};
  g.shadowColor='#B57BFF';g.shadowBlur=26;star(50,21);g.fillStyle='#C99BFF';g.fill();g.shadowBlur=0;star(40,17);g.fillStyle='#F3E6FF';g.fill();
  const tex=new T.CanvasTexture(cv),sp=new T.Sprite(new T.SpriteMaterial({map:tex,transparent:true,depthTest:false,toneMapped:false,fog:false}));sp.scale.set(1.25,1.25,1.25);sp.renderOrder=999;w.root.add(sp);
  const ring=new T.Mesh(new T.RingGeometry(.42,.56,40).rotateX(-Math.PI/2),new T.MeshBasicMaterial({color:'#D9B3FF',transparent:true,opacity:.9,depthWrite:false,toneMapped:false,fog:false}));ring.renderOrder=998;w.root.add(ring);
  w.disp&&w.disp.push(tex,ring.geometry);myFigure(M,idx);
  const tick=w.tick;w.tick=(dt,t)=>{tick(dt,t);const p=M.P&&M.P[idx],vis=!!(p&&UI.jl&&UI.jl.on);sp.visible=ring.visible=vis;if(!vis)return;const k=t/1000;
    sp.position.set(p.x,2.6+Math.sin(k*3)*.12,p.z);ring.position.set(p.x,.05,p.z);ring.material.opacity=.55+Math.sin(k*4)*.3;};}
function feed(t,hot){const f=document.getElementById('feed');if(!f)return;const p=document.createElement('p');p.textContent=(UI.jl?UI.jl.m+"' ":'')+t;if(hot)p.className='j-hot';f.prepend(p);}
function score(){const L=UI.jl,s=`${L.hg}-${L.ag}`;const a=document.getElementById('sc'),b=document.getElementById('bc-sc'),k=document.getElementById('clk'),kb=document.getElementById('bc-clk');if(a)a.textContent=s;if(b)b.textContent=`${L.hg}–${L.ag}`;const cl=L.m>90?`90+${L.m-90}'`:`${L.m}'`;if(k)k.textContent=cl;if(kb)kb.textContent=cl;}
function liveRun(){const L=UI.jl;clearInterval(L.timer);L.timer=setInterval(liveStep,Math.round(380/L.speed));}
function livePause(){clearInterval(UI.jl.timer);UI.jl.timer=null;}
function liveGoal(side,name,assist,done){const L=UI.jl;if(side==='h')L.hg++;else L.ag++;score();
  const mine=side===L.mySide;feed(`¡Gol de ${name}!${assist?` Asistencia de ${assist}.`:''}`,mine);
  if(L.M&&!L.fast){livePause();L.M.goal({side,n:name,m:L.m,an:assist||'',...goalIdx(side,name,assist)},()=>{done&&done();if(!UI.jl.decide&&!UI.jl.ended)liveRun();});}else done&&done();}
function liveStep(){const L=UI.jl;if(!L||L.ended)return;if(!document.getElementById('feed')){clearInterval(L.timer);return;}
  if(L.M&&L.M.busy)return;
  L.m++;score();
  if(L.m>=90+L.stop){liveEnd();return;}
  while(L.ev.length&&L.ev[0].m<=L.m){const x=L.ev.shift();
    if(x.kind==='enter'){L.on=true;feed('Entras al campo. ¡A por ello!',true);L.M&&L.M.l3&&L.M.l3(`<span class="l3-tag">Cambio</span><b>Entra ${esc(P.last)}</b>`,2200);}
    else if(x.kind==='chance'){L.M&&L.M.chance&&L.M.chance({side:x.side});}
    else if(x.kind==='goal'){liveGoal(x.side,x.n);if(L.M&&!L.fast)return;}
    else if(x.kind==='cap'){if(!L.on||L.fast)continue;livePause();showCap();return;}
    else if(x.kind==='moment'){if(L.fast){autoMoment(x.mo);continue;}livePause();showDecision(x.mo);return;}}}
function autoMoment(mo){const pref={DEL:{Chutar:1,Pasar:.55,Regatear:.75},EXT:{Chutar:.7,Pasar:.95,Regatear:.95},MED:{Chutar:.5,Pasar:1.15,Regatear:.7},DEF:{},POR:{}}[P.pos];
  const j=mo.opts.map((o,j)=>[j,chanceP(o[1],o[2])*(pref[o[0]]??1)]).sort((a,b)=>b[1]-a[1])[0][0];liveResolve(mo,j,true);}
function showDecision(mo){const L=UI.jl,d=document.getElementById('jdec');if(!d)return;L.decide=mo;
  L.M&&L.M.l3&&L.M.l3(`<span class="l3-tag">Tu jugada</span><b>${esc(P.last)}</b><em>${L.m}'</em>`,2400);
  if(mo.kind==='fp'){d.classList.add('fp-on');d.innerHTML=`<p class="j-sit"><b class="num">${L.m}'</b> ${mo.text}</p><div id="fpbox"></div>`;d.hidden=false;startFp(d.querySelector('#fpbox'),mo.fk,out=>{if(mo.done)return;mo.out=out;liveResolve(mo,0);});return;}
  d.innerHTML=`<p class="j-sit"><b class="num">${L.m}'</b> ${mo.text}</p><div class="j-opts">${mo.opts.map((o,j)=>`<button class="j-op" data-act="jLiveMo" data-j="${j}"><b>${o[0]}</b><small>${(P.pos==='POR'?ANP:AN)[o[1]]} · ${Math.round(chanceP(o[1],o[2])*100)} %</small></button>`).join('')}</div>`;d.hidden=false;d.querySelector('button')?.focus({preventScroll:true});}
function liveResolve(mo,j,silent){if(mo.done)return;mo.done=true;const L=UI.jl,R0=UI.jm.res,g0=R0.g,a0=R0.a,c0=R0.conc||0;const r=resolveMoment(mo,j);if(R0.redMin&&!L.red){L.red=true;L.on=false;L.ev=L.ev.filter(x=>x.kind!=='moment'&&x.kind!=='cap');L.M&&L.M.l3&&L.M.l3('<span class="l3-tag">Roja</span><b>'+esc(P.last)+'</b>',2400);}
  const d=document.getElementById('jdec');if(d){d.hidden=true;d.innerHTML='';d.classList.remove('fp-on');}L.decide=null;feed(r.t,R0.g>g0||R0.a>a0);
  const after=()=>{if(!L.ended&&!L.fast)liveRun();};
  if(R0.g>g0)liveGoal(L.mySide,P.last,null,after);
  else if(R0.a>a0)liveGoal(L.mySide,R0.mate||pk(squadNames(L.myId||P.club,P.last)),P.last,after);
  else if((R0.conc||0)>c0)liveGoal(L.mySide==='h'?'a':'h',pk(squadNames(L.mySide==='h'?L.aId:L.hId)),null,after);
  else if(!silent)after();}
function liveEnd(){const L=UI.jl;if(L.ended)return;L.ended=true;clearInterval(L.timer);feed('Final del partido.');
  const myG=L.mySide==='h'?L.hg:L.ag,thG=L.mySide==='h'?L.ag:L.hg;UI.jm.pre={gf:myG,ga:thG};
  setTimeout(()=>{UI.m15=null;if(L.nat)natFinish();else finishMatch();},L.fast?0:900);}

/* ---------- ciudad: la ciudad de tu club en 3D, tu parcela y tu casa ---------- */
const HOUSE={
  estructura:['Solar vacío','Casa de una planta','Casa de dos plantas','Villa de diseño'],
  fachada:['Ladrillo visto','Pintura y estuco','Madera y piedra','Cristal y hormigón'],
  jardin:['Tierra','Césped','Jardín con árboles','Paisajismo con luces'],
  piscina:['Sin piscina','Piscina pequeña','Piscina con tumbonas','Piscina infinita'],
  garaje:['Sin garaje','Cochera','Garaje con coche','Garaje doble deportivo'],
  tecnologia:['Sin domótica','Placas solares','Casa inteligente','Neón y domótica total'],
};
const HPART={estructura:'Estructura',fachada:'Fachada',jardin:'Jardín',piscina:'Piscina',garaje:'Garaje',tecnologia:'Tecnología'};
const HW={estructura:1.4,fachada:.8,jardin:.6,piscina:1,garaje:.9,tecnologia:.8};
const citySize=id=>{const k=club(id);return clamp(((k?k.base:55)-52)/36-(k?k.tier:0)*.06,0,1);};
const cityName=id=>{const k=club(id);return k?k.name:'tu ciudad';};
function plotPrice(id){const k=club(id),b=k?k.base:55;return Math.round(12000*Math.pow(1.075,b-55)/500)*500;}
function upCost(id,part,lvl){return Math.round(plotPrice(id)*[.3,.65,1.3][lvl]*HW[part]/500)*500;}
const homeLevel=h=>h?Object.values(h.parts).reduce((a,b)=>a+b,0):0;
function hasHome(){return !!(P.home&&P.home.club===P.club);}
function sellHome(reason){if(!P.home)return;const v=Math.round(P.home.spent*.6);P.money+=v;P.homes=P.homes||[];P.homes.push({c:cname(P.home.club),lvl:homeLevel(P.home),s:seasonLabel(P.season),v});
  news(`${P.last} vende su casa en ${cname(P.home.club)} por ${eur(v)}${reason?' ('+reason+')':''}.`);P.home=null;}
function vCiudad(){const id=P.club,k=club(id),s=citySize(id),h=hasHome()?P.home:null,lvl=homeLevel(h),price=plotPrice(id);
  const kind=s>.75?'Gran metrópoli':s>.5?'Ciudad grande':s>.25?'Ciudad mediana':'Pueblo';
  const rows=h?Object.keys(HOUSE).map(p=>{const L=h.parts[p],max=L>=3,cost=max?0:upCost(id,p,L),can=!max&&P.money>=cost&&(p==='estructura'||h.parts.estructura>=1);
    return `<div class="j-hrow"><div><b>${HPART[p]}</b><small>${HOUSE[p][L]}${max?'':` → ${HOUSE[p][L+1]}`}</small></div><span class="j-pips" aria-label="Nivel ${L} de 3">${[1,2,3].map(i=>`<i class="${i<=L?'on':''}"></i>`).join('')}</span>${max?'<em class="j-neon">Al máximo</em>':`<button class="btn small${can?' primary':''}" data-act="jHouseUp" data-k="${p}" ${can?'':'disabled'}>${eur(cost)}</button>`}</div>`;}).join(''):'';
  return `<div class="j-eyebrow">${kind} · ${esc(LG[k.league].country)}</div><h2 class="j-h">Ciudad de ${esc(cityName(id))}</h2>
  <p class="muted" style="max-width:64ch">La ciudad de tu club, con su estadio y todas sus instalaciones. Tu parcela está en el barrio del club: arrastra para girar, usa la rueda para acercarte. ${P.squad==='cantera'?'Si subes al primer equipo te quedas en la misma casa.':'Si cambias de equipo, venderás tu casa y empezarás de cero en la nueva ciudad.'}</p>
  <div class="j-city"><div class="j-city3d"><div class="j-city-slot" id="jcity-slot"></div><div class="j-city-fb" hidden><p class="muted">Tu dispositivo no puede mostrar la ciudad en 3D.</p></div>
    <div class="j-city-ui"><button class="btn small" data-act="jCityView" data-k="city">Ver la ciudad</button><button class="btn small" data-act="jCityView" data-k="home">Ver mi parcela</button><button class="btn small" data-act="jCityView" data-k="stadium">Ver el estadio</button></div></div>
  <div class="j-col"><div class="j-panel j-house">${h?`<h3>Tu casa</h3><div class="j-kv"><div><small>Nivel</small><b class="num">${lvl} / 18</b></div><div><small>Invertido</small><b class="num">${eur(h.spent)}</b></div><div><small>Ahorros</small><b class="num">${eur(P.money)}</b></div></div>
    ${lvl>=18?'<p class="j-neon" style="margin:12px 0 0;font-weight:700">Casa moderna terminada.</p>':`<p class="j-hint">Mejora cada parte hasta tener una casa moderna. Primero la estructura: sin casa no hay piscina.</p>`}<div class="j-hlist">${rows}</div>`
    :`<h3>Tu parcela</h3><p>Una parcela en el barrio residencial de ${esc(cityName(id))}, con una casa sencilla para empezar.</p><div class="j-kv"><div><small>Precio</small><b class="num">${eur(price)}</b></div><div><small>Ahorros</small><b class="num">${eur(P.money)}</b></div></div>
    <div class="j-acts"><button class="btn primary" data-act="jHouseBuy" ${P.money>=price?'':'disabled'}>Comprar parcela y casa</button></div>${P.money<price?`<p class="j-hint">Te faltan ${eur(price-P.money)}. El salario entra cada semana.</p>`:''}<p class="j-hint">Sin casa propia vives de alquiler: tu moral lo nota.</p>`}</div>
   ${P.homes&&P.homes.length?`<div class="j-panel"><h3>Casas anteriores</h3>${P.homes.map(x=>`<p class="j-n"><b class="num">${x.s}</b>${esc(x.c)} · nivel ${x.lvl} · vendida por ${eur(x.v)}</p>`).join('')}</div>`:''}</div></div>${housePanel()}`;}

/* ---------- ciudad 3D: la misma ciudad del modo Clubes (todo al máximo) y tu parcela en el barrio del club ----------
   Dirección de arte: atardecer cálido del modo Clubes; tu casa es el único acento morado (neón de la parcela y
   detalles de domótica), para que el ojo la encuentre entre el resto de la ciudad. */
const HOME_PLOT='residencial';
let C3D=null,_cityCache=null;
function cityState(cid){if(_cityCache&&_cityCache.cid===cid)return _cityCache.st;
  const prev=S;let st=null;try{newGame(cid);st=S;if(typeof ensureFac==='function')ensureFac();}finally{S=prev;}
  st.fac=st.fac||{};
  Object.keys(FAC).forEach(k=>{st.fac[k]=FAC[k].lv.length-1;});st.fac[HOME_PLOT]=0;st.build={};st.lastAtt=st.cap;st.proj=null;
  _cityCache={cid,st};return st;}
const withCityS=(st,fn)=>{const p=S;S=st;try{return fn();}finally{S=p;}};
function unmountCity(){}
function mountCity(){const slot=document.getElementById('jcity-slot');if(!slot)return;
  const fb=()=>{const f=slot.parentElement.querySelector('.j-city-fb');if(f)f.hidden=false;};
  if(typeof view15!=='function'||typeof hasGL15!=='function'||!hasGL15()){fb();return;}
  const go=()=>{try{buildCity(slot);}catch(e){console.error(e);fb();}};
  if(!window.THREE){loadThree().then(ok=>{if(ok&&document.body.contains(slot))go();else fb();});return;}go();}
function buildCity(slot){const cid=P.club,st=cityState(cid);
  const w=view15('jcity',slot,{label:`Ciudad de ${cname(cid)} en 3D. Arrastra para girar, rueda para acercar.`,orbit:{r:240,th:.72,ph:.95,min:28,max:640,pan:340},exp:1.12});
  w.canvas.classList.add('cx-canvas');
  if(!w.jcity){const up=w.update;w.update=(dt,t)=>{const s=w.jcity&&w.jcity.st;if(!s)return up(dt,t);withCityS(s,()=>up(dt,t));};}
  if(!w.jcity||w.jcity.cid!==cid){withCityS(st,()=>{buildComplex(w);applyTod(w,'tarde');});w.jcity={cid,st,house:null};}
  const [cc,rr]=PLOT7[HOME_PLOT],[px,pz]=cellC(cc,rr);
  const fly=k=>{if(k==='home')w.ctl.fly(px,2,pz,46);else if(k==='stadium')w.ctl.fly(0,4,0,105);else w.ctl.reset();};
  const rebuildHouse=()=>{const J=w.jcity;if(J.house){w.root.remove(J.house);J.house.traverse(o=>{o.geometry&&o.geometry.dispose();if(o.material){o.material.map&&o.material.map.dispose();o.material.dispose();}});}
    const g=new w.T.Group();g.position.set(px,0,pz);w.root.add(g);J.house=g;buildHome(w.T,g,hasHome()?P.home.parts:null,P.cars);if(hasHome()&&P.pet)petMesh(w.T,g,P.pet.k);
    if(!J.petA&&w.anim){J.petA=1;w.anim.push((dt,t)=>{const hs=w.jcity&&w.jcity.house,p=hs&&hs.getObjectByName('pet');if(!p)return;const a=t/2600,dx=-Math.sin(a)*1.4,dz=Math.cos(a)*1.8;p.position.set(-2+Math.cos(a)*1.4,.2+Math.abs(Math.sin(t/160))*.04,3.5+Math.sin(a)*1.8);p.rotation.y=Math.atan2(-dz,dx);});}};
  rebuildHouse();C3D={fly,rebuildHouse};if(!w.jcity.flown){w.jcity.flown=true;w.ctl.st.r=300;fly('city');}w.W=0;if(typeof kick==='function')kick();}

/* ---- tu casa: de solar a mansión moderna (unidades del mundo: la parcela mide 19 × 19) ---- */
function buildHome(T,g,parts,cars){
  const M=(c,o={})=>new T.MeshStandardMaterial({color:new T.Color(c),roughness:.8,metalness:0,...o});
  const glow=(c,i=1.2)=>new T.MeshStandardMaterial({color:new T.Color(c),emissive:new T.Color(c),emissiveIntensity:i,roughness:.4});
  const box=(w_,h,d,m,x,y,z,ry)=>{const o=new T.Mesh(new T.BoxGeometry(w_,h,d),m);o.position.set(x,y,z);if(ry)o.rotation.y=ry;o.castShadow=o.receiveShadow=true;g.add(o);return o;};
  const cyl=(rt,rb,h,m,x,y,z,seg=12)=>{const o=new T.Mesh(new T.CylinderGeometry(rt,rb,h,seg),m);o.position.set(x,y,z);o.castShadow=true;g.add(o);return o;};
  const tree=(x,z,s=1,kind=0)=>{cyl(.12*s,.16*s,1.3*s,M('#5b3d27'),x,.65*s,z,6);const top=new T.Mesh(kind?new T.ConeGeometry(.9*s,2.4*s,8):new T.IcosahedronGeometry(1.05*s,1),M(kind?'#2d6b45':'#3f8a4f',{roughness:.9}));top.position.set(x,(kind?2.3:2.05)*s,z);top.castShadow=true;g.add(top);};
  /* base de la parcela: bordillo de piedra y neón morado discreto */
  box(18.6,.18,18.6,M('#b9b2a6'),0,.09,0);
  const edge=new T.LineSegments(new T.EdgesGeometry(new T.BoxGeometry(18.2,.02,18.2)),new T.LineBasicMaterial({color:0xC99BFF}));edge.position.y=.22;g.add(edge);
  if(!parts){box(17.6,.06,17.6,M('#7a6448',{roughness:1}),0,.2,0);
    for(let i=0;i<14;i++){const a=i/14*Math.PI*2;box(.12,1.1,.12,M('#9a8f80'),Math.cos(a)*8.4,.75,Math.sin(a)*8.4);}
    cyl(.07,.07,2.6,M('#8d8d8d'),0,1.3,6.8,6);const sign=box(3.4,1.5,.12,glow('#7b3fe0',.8),0,2.7,6.8);
    const cv=document.createElement('canvas');cv.width=256;cv.height=112;const x=cv.getContext('2d');x.fillStyle='#14082a';x.fillRect(0,0,256,112);x.strokeStyle='#C99BFF';x.lineWidth=6;x.strokeRect(6,6,244,100);x.fillStyle='#F1E3FF';x.font='900 40px Impact,sans-serif';x.textAlign='center';x.fillText('TU PARCELA',128,52);x.font='700 22px sans-serif';x.fillText('Compra y construye',128,86);
    const tex=new T.CanvasTexture(cv);const face=new T.Mesh(new T.PlaneGeometry(3.3,1.45),new T.MeshBasicMaterial({map:tex}));face.position.set(0,2.7,6.87);g.add(face);return;}
  const st=parts.estructura,fa=parts.fachada,ja=parts.jardin,pi=parts.piscina,ga=parts.garaje,te=parts.tecnologia;
  /* suelo: tierra → césped → jardín → paisajismo */
  box(17.6,.06,17.6,M(ja>=1?'#4f8f45':'#7a6448',{roughness:1}),0,.2,0);
  box(2,.07,7.5,M('#d8d2c6'),1.5,.24,5.4);
  /* materiales de fachada por nivel */
  const wall=[M('#a65a44',{roughness:.95}),M('#efe9df',{roughness:.85}),M('#8a6142',{roughness:.7}),M('#f4f4f2',{roughness:.5})][fa];
  const trim=[M('#e8e0d2'),M('#c9c1b4'),M('#5e646b',{metalness:1,roughness:.4}),M('#26292e',{metalness:1,roughness:.35})][fa];
  const glass=new T.MeshStandardMaterial({color:new T.Color('#9fc4e8'),roughness:.05,metalness:.9,emissive:new T.Color('#ffd8a0'),emissiveIntensity:fa>=3?.55:.35,transparent:true,opacity:.85});
  const win=(x,y,z,w_,h,ry=0)=>{const o=box(w_,h,.08,glass,x,y,z,ry);o.castShadow=false;box(w_+.16,.12,.14,trim,x,y-h/2-.04,z+(ry?0:.02),ry);};
  if(st===1){/* casa básica: una planta y tejado a dos aguas */
    box(7,2.8,5.4,wall,-1,1.65,-2.4);
    const sh=new T.Shape();sh.moveTo(-3.9,0);sh.lineTo(3.9,0);sh.lineTo(0,2);sh.lineTo(-3.9,0);
    const roof=new T.Mesh(new T.ExtrudeGeometry(sh,{depth:6.2,bevelEnabled:false}),M('#7a3b2e',{roughness:.9}));roof.position.set(-1,3.05,-5.5);roof.castShadow=true;g.add(roof);
    box(.6,1.6,.6,M('#8c8279'),.6,4.2,-3);win(-3.1,1.8,.32,1.4,1.1);win(1.2,1.8,.32,1.4,1.1);box(1.1,2.1,.1,M('#4a2f22'),-1,1.3,.33);
    box(2.4,.18,1.4,M('#bfb6a8'),-1,.33,1.1);}
  else if(st===2){/* dos plantas, tejado a cuatro aguas y balcón */
    box(8.4,2.8,6,wall,-1,1.65,-2.4);box(8.4,2.8,6,wall,-1,4.45,-2.4);box(8.8,.22,6.4,trim,-1,3.05,-2.4);
    const hip=new T.Mesh(new T.ConeGeometry(6.4,2.3,4,1),M('#4a4f57',{roughness:.7}));hip.rotation.y=Math.PI/4;hip.scale.set(1,1,.72);hip.position.set(-1,7.0,-2.4);hip.castShadow=true;g.add(hip);
    [-3.6,-1,1.6].forEach(x=>{win(x,1.8,.62,1.5,1.3);win(x,4.6,.62,1.5,1.3);});box(1.2,2.2,.1,M('#2e2a28'),-1,1.3,.64);
    box(4,.16,1.4,trim,-1,3.2,1.3);box(4,.9,.06,new T.MeshStandardMaterial({color:'#cfe2ff',transparent:true,opacity:.35,roughness:.05}),-1,3.7,1.98);}
  else if(st>=3){/* mansión moderna: volúmenes en voladizo, cristal, madera y cubiertas planas */
    box(11,3,7,wall,-1.2,1.7,-2.6);
    win(-1.2,1.75,.94,9.4,2.4);
    box(9.4,3,5.6,M(fa>=2?'#3b2a20':'#e8e6e2',{roughness:.6}),.6,4.85,-3.6);
    for(let i=0;i<14;i++)box(.18,2.8,.1,M('#a8754e',{roughness:.65}),-3.9+i*.6,4.85,-.77);
    win(3.6,4.85,-.75,2.6,2.4);box(12.2,.26,8.2,trim,-1.2,3.3,-2.4);box(10.4,.26,6.8,trim,.6,6.45,-3.4);
    box(3.6,.08,3.6,M('#d9d3c8'),-4.6,6.62,-4.4);box(3.6,.9,.06,new T.MeshStandardMaterial({color:'#cfe2ff',transparent:true,opacity:.35}),-4.6,7.05,-2.62);
    for(let s=0;s<6;s++)box(1.4,.2,.5,M('#cfc8bc'),5.3,.4+s*.5,-1.2-s*.5);
    box(1.6,6.2,1.6,M('#2b2e33',{metalness:1,roughness:.4}),-6.4,3.2,-2.4);}
  if(st>=1){/* luz interior para el atardecer */const L=new T.PointLight(0xffc98a,.9,18);L.position.set(-1,2.5,-1);g.add(L);}
  /* jardín */
  if(ja>=2){[[-7,-7.5],[-4,-7.8],[3,-7.6],[6.5,-7],[7.5,-3]].forEach(([x,z],i)=>tree(x,z,1,i%2));for(let i=0;i<12;i++)box(1.3,.7,.7,M('#2f6b3f',{roughness:.95}),-7.6+i*1.38,.55,7.9);}
  if(ja>=3){for(let i=0;i<7;i++){const p=new T.Mesh(new T.SphereGeometry(.09,8,6),glow('#ffe2a8',2));p.position.set(.6,.32,1.6+i*.9);g.add(p);const q=p.clone();q.position.x=2.4;g.add(q);}
    tree(7.3,6.8,1.3,0);tree(-7.4,6.6,1.2,1);}
  /* piscina */
  if(pi>=1){const w_=pi>=3?7:4.2,d=pi>=3?3:2.6,x=pi>=3?4.2:5,z=pi>=3?4.6:4.8;
    box(w_+.6,.24,d+.6,M('#e9e4da'),x,.3,z);
    const water=new T.Mesh(new T.BoxGeometry(w_,.1,d),new T.MeshStandardMaterial({color:'#2fc0e6',emissive:new T.Color('#1aa6d6'),emissiveIntensity:pi>=3?.9:.45,roughness:.05,metalness:.1}));water.position.set(x,.43,z);g.add(water);
    if(pi>=2){box(w_+3,.12,1.6,M('#a8754e',{roughness:.7}),x,.32,z-d/2-1.2);for(let i=0;i<3;i++)box(.7,.25,1.6,M('#f2efe8'),x-w_/2+1+i*1.6,.52,z-d/2-1.2);
      cyl(.05,.05,2,M('#d9d3c8'),x+w_/2,1.3,z-d/2-1.2,6);const um=new T.Mesh(new T.ConeGeometry(1.2,.5,8),M('#f2efe8'));um.position.set(x+w_/2,2.3,z-d/2-1.2);g.add(um);}
    if(pi>=3){const spa=new T.Mesh(new T.CylinderGeometry(1,1,.3,20),new T.MeshStandardMaterial({color:'#5fd6f2',emissive:new T.Color('#3ab8e0'),emissiveIntensity:.9}));spa.position.set(x-w_/2-1.4,.45,z);g.add(spa);
      const L=new T.PointLight(0x7fe0ff,1,9);L.position.set(x,1.2,z);g.add(L);}}
  /* garaje */
  const car=(x,z,col)=>{const b=box(1.9,.62,4,M(col,{roughness:.25,metalness:1}),x,.62,z);const c=box(1.6,.5,2,M('#1a1c20',{roughness:.1,metalness:1}),x,1.15,z-.2);[[-.9,-1.3],[.9,-1.3],[-.9,1.3],[.9,1.3]].forEach(([dx,dz])=>{const wh=new T.Mesh(new T.CylinderGeometry(.34,.34,.24,14),M('#111'));wh.rotation.z=Math.PI/2;wh.position.set(x+dx,.36,z+dz);g.add(wh);});};
  if(ga===1){box(3.6,.16,5,M('#6c7078'),-6.3,2.6,2.4);[[-7.9,.2],[-4.7,.2],[-7.9,4.6],[-4.7,4.6]].forEach(([x,z])=>cyl(.08,.08,2.5,M('#9a9a9a'),x,1.3,z,6));}
  if(ga>=2){box(ga>=3?7.2:4,2.8,5.4,wall,ga>=3?-5.6:-6.3,1.6,3.4);box(ga>=3?6.4:3.4,2.2,.08,M('#3b3f46',{metalness:1,roughness:.5}),ga>=3?-5.6:-6.3,1.4,6.12);if(!(cars&&cars.length)){car(-6.3,9.2-0.6*0,ga>=3?'#7a2ee0':'#d7d9dd');if(ga>=3)car(-3,8.9,'#111216');}}
  if(cars&&cars.length)homeCars(T,g,M,glow,cars);
  /* tecnología */
  const roofTop=st===1?4.1:st===2?6.1:6.6;
  if(te>=1&&st>=1){for(let i=0;i<4;i++){const p=box(1.3,.06,1.9,M('#1c2c5a',{metalness:1,roughness:.25}),(st>=3?2:-2.6)+i*1.45,roofTop+.15,st>=3?-4.4:-3.4);p.rotation.x=st>=3?-.2:0;}}
  if(te>=2){[[-6,6.6],[1.5,1],[7,1]].forEach(([x,z])=>{const L=new T.SpotLight(0xffe0b0,1.2,10,.6,.6);L.position.set(x,.3,z);L.target.position.set(x,5,z-2);g.add(L);g.add(L.target);});}
  if(te>=3&&st>=1){const n=glow('#b57bff',2.2);box(st>=3?12.2:8.8,.08,.08,n,st>=3?-1.2:-1,st>=3?3.46:3.2,st>=3?1.72:.65);if(st>=3)box(10.4,.08,.08,n,.6,6.6,-.02);
    const L=new T.PointLight(0xb57bff,1.1,14);L.position.set(-1,2,3);g.add(L);box(.4,1.4,.4,M('#e8e8e8'),-2.8,.9,6.6);box(.3,.3,.06,glow('#7bff9a',1.5),-2.8,1.3,6.82);}
}

/* ====== ampliación: equipaciones, celebraciones, álbum de cartas, química, rasgos, posiciones, momentos en primera
   persona, familia (y tu hijo futbolista), garaje, inversiones y carrera de entrenador tras la retirada ====== */

/* ---------- equipaciones ---------- */
const KITS={local:'Local',visitante:'Visitante',tercera:'Tercera',seleccion:'Selección'};
const NATK={'España':['#C8102E','#FFC72C','#0B2A6B'],'Argentina':['#75AADB','#FFFFFF','#14141A'],'Brasil':['#FFDC02','#009739','#1C3F94'],'Francia':['#14256B','#FFFFFF','#FFFFFF'],'Inglaterra':['#F4F4F6','#0B1E5B','#0B1E5B'],'Portugal':['#A2192D','#0B6B3A','#A2192D'],'Alemania':['#F4F4F6','#141414','#141414'],'Italia':['#1E5BC6','#FFFFFF','#FFFFFF'],'Países Bajos':['#F36C21','#14256B','#F36C21'],'Bélgica':['#C8102E','#FFD100','#C8102E'],'Croacia':['#F4F4F6','#D7141A','#1C3F94'],'Uruguay':['#5CB3E6','#FFFFFF','#14141A'],'Colombia':['#FCD116','#003893','#003893'],'Marruecos':['#C1272D','#006233','#006233'],'Senegal':['#F4F4F6','#00853F','#F4F4F6'],'México':['#006847','#FFFFFF','#FFFFFF'],'Estados Unidos':['#F4F4F6','#0A3161','#0A3161'],'Japón':['#1B2C6B','#FFFFFF','#1B2C6B'],'Chile':['#D52B1E','#0039A6','#0039A6'],'Arabia Saudí':['#F4F4F6','#006C35','#006C35']};
function kitOf(L){if(L.kitC)return L.kitC;const c=L.club&&club(L.club),k=L.kit||'local';
  if(k==='seleccion'&&NATK[L.nat]){const n=NATK[L.nat];return{s:n[0],t:n[1],p:n[2],m:n[0]};}
  if(!c)return{s:'#6B2BD9',t:'#E4CCFF',p:'#1A0F33',m:'#F1E9FF'};
  if(k==='visitante')return{s:c.c2,t:c.c1,p:c.c1,m:c.c2};
  if(k==='tercera')return{s:'#16101F',t:'#C99BFF',p:'#16101F',m:'#2A1A45'};
  return{s:c.c1,t:c.c2,p:c.c2,m:c.c1};}

/* ---------- celebraciones: se eligen en Aspecto, se ven en el modelo 3D y aparecen en cada gol ---------- */
const CELEB=[['Puño al cielo',0],['De rodillas',0],['Corazón con las manos',0],['El avión',0],['Silencio a la grada',20],['El baile',35],['Salto y giro',50],['Voltereta',70]];
const celebName=()=>CELEB[(P&&P.celeb)||0][0];
function celebPose(G,fig,id,u){const aL=fig.getObjectByName('armL'),aR=fig.getObjectByName('armR'),s=Math.sin,e=Math.min(1,u/.3),k=e*(u>2.7?Math.max(0,1-(u-2.7)/.5):1);
  let py=0,pz=0,rx=0,rz=0,L=[0,-.05],Rr=[0,.05];
  switch(id){
    case 0:L=[0,-.2];Rr=[-2.95,.12];py=Math.abs(s(u*6))*.14;break;
    case 1:L=[-.35,-1.3];Rr=[-.35,1.3];rx=-.3;py=-.3;pz=Math.min(u,.7)*.7;break;
    case 2:L=[-2.15,.45];Rr=[-2.15,-.45];py=Math.abs(s(u*3))*.04;break;
    case 3:L=[0,-1.5];Rr=[0,1.5];rz=s(u*4)*.25;G.rotY+=.035*k;break;
    case 4:L=[0,-.1];Rr=[-2.55,-.6];break;
    case 5:{const b=s(u*9);L=[-1.3-b*.9,-.5];Rr=[-1.3+b*.9,.5];py=Math.abs(b)*.09;G.rotY+=s(u*4.5)*.02;break;}
    case 6:{const q=clamp(u/1.1,0,1);py=u<1.1?s(q*Math.PI)*.65:0;if(u<1.1)G.rotY+=Math.PI*2/66;L=[0,u<1.1?-.4:-.8];Rr=[0,u<1.1?.4:.8];break;}
    case 7:{const q=clamp((u-.15)/.85,0,1),th=-q*Math.PI*2;fig.position.set(0,s(q*Math.PI)*.9+1-Math.cos(th),-Math.sin(th));fig.rotation.x=th;fig.rotation.z=0;
      if(aL){aL.rotation.x=-2.6*k;aL.rotation.z=-.2*k;}if(aR){aR.rotation.x=-2.6*k;aR.rotation.z=.2*k;}return;}}
  fig.position.set(0,py*k,pz*k);fig.rotation.x=rx*k;fig.rotation.z=rz*k;
  if(aL){aL.rotation.x=L[0]*k;aL.rotation.z=L[1]*k;}if(aR){aR.rotation.x=Rr[0]*k;aR.rotation.z=Rr[1]*k;}}
function playCeleb(){if(G3D){G3D.rotY=0;G3D.celeb={id:(lookSrc().celeb)||0,t0:performance.now()};}}
function celebFx(e){const id=P.celeb||0;if(id===4&&!e.home){P.rep.polemico+=.4;P.fame=clamp(P.fame+.6,0,100);}else if(id===2)P.rep.humilde+=.15;else if(id>=5)P.rep.mediatico+=.2;}
function lookExtra(src){
  return `<div class="j-grp"><h4>Equipación</h4><div class="j-chips" role="radiogroup" aria-label="Equipación">${Object.entries(KITS).map(([k,l])=>{const dis=k==='seleccion'&&!P.sel.caps,on=(src.kit||'local')===k;return `<button class="j-chip${on?' on':''}" role="radio" aria-checked="${on}" data-act="jKit" data-k="${k}" ${dis?'disabled title="Debuta con la absoluta para desbloquearla"':''}>${l}${dis?' · al debutar':''}</button>`;}).join('')}</div></div>
   <div class="j-grp"><h4>Celebración de gol</h4><div class="j-chips" role="radiogroup" aria-label="Celebración de gol">${CELEB.map(([l,f],i)=>{const lock=P.fame<f,on=(src.celeb||0)===i;return `<button class="j-chip${on?' on':''}" role="radio" aria-checked="${on}" data-act="jCelebSet" data-k="${i}" ${lock?'disabled':''}>${l}${lock?` · fama ${f}`:''}</button>`;}).join('')}</div>
   <button class="btn small" data-act="jCeleb" style="margin-top:10px">Ver celebración en 3D</button></div>`;}
function chipOn(el){const g=el&&el.closest('[role=radiogroup]');if(g)g.querySelectorAll('[role=radio]').forEach(b=>{const on=b===el;b.classList.toggle('on',on);b.setAttribute('aria-checked',String(on));});}

/* ---------- álbum de cartas de temporada ---------- */
const CARDT={debut:'Debut',bronce:'Bronce',plata:'Plata',oro:'Oro',forma:'En forma',campeon:'Campeón',tots:'Equipo de la temporada',balon:'Balón de Oro',icono:'Icono'};
function snap(){return{name:P.name,last:P.last,num:P.num,pos:P.pos,club:P.club,nat:P.nat,at:{...P.at},skin:P.skin,hair:P.hair,hairc:P.hairc,beard:P.beard,boots:P.boots,acc:P.acc,accs:accsOf(P),socks:P.socks||0,bootm:P.bootm||0,kit:P.kit};}
function addCard(type,label){P.cards=P.cards||[];const c={t:type,s:label||seasonLabel(P.season),o:ovr(),p:snap()};P.cards.push(c);news(`Nueva carta para tu álbum: ${CARDT[type]} · ${c.o}.`,type==='bronce'||type==='plata'?'':'hot');return c;}
function seasonCard(n,o){const sl=seasonLabel(P.season),aw=P.awards.filter(a=>a.s===sl).map(a=>a.n),tt=P.titles.filter(t=>t.s===sl).length;
  addCard(aw.includes('Balón de Oro')?'balon':aw.includes('Once ideal de la temporada')?'tots':tt?'campeon':n>=7.3?'forma':o>=75?'oro':o>=65?'plata':'bronce');}
function cardBox(c){return `<figure class="j-cc v-${c.t}">${card(c.p,false)}<figcaption><b>${CARDT[c.t]}</b><small>${esc(c.s)} · ${esc(cname(c.p.club))}</small></figcaption></figure>`;}
function vAlbum(){const C=P.cards||[],counts={};C.forEach(c=>{counts[c.t]=(counts[c.t]||0)+1;});
  return `<div class="j-eyebrow">Colección</div><h2 class="j-h">Álbum de cartas</h2><p class="muted" style="max-width:64ch">Cada temporada ganas una carta: bronce, plata u oro según tu media, o una especial si estás en forma, ganas un título, entras en el once ideal o te llevas el Balón de Oro. Al retirarte llega la carta Icono.</p>
  <div class="j-bigs"><div><b class="num">${C.length}</b>cartas</div>${Object.keys(CARDT).filter(k=>counts[k]).map(k=>`<div><b class="num">${counts[k]}</b>${CARDT[k]}</div>`).join('')}</div>
  ${C.length?`<div class="j-album">${C.slice().reverse().map(cardBox).join('')}</div>`:'<p class="muted">Tu primera carta llega al firmar con un club.</p>'}`;}

/* ---------- química con compañeros ---------- */
function ensureMates(){if(!P.club)return;if(P.matesClub===P.club&&P.mates&&P.mates.length>=5)return;const pool=squadNames(P.club,P.last).filter(n=>n!=='un compañero');while(pool.length<5){const n=pk(FIRSTN)+' '+pk(LASTN);if(!pool.includes(n))pool.push(n);}P.mates=[];
  for(let i=0;i<5&&pool.length;i++)P.mates.push({n:pool.splice(R(0,pool.length-1),1)[0],c:R(25,45)});P.matesClub=P.club;}
function pickMate(){ensureMates();const m=P.mates||[];if(!m.length)return{n:'un compañero',c:50};let r=Math.random()*m.reduce((s,x)=>s+x.c+10,0);for(const x of m){r-=x.c+10;if(r<=0)return x;}return m[0];}
const topChem=()=>{ensureMates();return (P.mates||[]).reduce((a,x)=>Math.max(a,x.c),0);};
function chemAfterMatch(){ensureMates();const M=P.mates||[],on=new Set([pk(M),pk(M)]);M.forEach(x=>{x.c=clamp(x.c+(on.has(x)?R(1,2):-.25),0,100);if(x.c>=80&&!x.duo){x.duo=true;news(`${P.last} y ${x.n} forman una dupla letal: se entienden con la mirada.`,'hot');}});
  P.chem=clamp(P.chem+(hasT('lider')?1:.4),0,100);}
function chemPanel(){ensureMates();return `<div class="j-panel"><h3>Química con compañeros</h3>${(P.mates||[]).map(m=>meter(esc(m.n)+(m.duo?' · dupla':''),m.c)).join('')}<p class="j-hint">Cuanta más química, más fácil es el pase de gol, y tus asistencias buscan a quien mejor te entiende. Se gana jugando juntos.</p></div>`;}

/* ---------- rasgos que evolucionan ---------- */
const TRAITS={grandes:['Jugador de grandes partidos',1,'+5 % de acierto en Copa y Champions.'],killer:['Asesino del área',1,'+4 % en los disparos.'],seda:['Pie de seda',1,'+5 % en los regates.'],pulmon:['Pulmón',1,'Acumulas menos fatiga cada semana.'],lider:['Líder nato',1,'La química del vestuario sube más rápido.'],veterano:['Veteranía',1,'+3 % de acierto en todo.'],mediatico:['Imán mediático',1,'Tus patrocinadores pagan un 20 % más.'],cristal:['Cristal',-1,'Te lesionas con más facilidad.'],nervios:['Se le encoge el brazo',-1,'-5 % de acierto en Copa y Champions.'],irregular:['Irregular',-1,'Tu forma sube y baja más de la cuenta.']};
const hasT=k=>!!(P&&P.traits&&P.traits[k]);
function traitsTick(){P.traits=P.traits||{};const S=P.sea,n=S.rt.length?avg(S.rt):0,big=S.big||[],bn=big.length?avg(big):0;
  const set=(k,on)=>{if(on&&!P.traits[k]){P.traits[k]=seasonLabel(P.season);news(`${P.last} gana un rasgo: ${TRAITS[k][0]}.`,TRAITS[k][1]>0?'hot':'bad');}else if(!on&&P.traits[k]){delete P.traits[k];news(`${P.last} pierde el rasgo «${TRAITS[k][0]}».`,TRAITS[k][1]>0?'bad':'hot');}};
  if(big.length>=3){set('grandes',bn>=7.4||(hasT('grandes')&&bn>=6.8));set('nervios',bn<5.9||(hasT('nervios')&&bn<6.5));}
  set('killer',S.g>=20||(hasT('killer')&&S.g>=12));set('seda',P.at.reg>=78&&P.sk>=4);
  set('pulmon',(P.at.fis>=78&&S.min>=2400)||(hasT('pulmon')&&P.at.fis>=74));set('lider',P.captain||P.rep.lider>=6);
  set('veterano',P.age>=30&&P.st.pj>=250);set('mediatico',P.fame>=70);set('cristal',(S.inj||0)>=2||(hasT('cristal')&&(S.inj||0)>=1));
  const sd=S.rt.length>5?Math.sqrt(avg(S.rt.map(x=>(x-n)**2))):0;set('irregular',sd>1.35||(hasT('irregular')&&sd>1.1));}
function traitPanel(){const t=Object.keys(P.traits||{});return `<div class="j-panel"><h3>Rasgos</h3>${t.length?`<div class="j-skills">${t.map(k=>`<div class="${TRAITS[k][1]>0?'pos':'neg'}"><b>${TRAITS[k][0]}</b><small>${TRAITS[k][2]}</small></div>`).join('')}</div>`:''}<p class="j-hint">Aparecen y desaparecen al final de cada temporada según cómo juegues: grandes noches, goles, lesiones, regularidad…</p></div>`;}
/* bonificaciones de rasgos, química y posición en cada jugada */
function xBonus(k){const e=UI.jm&&UI.jm.e,big=!!e&&(e.type==='copa'||e.type==='eur');
  return (talkNow()?(P.talk.k==='conc'?.03:P.talk.k==='motivar'?.015:0):0)+(big&&hasT('grandes')?.05:0)-(big&&hasT('nervios')?.05:0)+(k==='tir'&&hasT('killer')?.04:0)+(k==='reg'&&hasT('seda')?.05:0)+(hasT('veterano')?.03:0)
    +(k==='pas'&&P.club?(topChem()-50)/600:0)-(100-(posF()[P.pos]??100))/500;}

/* ---------- posiciones y reconversión ---------- */
function posF(){P.posf=P.posf||{};if(P.posf[P.pos]==null)P.posf[P.pos]=100;if(P.posf[P.pos2]==null)P.posf[P.pos2]=60;return P.posf;}
function setPos(np,why){const f=posF();if(np===P.pos)return;const old=P.pos;P.pos=np;if(P.pos2===np)P.pos2=old;f[np]=f[np]??30;news(`${P.last} pasa a jugar de ${POS[np].toLowerCase()}${why?' '+why:''}.`,'hot');}
function posPanel(){const f=posF(),gk=P.pos==='POR';
  return `<div class="j-panel"><h3>Posiciones</h3><p class="j-hint">Jugar fuera de tu sitio resta acierto hasta que te adaptas. Elige una posición para aprenderla en los entrenamientos y pide jugar en ella cuando la domines.</p>
  ${Object.keys(POS).filter(k=>(k==='POR')===gk).map(k=>{const v=Math.round(f[k]||0),cur=k===P.pos;return `<div class="j-pos${cur?' on':''}"><span>${POS[k]}${cur?' · actual':P.learn===k?' · aprendiendo':''}</span><i><u style="width:${v}%"></u></i><b class="num">${v}</b>${cur?'':`<div class="j-pos-b"><button class="btn small" data-act="jLearn" data-k="${k}" ${P.learn===k?'disabled':''}>Aprender</button><button class="btn small" data-act="jPosSet" data-k="${k}" ${v>=50?'':'disabled'}>Jugar aquí</button></div>`}</div>`;}).join('')}</div>`;}

/* ---------- momentos clave en primera persona: penalti, falta, mano a mano y penalti en contra ---------- */
const ZN=['Arriba a la izquierda','Arriba al centro','Arriba a la derecha','Abajo a la izquierda','Abajo al centro','Abajo a la derecha'];
const zc=z=>[[16.7,28],[50,28],[83.3,28],[16.7,74],[50,74],[83.3,74]][z];
function fpHTML(kind){return `<div class="fp fp-${kind}"><div class="fp-scene" aria-hidden="false"><div class="fp-sky"></div><div class="fp-stand"></div><div class="fp-turf"></div>
  <div class="fp-goal"><div class="fp-net"></div><div class="fp-gk"><i class="h"></i><i class="b"></i></div><div class="fp-zones">${ZN.map((l,i)=>`<button class="fp-z" data-act="jFpAim" data-z="${i}" aria-label="${l}"></button>`).join('')}</div></div>
  ${kind==='fk'?'<div class="fp-wall"><i></i><i></i><i></i><i></i></div>':''}<div class="fp-ball"></div></div>
  <div class="fp-ui"><p class="fp-step">${kind==='gk'?'Eres el portero: elige hacia dónde te lanzas':'1 · Elige dónde apuntar'}</p><div class="j-bar fp-pow" hidden></div><div><button class="btn primary fp-go" data-act="jFpShoot" hidden>¡Chuta!</button></div></div></div>`;}
function startFp(box,kind,cb){const oppS=UI.jm?UI.jm.oppS:70,opp=UI.jm&&UI.jm.e&&UI.jm.e.opp&&club(UI.jm.e.opp);box.innerHTML=fpHTML(kind);const root=box.querySelector('.fp');
  const gk=root.querySelector('.fp-gk');gk.style.setProperty('--gk',kind==='gk'?'#B57BFF':opp?opp.c2:'#FFD24A');const wall=root.querySelector('.fp-wall');if(wall&&opp)wall.style.setProperty('--wall',opp.c1);
  UI.fp={kind,cb,aim:null,oppS,root,w:clamp(12+P.at.tir/5,14,32),c:R(45,70),done:false};try{fp3D(UI.fp);}catch(e){console.error(e);}root.querySelector('.fp-z').focus({preventScroll:true});}
function fpAim(z){const F=UI.fp;if(!F||F.aim!=null||!document.body.contains(F.root))return;F.aim=z;F.root.querySelectorAll('.fp-z').forEach((b,i)=>b.classList.toggle('sel',i===z));
  if(F.kind==='gk'){fpFinish(null);return;}
  F.root.querySelector('.fp-step').textContent='2 · Para la potencia dentro de la zona morada';
  const bar=F.root.querySelector('.fp-pow');bar.hidden=false;bar.innerHTML=`<i class="z" style="left:${F.c-F.w/2}%;width:${F.w}%"></i><span style="--dur:${clamp(1.25-P.at.tir/220,.7,1.1)}s"></span>`;
  const go=F.root.querySelector('.fp-go');go.hidden=false;go.focus({preventScroll:true});}
function fpShoot(){const F=UI.fp;if(!F||F.aim==null||F.done)return;const bar=F.root.querySelector('.fp-pow'),mk=bar.querySelector('span'),b=bar.getBoundingClientRect(),m=mk.getBoundingClientRect();
  const pw=(m.left+m.width/2-b.left)/b.width*100;mk.style.animation='none';mk.style.left=`calc(${pw}% - 3px)`;fpFinish(pw);}
function fpFinish(pw){const F=UI.fp;F.done=true;F.root.classList.add('done');F.root.querySelector('.fp-go').hidden=true;
  const z=F.aim,top=z<3,k=F.kind;let out,kz,bz=z;
  if(k==='gk'){const wts=[.12,.08,.12,.3,.08,.3];let r=Math.random();bz=5;for(let i=0;i<6;i++){r-=wts[i];if(r<0){bz=i;break;}}kz=z;
    out=ch(.07)?'miss':bz===z?(ch(.82+P.at.def/1000)?'save':'goal'):bz%3===z%3?(ch(.3)?'save':'goal'):'goal';}
  else{const d=pw-F.c,over=d>F.w/2,weak=d<-F.w/2,guess={pen:.3,fk:.22,uno:.4}[k]+(F.oppS-65)/250;
    kz=ch(guess)?z:pk([0,1,2,3,4,5].filter(i=>i!==z));
    if(k==='fk'&&(z===3||z===4)&&!over&&ch(z===4?.8:.5))out='wall';
    else if(over)out=top||ch(.5)?'miss':kz===z&&ch(.4)?'save':'goal';
    else if(weak)out=kz===z?'save':ch(k==='fk'?.35:.55)?'goal':'save';
    else out=kz===z?(ch(top?.3:.65)?'save':'goal'):(k==='fk'&&ch(.15)?'miss':'goal');}
  if(F.g3)F.g3.anim(out,kz,bz);else{const gk=F.root.querySelector('.fp-gk'),ball=F.root.querySelector('.fp-ball'),[gx,gy]=zc(kz),[bx,by]=zc(bz);
  gk.style.left=gx+'%';gk.style.top=gy+'%';gk.style.transform=`translate(-50%,-50%) rotate(${gx<40?-72:gx>60?72:0}deg)`;
  let sx=18+64*bx/100,sy=18+44*by/100;if(out==='miss'){sy=4;sx+=bx<40?-6:bx>60?6:0;}if(out==='wall'){sx=48;sy=52;}
  ball.style.left=sx+'%';ball.style.top=sy+'%';ball.style.transform='translate(-50%,-50%) scale(.55)';
  if(out==='save')setTimeout(()=>{ball.style.top=(sy+20)+'%';ball.style.left=(sx+(sx<50?8:-8))+'%';},480);}
  const label=k==='gk'?{save:'¡PARADÓN!',miss:'¡FUERA!',goal:'Gol del rival'}[out]:{goal:'¡GOL!',save:'¡Para el portero!',miss:'¡Fuera!',wall:'¡Barrera!'}[out];
  const showL=()=>{F.root.querySelector('.fp-step').innerHTML=`<span class="fp-res ${(k==='gk'?out!=='goal':out==='goal')?'ok':'ko'}">${label}</span>`;};
  if(F.g3){F.root.querySelector('.fp-step').textContent='…';setTimeout(showL,k==='fk'?1000:k==='gk'?1200:700);}else showL();
  const cb=F.cb;setTimeout(()=>{if(UI.fp===F)UI.fp=null;cb&&cb(out);},reduced()?700:F.g3?2400:1500);}
function fpAuto(k){if(k==='gk')return ch(.24+P.at.def/500)?'save':'goal';return ch(clamp({pen:.7+P.at.tir/500,fk:.08+P.at.tir/550,uno:.32+P.at.tir/320}[k],.05,.92))?'goal':pk(['save','miss']);}
function fpResolve(mo,R0){const out=mo.out||fpAuto(mo.fk);if(mo.out){if(mo.fk==='gk'&&out==='save')flag('save');if(out==='goal'&&(mo.fk==='pen'||mo.fk==='fk'))flag(mo.fk);}let t,ok;
  if(mo.fk==='gk'){ok=out!=='goal';if(ok){R0.saves++;R0.ok++;t=out==='save'?'¡Paradón! Adivinas el lado y detienes el penalti.':'El lanzador manda el penalti fuera.';}else{R0.ko+=.5;R0.conc=(R0.conc||0)+1;t='Penalti en contra: el lanzador te engaña.';}}
  else{ok=out==='goal';if(ok){R0.g++;t={pen:`¡GOL de penalti! ${P.last} no perdona.`,fk:`¡GOLAZO de falta! ${P.last} la clava lejos del portero.`,uno:`¡GOL! ${P.last} gana el mano a mano.`}[mo.fk]+` Lo celebra: ${celebName()}.`;}
    else{R0.ko+=.5;t=out==='save'?'El portero adivina tu disparo y lo detiene.':out==='wall'?'El balón se estrella en la barrera.':'El disparo se marcha fuera.';}}
  R0.log.push(`${mo.m}' ${t}`);return{ok,t};}
function fpMoment(m,att){if(P.pos==='POR'&&ch(.22))return{m,kind:'fp',fk:'gk',text:'Penalti en contra. Estás bajo palos: elige hacia dónde te lanzas.',opts:[['Lanzarse','def',0]]};
  if(att&&ch(.24)){const fk=pk(['pen','fk','uno','uno']);return{m,kind:'fp',fk,text:{pen:'¡Penalti a favor! Coges el balón: lo tiras tú.',fk:'Falta directa al borde del área. La barrera se coloca.',uno:'Te quedas solo delante del portero.'}[fk],opts:[['Tirar','tir',0]]};}
  return null;}

/* ---------- familia y tu hijo futbolista ---------- */
const PARTN=['Lucía','Álex','Sara','Noa','Inés','Dani','Carla','Andrea','Maya','Sam','Elena','Martina'];
const KIDN=['Leo','Hugo','Martín','Lucas','Mateo','Pablo','Álvaro','Nico','Bruno','Iker','Marco','Teo','Gael','Thiago'];
function fam(){return P.family||(P.family={partner:null,married:false,kids:[]});}
const kidAge=k=>P.season-k.b;
function kidStatus(k){const a=kidAge(k);if(!k.fb)return a<3?'En casa':a<18?'Estudia':'Hace su vida';
  return a<5?'Aún no da patadas':a<10?'Juega en el equipo del barrio':a<18?`Cantera de ${cname(k.club)}`:k.pro?`Profesional en ${cname(k.club)}`:'Estudia';}
function familyTick(){const F=fam(),cid=(P.coach&&P.coach.club)||P.club||P.origin0;
  F.kids.forEach(k=>{if(!k.fb)return;k.ms=k.ms||[];const a=kidAge(k),say=(m,t,h)=>{if(a>=m&&!k.ms.includes(m)){k.ms.push(m);news(t,h);}};
    say(5,`${k.n} da sus primeras patadas al balón en el jardín de casa.`);
    say(8,`${k.n} se apunta al equipo del barrio. Dicen que tiene tu zancada.`);
    if(a>=10&&!k.club&&cid)k.club=cid;
    if(k.club)say(10,`${k.n} entra en la cantera de ${cname(k.club)}.`,'hot');
    say(13,`Los ojeadores dan a ${k.n} un potencial de ${k.pot} estrellas.`);
    say(16,k.pot>=3?`${k.n} es convocado con la ${P.nat} sub-17.`:`${k.n} sigue formándose en el juvenil de ${cname(k.club)}.`,k.pot>=3?'hot':'');
    if(a>=18&&!k.ms.includes(18)){k.pro=k.pot>=2;}
    say(18,k.pot>=2?`${k.n} firma su primer contrato profesional con ${cname(k.club)}.`:`${k.n} decide estudiar y aparcar el fútbol.`,'hot');
    if(a>=19&&k.pro&&P.coach&&P.coach.club===k.club&&!k.ms.includes(99)){k.ms.push(99);news(`${k.n} debuta en el primer equipo de ${cname(k.club)} bajo tus órdenes.`,'hot');}});}
function famPanel(){const F=fam();
  return `<div class="j-panel"><h3>Familia</h3>${F.partner?`<div class="j-fam">${partnerSvg(F,96)}<p class="j-n"><b>${F.married?'Matrimonio':'Pareja'}</b>${esc(F.partner.n)}<small>${partnerDesc(F)}</small></p></div>`:'<p class="muted">Sin pareja por ahora. La vida fuera del campo también tiene sus momentos.</p>'}
  ${F.kids.map(k=>{const a=kidAge(k);return `<div class="j-kid">${kidSvg(k,64)}<b>${esc(k.n)}${k.fb?' · futbolista':''}</b><small>${a<1?'Recién nacido':a+' año'+(a>1?'s':'')} · ${kidStatus(k)} · ${kidDesc(k)}</small>${k.fb?`<span>${a>=13?stars(k.pot):'<em class="muted">Potencial ¿?</em>'}</span>`:''}</div>`;}).join('')}
  ${F.kids.some(k=>k.fb)?'<p class="j-hint">Tu hijo crece temporada a temporada: barrio, cantera, selección… Su potencial se descubre a los 13 años.</p>':''}</div>`;}

/* ---------- garaje ---------- */
const CARS=[['urbano','Utilitario eléctrico',28000,'#7FD1FF'],['suv','SUV familiar',75000,'#3A3F4A'],['gt','Deportivo GT',190000,'#E8283C'],['clasico','Clásico de colección',340000,'#E6C068'],['todo','Todoterreno de lujo',460000,'#F2F2F2'],['hiper','Hiperdeportivo',1900000,'#B57BFF']];
const garageCap=()=>hasHome()?[1,2,3,5][P.home.parts.garaje]:1;
function garagePanel(){const cars=P.cars||[],cap=garageCap();
  return `<div class="j-panel"><h3>Garaje · <span class="num">${cars.length}/${cap}</span> plazas</h3><p class="j-hint">${hasHome()?'Tus coches aparcan en tu parcela de la Ciudad. Mejora el garaje de tu casa para tener más plazas.':'Sin casa propia solo tienes una plaza alquilada. Compra tu parcela en la Ciudad para verlos aparcados.'}</p>
  ${CARS.map(([k,l,price,col])=>{const own=cars.includes(k),can=P.money>=price&&cars.length<cap;return `<div class="j-car"><i style="background:${col}"></i><span>${l}</span>${own?`<button class="btn small" data-act="jCarSell" data-k="${k}">Vender · ${eur(price*.6)}</button>`:`<button class="btn small${can?' primary':''}" data-act="jCarBuy" data-k="${k}" ${can?'':'disabled'}>${eur(price)}</button>`}</div>`;}).join('')}</div>`;}
function homeCars(T,g,M,glow,cars){const SL=[[-6.3,8.4,0],[-3.1,8.4,0],[1.5,6.4,0],[-.9,8.4,0],[5.6,8.2,Math.PI/2]];
  cars.slice(0,5).forEach((kind,i)=>{const [x,z,ry]=SL[i],col=(CARS.find(c=>c[0]===kind)||CARS[0])[3],G=new T.Group();G.position.set(x,.2,z);G.rotation.y=ry;g.add(G);
    const b=(w_,h,d,m,X,Y,Z)=>{const o=new T.Mesh(new T.BoxGeometry(w_,h,d),m);o.position.set(X,Y,Z);o.castShadow=true;G.add(o);return o;};
    const [w_,h,d,ch_,cl]={urbano:[1.7,.7,3.3,.62,1.7],suv:[2,.95,4.3,.78,2.3],gt:[1.95,.55,4.4,.48,1.7],clasico:[1.85,.62,4.5,.55,1.9],todo:[2.1,1.05,4.6,.85,2.6],hiper:[2.05,.42,4.5,.4,1.5]}[kind]||[1.9,.6,4,.5,2];
    const paint=M(col,{roughness:.22,metalness:.85}),gl=M('#12141a',{roughness:.06,metalness:1});
    b(w_,h,d,paint,0,.32+h/2,0);b(w_*.86,ch_,cl,gl,0,.32+h+ch_/2,kind==='gt'||kind==='hiper'?-.35:-.15);
    [[-1,-1],[1,-1],[-1,1],[1,1]].forEach(([sx,sz])=>{const wh=new T.Mesh(new T.CylinderGeometry(.36,.36,.26,14),M('#121212'));wh.rotation.z=Math.PI/2;wh.position.set(sx*w_/2,.36,sz*d*.32);G.add(wh);});
    [-1,1].forEach(sx=>{b(.34,.12,.05,glow('#fff4d6',1.6),sx*w_*.3,.32+h*.72,d/2+.02);b(.34,.1,.05,glow('#ff2a3a',1.2),sx*w_*.3,.32+h*.72,-d/2-.02);});
    if(kind==='gt'){b(w_*.9,.06,.42,paint,0,.32+h+.32,-d/2+.25);[-.6,.6].forEach(sx=>b(.06,.3,.06,gl,sx,.32+h+.15,-d/2+.25));}
    if(kind==='hiper')[-1,1].forEach(sx=>b(.04,.06,d*.8,glow('#C99BFF',2.2),sx*(w_/2+.01),.5,0));
    if(kind==='clasico')[-1,1].forEach(sz=>b(w_+.04,.12,.12,M('#dcdcdc',{metalness:1,roughness:.18}),0,.42,sz*(d/2+.04)));
    if(kind==='todo'){b(w_*.8,.08,cl*.9,M('#222'),0,.32+h+ch_+.06,-.15);const sp=new T.Mesh(new T.CylinderGeometry(.38,.38,.24,14),M('#121212'));sp.rotation.x=Math.PI/2;sp.position.set(0,.32+h*.6,-d/2-.14);G.add(sp);}
    if(kind==='suv')[-1,1].forEach(sx=>b(.06,.06,cl,M('#9a9a9a',{metalness:1}),sx*w_*.38,.32+h+ch_+.04,-.15));});}

/* ---------- inversiones ---------- */
const INV=[['restaurante','Restaurante en tu ciudad',150000,.12,.22],['academia','Academia de fútbol base',300000,.07,.08],['ropa','Marca de ropa',500000,.2,.35],['inmo','Promoción inmobiliaria',1000000,.09,.12],['esports','Club de eSports',250000,.25,.45],['bodega','Bodega y viñedos',400000,.08,.14]];
function investTick(){const I=P.inv||{};Object.entries(I).forEach(([id,x])=>{const d=INV.find(v=>v[0]===id);if(!d)return;let r=d[3]+(Math.random()*2-1)*d[4];
    if(ch(.04+d[4]*.12)){r=-.45;news(`Mal año para tu inversión «${d[1]}»: pierde casi la mitad de su valor.`,'bad');}else if(r>.3)news(`Tu inversión «${d[1]}» se dispara: +${Math.round(r*100)} %.`,'hot');
    x.v=Math.max(0,Math.round(x.v*(1+r)));const div=Math.round(x.v*.04);P.money+=div;x.div=(x.div||0)+div;x.last=r;
    if(id==='academia'){P.rep.humilde+=.5;P.fame=clamp(P.fame+.5,0,100);}if(id==='ropa'&&r>0)P.fame=clamp(P.fame+1,0,100);});}
function investPanel(){const I=P.inv||{};
  return `<div class="j-panel"><h3>Inversiones</h3><p class="j-hint">Cada temporada tus negocios suben o bajan de valor y te pagan un dividendo del 4 %. Más rentabilidad, más riesgo.</p>
  ${INV.map(([id,l,cost,ret,vol])=>{const x=I[id];return `<div class="j-iv"><div><b>${l}</b><small>Riesgo ${vol>=.3?'alto':vol>=.15?'medio':'bajo'} · rentabilidad esperada ${Math.round(ret*100)} % al año</small></div>${x?`<div class="j-ivr"><b class="num ${x.v>=x.in?'up':'dn'}">${eur(x.v)}</b><small class="num">${x.v>=x.in?'+':''}${Math.round((x.v/x.in-1)*100)} % · dividendos ${eur(x.div||0)}</small><button class="btn small" data-act="jInvSell" data-k="${id}">Vender</button></div>`:`<button class="btn small${P.money>=cost?' primary':''}" data-act="jInvBuy" data-k="${id}" ${P.money>=cost?'':'disabled'}>Invertir ${eur(cost)}</button>`}</div>`;}).join('')}</div>`;}
function vFam(){return `<div class="j-eyebrow">Fuera del campo</div><h2 class="j-h">Familia y patrimonio</h2><div class="j-two"><div class="j-col">${famPanel()}${garagePanel()}</div><div class="j-col">${petPanel()}${investPanel()}</div></div>`;}

/* ---------- eventos nuevos (familia y reconversión) ---------- */
Object.assign(EV,{
  pareja:{t:ev=>`En un evento benéfico conoces a ${ev.n}. Hay química desde el primer minuto.`,o:[['Empezar una relación',ev=>{fam().partner={n:ev.n,s:P.season};P.mor+=8;news(`${P.last} confirma su relación con ${ev.n}.`);}],['Centrarte en el fútbol',()=>{P.lp+=.5;}]]},
  boda:{t:()=>`Llevas tiempo con ${fam().partner.n}. ¿Dais el paso?`,o:[['Casaros este verano',()=>{P.money-=Math.min(250000,Math.round(Math.max(P.money,0)*.15)+20000);fam().married=true;P.mor+=12;P.fame+=2;news(`${P.last} y ${fam().partner.n} se casan.`,'hot');}],['Esperar un poco más',()=>{}]]},
  bebe:{t:()=>`¡${fam().partner.n} y tú vais a tener un bebé! ¿Cómo se llamará?`,o:ev=>ev.names.map(n=>[`Llamarle ${n}`,()=>{const F=fam(),first=!F.kids.some(k=>k.fb);F.kids.push({n,b:P.season,fb:first||ch(.3),pot:clamp(Math.round((ceil()-80)/3.5)+R(-1,1),1,5),ms:[]});P.mor+=15;news(`¡Nace ${n}, hijo de ${P.name} ${P.last}!`,'hot');}])},
  mudanza:{t:()=>`Te vas a otro país y tu familia duda si mudarse contigo.`,o:[['Mudaros todos juntos',()=>{P.adapt+=25;P.mor-=2;}],['Ir solo la primera temporada',()=>{P.mor-=10;P.adapt+=5;}]]},
  reconversion:{t:ev=>`Con ${P.age} años, el míster cree que rendirías más como ${POS[ev.to].toLowerCase()}.`,o:[['Aceptar el cambio',ev=>{posF()[ev.to]=Math.max(posF()[ev.to]||0,65);setPos(ev.to,'por decisión del míster');P.tru+=6;P.lp+=1;}],['Seguir en tu posición',()=>{P.tru-=3;}]]},
});
function famCands(c){const F=fam();if(!F.partner&&P.age>=20)c.push('pareja');if(F.partner&&!F.married&&P.season-F.partner.s>=1)c.push('boda');
  if(F.partner&&F.kids.length<3&&P.age>=23&&(!F.kids.length||P.season-F.kids[F.kids.length-1].b>=2))c.push('bebe','bebe');
  if(P.age>=29&&(P.pos==='EXT'||P.pos==='DEL')&&P.at.rit<80&&P.squad!=='cantera')c.push('reconversion');}
function mkEv(id){const ev={id};if(id==='pareja')ev.n=pk(PARTN);if(id==='reconversion')ev.to='MED';
  if(id==='bebe'){const used=fam().kids.map(k=>k.n),pool=KIDN.filter(n=>!used.includes(n));ev.names=[];while(ev.names.length<3&&pool.length)ev.names.push(pool.splice(R(0,pool.length-1),1)[0]);}return ev;}

/* ---------- carrera de entrenador tras la retirada ---------- */
const TACT={equilibrio:'Equilibrio',posesion:'Posesión',presion:'Presión alta',contra:'Contragolpe',defensivo:'Bloque bajo'};
const prefT=id=>['posesion','presion','contra','defensivo'][[...id].reduce((x,c)=>(x*31+c.charCodeAt(0))>>>0,3)%4];
const coachWage=id=>Math.round(Math.pow(Math.max(clubStr(id)-40,5),2.2)*120/1000)*1000;
function coachObj(id){const k=club(id),ids=LG[k.league].pyr[k.tier],n=ids.length,rank=ids.map(clubStr).sort((a,b)=>b-a).indexOf(k.base)+1;
  if(k.tier>0&&rank<=3)return{t:'Subir de categoría (acabar entre los 2 primeros)',pos:2};
  return rank<=1?{t:'Ganar la liga',pos:1}:rank<=4?{t:'Acabar entre los 4 primeros',pos:4}:rank<=Math.ceil(n/2)?{t:`Acabar entre los ${Math.ceil(n/2)} primeros`,pos:Math.ceil(n/2)}:{t:`Evitar el descenso (puesto ${n-3} o mejor)`,pos:n-3};}
function coachOffers(fired){const C=P.coach,t=50+C.lvl*.38-(fired?5:0),pool=ALL().filter(k=>Math.abs(k.base-t)<=5&&k.id!==C.club),out=[];
  if(!C.hist.length&&P.origin0&&club(P.origin0)&&club(P.origin0).base<=t+8)out.push(P.origin0);
  while(out.length<3&&pool.length){const k=pool.splice(R(0,pool.length-1),1)[0];if(!out.includes(k.id))out.push(k.id);}
  C.offers=out.map(id=>({club:id,years:R(2,3),obj:coachObj(id)}));}
function coachStart(){P.coach={lvl:clamp(Math.round(40+(P.peak-80)*.8+P.fame/12+(P.captain?3:0)+Math.min(4,P.rep.lider)),38,66),trust:60,club:null,tactic:'equilibrio',rot:'rotar',youth:false,hist:[],titles:[],offers:[],years:0,done:false};
  coachOffers();news(`${P.name} ${P.last} se saca el título de entrenador.`,'hot');}
function coachSeason(){const C=P.coach,k=club(C.club);C.tbl={};LG[k.league].pyr[k.tier].forEach(id=>{C.tbl[id]=0;});C.block=0;C.pld=0;C.obj=coachObj(C.club);C.eur=eurQualifiedId(C.club);C.tired=0;C.last=null;}
function coachSign(i){const C=P.coach,o=C.offers[i];if(!o)return;if(C.club)news(`${P.last} deja el banquillo de ${cname(C.club)}.`);
  C.club=o.club;C.years=o.years;C.trust=60;C.offers=[];coachSeason();news(`${P.name} ${P.last}, nuevo entrenador de ${cname(o.club)}.`,'hot');}
const coachGames=()=>(Object.keys(P.coach.tbl).length-1)*2;
const coachPos=()=>{const C=P.coach;return Object.entries(C.tbl).sort((a,b)=>b[1]-a[1]).findIndex(x=>x[0]===C.club)+1;};
function coachStr(){const C=P.coach,k=club(C.club),pf=prefT(C.club);return k.base+(C.lvl-60)*.1+(C.tactic===pf?1.5:C.tactic==='equilibrio'?.5:-1)+(C.rot==='fijo'?1:0)-C.tired-(C.youth?1:0)+(C.trust-50)/90;}
function coachBlock(){const C=P.coach,ids=Object.keys(C.tbl),avgB=avg(ids.map(clubStr)),G=coachGames(),n=C.block<3?Math.round(G/4):G-C.pld,s=coachStr();let w=0,d=0,l=0;
  for(let i=0;i<n;i++){const opp=clubStr(pk(ids.filter(x=>x!==C.club))),pw=clamp(.33+(s-opp)*.025,.06,.8),r=Math.random();if(r<pw)w++;else if(r<pw+.26)d++;else l++;}
  C.tbl[C.club]+=w*3+d;ids.forEach(id=>{if(id!==C.club)C.tbl[id]+=Math.round(n*clamp(1.35+(clubStr(id)-avgB)*.055+(Math.random()-.5)*.5,.3,2.6));});
  C.pld+=n;C.block++;C.tired=C.rot==='fijo'?Math.min(4,C.tired+1.2):Math.max(0,C.tired-1.2);if(C.youth)C.lvl=Math.min(99,C.lvl+.3);
  const exp=1.35+(clubStr(C.club)-avgB)*.055;C.trust=clamp(C.trust+((w*3+d)/Math.max(1,n)-exp)*22,0,100);
  C.last={n,w,d,l,pos:coachPos(),txt:C.tactic===prefT(C.club)?'El equipo entiende a la perfección tu idea de juego.':C.tactic==='equilibrio'?'El equipo cumple con un planteamiento equilibrado.':'A la plantilla le cuesta adaptarse a esa táctica.'};
  news(`Bloque ${C.block}: ${w}V ${d}E ${l}D. ${cname(C.club)} va ${C.last.pos}.º`);
  if(C.trust<12&&C.block<4){coachFired(false);return 'fired';}
  if(C.block>=4)return coachEndSeason();return 'block';}
function coachEndSeason(){const C=P.coach,k=club(C.club),pos=coachPos(),sl=seasonLabel(P.season),tit=[],s=coachStr();
  if(pos===1)tit.push(divOf(k));
  let cup='';for(let r=0;r<5;r++){if(Math.random()<clamp(.5+(s-(55+r*6+R(-4,8)))*.03,.1,.9)){if(r===4){cup='Campeón';tit.push('Copa');}}else{cup=CUPN[r];break;}}
  let eu='';if(C.eur)for(let r=0;r<6;r++){if(Math.random()<clamp(.5+(s-(78+r*2.2))*.035,.05,.85)){if(r===5){eu='Campeón';tit.push('Champions League');}}else{eu=EURN[r];break;}}
  tit.forEach(t=>{C.titles.push({n:t,s:sl,c:k.name});news(`¡${k.name} de ${P.last} gana la ${t}!`,'hot');});
  const met=pos<=C.obj.pos;C.trust=clamp(C.trust+(met?18:-22)+tit.length*8,0,100);
  C.lvl=clamp(Math.round(C.lvl+clamp(((C.obj.pos-pos)/Math.max(3,C.obj.pos)+tit.length*.4)*2.5+(met?1:-1),-3,3)),30,95);
  C.hist.push({s:sl,c:k.name,pos,cup:cup||'—',eu:eu||'—',obj:C.obj.t,met,lvl:C.lvl});P.money+=coachWage(C.club);
  C.years--;P.age++;P.season++;familyTick();investTick();C.report={s:sl,pos,met,tit,c:k.name};
  if(C.trust<25){coachFired(true);return 'season';}
  C.offers=[];if(met&&(pos<=2||tit.length)&&ch(.6)){coachOffers();C.offers=C.offers.filter(o=>clubStr(o.club)>k.base);}
  if(C.years<=0){if(C.trust>=50){C.years=R(2,3);news(`${k.name} renueva a ${P.last} como entrenador.`);}else{news(`${k.name} no renueva a ${P.last}.`,'bad');C.club=null;coachOffers();}}
  if(C.club)coachSeason();return 'season';}
function coachFired(seasonOver){const C=P.coach;news(`${cname(C.club)} destituye a ${P.last}.`,'bad');
  if(!seasonOver){C.hist.push({s:seasonLabel(P.season),c:cname(C.club),pos:coachPos(),cup:'—',eu:'—',obj:C.obj.t,met:false,lvl:C.lvl,fired:true});P.season++;P.age++;familyTick();investTick();}
  else C.hist[C.hist.length-1].fired=true;
  C.lvl=Math.max(30,C.lvl-2);C.club=null;C.firedMsg=true;coachOffers(true);}
function coachHist(C){return C.hist.length?`<table class="j-t"><thead><tr><th>Temporada</th><th>Club</th><th>Puesto</th><th>Copa</th><th>Champions</th><th>Objetivo</th></tr></thead><tbody>${C.hist.map(x=>`<tr><td class="num">${x.s}</td><td>${esc(x.c)}</td><td class="num">${x.pos}.º${x.fired?' · destituido':''}</td><td>${esc(x.cup)}</td><td>${esc(x.eu)}</td><td>${x.met?'Cumplido':'No'}</td></tr>`).join('')}</tbody></table>`:'<p class="muted">Aún no has completado ninguna temporada.</p>';}
function vCoach(){const C=P.coach,k=C.club&&club(C.club);
  const hd=`<header class="j-hud"><div class="j-hud-in"><button class="back" data-act="jExit">← Modos</button><div class="j-brand">PALCO<span>ENTRENADOR</span></div>
   <div class="j-ind"><div class="j-big"><b class="num">${Math.round(C.lvl)}</b><small>Nivel</small></div><div><small>Directiva</small><b class="num ${C.trust<35?'bad':''}">${Math.round(C.trust)}</b></div><div><small>Títulos</small><b class="num">${C.titles.length}</b></div><div><small>Edad</small><b class="num">${P.age}</b></div><div><small>Ahorros</small><b class="num">${eur(P.money)}</b></div></div>
   <div class="j-hclub">${k?crest(k,28):''}<span>${k?esc(k.name):'Sin banquillo'}<small class="num">${seasonLabel(P.season)}${k?` · bloque ${Math.min(4,C.block+1)} de 4`:''}</small></span></div></div></header>`;
  const offers=C.offers.map((o,i)=>`<button class="j-offer" data-act="jCoachSign" data-i="${i}">${crest(club(o.club),58)}<div><h3>${esc(cname(o.club))}</h3><p class="muted">${esc(divOf(club(o.club)))} · ${esc(LG[club(o.club).league].country)} · Objetivo: ${esc(o.obj.t)}</p></div><div class="j-offer-r"><b class="num">${o.years} años</b><small>${eur(coachWage(o.club))} por temporada</small></div></button>`).join('');
  let body;
  if(!k)body=`<div class="j-eyebrow">Banquillo libre</div><h2 class="j-h">${C.hist.length?'Buscas equipo':'Tu primer banquillo'}</h2><p class="muted" style="max-width:62ch">${C.hist.length?'Los clubes que te llaman dependen de tu nivel como entrenador.':'Colgaste las botas, pero el fútbol sigue. Tu nivel de partida depende de la carrera que hiciste como jugador.'}</p>
    <div class="j-offers">${offers||'<p class="muted">Nadie llama… de momento.</p>'}</div><div class="j-acts">${C.offers.length?'':'<button class="btn" data-act="jCoachWait">Esperar una temporada</button>'}<button class="btn" data-act="jCoachRetire">Retirarte de los banquillos</button></div>
    <div class="j-two"><div class="j-panel"><h3>Historial</h3>${coachHist(C)}</div>${famPanel()}</div>`;
  else{const t=Object.entries(C.tbl).sort((a,b)=>b[1]-a[1]),me=t.findIndex(x=>x[0]===C.club),G=coachGames(),per=Math.round(G/4),from=C.pld+1,to=C.block<3?C.pld+per:G;
    body=`<div class="j-two j-coach"><div class="j-col">
     <div><div class="j-eyebrow">${esc(divOf(k))} · ${seasonLabel(P.season)}</div><h2 class="j-h">${esc(k.name)}</h2><p class="muted">Objetivo de la directiva: <b>${esc(C.obj.t)}</b>${C.eur?' · juegas la Champions':''} · contrato: ${C.years} año${C.years>1?'s':''}</p></div>
     <div class="j-next"><div class="j-eyebrow">Bloque ${C.block+1} de 4 · jornadas ${from}–${to}</div><h3>Prepara el bloque</h3>
      <div class="j-grp"><h4>Táctica</h4><div class="j-chips">${Object.entries(TACT).map(([x,l])=>`<button class="j-chip${C.tactic===x?' on':''}" data-act="jCoachT" data-k="${x}">${l}</button>`).join('')}</div></div>
      <div class="j-grp"><h4>Gestión de la plantilla</h4><div class="j-chips"><button class="j-chip${C.rot==='rotar'?' on':''}" data-act="jCoachRot" data-k="rotar">Rotar y llegar frescos</button><button class="j-chip${C.rot==='fijo'?' on':''}" data-act="jCoachRot" data-k="fijo">Once de gala (rinde más, cansa más)</button></div></div>
      <label class="j-check"><input type="checkbox" data-in="coachYouth" ${C.youth?'checked':''}> Dar minutos a la cantera (subes como formador, el equipo rinde algo menos)</label>
      <div class="j-acts"><button class="btn primary" data-act="jCoachBlock">Jugar el bloque</button></div></div>
     ${C.last?`<div class="j-panel"><h3>Último bloque</h3><p class="j-n"><b class="num">${C.last.w}V · ${C.last.d}E · ${C.last.l}D</b>${esc(C.last.txt)}</p></div>`:''}
     <div class="j-panel"><h3>Clasificación</h3><table class="j-t"><tbody>${t.map(([id,pts],i)=>`<tr class="${id===C.club?'me':''}"><td class="num">${i+1}</td><td>${esc(cname(id))}</td><td class="num">${pts}</td></tr>`).join('')}</tbody></table></div></div>
    <div class="j-col"><div class="j-panel"><h3>Estado</h3>${meter('Confianza de la directiva',C.trust,1)}${meter('Nivel como entrenador',C.lvl)}</div>
     ${C.offers.length?`<div class="j-panel j-alert"><h3>Otros clubes te quieren</h3><div class="j-offers">${offers}</div></div>`:''}
     <div class="j-panel"><h3>Historial</h3>${coachHist(C)}</div>${famPanel()}${investPanel()}
     <div class="j-acts"><button class="btn" data-act="jCoachRetire">Retirarte de los banquillos</button></div></div></div>`;}
  return hd+`<div class="j-shell"><main class="j-main" id="jmain" tabindex="-1">${body}</main></div>`;}
function legendExtra(){const C=P.coach;let h=trophyPanel();
  if(C&&C.hist.length)h+=`<div class="j-panel"><h3>Carrera en los banquillos</h3><div class="j-kv"><div><small>Temporadas</small><b class="num">${C.hist.length}</b></div><div><small>Títulos</small><b class="num">${C.titles.length}</b></div><div><small>Nivel máximo</small><b class="num">${Math.max(...C.hist.map(x=>x.lvl))}</b></div></div>${coachHist(C)}</div>`;
  return h+famPanel();}

/* ---------- acciones nuevas ---------- */
Object.assign(ACT,{
  jKit(d,el){P.kit=d.k;chipOn(el);save();const hc=document.querySelector('.j-hero .j-card');if(hc)hc.outerHTML=card(P,true);const fb=document.querySelector('.j-3d-fb');if(fb)fb.innerHTML=avatar(P,170);if(G3D)G3D.rebuild();},
  jCelebSet(d,el){P.celeb=+d.k;chipOn(el);save();playCeleb();},
  jCeleb(){playCeleb();},
  jFpAim(d){fpAim(+d.z);},jFpShoot(){fpShoot();},
  jLearn(d){P.learn=d.k;save();rr();},
  jPosSet(d){const v=posF()[d.k]||0;if(v>=75||ch(.55+P.tru/300)){setPos(d.k,'tras hablar con el míster');P.tru=clamp(P.tru-2,0,100);toast(`Jugarás de ${POS[d.k].toLowerCase()}.`);}else{P.tru=clamp(P.tru-5,0,100);toast('El míster prefiere que sigas en tu sitio.');}save();rr();},
  jCarBuy(d){const c=CARS.find(x=>x[0]===d.k);P.cars=P.cars||[];if(!c||P.money<c[2]||P.cars.includes(c[0])||P.cars.length>=garageCap())return;P.money-=c[2];P.cars.push(c[0]);P.mor=clamp(P.mor+2,0,100);if(c[2]>1e6)P.rep.mediatico+=1;if(P.age<22&&c[2]>2e5)P.lp-=1;news(`${P.last} estrena coche: ${c[1].toLowerCase()}.`);save();rr();C3D&&C3D.rebuildHouse();},
  jCarSell(d){const c=CARS.find(x=>x[0]===d.k);if(!c||!(P.cars||[]).includes(c[0]))return;P.cars=P.cars.filter(x=>x!==c[0]);P.money+=Math.round(c[2]*.6);save();rr();C3D&&C3D.rebuildHouse();},
  jInvBuy(d){const v=INV.find(x=>x[0]===d.k);P.inv=P.inv||{};if(!v||P.inv[v[0]]||P.money<v[2])return;P.money-=v[2];P.inv[v[0]]={v:v[2],in:v[2],s:seasonLabel(P.season),div:0};news(`${P.last} invierte en: ${v[1].toLowerCase()}.`);save();rr();},
  jInvSell(d){const x=P.inv&&P.inv[d.k];if(!x)return;P.money+=x.v;delete P.inv[d.k];toast(`Vendes por ${eur(x.v)}.`);save();rr();},
  jCoachStart(){coachStart();save();render();scrollTo(0,0);},
  jCoachSign(d){coachSign(+d.i);save();render();scrollTo(0,0);},
  jCoachT(d){P.coach.tactic=d.k;save();rr();},jCoachRot(d){P.coach.rot=d.k;save();rr();},
  jCoachWait(){P.season++;P.age++;familyTick();investTick();coachOffers();save();render();},
  jCoachRetire(){P.coach.done=true;news(`${P.name} ${P.last} se retira de los banquillos.`);save();render();scrollTo(0,0);},
  jCoachBlock(){const r=coachBlock();save();render();const C=P.coach;
    if(r==='season'||r==='fired'){const R0=C.report;const head=r==='fired'||C.firedMsg?'Destituido':R0?`Fin de la temporada ${R0.s}`:'Fin de temporada';C.firedMsg=false;
      modal(`<div class="hd j-mhd"><h3>${head}</h3></div><div class="bd">${R0&&r==='season'?`<div class="j-kv"><div><small>Puesto</small><b class="num">${R0.pos}.º</b></div><div><small>Objetivo</small><b>${R0.met?'Cumplido':'No cumplido'}</b></div><div><small>Títulos</small><b class="num">${R0.tit.length}</b></div><div><small>Nivel</small><b class="num">${Math.round(C.lvl)}</b></div></div>${R0.tit.length?`<p class="j-neon" style="font-weight:700">${R0.tit.map(esc).join(' · ')}</p>`:''}`:'<p class="j-sit">La directiva ha perdido la confianza en tu proyecto. Toca buscar banquillo.</p>'}
        <p class="j-hint">${C.club?(C.offers.length?'Otros clubes llaman a tu puerta.':'Sigues al frente del equipo.'):'Estás sin equipo: revisa las ofertas.'}</p><button class="btn primary" data-act="jClose" data-focus>Seguir</button></div>`);}},
});

const css2=document.createElement('style');css2.textContent=`
.j-album{display:grid;grid-template-columns:repeat(auto-fill,minmax(180px,1fr));gap:20px;margin-top:20px}
.j-cc{margin:0;display:grid;gap:8px;justify-items:center}
.j-cc .j-card{max-width:220px;padding:14px;gap:8px}
.j-cc figcaption{display:grid;text-align:center;gap:2px}
.j-cc figcaption b{font-family:var(--mono);font-size:11px;letter-spacing:.16em;text-transform:uppercase;color:var(--neon)}
.j-cc figcaption small{color:var(--muted);font-size:12px}
.j-newcard{display:flex;justify-content:center;margin:14px 0}
.j-newcard .j-cc .j-card{max-width:200px}
.v-bronce .j-card{background:radial-gradient(120% 70% at 72% 0%,#D9925C,transparent 60%),linear-gradient(160deg,#7A4526,#3A2214 55%,#1C0F08);box-shadow:inset 0 0 0 1px rgba(255,200,160,.5)}
.v-plata .j-card{background:radial-gradient(120% 70% at 72% 0%,#E9EDF5,transparent 60%),linear-gradient(160deg,#8D94A6,#454B5A 55%,#1E2129);box-shadow:inset 0 0 0 1px rgba(235,240,255,.55)}
.v-oro .j-card{background:radial-gradient(120% 70% at 72% 0%,#FFE7A0,transparent 60%),linear-gradient(160deg,#C8952E,#6E4E12 55%,#2A1C05);box-shadow:inset 0 0 0 1px rgba(255,226,150,.65),0 0 30px -12px #FFD24A}
.v-forma .j-card{box-shadow:inset 0 0 0 2px #E4CCFF,0 0 36px -6px #B57BFF}
.v-campeon .j-card{background:radial-gradient(120% 70% at 72% 0%,#5CF2D2,transparent 60%),linear-gradient(160deg,#127A68,#0B3D36 55%,#061A17);box-shadow:inset 0 0 0 1px rgba(120,255,225,.6)}
.v-tots .j-card{background:radial-gradient(120% 70% at 72% 0%,#4D6BFF,transparent 60%),linear-gradient(160deg,#16236B,#0B1240 55%,#050820);box-shadow:inset 0 0 0 2px #FFD24A}
.v-balon .j-card{background:radial-gradient(120% 70% at 72% 0%,#FFF6D8,transparent 55%),linear-gradient(160deg,#E2B347,#8A6316 55%,#2E1F04);box-shadow:inset 0 0 0 2px #FFF1C2,0 0 40px -6px #FFD24A}
.v-debut .j-card{background:radial-gradient(120% 70% at 72% 0%,#FF7DB5,transparent 60%),linear-gradient(160deg,#8A1F55,#3E0B27 55%,#1A0410)}
.v-icono .j-card{background:radial-gradient(120% 70% at 72% 0%,#F7EFD9,transparent 55%),linear-gradient(160deg,#BBA779,#5A4C2E 55%,#211A0C);box-shadow:inset 0 0 0 2px #F7EFD9,0 0 40px -8px #F7EFD9}
.j-skills .neg b{color:var(--loss)}
.j-kid{display:grid;grid-template-columns:auto 1fr auto;gap:2px 12px;padding:10px 0;border-top:1px solid var(--line);align-items:center}.j-kid>svg{grid-row:1/3;border-radius:12px}.j-fam{display:flex;gap:14px;align-items:center;margin-bottom:6px}.j-fam svg{flex:none;border-radius:14px;box-shadow:0 0 22px -10px #ff7fa8}.j-fam small{display:block;color:var(--muted);font-size:12.5px;margin-top:3px}
.j-kid small{color:var(--muted)}.j-kid span{grid-row:1/3;grid-column:3;align-self:center}.j-kid b,.j-kid small{grid-column:2}
.j-car{display:grid;grid-template-columns:38px 1fr auto;gap:12px;align-items:center;padding:9px 0;border-top:1px solid var(--line)}
.j-car i{display:block;width:38px;height:16px;border-radius:4px 10px 3px 3px;box-shadow:inset 0 -6px 0 rgba(0,0,0,.4)}
.j-iv{display:grid;grid-template-columns:1fr auto;gap:12px;align-items:center;padding:10px 0;border-top:1px solid var(--line)}
.j-iv small{display:block;color:var(--muted);font-size:12px}
.j-ivr{display:grid;justify-items:end;gap:3px}.j-ivr .up{color:var(--win)}.j-ivr .dn{color:var(--loss)}
.j-pos{display:grid;grid-template-columns:minmax(110px,1fr) minmax(90px,2fr) 34px;gap:6px 12px;align-items:center;padding:9px 0;border-top:1px solid var(--line)}
.j-pos i{display:block;height:8px;border-radius:4px;background:#1A0D33;overflow:hidden}.j-pos u{display:block;height:100%;background:linear-gradient(90deg,#7B3FE0,#D2A8FF)}
.j-pos.on>span:first-child{color:var(--neon);font-weight:700}.j-pos-b{grid-column:1/-1;display:flex;gap:6px;justify-content:flex-end}

.j-dec.fp-on{max-height:none}.j-dec-3d.fp-on{top:6px;overflow:auto}
.fp{display:grid;gap:10px}
.fp-scene{position:relative;width:100%;aspect-ratio:16/9;max-height:min(46vh,380px);overflow:hidden;border-radius:8px;border:1px solid rgba(201,155,255,.45);background:linear-gradient(180deg,#0b0518 0%,#1a0d36 24%,#2a1652 36%,#0e3d24 36.4%,#145a33 70%,#1b7040 100%)}
.fp-stand{position:absolute;left:0;right:0;top:10%;height:26%;background:repeating-linear-gradient(90deg,rgba(255,255,255,.06) 0 5px,transparent 5px 13px),linear-gradient(180deg,#22104a,#3a2070)}
.fp-sky::before,.fp-sky::after{content:"";position:absolute;top:1%;width:24%;height:11%;border-radius:50%;background:radial-gradient(closest-side,rgba(255,255,240,.95),rgba(201,155,255,.25) 60%,transparent)}
.fp-sky::before{left:5%}.fp-sky::after{right:5%}
.fp-turf{position:absolute;left:0;right:0;top:62%;bottom:0;background:repeating-linear-gradient(90deg,rgba(255,255,255,.04) 0 9%,transparent 9% 18%);border-top:2px solid rgba(255,255,255,.55)}
.fp-goal{position:absolute;left:18%;width:64%;top:18%;height:44%;border:6px solid #F4F1FA;border-bottom:none;box-shadow:0 0 18px rgba(201,155,255,.55);z-index:2}
.fp-net{position:absolute;inset:0;background:repeating-linear-gradient(0deg,rgba(255,255,255,.2) 0 1px,transparent 1px 9px),repeating-linear-gradient(90deg,rgba(255,255,255,.2) 0 1px,transparent 1px 9px),rgba(10,4,24,.4)}
.fp-zones{position:absolute;inset:0;display:grid;grid-template-columns:repeat(3,1fr);grid-template-rows:repeat(2,1fr);z-index:4}
.fp-z{background:transparent;border:1px dashed rgba(201,155,255,.3);cursor:crosshair;transition:background .15s}
.fp-z:hover,.fp-z:focus-visible{background:rgba(181,123,255,.24);outline:none}
.fp-z.sel{background:rgba(181,123,255,.4);box-shadow:inset 0 0 0 2px #E4CCFF}
.fp.done .fp-z{pointer-events:none}
.fp-gk{position:absolute;left:50%;top:100%;width:11%;height:64%;transform:translate(-50%,-100%);transition:left .42s cubic-bezier(.2,.8,.2,1),top .42s cubic-bezier(.2,.8,.2,1),transform .42s;z-index:3}
.fp-gk .h{position:absolute;left:26%;width:48%;top:0;height:22%;background:#E8B48A;box-shadow:inset 0 -3px 0 rgba(0,0,0,.2)}
.fp-gk .b{position:absolute;left:0;right:0;top:22%;bottom:0;background:linear-gradient(180deg,var(--gk,#FFD24A) 0 56%,#1b1b24 56% 74%,var(--gk,#FFD24A) 74%);box-shadow:inset 0 0 0 2px rgba(0,0,0,.18)}
.fp-wall{position:absolute;left:37%;width:24%;top:43%;height:23%;display:flex;gap:4%;z-index:5}
.fp-wall i{flex:1;background:linear-gradient(180deg,#E8B48A 0 18%,var(--wall,#2B2F8A) 18% 68%,#14141c 68%);box-shadow:inset 0 0 0 1px rgba(0,0,0,.25)}
.fp-ball{position:absolute;left:50%;top:86%;width:5%;aspect-ratio:1;transform:translate(-50%,-50%) scale(1.5);background:radial-gradient(circle at 35% 35%,#fff,#d8d4e4 60%,#9b95ad);border-radius:30%;box-shadow:0 4px 8px rgba(0,0,0,.45);z-index:6;transition:left .5s cubic-bezier(.3,.7,.3,1),top .5s cubic-bezier(.3,.7,.3,1),transform .5s}
.fp-ui{display:grid;gap:6px}.fp-step{margin:0;font-weight:700}
.fp-res{font-family:var(--display);font-size:30px;letter-spacing:.02em}.fp-res.ok{color:#E4CCFF;text-shadow:0 0 18px rgba(201,155,255,.9)}.fp-res.ko{color:var(--loss)}
.j-dec-3d .fp-scene{max-height:32vh}
@media(prefers-reduced-motion:reduce){.fp-gk,.fp-ball{transition:none}}
`;document.head.appendChild(css2);

/* ====== ampliación 2: tu futbolista cúbico en el partido 3D, momentos clave en 3D, capitán en el campo,
   pretemporada, sanciones, votaciones del vestuario, redes sociales, documental, mascota y logros ====== */

/* ---------- tu futbolista en el partido 3D: sustituye a su muñeco y celebra tus goles ---------- */
function myFigure(M,idx){const w=M.w,T=w.T,outer=new T.Group(),inner=new T.Group();outer.add(inner);
  buildFigure(T,inner,{...P,kit:UI.jl&&UI.jl.nat?'seleccion':'local'});inner.traverse(o=>{if(o.isMesh)o.castShadow=true;});outer.scale.setScalar(.3);w.root.add(outer);
  const fake={rotY:0},tick=w.tick;
  w.tick=(dt,t)=>{tick(dt,t);const L=UI.jl,p=M.P&&M.P[idx],on=!!(p&&L&&L.on&&!p.gone);outer.visible=on;if(!on)return;
    M.F.set(idx,0,-300,0,false,0);M.F.done();outer.position.set(p.x,0,p.z);
    const now=performance.now(),aL=inner.getObjectByName('armL'),aR=inner.getObjectByName('armR');
    if(L.cel&&now>L.cel&&now<L.cel+2600){if(!L.celOn){L.celOn=1;fake.rotY=0;}celebPose(fake,inner,P.celeb||0,(now-L.cel)/1000);
      const c=w.cam.position;outer.rotation.y=Math.atan2(c.x-p.x,c.z-p.z)+fake.rotY;return;}
    L.celOn=0;inner.rotation.set(0,0,0);const k=t/1000,run=p.run?1:0;inner.position.set(0,run*Math.abs(Math.sin(k*12))*.08,0);
    outer.rotation.y=p.ry+Math.PI/2;if(aL){aL.rotation.x=Math.sin(k*12)*.8*run;aL.rotation.z=-.05;}if(aR){aR.rotation.x=-Math.sin(k*12)*.8*run;aR.rotation.z=.05;}};}
function goalIdx(side,name,assist){const L=UI.jl;if(!L||side!==L.mySide||!L.on||P.pos==='POR')return{};const idx=MYIDX[P.pos]+(L.mySide==='h'?0:11);
  if(name===P.last){L.cel=performance.now()+2400;return{sc:idx,cel:1};}if(assist===P.last)return{as:idx};return{};}

/* ---------- momentos clave en 3D: césped, portería con red, grada, portero y barrera cúbicos ---------- */
function fp3D(F){const T=window.THREE;if(!T||typeof hasGL15!=='function'||!hasGL15()||reduced())return false;
  const scn=F.root.querySelector('.fp-scene');
  const k=F.kind,opp=UI.jm&&UI.jm.e&&UI.jm.e.opp&&club(UI.jm.e.opp),oc1=opp?opp.c1:'#2B2F8A',oc2=opp?opp.c2:'#F2F2F2';
  scn.classList.add('fp-3d');scn.innerHTML=`<canvas class="fp-cv" role="img" aria-label="Vista en 3D de la portería"></canvas><div class="fp-zones">${ZN.map((l,i)=>`<button class="fp-z" data-act="jFpAim" data-z="${i}" aria-label="${l}"></button>`).join('')}</div>`;
  const cv=scn.querySelector('canvas'),zones=scn.querySelector('.fp-zones');let r;
  try{r=new T.WebGLRenderer({canvas:cv,antialias:true});}catch(e){return false;}
  r.setPixelRatio(Math.min(devicePixelRatio||1,2));if('outputEncoding' in r)r.outputEncoding=T.sRGBEncoding;r.shadowMap.enabled=true;
  const sc=new T.Scene(),sky=pixTex(T,4,64,g=>{const gr=g.createLinearGradient(0,0,0,64);gr.addColorStop(0,'#05020c');gr.addColorStop(.55,'#1a0b3a');gr.addColorStop(1,'#3b1f6e');g.fillStyle=gr;g.fillRect(0,0,4,64);});
  sky.magFilter=T.LinearFilter;sc.background=sky;sc.fog=new T.Fog('#24113f',48,100);
  sc.add(new T.HemisphereLight(0xd8ccff,0x16351f,.8));const sun=new T.DirectionalLight(0xffffff,1.05);sun.position.set(-10,22,18);sun.castShadow=true;sun.shadow.mapSize.set(1024,1024);
  Object.assign(sun.shadow.camera,{left:-16,right:16,top:16,bottom:-16,near:1,far:80});sc.add(sun);const rim=new T.DirectionalLight(0xb57bff,.7);rim.position.set(12,8,-20);sc.add(rim);
  const Mt=(c,o={})=>new T.MeshStandardMaterial({color:new T.Color(c),roughness:.8,...o});
  const add=(geo,m,x,y,z,sh)=>{const o=new T.Mesh(geo,m);o.position.set(x,y,z);if(sh){o.castShadow=true;o.receiveShadow=true;}sc.add(o);return o;};
  const bx=(w_,h,d,m,x,y,z,sh)=>add(new T.BoxGeometry(w_,h,d),m,x,y,z,sh);
  /* césped a franjas y líneas del área */
  const gtx=pixTex(T,8,64,g=>{for(let i=0;i<8;i++){g.fillStyle=i%2?'#1d7039':'#238446';g.fillRect(0,i*8,8,8);}});gtx.wrapS=gtx.wrapT=T.RepeatWrapping;gtx.repeat.set(10,3);
  const gr=add(new T.PlaneGeometry(90,70),Mt('#ffffff',{map:gtx,roughness:.95}),0,0,15);gr.rotation.x=-Math.PI/2;gr.receiveShadow=true;
  const wl=Mt('#f4f4f4',{roughness:.6}),ln=(w_,d,x,z)=>bx(w_,.02,d,wl,x,.011,z);
  ln(60,.12,0,0);ln(18.32,.12,0,5.5);ln(.12,5.5,-9.16,2.75);ln(.12,5.5,9.16,2.75);ln(40.32,.12,0,16.5);ln(.12,16.5,-20.16,8.25);ln(.12,16.5,20.16,8.25);
  add(new T.CircleGeometry(.12,16),wl,0,.012,11).rotation.x=-Math.PI/2;
  /* portería y red */
  const pm=Mt('#ffffff',{roughness:.35});[-3.72,3.72].forEach(x=>bx(.12,2.5,.12,pm,x,1.25,0,true));bx(7.56,.12,.12,pm,0,2.5,0,true);
  const netM=(rx,ry)=>{const t=pixTex(T,32,32,g=>{g.fillStyle='rgba(255,255,255,.8)';for(let i=0;i<32;i+=8){g.fillRect(i,0,1,32);g.fillRect(0,i,32,1);}});t.wrapS=t.wrapT=T.RepeatWrapping;t.repeat.set(rx,ry);return new T.MeshBasicMaterial({map:t,transparent:true,side:T.DoubleSide,depthWrite:false});};
  const back=add(new T.PlaneGeometry(7.44,2.44),netM(18,6),0,1.22,-2);const roof=add(new T.PlaneGeometry(7.44,2),netM(18,5),0,2.44,-1);roof.rotation.x=-Math.PI/2;
  [-3.72,3.72].forEach(x=>{add(new T.PlaneGeometry(2,2.44),netM(5,6),x,1.22,-1).rotation.y=Math.PI/2;});
  /* grada con público, publicidad y focos */
  const stm=Mt('#24124a',{roughness:.9});for(let i=0;i<7;i++)bx(84,1.1,2.4,stm,0,.55+i*1.1,-7-i*2.4);
  const ad=pixTex(T,256,16,g=>{g.fillStyle='#12062a';g.fillRect(0,0,256,16);g.fillStyle='#C99BFF';g.font='bold 12px sans-serif';g.textBaseline='middle';for(let x=4;x<256;x+=128)g.fillText('PALCO DE HONOR',x,8.5);});
  ad.wrapS=T.RepeatWrapping;ad.repeat.set(4,1);bx(64,.9,.12,new T.MeshBasicMaterial({map:ad}),0,.45,-4.2);
  const n=900,im=new T.InstancedMesh(new T.BoxGeometry(.38,.55,.3),Mt('#ffffff',{roughness:.9}),n),d0=new T.Object3D(),col=new T.Color(),cb=[];
  for(let i=0;i<n;i++){const row=i%7,x=-40+Math.random()*80,y=1.1+row*1.1+.3,z=-7-row*2.4+(Math.random()-.5)*.5;cb.push([x,y,z]);d0.position.set(x,y,z);d0.updateMatrix();im.setMatrixAt(i,d0.matrix);col.set(pk([oc1,oc1,oc2,'#b57bff','#e8e0ff','#2a2a33']));im.setColorAt(i,col);}
  sc.add(im);[-30,30].forEach(x=>{bx(.5,24,.5,Mt('#3a3a46'),x,12,-27);bx(5,2,.6,new T.MeshBasicMaterial({color:'#fff6dc'}),x,24,-26.6);});
  /* jugadores cúbicos */
  const fig=(L,x,z,ry,s=.86)=>{const o=new T.Group(),inner=new T.Group();o.add(inner);buildFigure(T,inner,L);inner.traverse(m=>{if(m.isMesh)m.castShadow=true;});o.scale.setScalar(s);o.position.set(x,0,z);o.rotation.y=ry;sc.add(o);return{o,inner};};
  const rl=()=>({skin:R(0,6),hair:R(0,15),hairc:R(0,6),beard:R(0,3),boots:R(0,4),acc:0,num:R(2,24),last:pk(LASTN).toUpperCase(),height:R(176,192)});
  const gkL=k==='gk'?{...P,acc:4,num:1,kitC:{s:'#B57BFF',t:'#2A1450',p:'#2A1450',m:'#B57BFF'}}:{...rl(),acc:4,num:1,kitC:{s:'#F2C200',t:'#14141c',p:'#14141c',m:'#F2C200'}};
  const kz0=k==='uno'?3.4:.45,gk=fig(gkL,0,kz0,0,.88),B0={pen:[0,11],gk:[0,11],fk:[-4,18],uno:[.4,8]}[k];
  const btx=pixTex(T,16,16,g=>{g.fillStyle='#f4f4f4';g.fillRect(0,0,16,16);g.fillStyle='#1a1a22';[[2,2],[10,4],[5,9],[12,12],[1,13]].forEach(([x,y])=>g.fillRect(x,y,3,3));});
  const ball=add(new T.SphereGeometry(.12,18,14),Mt('#ffffff',{map:btx,roughness:.5}),B0[0],.12,B0[1],true);
  const wall=[];if(k==='fk'){const dx=-B0[0],dz=-B0[1],len=Math.hypot(dx,dz),wx=B0[0]+dx/len*9.15,wz=B0[1]+dz/len*9.15;F.wallAt=[wx,wz];
    for(let i=0;i<4;i++)wall.push(fig({...rl(),kitC:{s:oc1,t:oc2,p:oc2,m:oc1}},wx-.35+i*.6,wz,0,.86));}
  const shooter=k==='gk'?fig({...rl(),kitC:{s:oc1,t:oc2,p:oc2,m:oc1}},.35,12.3,Math.PI,.88):null;
  const camP={pen:[0,1.45,14.8],gk:[2.6,2.4,16.2],fk:[-4.6,1.6,21.6],uno:[.4,1.45,11.6]}[k],look={pen:[0,.75,0],gk:[0,1.1,2],fk:[0,.8,0],uno:[0,.8,0]}[k];
  const cam=new T.PerspectiveCamera({pen:40,fk:44,uno:40,gk:38}[k],16/9,.1,220);cam.position.set(...camP);cam.lookAt(...look);
  const place=()=>{const w_=scn.clientWidth||600,h=scn.clientHeight||338;r.setSize(w_,h,false);cam.aspect=w_/h;cam.updateProjectionMatrix();
    const a=new T.Vector3(-3.66,2.44,0).project(cam),b=new T.Vector3(3.66,0,0).project(cam),L_=(a.x+1)/2*100,Tp=(1-a.y)/2*100,R_=(b.x+1)/2*100,Bt=(1-b.y)/2*100;
    Object.assign(zones.style,{left:L_+'%',top:Tp+'%',width:(R_-L_)+'%',height:(Bt-Tp)+'%'});};
  place();const ro=window.ResizeObserver?new ResizeObserver(place):null;ro&&ro.observe(scn);
  const Z3=[[-2.45,1.78],[0,1.85],[2.45,1.78],[-2.45,.5],[0,.45],[2.45,.5]],ease=u=>1-Math.pow(1-u,3),t0=performance.now();let A=null,raf=0,dead=false;
  const arms=(f,l,rr,x)=>{const aL=f.inner.getObjectByName('armL'),aR=f.inner.getObjectByName('armR');if(aL){aL.rotation.z=l;aL.rotation.x=x||0;}if(aR){aR.rotation.z=rr;aR.rotation.x=x||0;}};
  const disp=()=>{if(dead)return;dead=true;cancelAnimationFrame(raf);ro&&ro.disconnect();sc.traverse(o=>{o.geometry&&o.geometry.dispose();if(o.material)(Array.isArray(o.material)?o.material:[o.material]).forEach(m=>{m.map&&m.map.dispose();m.dispose();});});sky.dispose();r.dispose();try{r.forceContextLoss();}catch(e){}};
  const loop=now=>{if(!document.body.contains(cv)){disp();return;}raf=requestAnimationFrame(loop);const t=(now-t0)/1000;
    if(!A){gk.o.position.x=Math.sin(t*1.7)*.35;gk.inner.position.y=Math.abs(Math.sin(t*3.4))*.04;arms(gk,-.5,.5);wall.forEach((w,i)=>{w.inner.position.y=Math.abs(Math.sin(t*2+i))*.02;});}
    else A();r.render(sc,cam);};
  raf=requestAnimationFrame(loop);
  F.g3={anim(out,kz,bz){const s0=performance.now(),[kx,ky]=Z3[kz];let [tx,ty]=Z3[bz],tz=-.15;tx+=(Math.random()-.5)*.5;ty+=(Math.random()-.5)*.2;
    if(out==='miss'){if(bz<3||ch(.5))ty=2.95;else tx=(Math.sign(tx)||1)*4.4;tz=-1.5;}
    if(out==='wall'){tx=F.wallAt[0];ty=1.45;tz=F.wallAt[1]+.3;}
    if(out==='save'){tx=kx*.86;ty=Math.max(.4,ky*.95);tz=kz0+.15;}
    const p0=ball.position.clone(),curve=k==='fk'?(tx>p0.x?-2.4:2.4):0,p1=new T.Vector3((p0.x+tx)/2+curve,Math.max(p0.y,ty)+(k==='fk'?2.4:.5),(p0.z+tz)/2),run=k==='gk'?.5:0,fl=k==='fk'?1:.7,gx0=gk.o.position.x,dir=Math.sign(kx),top=kz<3;
    A=()=>{const e=(performance.now()-s0)/1000;if(shooter)shooter.o.position.z=12.3-Math.min(1,e/Math.max(run,.01))*1;
      if(e<run)return;const u=clamp((e-run)/fl,0,1),q=1-u;
      if(u<1)ball.position.set(q*q*p0.x+2*q*u*p1.x+u*u*tx,q*q*p0.y+2*q*u*p1.y+u*u*ty,q*q*p0.z+2*q*u*p1.z+u*u*tz);ball.rotation.x-=.3;
      const g=ease(clamp((e-run-.1)/(fl*.75),0,1));gk.o.position.x=gx0+(kx-gx0)*g*.92;gk.o.position.y=top?g*.55:0;gk.o.position.z=kz0+(k==='uno'?g*.7:0);
      gk.inner.rotation.z=-dir*g*(top?1.05:1.35);if(!dir&&top)arms(gk,-.3,.3,-2.8*g);else arms(gk,-.5-g*(dir<0?2.3:1.5),.5+g*(dir>0?2.3:1.5));
      wall.forEach(w=>{w.o.position.y=Math.sin(clamp((e-run)/.5,0,1)*Math.PI)*.45;arms(w,-.1,.1,-2.6*Math.sin(clamp((e-run)/.5,0,1)*Math.PI));});
      if(u>=1){const a=e-run-fl;
        if(out==='goal'){back.position.z=-2-Math.sin(clamp(a/.45,0,1)*Math.PI)*.4;ball.position.set(tx,Math.max(.12,ty-a*2.6),Math.max(-1.85,tz-a*3));
          if(a<2.6)for(let i=0;i<n;i+=2){const c=cb[i];d0.position.set(c[0],c[1]+Math.abs(Math.sin(a*11+i))*.35,c[2]);d0.updateMatrix();im.setMatrixAt(i,d0.matrix);}im.instanceMatrix.needsUpdate=true;}
        else if(out==='save'||out==='wall')ball.position.set(tx+(tx>=0?1:-1)*a*4,Math.max(.12,ty+a*2.2-a*a*6),tz+a*7);
        else ball.position.set(tx+(tx-p0.x)*a*.3,ty+a*.5,tz-a*6);}
      cam.position.x+=(camP[0]*.85-cam.position.x)*.02;cam.position.z+=(camP[2]-1.3-cam.position.z)*.02;cam.lookAt(...look);};}};
  return true;}

/* ---------- capitán en el campo ---------- */
const CAPO=[['Calmar el partido','Pides al equipo replegarse y tocar.'],['Presión arriba','Ordenas adelantar líneas y apretar.'],['Protestar al árbitro','Te encaras con el árbitro por una falta no pitada.']];
function showCap(){const L=UI.jl,d=document.getElementById('jdec');if(!d){liveRun();return;}const my=L.mySide==='h'?L.hg:L.ag,th=L.mySide==='h'?L.ag:L.hg;L.capOpen=true;
  L.M&&L.M.l3&&L.M.l3(`<span class="l3-tag">Capitán</span><b>${esc(P.last)}</b><em>${L.m}'</em>`,2200);
  d.innerHTML=`<p class="j-sit"><b class="num">${L.m}'</b> Llevas el brazalete. ${my<th?'Vais por detrás en el marcador.':my>th?'Vais ganando y el rival aprieta.':'Partido igualado.'} ¿Qué ordenas?</p><div class="j-opts">${CAPO.map((o,j)=>`<button class="j-op" data-act="jCap" data-j="${j}"><b>${o[0]}</b><small>${o[1]}</small></button>`).join('')}</div>`;d.hidden=false;d.querySelector('button').focus({preventScroll:true});}
function capDecide(j){const L=UI.jl;if(!L||!L.capOpen)return;L.capOpen=false;const d=document.getElementById('jdec');if(d){d.hidden=true;d.innerHTML='';}
  const mine=L.mySide,rival=mine==='h'?'a':'h',mates=squadNames(P.club,P.last),later=()=>clamp(L.m+R(3,12),L.m+1,89);
  if(j===0){const ix=L.ev.findIndex(x=>x.kind==='goal'&&x.side===rival);if(ix>=0&&ch(.6))L.ev.splice(ix,1);const ox=L.ev.findIndex(x=>x.kind==='goal'&&x.side===mine);if(ox>=0&&ch(.3))L.ev.splice(ox,1);feed('El capitán pide calma: el equipo controla el balón.');P.chem=clamp(P.chem+1,0,100);}
  else if(j===1){if(ch(.55))L.ev.push({m:later(),kind:'goal',side:mine,n:pk(mates)});if(ch(.35))L.ev.push({m:later(),kind:'goal',side:rival,n:pk(squadNames(L.mySide==='h'?L.aId:L.hId))});feed('El capitán ordena presión arriba: el equipo se lanza.');P.chem=clamp(P.chem+1,0,100);}
  else{if(ch(.4+P.rep.polemico/40)){UI.jm.res.yel=(UI.jm.res.yel||0)+1;feed(`Amarilla para ${P.last} por protestar.`);if(UI.jm.res.yel>=2){UI.jm.res.redMin=L.m;L.on=false;L.ev=L.ev.filter(x=>x.kind!=='moment'&&x.kind!=='cap');feed(`¡Segunda amarilla! ${P.last} se va a la caseta.`,true);}}
    else{feed('El árbitro toma nota de la protesta.');if(ch(.25))L.ev.push({m:later(),kind:'goal',side:mine,n:pk(mates)});}P.rep.polemico+=.2;}
  P.rep.lider+=.3;L.ev.sort((a,b)=>a.m-b.m);liveRun();}

/* ---------- votaciones del vestuario ---------- */
function lockerVotes(n){ensureMates();const M=P.mates||[],nm=()=>(pk(M)||{n:'un compañero'}).n;
  const best=n>=7.1&&P.sea.pj>=10&&(avg(M.map(m=>m.c))>=40||ch(.5)),hard=(P.sea.hard||0)>=12||(P.intensity==='intensa'&&ch(.5)),pes=(P.rep.polemico>=4&&ch(.6))||(P.sea.party||0)>=4;
  const v=[['Mejor jugador del vestuario',best?'tú':nm()],['El más trabajador',hard?'tú':nm()],['El más pesado',pes?'tú':nm()]];
  P.votes=P.votes||[];P.votes.push({s:seasonLabel(P.season),v});P.votes=P.votes.slice(-25);
  if(best)award('MVP del vestuario');if(hard){P.tru=clamp(P.tru+4,0,100);P.chem=clamp(P.chem+3,0,100);}
  if(pes){P.chem=clamp(P.chem-4,0,100);news('El vestuario te elige «el más pesado» de la temporada. Risas… y algún mensaje en el grupo.');}}
function votesBlock(s){const v=(P.votes||[]).slice(-1)[0];return v&&v.s===s?`<div class="j-votes"><h4>Votaciones del vestuario</h4>${v.v.map(([k,w])=>`<p class="j-n"><b>${k}</b>${w==='tú'?'<span class="j-neon">¡Tú!</span>':esc(w)}</p>`).join('')}</div>`:'';}

/* ---------- redes sociales ---------- */
const handle=()=>'@'+(P.name+P.last).toLowerCase().normalize('NFD').replace(/[^a-z0-9]/g,'');
function postOpts(won,g){return[['equipo',won?'Tres puntos que valen oro. Equipo.':'Toca levantarse. Juntos.'],['yo',g?`${g>1?g+' goles':'Gol'} y a seguir. Esto no ha hecho más que empezar.`:'Trabajo, trabajo y más trabajo.'],['pique',won?'Que sigan hablando.':'Ya hablaremos en la vuelta.'],['casa','Recuperando en casa. Mañana, más.']];}
const COMS={bien:['¡Qué partidazo!','Crack, sigue así.','El mejor del equipo, sin discusión.','Te mereces la selección.','Orgulloso de ti.'],mal:['Hoy no era el día…','A levantarse, campeón.','Más intensidad, por favor.','Se te ha visto cansado.'],pique:['Uff, se viene polémica.','Eso no se dice, hombre.','¡Con dos narices!','El rival no va a olvidar esto.'],casa:['¡Qué casa!','Descansa, que lo necesitas.','Esa vida, quién la pillara.']};
function socialBlock(F,won){if(!F.min)return'';const R0=UI.jm.res;
  return `<div class="j-social" id="jsoc"><h4>Publicar en redes</h4><div class="j-chips">${postOpts(won,R0.g).map(([k,t])=>`<button class="j-chip" data-act="jPost" data-k="${k}">«${esc(t)}»</button>`).join('')}<button class="j-chip" data-act="jPost" data-k="no">No publicar</button></div></div>`;}
function doPost(k){const M=UI.jm;if(!M||M.posted||!M.final)return;M.posted=true;const box=document.getElementById('jsoc');if(k==='no'){if(box)box.remove();return;}
  const F=M.final,won=F.pens?F.won:F.gf>F.ga,g=M.res.g,cap=(postOpts(won,g).find(x=>x[0]===k)||[])[1]||'';
  const likes=Math.round(P.followers*(.02+F.rt/220)*(won?1.3:.8)*({pique:1.7,yo:1.2,equipo:1,casa:.9}[k])*(.8+Math.random()*.4));
  const pool=k==='pique'?COMS.pique:k==='casa'?COMS.casa:F.rt>=6.5?COMS.bien:COMS.mal,com=[...pool].sort(()=>Math.random()-.5).slice(0,3);
  P.fame=clamp(P.fame+({pique:.8,yo:.5,equipo:.4,casa:.3}[k])*(won?1:.5),0,100);
  if(k==='equipo'){P.rep.humilde+=.3;P.chem=clamp(P.chem+1,0,100);}else if(k==='yo')P.rep.mediatico+=.3;else if(k==='casa')P.rep.mediatico+=.2;
  else{P.rep.polemico+=.6;if(!won){P.tru=clamp(P.tru-3,0,100);P.mor=clamp(P.mor-3,0,100);com[0]='Perder y encima provocar…';}}
  if(likes>=1e6)flag('viral');P.posts=P.posts||[];P.posts.unshift({s:P.season,w:P.week,cap,likes,com});P.posts=P.posts.slice(0,15);save();
  if(box)box.innerHTML=postCard(P.posts[0]);}
function postCard(p){return `<div class="j-post"><div class="j-post-h">${avatar(P,36)}<div><b>${esc(P.name)} ${esc(P.last)}</b><small>${handle()}</small></div></div><p>${esc(p.cap)}</p><small class="num">${p.likes.toLocaleString('es-ES')} me gusta</small>${p.com.map(c=>`<p class="j-com"><b>@aficionado${R(10,999)}</b> ${esc(c)}</p>`).join('')}</div>`;}
function postsBlock(){const L=P.posts||[];return `<h3 style="margin-top:20px">Tus publicaciones</h3>${L.length?L.slice(0,4).map(p=>`<p class="j-n"><b class="num">${p.likes.toLocaleString('es-ES')} ♥</b>«${esc(p.cap)}» · ${esc(p.com[0]||'')}</p>`).join(''):'<p class="muted">Publica después de cada partido desde el resumen.</p>'}`;}

/* ---------- documental de tu carrera ---------- */
function docChapters(){const C=[],cards=P.cards||[],F=fam();
  C.push({e:'Capítulo 1 · Los inicios',h:`${P.name} ${P.last}`,b:`${P.nat}, ${P.startAge} años. ${P.origin}: así empezó todo. Primera parada, ${cname(P.origin0)}. Sueño: ${DREAMS[P.dream].toLowerCase()}.`,c:cards.find(c=>c.t==='debut')});
  P.hist.forEach((h,i)=>{const t=P.titles.filter(x=>x.s===h.s).map(x=>x.n),a=P.awards.filter(x=>x.s===h.s).map(x=>x.n),mv=P.moves.filter(x=>x.s===h.s).map(x=>`${x.t}: ${x.from} → ${x.to}`),kids=F.kids.filter(k=>seasonLabel(k.b)===h.s).map(k=>`Nace ${k.n}`);
    C.push({e:`Capítulo ${i+2} · ${h.s}`,h:h.c,st:[['Partidos',h.pj],['Goles',h.g],['Asist.',h.a],['Nota',h.n],['Media',h.o]],li:[...t.map(x=>'Título: '+x),...a.map(x=>'Premio: '+x),...mv,...kids],c:cards.find(c=>c.s===h.s&&c.t!=='debut')});});
  C.push({e:'Último capítulo · El adiós',h:'Leyenda',b:`${P.st.pj} partidos, ${P.st.g} goles y ${P.st.a} asistencias. ${P.titles.length} títulos, ${P.awards.length} premios y una media máxima de ${P.peak}.${P.coach&&P.coach.hist.length?` Después, ${P.coach.hist.length} temporadas en los banquillos y ${P.coach.titles.length} títulos más.`:''}`,c:cards.find(c=>c.t==='icono')});
  return C;}
function showDoc(i){const C=docChapters();i=clamp(i,0,C.length-1);clearTimeout(UI.docT);const c=C[i];UI.docI=i;
  modal(`<div class="hd j-mhd"><h3>Documental · ${esc(P.name)} ${esc(P.last)}</h3></div><div class="bd j-doc"><div class="j-doc-dots" aria-hidden="true">${C.map((_,j)=>`<i class="${j<=i?'on':''}"></i>`).join('')}</div>
   <div class="j-doc-ch" key="${i}"><div class="j-doc-tx"><div class="j-eyebrow">${esc(c.e)}</div><h2 class="j-h">${esc(c.h)}</h2>${c.b?`<p>${esc(c.b)}</p>`:''}${c.st?`<div class="j-kv">${c.st.map(([l,v])=>`<div><small>${l}</small><b class="num">${v}</b></div>`).join('')}</div>`:''}${c.li&&c.li.length?`<ul class="j-doc-li">${c.li.map(x=>`<li>${esc(x)}</li>`).join('')}</ul>`:''}</div>${c.c?`<div class="j-doc-card">${cardBox(c.c)}</div>`:''}</div>
   <div class="j-acts"><button class="btn" data-act="jDoc" data-i="${i-1}" ${i?'':'disabled'}>← Anterior</button>${i<C.length-1?`<button class="btn primary" data-act="jDoc" data-i="${i+1}" data-focus>Siguiente →</button>`:'<button class="btn primary" data-act="jClose" data-focus>Fin</button>'}<button class="btn" data-act="jDocAuto">${UI.docAuto?'Pausa':'Reproducción automática'}</button></div></div>`);
  if(UI.docAuto&&i<C.length-1&&!reduced())UI.docT=setTimeout(()=>{if(document.querySelector('.j-doc'))showDoc(i+1);},5200);}

/* ---------- mascota (solo una) ---------- */
const PETS=[['perro','Perro',1200,'Te saca a pasear: recuperas algo más de energía.'],['gato','Gato',600,'Te recibe ronroneando: más moral.'],['hamster','Hámster',80,'Pequeño y gracioso: un poco más de moral.'],['conejo','Conejo',150,'Tranquilo y adorable: más moral.'],['loro','Loro',900,'Sus vídeos se hacen virales: algo más de fama.'],['tortuga','Tortuga',200,'Te enseña paciencia: mejores decisiones a largo plazo.']];
const PETN={perro:['Toby','Luna','Rocky','Kira','Thor'],gato:['Misi','Simba','Nala','Garfield','Mía'],hamster:['Bolita','Pipas','Nuez','Gofre'],conejo:['Copito','Tambor','Pelusa','Zanahoria'],loro:['Paco','Kiwi','Coco','Lola'],tortuga:['Manuelita','Rayo','Tortu','Sabia']};
const PET3={perro:{c:'#b07a3e',p:[[.9,.42,.38,0,0,.55,0],[.4,.38,.36,0,.6,.82,0],[.2,.16,.26,'#d9a46a',.86,.74,0],[.06,.06,.1,'#111',.97,.8,0],[.1,.24,.1,'#5a3a1e',.55,1.04,.17],[.1,.24,.1,'#5a3a1e',.55,1.04,-.17],[.32,.08,.08,0,-.58,.82,0]],legs:[.12,.36,.3,.12],eye:[.8,.9,.09]},
  gato:{c:'#f0a040',p:[[.7,.32,.3,0,0,.45,0],[.32,.3,.3,0,.45,.66,0],[.08,.12,.08,'#c87a28',.48,.87,.1],[.08,.12,.08,'#c87a28',.48,.87,-.1],[.08,.5,.08,0,-.4,.75,0]],legs:[.08,.3,.25,.1],eye:[.61,.7,.07]},
  hamster:{c:'#e8c08a',p:[[.42,.3,.34,0,0,.2,0],[.24,.24,.26,0,.26,.25,0],[.2,.12,.26,'#fff3df',.1,.12,0],[.06,.08,.06,'#c48a5a',.3,.4,.08],[.06,.08,.06,'#c48a5a',.3,.4,-.08]],legs:null,eye:[.39,.3,.07]},
  conejo:{c:'#f2f2f2',p:[[.55,.4,.35,0,0,.32,0],[.28,.28,.26,0,.36,.52,0],[.07,.38,.08,0,.34,.84,.07],[.07,.38,.08,0,.34,.84,-.07],[.14,.14,.14,'#ffffff',-.32,.4,0],[.04,.04,.04,'#ff8fb0',.51,.5,0]],legs:[.1,.12,.2,.12],eye:[.5,.58,.08]},
  loro:{c:'#2fbf4f',p:[[.3,.45,.3,0,0,.42,0],[.26,.26,.26,'#e23b3b',.06,.78,0],[.12,.1,.1,'#ffd24a',.24,.74,0],[.12,.36,.1,'#2a7bd8',-.2,.26,0],[.06,.14,.28,'#1f9a3c',0,.48,.17],[.06,.14,.28,'#1f9a3c',0,.48,-.17]],legs:[.05,.2,.06,.07],eye:[.19,.84,.08]},
  tortuga:{c:'#3d7a3a',p:[[.7,.3,.55,0,0,.3,0],[.5,.12,.4,'#4f9a4a',0,.5,0],[.22,.16,.18,'#9a8a5a',.45,.25,0]],legs:[.14,.14,.25,.22],legc:'#9a8a5a',eye:[.56,.29,.06]}};
function petMesh(T,g,kind){const D=PET3[kind];if(!D)return;const G=new T.Group();G.name='pet';G.scale.setScalar(1.7);g.add(G);
  const M=c=>new T.MeshStandardMaterial({color:new T.Color(c||D.c),roughness:.8});const b=(w_,h,d,c,x,y,z)=>{const o=new T.Mesh(new T.BoxGeometry(w_,h,d),M(c));o.position.set(x,y,z);o.castShadow=true;G.add(o);};
  D.p.forEach(([w_,h,d,c,x,y,z])=>b(w_,h,d,c||D.c,x,y,z));
  if(D.legs){const [lw,lh,lx,lz]=D.legs;[[1,1],[1,-1],[-1,1],[-1,-1]].forEach(([sx,sz])=>b(lw,lh,lw,D.legc||D.c,sx*lx,lh/2,sz*lz));}
  const [ex,ey,ez]=D.eye;[1,-1].forEach(s=>b(.04,.05,.04,'#111',ex,ey,s*ez));}
function petSVG(kind,size=44){const D=PET3[kind];if(!D)return'';const c=D.c;
  const shapes={perro:`<rect x="6" y="20" width="26" height="12" fill="${c}"/><rect x="28" y="12" width="12" height="12" fill="${c}"/><rect x="38" y="17" width="5" height="5" fill="#d9a46a"/><rect x="28" y="9" width="4" height="7" fill="#5a3a1e"/><rect x="2" y="18" width="5" height="3" fill="${c}"/><rect x="8" y="32" width="4" height="7" fill="${c}"/><rect x="26" y="32" width="4" height="7" fill="${c}"/><rect x="34" y="15" width="2" height="2" fill="#111"/>`,
    gato:`<rect x="8" y="22" width="22" height="10" fill="${c}"/><rect x="28" y="14" width="11" height="11" fill="${c}"/><rect x="28" y="10" width="3" height="5" fill="#c87a28"/><rect x="36" y="10" width="3" height="5" fill="#c87a28"/><rect x="4" y="10" width="3" height="14" fill="${c}"/><rect x="10" y="32" width="3" height="7" fill="${c}"/><rect x="25" y="32" width="3" height="7" fill="${c}"/><rect x="34" y="18" width="2" height="2" fill="#111"/>`,
    hamster:`<rect x="10" y="20" width="22" height="16" fill="${c}"/><rect x="26" y="16" width="12" height="14" fill="${c}"/><rect x="14" y="30" width="14" height="6" fill="#fff3df"/><rect x="28" y="13" width="3" height="4" fill="#c48a5a"/><rect x="34" y="20" width="2" height="2" fill="#111"/>`,
    conejo:`<rect x="8" y="22" width="22" height="14" fill="${c}"/><rect x="26" y="16" width="12" height="12" fill="${c}"/><rect x="27" y="2" width="3" height="15" fill="${c}"/><rect x="32" y="2" width="3" height="15" fill="${c}"/><rect x="4" y="24" width="5" height="5" fill="#ffffff"/><rect x="34" y="20" width="2" height="2" fill="#111"/>`,
    loro:`<rect x="16" y="16" width="12" height="18" fill="${c}"/><rect x="17" y="6" width="11" height="11" fill="#e23b3b"/><rect x="28" y="10" width="5" height="4" fill="#ffd24a"/><rect x="12" y="30" width="5" height="10" fill="#2a7bd8"/><rect x="24" y="9" width="2" height="2" fill="#111"/>`,
    tortuga:`<rect x="8" y="18" width="26" height="12" fill="${c}"/><rect x="12" y="14" width="18" height="5" fill="#4f9a4a"/><rect x="33" y="22" width="8" height="6" fill="#9a8a5a"/><rect x="10" y="30" width="5" height="5" fill="#9a8a5a"/><rect x="27" y="30" width="5" height="5" fill="#9a8a5a"/><rect x="38" y="23" width="2" height="2" fill="#111"/>`};
  return `<svg viewBox="0 0 44 44" width="${size}" height="${size}" aria-hidden="true" shape-rendering="crispEdges">${shapes[kind]||''}</svg>`;}
function petPanel(){const p=P.pet;
  if(p){const d=PETS.find(x=>x[0]===p.k);return `<div class="j-panel"><h3>Tu mascota</h3><div class="j-pet on">${petSVG(p.k,64)}<div><b>${esc(p.n)}</b><small>${d[1]} · desde ${esc(p.s)}</small><small>${d[3]}</small></div></div><p class="j-hint">${hasHome()?'Vive en tu casa: la verás paseando por la parcela en la Ciudad.':'Cuando tengas casa propia la verás paseando por tu parcela en la Ciudad.'}</p><div class="j-acts"><button class="btn small" data-act="jPetName">Cambiar el nombre</button><button class="btn small" data-act="jPetGive">Buscarle otro hogar</button></div></div>`;}
  return `<div class="j-panel"><h3>Mascota</h3><p class="j-hint">Solo puedes tener una. Elige con calma: cada una te ayuda a su manera.</p><div class="j-pets">${PETS.map(([k,l,price,txt])=>`<button class="j-pet" data-act="jPetAdopt" data-k="${k}" ${P.money<price?'disabled':''}>${petSVG(k,48)}<div><b>${l}</b><small>${txt}</small><small class="num">${eur(price)}</small></div></button>`).join('')}</div></div>`;}

/* ---------- logros ---------- */
const flag=k=>{(P.flags=P.flags||{})[k]=1;},F_=k=>!!(P.flags&&P.flags[k]);
const ACH=[
  ['gol1','Primer gol','Marca tu primer gol oficial.',()=>P.st.g>=1],['g100','Centenario','Llega a 100 goles.',()=>P.st.g>=100],['g300','Goleador histórico','Llega a 300 goles.',()=>P.st.g>=300],
  ['a100','Asistente de lujo','Da 100 asistencias.',()=>P.st.a>=100],['pj500','Incombustible','Juega 500 partidos.',()=>P.st.pj>=500],['hat','Hat-trick','Marca tres goles en un partido.',()=>F_('hat')],
  ['perfect','Partido perfecto','Saca un 9,5 o más en un partido.',()=>F_('perfect')],['pen','Sangre fría','Marca un penalti en primera persona.',()=>F_('pen')],['fk','Guante en el pie','Marca un gol de falta directa en primera persona.',()=>F_('fk')],
  ['save','Muro','Para un penalti en primera persona.',()=>F_('save')],['titulo','Primer título','Gana tu primer título.',()=>P.titles.length>=1],['champions','Noches de Champions','Gana la Champions League.',()=>P.titles.some(t=>t.n==='Champions League')],
  ['mundial','Campeón del mundo','Gana el Mundial.',()=>P.titles.some(t=>/^Mundial( \d+)?$/.test(t.n))],['balon','Balón de Oro','Gana el Balón de Oro.',()=>P.awards.some(a=>a.n==='Balón de Oro')],
  ['tres','Trotamundos ganador','Gana títulos con 3 clubes distintos.',()=>new Set(P.titles.filter(t=>t.c!==P.nat).map(t=>t.c)).size>=3],['capitan','El brazalete','Sé capitán de tu club o de tu selección.',()=>P.captain||P.sel.captain],
  ['media90','Élite mundial','Alcanza 90 de media.',()=>(P.peak||0)>=90],['dupla','Dupla letal','Forma una dupla letal con un compañero.',()=>(P.mates||[]).some(m=>m.duo)],['album','Coleccionista','Reúne 15 cartas en tu álbum.',()=>(P.cards||[]).length>=15],
  ['limpio','Juego limpio','Termina una temporada de 30 partidos o más sin tarjetas.',()=>F_('clean')],['roja','Cabeza caliente','Ve tu primera tarjeta roja.',()=>F_('red')],['mvp','El vestuario habla','Gana la votación al mejor jugador del vestuario.',()=>P.awards.some(a=>a.n==='MVP del vestuario')],
  ['viral','Viral','Consigue un millón de me gusta en una publicación.',()=>F_('viral')],['padre','Padre','Ten tu primer hijo.',()=>fam().kids.length>0],['hijo','De tal palo…','Tu hijo firma como profesional.',()=>fam().kids.some(k=>k.pro)],
  ['mansion','Casa de revista','Termina tu casa moderna.',()=>!!(P.home&&homeLevel(P.home)>=18)],['hiper','Garaje de ensueño','Ten un hiperdeportivo en tu garaje.',()=>(P.cars||[]).includes('hiper')],
  ['inversor','Inversor','Ten inversiones por valor de 3 M€.',()=>Object.values(P.inv||{}).reduce((s,x)=>s+x.v,0)>=3e6],['mascota','Mejor amigo','Adopta una mascota.',()=>!!P.pet],
  ['fiel','Un club, una vida','Retírate en tu primer club.',()=>P.retired&&P.club===P.origin0],['mister','Título desde el banquillo','Gana un título como entrenador.',()=>!!(P.coach&&P.coach.titles.length)],
];
function achCheck(){if(!P||!P.st)return;P.ach=P.ach||{};let got=0;ACH.forEach(([id,n,,fn])=>{if(P.ach[id])return;let ok=false;try{ok=fn();}catch(e){}if(ok){P.ach[id]=seasonLabel(P.season);got++;news(`Logro desbloqueado: ${n}.`,'hot');if(got<=2&&typeof toast==='function')toast(`Logro desbloqueado: ${n}`);}});}
function achPanel(){const A=P.ach||{},n=ACH.filter(a=>A[a[0]]).length;
  return `<div class="j-panel"><h3>Logros · <span class="num">${n}/${ACH.length}</span></h3><div class="j-ach">${ACH.map(([id,l,d])=>`<div class="${A[id]?'on':''}"><b>${l}</b><small>${esc(d)}${A[id]?` · ${esc(A[id])}`:''}</small></div>`).join('')}</div></div>`;}

/* ---------- eventos y acciones nuevas ---------- */
Object.assign(EV,{
  pretemporada:{t:()=>`Arranca la pretemporada. El club te deja elegir cómo prepararla.`,o:[
    ['Gira por Asia (fama y dinero, mucho cansancio)',()=>{P.fame+=4;P.money+=Math.round(wageWeek()*3+20000);P.fat+=18;news(`Gira por Asia: estadios llenos y miles de camisetas de ${P.last} vendidas.`,'hot');}],
    ['Gira por Estados Unidos (fama, algo de cansancio)',()=>{P.fame+=3;P.money+=Math.round(wageWeek()*2+15000);P.fat+=10;news(`Gira por Estados Unidos: ${P.last} brilla en los amistosos.`);}],
    ['Pretemporada en casa (llegas a tope)',()=>{P.fat=Math.max(0,P.fat-20);P.form=clamp(P.form+10,10,99);P.tru+=4;P.lp+=.5;news(`${P.last} hace una pretemporada impecable en la ciudad deportiva.`);}]]},
});
Object.assign(ACT,{
  jCap(d){capDecide(+d.j);},
  jPost(d){doPost(d.k);},
  jDoc(d){showDoc(+d.i);},jDocAuto(){UI.docAuto=!UI.docAuto;showDoc(UI.docI||0);},
  jPetAdopt(d){const p=PETS.find(x=>x[0]===d.k);if(!p||P.pet||P.money<p[2])return;P.money-=p[2];P.pet={k:p[0],n:pk(PETN[p[0]]),s:seasonLabel(P.season)};P.mor=clamp(P.mor+6,0,100);news(`${P.last} adopta a ${P.pet.n}, su nuevo ${p[1].toLowerCase()}.`,'hot');save();rr();C3D&&C3D.rebuildHouse();},
  jPetName(){if(!P.pet)return;const L=PETN[P.pet.k],i=L.indexOf(P.pet.n);P.pet.n=L[(i+1)%L.length];save();rr();},
  jPetGive(){if(!P.pet)return;news(`${P.pet.n} encuentra un nuevo hogar con una familia amiga.`);P.pet=null;P.mor=clamp(P.mor-6,0,100);save();rr();C3D&&C3D.rebuildHouse();},
});

const css3=document.createElement('style');css3.textContent=`
.fp-3d{background:#0f0722}.fp-3d .fp-cv{position:absolute;inset:0;width:100%;height:100%;display:block}
.fp-3d .fp-zones{position:absolute;inset:auto;z-index:4}
.fp-3d .fp-z{border-color:rgba(228,204,255,.28)}
.j-social{margin-top:14px;padding-top:12px;border-top:1px solid var(--line)}.j-social h4{margin:0 0 8px}
.j-social .j-chip{text-align:left;white-space:normal}
.j-post{padding:12px 14px;border:1px solid rgba(201,155,255,.4);border-radius:10px;background:#160a2c}
.j-post-h{display:flex;gap:10px;align-items:center;margin-bottom:6px}.j-post-h svg{border-radius:8px}.j-post-h small{display:block;color:var(--muted)}
.j-post>p{margin:4px 0 6px}.j-com{margin:4px 0 0;font-size:13px;color:var(--muted)}.j-com b{color:var(--neon);font-weight:600}
.j-votes{margin:10px 0}.j-votes h4{margin:0 0 4px}
.j-ach{display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:10px}
.j-ach>div{padding:10px 12px;border:1px solid var(--line);border-radius:8px;opacity:.5}
.j-ach>div.on{opacity:1;border-color:rgba(201,155,255,.6);box-shadow:inset 0 0 0 1px rgba(201,155,255,.25),0 0 22px -12px #B57BFF}
.j-ach b{display:block}.j-ach small{color:var(--muted);font-size:12px}
.j-doc-dots{display:flex;gap:4px;margin-bottom:14px}.j-doc-dots i{flex:1;height:3px;border-radius:2px;background:rgba(214,190,255,.18)}.j-doc-dots i.on{background:#C99BFF}
.j-doc-ch{display:grid;grid-template-columns:1fr auto;gap:20px;align-items:center;animation:jdoc .6s cubic-bezier(.16,1,.3,1)}
.j-doc-card .j-cc .j-card{max-width:190px}.j-doc-li{margin:10px 0 0;padding-left:18px}.j-doc-li li{margin:3px 0}
@keyframes jdoc{from{opacity:0;transform:translateY(14px)}}
@media(max-width:640px){.j-doc-ch{grid-template-columns:1fr}}
.j-pets{display:grid;gap:8px}
.j-pet{display:grid;grid-template-columns:auto 1fr;gap:12px;align-items:center;text-align:left;padding:8px 10px;border:1px solid var(--line);border-radius:8px;background:transparent;color:inherit;cursor:pointer}
.j-pet:hover:not(:disabled){border-color:#C99BFF}.j-pet:disabled{opacity:.45;cursor:not-allowed}.j-pet small{display:block;color:var(--muted);font-size:12px}
.j-pet.on{cursor:default;border-color:rgba(201,155,255,.55)}.j-pet svg{background:#1A0D33;border-radius:8px;padding:4px}
@media(prefers-reduced-motion:reduce){.j-doc-ch{animation:none}}
`;document.head.appendChild(css3);

/* tarjetas y sanciones tras el partido; efectos semanales de la mascota */
function cardsAfter(R0){if(R0.yel){P.sea.yel=(P.sea.yel||0)+R0.yel;P.st.yel=(P.st.yel||0)+R0.yel;if(!R0.redMin&&P.sea.yel%5===0){P.ban=1;P.banNew=true;news(`${P.last} ve la quinta amarilla: un partido de sanción.`,'bad');}}
  if(R0.redMin){P.sea.red=(P.sea.red||0)+1;P.st.red=(P.st.red||0)+1;P.ban=R(1,3);P.banNew=true;P.tru=clamp(P.tru-6,0,100);P.rep.polemico+=1;flag('red');news(`Roja a ${P.last}: ${P.ban} partido${P.ban>1?'s':''} de sanción.`,'bad');}}
function petWeek(){if(!P.pet)return;const k=P.pet.k;if(k==='perro')P.fat=clamp(P.fat-1.5,0,100);if(k==='loro')P.fame=clamp(P.fame+.08,0,100);if(k==='tortuga')P.lp+=.02;
  P.mor=clamp(P.mor+({gato:.45,conejo:.3,perro:.2,hamster:.2,loro:.15,tortuga:.15}[k]||0),0,100);}

/* ====== ampliación 3: rutina semanal visual, campo de entrenamiento 3D y sala de trofeos 3D ====== */

/* ---------- rutina semanal: bloques que se arrastran a cada día ---------- */
const BLK={entreno:['Entreno técnico','#B57BFF','Progreso en tu foco. Cansa.'],gym:['Gimnasio','#FF5DA2','Físico y fuerza. Cansa bastante.'],video:['Vídeo y táctica','#3DE0C2','Defensa, pase y confianza del míster.'],
  fisio:['Fisio','#7FD1FF','Recupera y previene lesiones.'],descanso:['Descanso','#9C8CC9','Mucha energía.'],ocio:['Ocio','#FFD24A','Sube la moral.'],familia:['Familia','#FF9F5A','Moral, más si tienes familia.'],marca:['Patrocinio y prensa','#E4CCFF','Fama y dinero. Algo de cansancio.']};
const DAYS=['Lunes','Martes','Miércoles','Jueves','Viernes','Sábado','Domingo'];
const rout=()=>P.routine||(P.routine=['entreno','gym','video','entreno','fisio','partido','descanso']);
function routineCount(){const c={};rout().forEach(b=>{c[b]=(c[b]||0)+1;});return c;}
function routineDelta(){const c=routineCount(),n=k=>c[k]||0,fm=fam().partner||fam().kids.length;
  return{ene:-(3*n('entreno')+4*n('gym')+n('marca')-3*n('fisio')-6*n('descanso')),mor:1.2*n('ocio')+(fm?1.4:.6)*n('familia')-(n('ocio')||n('familia')||n('descanso')?0:1.5),
    pro:.6*n('entreno')+.7*n('gym')+.35*n('video'),fama:.2*n('marca'),tru:.4*n('video'),fisio:n('fisio')};}
function routineWeek(){const c=routineCount(),n=k=>c[k]||0,D=routineDelta();
  if(P.inj===0){if(n('entreno'))xp(P.focus,.6*n('entreno'));if(n('gym'))xp('fis',.7*n('gym'));if(n('video'))xp(pk(['def','pas']),.35*n('video'));}
  P.tru=clamp(P.tru+D.tru,0,100);P.fat=clamp(P.fat-D.ene,0,100);P.mor=clamp(P.mor+D.mor,0,100);
  if(n('marca')){P.fame=clamp(P.fame+D.fama,0,100);P.money+=Math.round((2000+P.fame*P.fame*8)*n('marca'));}P._fisio=n('fisio');}
function routinePanel(){const r=rout(),D=routineDelta(),sel=UI.blkSel,sg=v=>(v>0?'+':v<0?'−':'')+f1(Math.abs(v)).replace('.',',');
  return `<div class="j-panel j-rout"><h3>Rutina semanal</h3><p class="j-hint">Arrastra un bloque a un día, o tócalo y después toca el día. Se aplica cada semana, además del foco y la intensidad.</p>
  <div class="j-week">${r.map((b,i)=>b==='partido'?`<div class="j-day fixed"><small>${DAYS[i]}</small><b>Día de partido</b></div>`:`<button class="j-day" data-act="jDay" data-i="${i}" data-drop="${i}" style="--c:${BLK[b][1]}" aria-label="${DAYS[i]}: ${BLK[b][0]}"><small>${DAYS[i]}</small><b>${BLK[b][0]}</b></button>`).join('')}</div>
  <div class="j-blks" role="listbox" aria-label="Bloques de la rutina">${Object.entries(BLK).map(([k,[l,col,d]])=>`<button class="j-blk${sel===k?' on':''}" draggable="true" data-blk="${k}" data-act="jBlk" data-k="${k}" style="--c:${col}" aria-pressed="${sel===k}"><b>${l}</b><small>${d}</small></button>`).join('')}</div>
  <div class="j-rfx"><span>Cada semana</span><em class="${D.ene<0?'dn':'up'}">Energía ${sg(D.ene)}</em><em class="${D.mor<0?'dn':'up'}">Moral ${sg(D.mor)}</em><em class="up">Progreso ${sg(D.pro)}</em>${D.fama?`<em class="up">Fama ${sg(D.fama)}</em>`:''}${D.fisio?`<em class="up">Riesgo de lesión −${Math.min(3,D.fisio)*15} %</em>`:''}</div></div>`;}
function refreshRoutine(){const el=document.querySelector('.j-rout');if(el)el.outerHTML=routinePanel();}
document.addEventListener('dragstart',e=>{const b=e.target.closest&&e.target.closest('[data-blk]');if(b&&e.dataTransfer){e.dataTransfer.setData('text/plain',b.dataset.blk);e.dataTransfer.effectAllowed='copy';}});
document.addEventListener('dragover',e=>{const d=e.target.closest&&e.target.closest('[data-drop]');if(d){e.preventDefault();d.classList.add('over');}});
document.addEventListener('dragleave',e=>{const d=e.target.closest&&e.target.closest('[data-drop]');if(d)d.classList.remove('over');});
document.addEventListener('drop',e=>{const d=e.target.closest&&e.target.closest('[data-drop]');if(!d||!P)return;e.preventDefault();const k=e.dataTransfer.getData('text/plain');if(BLK[k]){rout()[+d.dataset.drop]=k;save();refreshRoutine();}});

/* ---------- visores 3D pequeños (entrenamiento y trofeos) ---------- */
const V3={};
function disposeV(key){const V=V3[key];if(!V)return;cancelAnimationFrame(V.raf);V.ro&&V.ro.disconnect();
  V.scene.traverse(o=>{o.geometry&&o.geometry.dispose();if(o.material)(Array.isArray(o.material)?o.material:[o.material]).forEach(m=>{m.map&&m.map.dispose();m.dispose();});});
  V.env&&V.env.dispose();V.r.dispose();try{V.r.forceContextLoss();}catch(e){}V3[key]=null;}
function mountV(key,build){const cv=document.getElementById('jv-'+key),V=V3[key];
  if(!cv){if(V)disposeV(key);return;}if(V&&V.cv===cv)return;if(V)disposeV(key);if(cv.dataset.on)return;cv.dataset.on='1';
  const fb=()=>{const f=cv.parentElement.querySelector('.jv-fb');if(f){f.hidden=false;cv.hidden=true;}};
  if(typeof loadThree!=='function'||(typeof hasGL15==='function'&&!hasGL15())){fb();return;}
  loadThree().then(ok=>{if(!ok||!window.THREE||!document.body.contains(cv)){fb();return;}try{initV(key,cv,build);}catch(e){console.error(e);fb();}});}
function initV(key,cv,build){const T=window.THREE,box=cv.parentElement,r=new T.WebGLRenderer({canvas:cv,antialias:true});
  r.setPixelRatio(Math.min(devicePixelRatio||1,2));if('outputEncoding' in r)r.outputEncoding=T.sRGBEncoding;r.shadowMap.enabled=true;
  const scene=new T.Scene(),cam=new T.PerspectiveCamera(40,1,.1,200),V={cv,r,scene,cam,raf:0,rot:0,drag:null};V3[key]=V;
  const tick=build(T,V);
  const size=()=>{const w=box.clientWidth||400,h=box.clientHeight||300;r.setSize(w,h,false);cam.aspect=w/h;cam.updateProjectionMatrix();};size();
  if(window.ResizeObserver){V.ro=new ResizeObserver(size);V.ro.observe(box);}
  box.addEventListener('pointerdown',e=>{V.drag={x:e.clientX,r:V.rot};box.setPointerCapture(e.pointerId);});
  box.addEventListener('pointermove',e=>{if(V.drag)V.rot=V.drag.r+(e.clientX-V.drag.x)*.008;});
  const up=()=>{V.drag=null;};box.addEventListener('pointerup',up);box.addEventListener('pointercancel',up);
  const calm=reduced(),t0=performance.now();
  const loop=now=>{if(V3[key]!==V)return;if(!document.body.contains(cv)){disposeV(key);return;}V.raf=requestAnimationFrame(loop);tick(calm?0:now-t0);r.render(scene,cam);};
  V.raf=requestAnimationFrame(loop);}
const v3Box=(key,h,cap)=>`<div class="j-vbox" style="height:${h}px"><canvas id="jv-${key}" role="img" aria-label="${esc(cap)}"></canvas><div class="jv-fb" hidden><p class="muted">Tu dispositivo no puede mostrar esta vista en 3D.</p></div><small class="jv-tip">Arrastra para girar</small></div>`;
function stripes(T,a,b,n){const t=pixTex(T,8,64,g=>{for(let i=0;i<8;i++){g.fillStyle=i%2?a:b;g.fillRect(0,i*8,8,8);}});t.wrapS=t.wrapT=T.RepeatWrapping;t.repeat.set(4,n);return t;}

/* ---------- campo de entrenamiento 3D: tu futbolista hace el ejercicio de tu foco ---------- */
const DRILL={rit:'Sprints entre conos',tir:'Disparos a portería',pas:'Pases contra el muro de rebote',reg:'Eslalon con balón',def:'Defensa uno contra uno ante el maniquí',fis:'Saltos al cajón pliométrico',wf:'Disparos con la pierna mala',sk:'Toques y filigranas',rehab:'Rehabilitación: caminata suave con el fisio'};
function trainPanel(){const d=P.inj>0?'rehab':P.focus,int={suave:'suave',normal:'normal',intensa:'intensa'}[P.intensity];
  return `<div class="j-panel j-v3"><h3>Campo de entrenamiento</h3>${v3Box('train',300,'Tu futbolista entrenando en 3D')}<p class="j-hint">${DRILL[d]} · intensidad ${int}${P.fat>65?' · se te nota cansado':''}. Cambia el foco y lo verás entrenar otra cosa.</p></div>`;}
function buildTrain(T,V){const sc=V.scene,Mt=(c,o={})=>new T.MeshStandardMaterial({color:new T.Color(c),roughness:.8,...o});
  sc.background=new T.Color('#120826');sc.fog=new T.Fog('#120826',24,52);
  sc.add(new T.HemisphereLight(0xe8dcff,0x1a3a22,.85));const sun=new T.DirectionalLight(0xffffff,1);sun.position.set(6,12,8);sun.castShadow=true;sun.shadow.mapSize.set(1024,1024);Object.assign(sun.shadow.camera,{left:-12,right:12,top:12,bottom:-12});sc.add(sun);
  const rim=new T.DirectionalLight(0xb57bff,.8);rim.position.set(-8,5,-8);sc.add(rim);
  const add=(geo,m,x,y,z)=>{const o=new T.Mesh(geo,m);o.position.set(x,y,z);o.castShadow=true;o.receiveShadow=true;sc.add(o);return o;},bx=(w,h,d,m,x,y,z)=>add(new T.BoxGeometry(w,h,d),m,x,y,z);
  const gr=add(new T.PlaneGeometry(44,44),Mt('#ffffff',{map:stripes(T,'#1e7a3f','#22874a',6),roughness:.95}),0,0,0);gr.rotation.x=-Math.PI/2;gr.castShadow=false;
  const neon=new T.MeshStandardMaterial({color:'#C99BFF',emissive:new T.Color('#B57BFF'),emissiveIntensity:1.3});[[16,.06,.06,0,-6],[16,.06,.06,0,6],[.06,.06,12,-8,0],[.06,.06,12,8,0]].forEach(([w,h,d,x,z])=>bx(w,h,d,neon,x,.03,z));
  const wm=Mt('#f4f4f4',{roughness:.4});[-1.8,1.8].forEach(x=>bx(.1,1.4,.1,wm,x,.7,-6.4));bx(3.7,.1,.1,wm,0,1.4,-6.4);
  const nt=pixTex(T,32,32,g=>{g.fillStyle='rgba(255,255,255,.75)';for(let i=0;i<32;i+=8){g.fillRect(i,0,1,32);g.fillRect(0,i,32,1);}});nt.wrapS=nt.wrapT=T.RepeatWrapping;nt.repeat.set(6,3);
  const net=new T.Mesh(new T.PlaneGeometry(3.6,1.4),new T.MeshBasicMaterial({map:nt,transparent:true,side:T.DoubleSide,depthWrite:false}));net.position.set(0,.7,-7.2);sc.add(net);
  const cone=(x,z)=>add(new T.ConeGeometry(.2,.45,10),Mt('#FF8A2A',{roughness:.5}),x,.22,z);
  const drill=P.inj>0?'rehab':P.focus,spd=Math.max(.55,1-P.fat/250)*({suave:.8,normal:1,intensa:1.25}[P.intensity]||1);
  if(drill==='rit'||drill==='reg')[-4,-2,0,2,4].forEach(x=>cone(x,drill==='rit'?2.5:0));
  if(drill==='rit')[-5,5].forEach(x=>cone(x,2.5));
  const dummy=Mt('#3A5BD9');if(drill==='def'){bx(.5,1.2,.3,dummy,0,1.1,-1.2);bx(.3,.3,.3,Mt('#E8B48A'),0,1.9,-1.2);bx(.12,.5,.12,dummy,0,.25,-1.2);}
  if(drill==='pas'){bx(4,1.4,.3,Mt('#4A2A80'),-1,.7,-4.2);bx(4,.08,.32,neon,-1,1.42,-4.2);}
  if(drill==='fis')bx(1.2,.8,1.2,Mt('#5B3A9E'),0,.4,-1.3);
  const btx=pixTex(T,16,16,g=>{g.fillStyle='#f4f4f4';g.fillRect(0,0,16,16);g.fillStyle='#1a1a22';[[2,2],[10,4],[5,9],[12,12],[1,13]].forEach(([x,y])=>g.fillRect(x,y,3,3));});
  const ball=add(new T.SphereGeometry(.17,16,12),Mt('#ffffff',{map:btx,roughness:.5}),0,.17,1);ball.visible=drill!=='rit'&&drill!=='def'&&drill!=='fis'&&drill!=='rehab';
  const outer=new T.Group(),inner=new T.Group();outer.add(inner);buildFigure(T,inner,{...P,kitC:{s:'#2A1450',t:'#B57BFF',p:'#14141c',m:'#2A1450'}});inner.traverse(o=>{if(o.isMesh)o.castShadow=true;});outer.scale.setScalar(.85);sc.add(outer);
  if(drill==='rehab'){const ring=new T.Mesh(new T.TorusGeometry(.17,.04,8,20),new T.MeshStandardMaterial({color:'#ff4d6d',emissive:new T.Color('#ff2a4a'),emissiveIntensity:1.6}));ring.rotation.x=Math.PI/2;ring.position.set(.13,.54,0);inner.add(ring);}
  const aL=inner.getObjectByName('armL'),aR=inner.getObjectByName('armR'),last={x:0,z:0},tri=u=>1-Math.abs(1-2*(u%1));
  const face=(x,z)=>{const dx=x-last.x,dz=z-last.z;if(Math.hypot(dx,dz)>.002)outer.rotation.y=Math.atan2(dx,dz);last.x=x;last.z=z;};
  const swing=(f,a)=>{if(aL)aL.rotation.x=Math.sin(f)*a;if(aR)aR.rotation.x=-Math.sin(f)*a;};
  return ms=>{const k=ms/1000*spd;let x=0,z=0,y=0;
    if(drill==='rit'){x=-5+10*tri(k*.28);z=2.5;swing(k*14,1);y=Math.abs(Math.sin(k*14))*.06;}
    else if(drill==='reg'){const u=tri(k*.16);x=-5+10*u;z=Math.sin(x*1.6)*.8;swing(k*10,.6);ball.position.set(x+(Math.cos(k*.16*Math.PI*2)>0?.45:-.45),.17,z+.1);}
    else if(drill==='tir'||drill==='wf'){const c=(k*.4)%1,sx=drill==='wf'?-1.2:1.2;if(c<.4){const u=c/.4;x=sx*.4;z=4.5-3.1*u;swing(k*12,.8);ball.position.set(sx*.3,.17,1.1);}
      else if(c<.7){x=sx*.4;z=1.4;const u=(c-.4)/.3;ball.position.set(sx*.3*(1-u),.17+Math.sin(u*Math.PI)*1.1,1.1-8*u);swing(0,0);}else{const u=(c-.7)/.3;x=sx*.4;z=1.4+3.1*u;swing(k*8,.4);ball.position.set(sx*.3,.17,1.1);}}
    else if(drill==='pas'){x=-1;z=1.5;const c=(k*.6)%1;ball.position.set(-1,.17,1.1-5*tri(c));swing(k*3,.15);}
    else if(drill==='def'){x=Math.sin(k*2.6)*1.3;z=.2;swing(k*5,.3);inner.rotation.x=Math.max(0,Math.sin(k*1.3))*.25;}
    else if(drill==='fis'){const c=(k*.7)%1;z=-.1;x=0;y=c<.5?Math.sin(c*2*Math.PI/2)*1.1:(c<.75?.8*(1-(c-.5)*4)+Math.sin((c-.5)*4*Math.PI)*.3:0);y=Math.max(0,y);if(aL)aL.rotation.x=-1.6*Math.max(0,Math.sin(c*Math.PI*2));if(aR)aR.rotation.x=-1.6*Math.max(0,Math.sin(c*Math.PI*2));}
    else if(drill==='sk'){x=0;z=.8;ball.position.set(.15,.35+Math.abs(Math.sin(k*3.2))*1.5,1.25);swing(k*3.2,.25);y=Math.abs(Math.sin(k*3.2))*.04;}
    else{const a=k*.25;x=Math.cos(a)*3;z=Math.sin(a)*2.5;swing(k*3,.25);}
    face(x,z);outer.position.set(x,y,z);
    V.cam.position.set(Math.sin(V.rot+.55)*8.2,3.8,Math.cos(V.rot+.55)*8.2);V.cam.lookAt(0,.9,0);};}

/* ---------- sala de trofeos 3D ---------- */
function tKind(n){return /^Mundial de Clubes/.test(n)?'cwc':/Supercopa|Supercoppa|Supercup|Community Shield|Trophée des Champions|Campeones Cup|Campeón de Campeones|Superliga/.test(n)?'sup':/Champions|Europa League|Conference|Libertadores/.test(n)?'ucl':/Mundial/.test(n)?'world':/Eurocopa|Copa América|Copa Oro|Copa África|Copa Asiática|Nations League/.test(n)?'cont':/^Copa|Cup|Pokal|Coppa|Coupe|Taça|Beker/.test(n)?'copa':/Balón de Oro/.test(n)?'ballon':/Bota de Oro/.test(n)?'boot':/Guante/.test(n)?'glove':/Mejor|Once|MVP|joven/i.test(n)?'award':'liga';}
const TRANK={ballon:0,ucl:1,world:2,cwc:2.5,cont:3,liga:4,copa:5,sup:5.5,boot:6,glove:7,award:8};
function trophyItems(){const all=[...P.titles.map(t=>({n:t.n,s:t.s,k:tKind(t.n)})),...P.awards.map(a=>({n:a.n,s:a.s,k:tKind(a.n)})),...((P.coach&&P.coach.titles)||[]).map(t=>({n:t.n+' (míster)',s:t.s,k:tKind(t.n)}))],g={};
  all.forEach(t=>{const x=g[t.n]||(g[t.n]={n:t.n,k:t.k,c:0,s:t.s});x.c++;});return Object.values(g).sort((a,b)=>TRANK[a.k]-TRANK[b.k]||b.c-a.c);}
function trophyPanel(){const n=trophyItems().reduce((a,t)=>a+t.c,0);return `<div class="j-panel j-v3"><h3>Sala de trofeos</h3>${v3Box('trophy',360,'Tu sala de trofeos en 3D')}<p class="j-hint">${n?`${n} pieza${n>1?'s':''} en tus vitrinas. Cada título y cada premio aparece aquí con su placa.`:'Las vitrinas esperan tu primer trofeo.'}</p></div>`;}
function buildTrophy(T,V){const sc=V.scene,r=V.r,Mt=(c,o={})=>new T.MeshStandardMaterial({color:new T.Color(c),roughness:.7,...o});
  sc.background=new T.Color('#0c0618');
  /* entorno sencillo para que el metal refleje algo */
  const pm=new T.PMREMGenerator(r),es=new T.Scene();es.background=new T.Color('#1a0f33');[[0,6,0,'#ffffff'],[6,2,4,'#ffffff'],[-6,3,4,'#ffe2b0'],[0,2,-6,'#C99BFF']].forEach(([x,y,z,c])=>{const m=new T.Mesh(new T.BoxGeometry(5,2,5),new T.MeshBasicMaterial({color:c}));m.position.set(x,y,z);es.add(m);});
  V.env=pm.fromScene(es,.04).texture;sc.environment=V.env;pm.dispose();es.traverse(o=>{o.geometry&&o.geometry.dispose();o.material&&o.material.dispose();});
  sc.add(new T.HemisphereLight(0xf0e8ff,0x120826,.75));const fr=new T.DirectionalLight(0xffffff,.9);fr.position.set(1,5,9);sc.add(fr);const key=new T.SpotLight(0xffe8c8,1,40,.55,.6);key.position.set(0,9,7);key.target.position.set(0,2,-2.5);key.castShadow=true;sc.add(key);sc.add(key.target);
  const add=(geo,m,x,y,z,g=sc)=>{const o=new T.Mesh(geo,m);o.position.set(x,y,z);o.castShadow=true;o.receiveShadow=true;g.add(o);return o;},bx=(w,h,d,m,x,y,z,g)=>add(new T.BoxGeometry(w,h,d),m,x,y,z,g);
  const fl=add(new T.PlaneGeometry(30,20),Mt('#2a1a3e',{map:stripes(T,'#2a1a3e','#24152f',10),roughness:.5}),0,0,2);fl.rotation.x=-Math.PI/2;
  const it=trophyItems(),cols=6,rows=Math.max(1,Math.min(5,Math.ceil(it.length/cols))),sh=1.6;
  bx(16,2+rows*sh+1,.3,Mt('#120a20',{roughness:.9}),0,(2+rows*sh+1)/2,-3.6);
  const neon=new T.MeshStandardMaterial({color:'#C99BFF',emissive:new T.Color('#B57BFF'),emissiveIntensity:1.5});
  const sign=pixTex(T,256,32,g=>{g.fillStyle='#0c0618';g.fillRect(0,0,256,32);g.fillStyle='#E4CCFF';g.font='900 24px Impact,sans-serif';g.textAlign='center';g.textBaseline='middle';g.fillText('PALMARÉS',128,17);});sign.magFilter=T.LinearFilter;
  bx(4.4,.55,.06,new T.MeshBasicMaterial({map:sign}),0,1.2+rows*sh+.9,-3.4);
  for(let i=0;i<rows;i++){const y=.9+i*sh;bx(13.4,.12,1.3,Mt('#3b2a55',{roughness:.3,metalness:.2}),0,y,-2.9);bx(13.4,.04,.04,neon,0,y+.07,-2.25);}
  const gold=Mt('#E8B83A',{metalness:1,roughness:.22}),silver=Mt('#D9DDE6',{metalness:1,roughness:.2}),black=Mt('#141018',{roughness:.4});
  const lathe=(pts,m,g,y)=>add(new T.LatheGeometry(pts.map(([a,b])=>new T.Vector2(a,b)),24),m,0,y||0,0,g);
  const handles=(g,m,r_,y,s=1)=>[-1,1].forEach(sd=>{const h=add(new T.TorusGeometry(r_,.035*s,8,16,Math.PI),m,sd*(.22*s),y,0,g);h.rotation.z=sd>0?-Math.PI/2:Math.PI/2;});
  const make=(k,g)=>{bx(.5,.18,.5,black,0,.09,0,g);
    if(k==='liga'){lathe([[0,0],[.12,.02],[.05,.1],[.04,.3],[.2,.45],[.24,.75],[0,.75]],silver,g,.18);handles(g,silver,.13,.75);}
    else if(k==='copa'){lathe([[0,0],[.14,.02],[.05,.12],[.04,.38],[.18,.5],[.22,.9],[.14,.95],[.05,1.05],[0,1.08]],gold,g,.18);handles(g,gold,.12,.85);}
    else if(k==='ucl'){lathe([[0,0],[.16,.02],[.06,.12],[.05,.36],[.22,.5],[.27,.95],[0,.95]],silver,g,.18);handles(g,silver,.22,.82,1.5);}
    else if(k==='world'){const kn=add(new T.TorusKnotGeometry(.14,.045,48,8),gold,0,.5,0,g);kn.scale.set(1,1.6,1);add(new T.SphereGeometry(.17,20,14),gold,0,.86,0,g);}
    else if(k==='cont'){lathe([[0,0],[.13,.02],[.05,.12],[.05,.4],[.2,.55],[.17,.85],[0,.85]],gold,g,.18);add(new T.OctahedronGeometry(.08),gold,0,1.1,0,g);}
    else if(k==='cwc'){lathe([[0,0],[.15,.02],[.07,.12],[.06,.4],[.1,.46],[0,.48]],gold,g,.18);add(new T.SphereGeometry(.2,24,16),gold,0,.86,0,g);const ri=add(new T.TorusGeometry(.25,.02,8,40),gold,0,.86,0,g);ri.rotation.x=Math.PI/2.6;}
    else if(k==='sup'){lathe([[0,0],[.12,.02],[.05,.1],[.04,.26],[.15,.34],[.17,.62],[0,.62]],silver,g,.18);add(new T.OctahedronGeometry(.06),gold,0,.86,0,g);}
    else if(k==='ballon'){const b=add(new T.IcosahedronGeometry(.24,1),gold,0,.46,0,g);b.material=gold;bx(.3,.06,.3,gold,0,.21,0,g);}
    else if(k==='boot'){bx(.42,.06,.18,gold,0,.24,0,g);bx(.28,.2,.17,gold,-.05,.37,0,g);bx(.14,.14,.16,gold,.14,.33,0,g);}
    else if(k==='glove'){bx(.26,.3,.1,gold,0,.38,0,g);[-.09,-.03,.03,.09].forEach(x=>bx(.05,.16,.08,gold,x,.6,0,g));bx(.06,.14,.08,gold,.16,.42,0,g);}
    else{const s=new T.Shape();for(let i=0;i<10;i++){const a=Math.PI/2+i*Math.PI/5,rr=i%2?.09:.22;i?s.lineTo(Math.cos(a)*rr,Math.sin(a)*rr):s.moveTo(Math.cos(a)*rr,Math.sin(a)*rr);}
      const st=add(new T.ExtrudeGeometry(s,{depth:.05,bevelEnabled:false}),silver,0,.55,0,g);st.position.z=-.025;bx(.05,.22,.05,silver,0,.29,0,g);}};
  const plate=(txt,sub)=>pixTex(T,128,32,g=>{g.fillStyle='#120826';g.fillRect(0,0,128,32);g.fillStyle='#E4CCFF';g.font='bold 11px sans-serif';g.textAlign='center';g.fillText(txt.slice(0,22),64,13);g.fillStyle='#9C88C4';g.font='10px sans-serif';g.fillText(sub,64,26);});
  const spin=[];
  if(!it.length){const g=new T.Group();g.position.set(0,.96,-2.9);sc.add(g);bx(.5,.18,.5,black,0,.09,0,g);const p=plate('Tu primer trofeo','te espera');p.magFilter=T.LinearFilter;bx(.9,.22,.02,new T.MeshBasicMaterial({map:p}),0,-.12,.66,g);}
  it.slice(0,cols*rows).forEach((t,i)=>{const row=Math.floor(i/cols),col=i%cols,g=new T.Group();g.position.set(-5.4+col*2.16,.96+row*sh,-2.9);g.scale.setScalar(1.45);sc.add(g);make(t.k,g);
    const p=plate(t.n,t.c>1?'×'+t.c:t.s);p.magFilter=T.LinearFilter;const pl=bx(1.3,.26,.02,new T.MeshBasicMaterial({map:p}),0,-.11,.66,g);pl.castShadow=false;spin.push(g);});
  /* tu futbolista en un podio, a un lado */
  const pod=new T.Group();pod.position.set(5,0,1.3);sc.add(pod);bx(1.4,.5,1.4,Mt('#2a1650',{roughness:.4}),0,.25,0,pod);bx(1.42,.04,1.42,neon,0,.5,0,pod);
  const fig=new T.Group();buildFigure(T,fig,{...P,kit:P.kit||'local'});fig.traverse(o=>{if(o.isMesh)o.castShadow=true;});fig.scale.setScalar(.75);fig.position.y=.52;fig.rotation.y=-.5;pod.add(fig);
  const lamp=new T.PointLight(0xC99BFF,1,8);lamp.position.set(5,3,2.6);sc.add(lamp);
  const D=7+rows*1.1,cy=1.1+rows*sh*.5;
  return ms=>{const t=ms/1000;spin.forEach((g,i)=>{g.rotation.y=Math.sin(t*.6+i)*.35;});fig.rotation.y=-.5+Math.sin(t*.5)*.25;
    const a=clamp(V.rot,-.7,.7);V.cam.position.set(Math.sin(a)*D,cy+1.2,Math.cos(a)*D-1);V.cam.lookAt(0,cy,-2.6);};}

Object.assign(ACT,{
  jBlk(d){UI.blkSel=UI.blkSel===d.k?null:d.k;refreshRoutine();},
  jDay(d){const r=rout(),keys=Object.keys(BLK),i=+d.i;if(r[i]==='partido')return;r[i]=UI.blkSel||keys[(keys.indexOf(r[i])+1)%keys.length];save();refreshRoutine();},
});
const css4=document.createElement('style');css4.textContent=`
.j-vbox{position:relative;width:100%;border-radius:10px;overflow:hidden;border:1px solid rgba(201,155,255,.35);background:#120826;touch-action:pan-y;cursor:grab}
.j-vbox canvas{display:block;width:100%;height:100%}.jv-fb{position:absolute;inset:0;display:grid;place-items:center;padding:16px;text-align:center}
.jv-tip{position:absolute;right:10px;bottom:8px;font-family:var(--mono);font-size:10px;letter-spacing:.12em;text-transform:uppercase;color:rgba(228,204,255,.7);pointer-events:none}
.j-v3{margin-bottom:18px}
.j-week{display:grid;grid-template-columns:repeat(7,minmax(0,1fr));gap:6px;margin:10px 0 12px}
.j-day{display:grid;gap:4px;align-content:start;min-height:84px;padding:8px;border-radius:8px;border:1px solid var(--line);border-top:4px solid var(--c,#555);background:#170a2e;color:inherit;text-align:left;cursor:pointer;font:inherit}
.j-day small{font-family:var(--mono);font-size:10px;letter-spacing:.1em;text-transform:uppercase;color:var(--muted)}.j-day b{font-size:13px;line-height:1.2}
.j-day:hover,.j-day.over{border-color:var(--c);box-shadow:0 0 0 1px var(--c),0 0 18px -6px var(--c)}
.j-day.fixed{border-top-color:#F3ECFF;background:repeating-linear-gradient(135deg,#1c0e38 0 8px,#170a2e 8px 16px);cursor:default}
.j-blks{display:grid;grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:6px}
.j-blk{display:grid;gap:2px;padding:8px 10px;border-radius:8px;border:1px solid var(--line);border-left:4px solid var(--c);background:#140a28;color:inherit;text-align:left;cursor:grab;font:inherit}
.j-blk small{color:var(--muted);font-size:11.5px}.j-blk.on{border-color:var(--c);box-shadow:0 0 0 1px var(--c),0 0 18px -6px var(--c)}
.j-rfx{display:flex;flex-wrap:wrap;gap:6px;align-items:center;margin-top:12px}.j-rfx span{font-family:var(--mono);font-size:10px;letter-spacing:.12em;text-transform:uppercase;color:var(--muted);margin-right:4px}
.j-rfx em{font-style:normal;font-size:12.5px;padding:3px 8px;border-radius:99px;border:1px solid var(--line)}.j-rfx .up{color:var(--win)}.j-rfx .dn{color:var(--loss)}
@media(max-width:700px){.j-week{grid-template-columns:repeat(4,minmax(0,1fr))}}
`;document.head.appendChild(css4);

/* más países para elegir selección (nivel, confederación) y sus colores */
Object.assign(NAT,{'Suiza':[80,'UEFA'],'Dinamarca':[81,'UEFA'],'Austria':[79,'UEFA'],'Polonia':[78,'UEFA'],'Suecia':[78,'UEFA'],'Noruega':[79,'UEFA'],'Turquía':[79,'UEFA'],'Serbia':[78,'UEFA'],'Ucrania':[78,'UEFA'],'Escocia':[76,'UEFA'],'Gales':[75,'UEFA'],'Irlanda':[74,'UEFA'],'Grecia':[75,'UEFA'],'Chequia':[77,'UEFA'],
  'Ecuador':[79,'CONMEBOL'],'Paraguay':[76,'CONMEBOL'],'Perú':[75,'CONMEBOL'],'Venezuela':[74,'CONMEBOL'],'Nigeria':[78,'CAF'],'Egipto':[76,'CAF'],'Ghana':[75,'CAF'],'Costa de Marfil':[78,'CAF'],'Argelia':[77,'CAF'],'Túnez':[75,'CAF'],'Camerún':[76,'CAF'],
  'Corea del Sur':[78,'AFC'],'Australia':[76,'AFC'],'Irán':[76,'AFC'],'Canadá':[76,'CONCACAF'],'Costa Rica':[73,'CONCACAF'],'Jamaica':[72,'CONCACAF'],'Panamá':[72,'CONCACAF']});
Object.assign(NATK,{'Suiza':['#D52B1E','#FFFFFF','#FFFFFF'],'Dinamarca':['#C8102E','#FFFFFF','#FFFFFF'],'Austria':['#ED2939','#FFFFFF','#FFFFFF'],'Polonia':['#F4F4F6','#DC143C','#DC143C'],'Suecia':['#FECC00','#006AA7','#006AA7'],'Noruega':['#BA0C2F','#00205B','#FFFFFF'],'Turquía':['#E30A17','#FFFFFF','#FFFFFF'],'Serbia':['#C6363C','#0C4076','#0C4076'],'Ucrania':['#FFD500','#005BBB','#FFD500'],'Escocia':['#0B1E5B','#FFFFFF','#FFFFFF'],'Gales':['#C8102E','#00B140','#C8102E'],'Irlanda':['#169B62','#FFFFFF','#FFFFFF'],'Grecia':['#0D5EAF','#FFFFFF','#0D5EAF'],'Chequia':['#D7141A','#11457E','#FFFFFF'],
  'Ecuador':['#FFDD00','#034EA2','#034EA2'],'Paraguay':['#D52B1E','#FFFFFF','#0038A8'],'Perú':['#F4F4F6','#D91023','#F4F4F6'],'Venezuela':['#7A1E2E','#FFCC00','#7A1E2E'],'Nigeria':['#008751','#FFFFFF','#008751'],'Egipto':['#CE1126','#FFFFFF','#141414'],'Ghana':['#F4F4F6','#006B3F','#F4F4F6'],'Costa de Marfil':['#F77F00','#009E60','#F4F4F6'],'Argelia':['#F4F4F6','#006233','#F4F4F6'],'Túnez':['#E70013','#FFFFFF','#FFFFFF'],'Camerún':['#007A5E','#FCD116','#CE1126'],
  'Corea del Sur':['#CD2E3A','#0047A0','#141414'],'Australia':['#FFCD00','#00843D','#00843D'],'Irán':['#F4F4F6','#DA0000','#F4F4F6'],'Canadá':['#D80621','#FFFFFF','#D80621'],'Costa Rica':['#CE1126','#002B7F','#002B7F'],'Jamaica':['#FED100','#009B3A','#141414'],'Panamá':['#DA121A','#072357','#DA121A']});
const CONFN={UEFA:'Europa',CONMEBOL:'Sudamérica',CONCACAF:'Norteamérica, Centroamérica y Caribe',CAF:'África',AFC:'Asia y Oceanía'};
function natPanel(c){const by={};Object.keys(NAT).forEach(n=>{(by[NAT[n][1]]=by[NAT[n][1]]||[]).push(n);});const sel=NAT[c.nat]||NAT['España'];
  return `<fieldset class="j-fs"><legend>País y selección</legend><p class="j-hint">Jugarás con la selección de <b>${esc(c.nat)}</b>: Sub-17, Sub-19, Sub-21 y la absoluta, con el Mundial y la ${CONT[sel[1]]}. Nivel de la selección: <b class="num">${sel[0]}</b>.</p>
   ${Object.keys(CONFN).filter(cf=>by[cf]).map(cf=>`<div class="j-grp"><h4>${CONFN[cf]}</h4><div class="j-chips" role="radiogroup" aria-label="${CONFN[cf]}">${by[cf].map(n=>{const k=NATK[n]||['#888','#ccc'],on=c.nat===n;return `<button class="j-chip j-natc${on?' on':''}" role="radio" aria-checked="${on}" data-act="jcf" data-k="nat" data-v="${esc(n)}"><i class="j-flag" style="--a:${k[0]};--b:${k[1]}" aria-hidden="true"></i>${esc(n)}</button>`;}).join('')}</div></div>`).join('')}</fieldset>`;}
const css5=document.createElement('style');css5.textContent=`.j-flag{display:inline-block;width:16px;height:11px;margin-right:7px;vertical-align:-1px;border-radius:2px;background:linear-gradient(180deg,var(--a) 0 50%,var(--b) 50%);box-shadow:0 0 0 1px rgba(255,255,255,.25)}`;document.head.appendChild(css5);

/* ====== ampliación 4: química con el entrenador, vestuario 3D antes del partido y tu casa por dentro en 3D ====== */

/* ---------- entrenador del club: personalidad y química contigo ---------- */
const MPERS={Exigente:'Quiere intensidad máxima y cero fiestas.',Canterano:'Apuesta por los jóvenes de la casa.',Defensivo:'Valora el sacrificio, los duelos y la portería a cero.',Motivador:'Cuida el ánimo del grupo por encima de todo.',Táctico:'Vive del vídeo y la disciplina táctica.',Ofensivo:'Quiere goles, asistencias y atrevimiento.'};
const hsh=s=>[...s].reduce((x,c)=>(x*31+c.charCodeAt(0))>>>0,7);
function mister(){if(!P||!P.club)return null;const gen=(P.mgen&&P.mgen[P.club])||0;
  if(!P.mister||P.mister.club!==P.club||P.mister.gen!==gen){const h=hsh(P.club+':'+gen),ks=Object.keys(MPERS);
    P.mister={club:P.club,gen,n:FIRSTN[h%FIRSTN.length]+' '+LASTN[(h>>>5)%LASTN.length],k:ks[(h>>>9)%ks.length],rel:50,skin:h%7,hair:(h>>>3)%16,hairc:(h>>>7)%7,beard:(h>>>11)%4,num:''};}
  return P.mister;}
function coachFit(){const m=mister();if(!m)return 0;let b=(m.rel-50)/12;
  if(m.k==='Canterano')b+=P.age<22?2:-.5;if(m.k==='Defensivo')b+=(P.pos==='DEF'||P.pos==='POR')?2:-1;if(m.k==='Ofensivo')b+=(P.pos==='DEL'||P.pos==='EXT')?2:-1;return b;}
function misterWeek(){const m=mister();if(!m)return;let d=0;const rc=routineCount();
  if(m.k==='Exigente')d+=(P.intensity==='intensa'?1:P.intensity==='suave'?-1:0)-(P.free==='fiesta'?2:0);
  if(m.k==='Táctico')d+=(rc.video||0)*.5-(rc.video?0:.5);
  if(m.k==='Canterano')d+=P.age<22?.5:-.2;
  if(m.k==='Motivador'){d+=.3;P.mor=clamp(P.mor+.3,0,100);}
  if(m.k==='Defensivo'&&(P.pos==='DEF'||P.pos==='POR'))d+=.4;
  if(P.free==='fiesta'&&m.k!=='Motivador'&&m.k!=='Exigente')d-=.5;
  m.rel=clamp(m.rel+d,0,100);}
function misterMatch(F,R0){const m=mister();if(!m||!F.min)return;let d=F.rt>=7.5?1.5:F.rt<5.5?-1.5:.2;
  if(m.k==='Ofensivo')d+=R0.g+R0.a*.5;if(m.k==='Defensivo')d+=R0.ok*.3+(F.ga===0?1:0);if(R0.redMin)d-=4;
  m.rel=clamp(m.rel+d,0,100);P.tru=clamp(P.tru+(m.rel-50)/100,0,100);}
function misterSeason(){const m=mister();if(!m||!ch(.14))return;P.mgen=P.mgen||{};P.mgen[P.club]=(P.mgen[P.club]||0)+1;
  news(`${cname(P.club)} cambia de entrenador: ${m.n} deja el banquillo.`);const nm=mister();news(`${nm.n} llega al banquillo de ${cname(P.club)}. Perfil: ${nm.k.toLowerCase()}.`,'hot');P.tru=45;}
function misterTip(m){return{Exigente:'Entrena en intensidad alta y evita las fiestas.',Canterano:P.age<22?'Le encanta que seas joven: aprovéchalo.':'Prefiere a los jóvenes: tendrás que demostrar más.',Defensivo:'Valora los duelos ganados y las porterías a cero.',Motivador:'Con él la moral sube sola; no le falles en los partidos.',Táctico:'Mete bloques de vídeo y táctica en tu rutina semanal.',Ofensivo:'Los goles y las asistencias le enamoran.'}[m.k];}
function misterPanel(){const m=mister();if(!m)return'';const lv=m.rel>=75?'Te adora':m.rel>=58?'Buena relación':m.rel>=42?'Relación neutral':m.rel>=25?'Relación tensa':'No cuenta contigo';
  return `<div class="j-panel j-mister"><h3>Tu entrenador</h3><div class="j-mst">${avatar({...m,club:P.club,kitC:{s:'#1b1b24',t:'#ffffff'}},60)}<div><b>${esc(m.n)}</b><small>${m.k} · ${MPERS[m.k]}</small></div></div>${meter('Química con el míster',m.rel,1)}<p class="j-hint">${lv}. ${misterTip(m)} Cuanta más química, más minutos.</p></div>`;}

/* ---------- vestuario 3D: la charla antes del partido ---------- */
const TALK={motivar:'Motivar al grupo',conc:'Pedir concentración total',broma:'Romper la tensión con una broma'};
function talkLine(m,e){const o=e.opp?cname(e.opp):'el rival';return{Exigente:`Hoy no quiero ver a nadie andando. Contra el ${o} se corre o se va fuera.`,Canterano:`Muchos os habéis criado aquí. Que se note ante el ${o}.`,Defensivo:`Orden, líneas juntas y paciencia. El ${o} se cansará antes.`,Motivador:`Sois mejores de lo que creéis. Salid a disfrutar contra el ${o}.`,Táctico:`Recordad el vídeo: presión tras pérdida y ocupar bien los espacios ante el ${o}.`,Ofensivo:`Quiero ir a por el ${o} desde el minuto uno. ¡A por el gol!`}[m.k];}
const talkNow=()=>P.talk&&P.talk.w===P.week&&P.talk.s===P.season;
function lockerPanel(){const e=nextEv();if(!P.club||!isMatch(e)||P.inj>0||P.ban>0)return'';const m=mister();
  return `<div class="j-panel j-v3"><h3>Vestuario</h3>${v3Box('locker',300,'El vestuario antes del partido')}<p class="j-sit" style="margin-top:12px">«${esc(talkLine(m,e))}» <span class="muted">— ${esc(m.n)}</span></p>
  ${talkNow()?`<p class="j-hint">Tu mensaje al grupo: ${TALK[P.talk.k].toLowerCase()}.</p>`:`<div class="j-chips">${Object.entries(TALK).map(([k,l])=>`<button class="j-chip" data-act="jTalkPre" data-k="${k}">${l}</button>`).join('')}</div><p class="j-hint">${P.captain?'Como capitán, tu mensaje pesa el doble.':'Antes de salir al campo, di algo al grupo.'}</p>`}</div>`;}
const shirtTex=(T,c,num,last)=>pixTex(T,64,64,g=>{g.fillStyle='rgba(0,0,0,0)';g.clearRect(0,0,64,64);g.fillStyle=c.c1;g.fillRect(14,8,36,50);g.fillRect(4,10,12,16);g.fillRect(48,10,12,16);
  g.fillStyle=c.c2;g.fillRect(26,8,12,4);g.font='bold 7px sans-serif';g.textAlign='center';g.fillText(last.slice(0,9),32,22);g.font='900 24px Impact,sans-serif';g.fillText(String(num),32,47);});
function buildLocker(T,V){const sc=V.scene,c=club(P.club)||{c1:'#6B2BD9',c2:'#E4CCFF'},Mt=(col,o={})=>new T.MeshStandardMaterial({color:new T.Color(col),roughness:.7,...o});
  sc.background=new T.Color('#0d0718');sc.add(new T.HemisphereLight(0xf2eaff,0x1a0f2a,.6));
  const add=(geo,m,x,y,z,g=sc)=>{const o=new T.Mesh(geo,m);o.position.set(x,y,z);o.castShadow=o.receiveShadow=true;g.add(o);return o;},bx=(w,h,d,m,x,y,z,g)=>add(new T.BoxGeometry(w,h,d),m,x,y,z,g);
  const tile=pixTex(T,16,16,g=>{for(let i=0;i<4;i++)for(let j=0;j<4;j++){g.fillStyle=(i+j)%2?'#2a2236':'#322a40';g.fillRect(i*4,j*4,4,4);}});tile.wrapS=tile.wrapT=T.RepeatWrapping;tile.repeat.set(6,4);
  const fl=add(new T.PlaneGeometry(14,10),Mt('#ffffff',{map:tile,roughness:.35}),0,0,0);fl.rotation.x=-Math.PI/2;
  const wall=Mt('#1d1430',{roughness:.9});bx(14,4.4,.2,wall,0,2.2,-4.1);bx(.2,4.4,9,wall,-6.8,2.2,0);bx(.2,4.4,9,wall,6.8,2.2,0);
  const neon=new T.MeshStandardMaterial({color:'#C99BFF',emissive:new T.Color('#B57BFF'),emissiveIntensity:1.6});bx(13.6,.06,.06,neon,0,3.9,-3.95);
  [[-3,3.6,-1],[3,3.6,-1]].forEach(([x,y,z])=>{const L=new T.PointLight(0xfff0dc,1.1,14);L.position.set(x,y,z);sc.add(L);bx(2.4,.06,.5,new T.MeshBasicMaterial({color:'#fff6e6'}),x,4.2,z);});
  const sun=new T.DirectionalLight(0xffffff,.5);sun.position.set(2,6,6);sun.castShadow=true;sc.add(sun);
  /* taquillas con nombre: la tuya en el centro, con neón y tu camiseta colgada */
  ensureMates();const names=[...(P.mates||[]).map(m=>m.n.split(' ').slice(-1)[0])],me=3,lk=Mt(c.c1,{roughness:.5,metalness:.2}),inner=Mt('#0e0a16');
  for(let i=0;i<7;i++){const x=-4.8+i*1.6;bx(1.44,2.7,.6,lk,x,1.35,-3.7);bx(1.2,2.2,.1,inner,x,1.45,-3.39);
    const nm=i===me?P.last:(names[(i>me?i-1:i)%Math.max(1,names.length)]||pk(LASTN));
    const pt=pixTex(T,64,16,g=>{g.fillStyle='#0d0718';g.fillRect(0,0,64,16);g.fillStyle=i===me?'#E4CCFF':'#cfc6e0';g.font='bold 9px sans-serif';g.textAlign='center';g.fillText(nm.toUpperCase().slice(0,10),32,11);});pt.magFilter=T.LinearFilter;
    bx(1.1,.26,.02,new T.MeshBasicMaterial({map:pt}),x,2.82,-3.38);
    const sh=new T.Mesh(new T.PlaneGeometry(.95,.95),new T.MeshStandardMaterial({map:shirtTex(T,c,i===me?P.num:R(2,30),nm.toUpperCase()),transparent:true,roughness:.8}));sh.position.set(x,1.7,-3.33);sc.add(sh);}
  bx(1.5,.05,.05,neon,-4.8+me*1.6,2.72,-3.36);bx(.05,2.7,.05,neon,-4.8+me*1.6-.74,1.35,-3.36);bx(.05,2.7,.05,neon,-4.8+me*1.6+.74,1.35,-3.36);
  const bench=Mt('#7a5a3e',{roughness:.6});bx(11.4,.12,.6,bench,0,.5,-2.6);[-5,-1.7,1.7,5].forEach(x=>bx(.12,.5,.5,Mt('#2b2b33'),x,.25,-2.6));
  /* pizarra táctica */
  const bt=pixTex(T,64,48,g=>{g.fillStyle='#f4f4f0';g.fillRect(0,0,64,48);g.strokeStyle='#2a8a4a';g.strokeRect(3,3,58,42);g.beginPath();g.moveTo(32,3);g.lineTo(32,45);g.stroke();g.fillStyle='#d03a3a';[[12,12],[12,36],[22,24],[44,18],[48,30]].forEach(([x,y])=>g.fillRect(x,y,3,3));g.fillStyle='#2a4ad0';[[26,14],[26,34],[40,24]].forEach(([x,y])=>g.fillRect(x,y,3,3));g.strokeStyle='#2a4ad0';g.beginPath();g.moveTo(27,15);g.lineTo(40,24);g.stroke();});
  bt.magFilter=T.LinearFilter;const board=bx(2.2,1.5,.06,new T.MeshStandardMaterial({map:bt,roughness:.6}),2.9,1.7,-1.2);board.rotation.y=-.45;bx(.06,1.7,.06,Mt('#555'),2.9,.85,-1.2);
  /* jugadores, tú y el míster */
  const fig=(L,x,z,ry,s=.88)=>{const o=new T.Group(),inn=new T.Group();o.add(inn);buildFigure(T,inn,L);inn.traverse(q=>{if(q.isMesh)q.castShadow=true;});o.scale.setScalar(s);o.position.set(x,0,z);o.rotation.y=ry;sc.add(o);return{o,inn};};
  const rl=()=>({skin:R(0,6),hair:R(0,15),hairc:R(0,6),beard:R(0,3),boots:R(0,4),acc:0,num:R(2,30),last:pk(LASTN).toUpperCase(),height:R(175,192),club:P.club,kit:'local'});
  const mates=[fig(rl(),-4.1,-1.9,.35),fig(rl(),-2.4,-2.1,.2),fig(rl(),3.6,-2.1,-.3),fig(rl(),-5.6,-.6,.9)],you=fig({...P,kit:'local'},0,-1.9,0);
  const m=mister(),coach=fig({...m,acc:0,num:'',last:'',kitC:{s:'#1b1b24',t:'#e8e8ee',p:'#1b1b24',m:'#1b1b24'}},1.5,.4,-2.7);
  return ms=>{const t=ms/1000;mates.forEach((f,i)=>{f.inn.position.y=Math.abs(Math.sin(t*1.2+i))*.02;const a=f.inn.getObjectByName('armL');if(a)a.rotation.x=Math.sin(t*.9+i)*.15;});
    const ar=coach.inn.getObjectByName('armR');if(ar){ar.rotation.x=-1.1-Math.sin(t*2.4)*.35;ar.rotation.z=.15;}const yl=you.inn.getObjectByName('armL'),yr=you.inn.getObjectByName('armR');if(yl)yl.rotation.x=Math.sin(t*1.5)*.08;if(yr)yr.rotation.x=-Math.sin(t*1.5)*.08;
    const a=clamp(V.rot,-.6,.6);V.cam.position.set(Math.sin(a)*6.2,2.6,3.6+Math.cos(a)*2.2);V.cam.lookAt(0,1.3,-2.2);};}


/* ---------- peinados de la familia: cada peinado es una lista de bloques [x0,x1,y0,y1,z0,z1,tono] en unidades de cabeza
   (la cabeza va de -0.5 a 0.5; la cara está en z=0.47). El mismo bloque sirve para el retrato y para el modelo 3D.
   Tono: 0 color del pelo, -1 sombra, 1 brillo, 'a' complemento (goma, pañuelo, cinta), 's' rapado. ---------- */
const HB=(x0,x1,y0,y1,z0,z1,t=0)=>[x0,x1,y0,y1,z0,z1,t];
const capH=(t=.42,fr=.5)=>[HB(-.54,.54,t,.6,-.52,fr),HB(-.56,-.5,.0,.5,-.5,.3),HB(.5,.56,.0,.5,-.5,.3)];
const strands=(x,y0,y1,z0,z1,n,alt)=>{const o=[];for(let i=0;i<n;i++){const a=y0+(y1-y0)*i/n,b=y0+(y1-y0)*(i+1)/n;o.push(HB(x[0]+(alt&&i%2?.03:0),x[1]+(alt&&i%2?.03:0),a,b,z0,z1,i%2?-1:0));}return o;};
const braid=(x,z,y0,y1)=>{const o=[];for(let y=y1,i=0;y>y0;y-=.13,i++)o.push(HB(x-.09+(i%2?.02:-.02),x+.09+(i%2?.02:-.02),y-.13,y,z-.08,z+.08,i%2?-1:0));o.push(HB(x-.05,x+.05,y0-.06,y0+.02,z-.05,z+.05,'a'),HB(x-.07,x+.07,y0-.22,y0-.06,z-.06,z+.06,1));return o;};
const WHAIR=[
 ['Melena lisa',()=>[...capH(),HB(-.6,-.5,-1.15,.45,-.5,.32),HB(.5,.6,-1.15,.45,-.5,.32),HB(-.58,.58,-1.3,.45,-.64,-.47),HB(-.2,.25,.55,.62,-.1,.45,1)]],
 ['Ondas largas',()=>[...capH(),HB(-.58,.58,-1.25,.45,-.64,-.47),...strands([-.66,-.5],-1.2,.4,-.5,.3,7,1),...strands([.5,.66],-1.2,.4,-.5,.3,7,1),HB(-.3,.1,.56,.63,0,.45,1)]],
 ['Coleta alta',()=>[...capH(.4,.48),HB(-.13,.13,.42,.62,-.66,-.5,'a'),HB(-.15,.15,-.2,.5,-.78,-.6),HB(-.12,.12,-.75,-.2,-.82,-.64,-1),HB(-.08,.08,-.95,-.75,-.8,-.66,1)]],
 ['Moño alto',()=>[...capH(.4,.48),HB(-.24,.24,.6,.98,-.24,.22),HB(-.18,.18,.94,1.06,-.18,.16,1),HB(-.26,.26,.58,.64,-.26,.24,'a'),HB(-.53,-.47,-.2,.25,.3,.5,-1),HB(.47,.53,-.2,.25,.3,.5,-1)]],
 ['Media melena',()=>[...capH(),HB(-.6,-.5,-.7,.45,-.5,.3),HB(.5,.6,-.7,.45,-.5,.3),HB(-.58,.58,-.75,.45,-.62,-.47),HB(-.6,-.45,-.75,-.6,-.5,.3,1),HB(.45,.6,-.75,-.6,-.5,.3,1)]],
 ['Bob con flequillo',()=>[...capH(),HB(-.5,.5,.16,.46,.47,.55),HB(-.42,-.1,.16,.22,.47,.56,-1),HB(-.6,-.5,-.38,.45,-.5,.35),HB(.5,.6,-.38,.45,-.5,.35),HB(-.58,.58,-.4,.45,-.62,-.47)]],
 ['Pixie',()=>[HB(-.53,.53,.42,.56,-.5,.48),HB(-.5,.15,.3,.48,.47,.54,1),HB(-.53,-.5,.05,.45,-.48,.2,-1),HB(.5,.53,.05,.45,-.48,.2,-1),HB(-.52,.52,-.1,.45,-.53,-.47)]],
 ['Trenza de lado',()=>[...capH(),HB(-.58,.58,-.3,.45,-.62,-.47),HB(.5,.6,-.4,.45,-.5,.3),...braid(.45,.22,-1.3,-.35)]],
 ['Dos trenzas',()=>[...capH(),HB(-.03,.03,.56,.63,-.45,.5,-1),HB(-.58,.58,-.25,.45,-.62,-.47),...braid(-.55,0,-1.2,-.1),...braid(.55,0,-1.2,-.1)]],
 ['Rizos afro',()=>{const o=[HB(-.82,.82,-.3,1.0,-.78,.34),HB(-.7,.7,.9,1.12,-.6,.24,1)];for(let i=0;i<9;i++){const x=-.8+i*.2;o.push(HB(x,x+.18,(i%2?.88:.94),(i%2?1.08:1.14),-.5,.3,i%3?-1:1));}[-1,1].forEach(s=>{for(let j=0;j<5;j++)o.push(HB(s>0?.78:-.88,s>0?.88:-.78,-.25+j*.25,-.07+j*.25,-.55,.2,j%2?-1:1));});return o;}],
 ['Rizos largos',()=>{const o=[...capH(),HB(-.6,.6,-1.15,.45,-.66,-.47)];[-1,1].forEach(s=>{for(let j=0;j<8;j++){const x=s>0?.5:-.66;o.push(HB(x+(j%2?.04:0),x+.16+(j%2?.04:0),-1.15+j*.19,-1+j*.19,-.5,.3,j%3===0?1:j%2?-1:0));}});return o;}],
 ['Dos moños',()=>[...capH(.42,.48),HB(-.03,.03,.56,.63,-.45,.5,-1),HB(-.6,-.28,.55,.88,-.2,.14),HB(.28,.6,.55,.88,-.2,.14),HB(-.55,-.33,.82,.92,-.15,.1,1),HB(.33,.55,.82,.92,-.15,.1,1)]],
 ['Flequillo recto',()=>[...capH(),HB(-.52,.52,.12,.46,.47,.56),HB(-.6,-.5,-1.2,.45,-.5,.32),HB(.5,.6,-1.2,.45,-.5,.32),HB(-.58,.58,-1.3,.45,-.64,-.47),HB(-.5,.5,.12,.17,.47,.57,-1)]],
 ['Raya al lado',()=>[...capH(),HB(-.05,.6,.3,.68,-.3,.56),HB(.5,.66,-1.05,.45,-.5,.38),HB(-.58,-.5,-.6,.45,-.5,.28),HB(-.58,.62,-1.0,.45,-.64,-.47),HB(.15,.55,.6,.7,-.2,.5,1)]],
 ['Rapado lateral',()=>[HB(-.53,-.5,-.1,.4,-.48,.35,'s'),HB(.5,.53,-.1,.4,-.48,.35,'s'),HB(-.45,.62,.42,.66,-.5,.52),HB(.2,.66,-.55,.62,-.45,.54),HB(.3,.6,.55,.72,-.3,.4,1)]],
 ['Pañuelo',()=>[...capH(.38,.48),HB(-.56,.56,.3,.52,-.54,.52,'a'),HB(-.2,.2,.25,.55,-.7,-.52,'a'),HB(-.12,.12,-.05,.25,-.72,-.6,'a'),HB(-.22,.22,.55,.85,-.35,.15),HB(-.16,.16,.82,.92,-.3,.1,1)]],
 ['Trenzas africanas',()=>{const o=[...capH()];for(let i=0;i<10;i++){const x=-.6+i*.12;o.push(HB(x,x+.09,-1.35+(i%3)*.06,.4,-.66,-.5,i%2?-1:0));}[-1,1].forEach(s=>{for(let j=0;j<4;j++){const z=-.45+j*.18;o.push(HB(s>0?.5:-.6,s>0?.6:-.5,-1.25+(j%2)*.08,.4,z,z+.12,j%2?-1:0),HB(s>0?.5:-.6,s>0?.6:-.5,-1.32+(j%2)*.08,-1.24+(j%2)*.08,z,z+.12,'a'));}});return o;}],
 ['Coleta baja',()=>[...capH(.4,.48),HB(-.58,.58,-.25,.45,-.62,-.47),HB(-.1,.1,-.4,-.25,-.7,-.58,'a'),HB(-.13,.13,-1.15,-.4,-.74,-.6),HB(-.1,.1,-1.3,-1.15,-.72,-.62,1)]]];
const KHAIR=[
 ['Corto clásico',()=>[HB(-.53,.53,.38,.58,-.5,.5),HB(-.45,.1,.3,.42,.47,.53),HB(-.53,-.5,.05,.45,-.48,.2),HB(.5,.53,.05,.45,-.48,.2),HB(-.52,.52,-.05,.45,-.52,-.47)]],
 ['Rapado',()=>[HB(-.52,.52,.4,.53,-.49,.49,'s'),HB(-.52,-.5,.05,.45,-.48,.3,'s'),HB(.5,.52,.05,.45,-.48,.3,'s'),HB(-.51,.51,-.05,.45,-.5,-.47,'s')]],
 ['Flequillo',()=>[HB(-.55,.55,.38,.6,-.52,.5),HB(-.52,.52,.16,.42,.47,.55),HB(-.58,-.5,-.1,.45,-.5,.38),HB(.5,.58,-.1,.45,-.5,.38),HB(-.56,.56,-.15,.45,-.6,-.47)]],
 ['De punta',()=>{const o=[HB(-.53,.53,.38,.56,-.5,.48)];for(let i=0;i<6;i++){const x=-.48+i*.17;o.push(HB(x,x+.13,.52,.7+(i%2)*.08,-.35+(i%3)*.15,-.15+(i%3)*.15,i%2?1:0));}o.push(HB(-.53,-.5,.1,.45,-.48,.2),HB(.5,.53,.1,.45,-.48,.2));return o;}],
 ['Rizos',()=>{const o=[HB(-.55,.55,.36,.58,-.52,.48)];for(let i=0;i<5;i++)for(let j=0;j<3;j++)o.push(HB(-.55+i*.22,-.37+i*.22,.52+(j%2)*.04,.68+(j%2)*.04,-.45+j*.3,-.25+j*.3,(i+j)%2?-1:1));o.push(HB(-.6,-.5,0,.45,-.5,.25),HB(.5,.6,0,.45,-.5,.25));return o;}],
 ['Afro',()=>{const o=[HB(-.7,.7,-.05,.86,-.66,.36)];for(let i=0;i<7;i++){const x=-.7+i*.2;o.push(HB(x,x+.18,.78,.95,-.45,.25,i%2?-1:1));}return o;}],
 ['Melenita surfera',()=>[HB(-.55,.55,.38,.6,-.52,.5),HB(-.5,.3,.25,.44,.47,.54,1),HB(-.62,-.5,-.55,.45,-.5,.3),HB(.5,.62,-.55,.45,-.5,.3),HB(-.6,.6,-.6,.45,-.64,-.47)]],
 ['Cresta',()=>[HB(-.52,-.15,.4,.52,-.49,.45,'s'),HB(.15,.52,.4,.52,-.49,.45,'s'),HB(-.15,.15,.45,.86,-.52,.5),HB(-.12,.12,.82,.92,-.4,.4,1),HB(-.52,-.5,.05,.45,-.48,.3,'s'),HB(.5,.52,.05,.45,-.48,.3,'s')]],
 ['Raya al lado',()=>[HB(-.53,.53,.38,.58,-.5,.5),HB(-.25,-.21,.5,.6,-.45,.5,-1),HB(-.2,.55,.34,.5,.4,.55,1),HB(-.53,-.5,.05,.45,-.48,.25),HB(.5,.55,.05,.45,-.48,.25),HB(-.52,.52,-.05,.45,-.52,-.47)]],
 ['Tupé',()=>[HB(-.53,.53,.38,.56,-.5,.46),HB(-.4,.4,.5,.8,.15,.58),HB(-.32,.32,.76,.86,.2,.52,1),HB(-.53,-.5,.1,.45,-.48,.2,'s'),HB(.5,.53,.1,.45,-.48,.2,'s')]],
 ['Trenzas pegadas',()=>{const o=[HB(-.52,.52,.4,.54,-.5,.47,'s')];for(let i=0;i<6;i++){const x=-.48+i*.17;o.push(HB(x,x+.09,.5,.58,-.5,.48,i%2?-1:0));}return o;}],
 ['Moño samurái',()=>[HB(-.53,.53,.38,.58,-.5,.48),HB(-.13,.13,.5,.74,-.42,-.16),HB(-.15,.15,.5,.55,-.44,-.14,'a'),HB(-.53,-.5,.05,.45,-.48,.2,'s'),HB(.5,.53,.05,.45,-.48,.2,'s')]],
 ['Mullet',()=>[HB(-.53,.53,.38,.58,-.5,.5),HB(-.45,.2,.3,.42,.47,.53,1),HB(-.53,-.5,.05,.45,-.48,.2,'s'),HB(.5,.53,.05,.45,-.48,.2,'s'),HB(-.55,.55,-.75,.45,-.64,-.47),HB(-.5,.5,-.85,-.7,-.62,-.5,-1)]],
 ['Melena con cinta',()=>[HB(-.55,.55,.38,.6,-.52,.5),HB(-.56,.56,.3,.4,-.53,.53,'a'),HB(-.62,-.5,-.85,.45,-.5,.3),HB(.5,.62,-.85,.45,-.5,.3),HB(-.6,.6,-.95,.45,-.64,-.47)]]];
const BHAIR=[['Calvito',()=>[]],['Tres pelos',()=>[HB(-.04,.0,.5,.66,0,.04),HB(.04,.08,.5,.6,-.04,0),HB(-.12,-.08,.5,.58,.04,.08)]],['Rizo',()=>[HB(-.08,.08,.5,.58,-.05,.1),HB(.0,.14,.58,.66,-.05,.1,1)]],['Pelusa',()=>[HB(-.48,.48,.48,.54,-.45,.45,1)]]];
const WHC=['#16101C','#2a1a12','#3B2416','#5a3220','#6E4424','#8a4a2a','#a8321e','#c4622d','#B07A3E','#D9B26A','#efe0b0','#9a9aa6','#e07aa8','#9a7ad8','#3a6ad0','#2fa38a'];
const HCN=['negro','castaño oscuro','castaño','avellana','castaño claro','caoba','pelirrojo','cobrizo','miel','rubio','rubio platino','canoso','rosa','lila','azul','verde agua'];
/* tono de cada bloque: brillo, sombra, rapado (mezcla con la piel), complemento; con degradado (ombré) las puntas son más claras */
function hairTone(t,y1,hc,skin,acc,ombre){if(t==='a')return acc;if(t==='s')return mixHex(hc,skin,.55);let c=t===1?shadeHex(hc,.22):t===-1?shadeHex(hc,-.25):hc;if(ombre&&y1<-.45)c=shadeHex(c,.45);return c;}
function mixHex(a,b,k){const p=h=>[1,3,5].map(i=>parseInt(h.slice(i,i+2),16)),A=p(a),B=p(b);return '#'+A.map((v,i)=>Math.round(v*(1-k)+B[i]*k).toString(16).padStart(2,'0')).join('');}
/* retrato: proyección frontal de los bloques; lo de detrás de la espalda va bajo la ropa, los mechones de los lados por encima
   de los hombros y el flequillo por encima de la cara */
function hairSvg(blocks,cx,cy,s,tone){const r=b=>R_((cx+b[0]*s).toFixed(1),(cy-b[3]*s).toFixed(1),((b[1]-b[0])*s+.3).toFixed(1),((b[3]-b[2])*s+.3).toFixed(1),tone(b));
  const srt=blocks.slice().sort((a,b)=>a[5]-b[5]);return{far:srt.filter(b=>b[5]<=-.4).map(r).join(''),back:srt.filter(b=>b[5]>-.4&&b[5]<=.47).map(r).join(''),front:srt.filter(b=>b[5]>.47).map(r).join('')};}
/* modelo 3D: un vóxel por bloque, a escala de la cabeza */
function hair3D(T,fig,blocks,H,hs,tone,M){const mats={};blocks.forEach(b=>{const c=tone(b),m=mats[c]||(mats[c]=M(c,{roughness:.72}));
  const o=new T.Mesh(new T.BoxGeometry((b[1]-b[0])*hs,(b[3]-b[2])*hs,(b[5]-b[4])*hs),m);o.position.set((b[0]+b[1])/2*hs,H+(b[2]+b[3])/2*hs,(b[4]+b[5])/2*hs);fig.add(o);});}

/* ---------- familia: aspecto propio de tu pareja y de tus hijos (retrato en píxeles y modelo 3D con detalle) ---------- */
const PEYE=['#5a3a22','#3f7a3a','#3b6fb0','#8a6a2a','#2a2a2a','#6a7a8a','#2f8a8a'],PLIP=['#c2324a','#a8344e','#d0607a','#b5523a','#8e2a3a','#c46a5a','#7a2a5a'];
const PDRESS=[['#c8506a','#f6d7df','flores'],['#2f4a8a','#e9eefc','lunares'],['#1d1d24','#d9b26a','liso'],['#3f8a6a','#e6f5ee','rayas'],['#e8c45a','#fff6d8','flores'],['#7a3fa8','#ead7ff','lunares'],['#d9d4cc','#8a6a4a','rayas'],['#b5332e','#ffd9d4','liso'],['#2fa3b8','#e0fbff','cuadros'],['#f08a4a','#fff0e0','flores'],['#4a4a58','#ff8ab0','cuadros'],['#f2f2f2','#2f4a8a','rayas']];
const PFIT=['vestido','vaqueros','falda','mono'],PFITN={vestido:'vestido',vaqueros:'vaqueros y camiseta',falda:'falda y blusa',mono:'mono'};
const PACC=['#ff5d8a','#3a7bd5','#E8B83A','#3f8a4f','#7a3fa8','#f2f2f2','#1b1022'];
const KTOP=['#3a7bd5','#e0663a','#3f8a4f','#7a3fa8','#d4a12a','#e0457a','#2fa3b8','#4a4a58','#b5332e','#8ac24a'];
const KFIT=['sudadera','camiseta','polo','chandal'],KPRINT=['dino','cohete','estrella','rayo','balon'];
/* el aspecto se deduce del nombre: siempre es el mismo para la misma persona */
function partnerLook(F){const p=F.partner,h=hsh(p.n),h2=hsh(p.n+'·');
  if(!p.lk||p.lk.v!==3){const dyed=h2%100<14;p.lk={v:3,eyeS:(h2>>>5)%4,brow:(h2>>>2)%4,mouth:(h>>>27)%3,nose:(h2>>>24)%3,liner:(h2>>>27)%3===0,shadow:[null,'#b56aa8','#c8906a','#6a8ac8','#8a6a5a',null][(h>>>29)%6],freck:(h>>>28)%6===0,skin:h%7,hairc:dyed?12+(h2>>>8)%4:(h2>>>8)%12,hair:(h>>>4)%WHAIR.length,ombre:(h2>>>14)%6===0,acc:PACC[(h2>>>17)%PACC.length],eye:(h>>>9)%PEYE.length,lip:(h>>>12)%PLIP.length,dress:(h>>>15)%PDRESS.length,fit:PFIT[(h2>>>20)%4],ear:(h>>>19)%3,mole:(h>>>22)%4===0,glass:(h>>>25)%6===0};}return p.lk;}
function kidLook(k){const h=hsh(k.n+k.b),h2=hsh(k.b+k.n+'·'),pl=fam().partner?partnerLook(fam()):null,fromMe=h%2===0;
  if(!k.lk||k.lk.v!==3){const mom=pl&&(h>>>2)%2&&pl.hairc<12,hcol=mom?WHC[pl.hairc]:HAIRC[(P.hairc||0)%7];
    k.lk={v:3,eyeS:(h2>>>4)%2,brow:(h>>>18)%4,mouth:(h>>>20)%4,nose:(h>>>22)%3,dimple:(h>>>24)%3===0,skin:fromMe||!pl?P.skin:pl.skin,hcol,eye:pl&&(h>>>4)%2?pl.eye:(h>>>5)%PEYE.length,freck:(h>>>7)%3===0,cap:(h>>>9)%4===0,col:KTOP[(h2>>>3)%KTOP.length],col2:KTOP[(h2>>>9)%KTOP.length],
      hair:(h2>>>12)%KHAIR.length,bhair:(h>>>13)%BHAIR.length,fit:KFIT[(h2>>>17)%4],print:KPRINT[(h2>>>20)%KPRINT.length],glass:(h2>>>23)%6===0,teenDye:(h2>>>26)%7===0,acc:PACC[(h>>>16)%PACC.length]};}return k.lk;}
const kidKit=k=>{const c=club(k.club||P.club)||{c1:'#6B2BD9',c2:'#ffffff'};return{c1:c.c1,c2:c.c2&&c.c2.toLowerCase()!==c.c1.toLowerCase()?c.c2:'#ffffff'};};
const kidHairC=(k,L)=>kidAge(k)>=13&&L.teenDye?WHC[12+hsh(k.n)%4]:L.hcol||'#3B2416';
const kidHair=(k,L)=>kidAge(k)<2?BHAIR[L.bhair]:KHAIR[L.hair];
function partnerDesc(F){const L=partnerLook(F);return `${WHAIR[L.hair][0]} · pelo ${HCN[L.hairc]}${L.ombre?' con mechas':''} · ${L.fit==='vestido'?'vestido '+{flores:'de flores',lunares:'de lunares',rayas:'de rayas',liso:'liso',cuadros:'de cuadros'}[PDRESS[L.dress][2]]:PFITN[L.fit]}${F.married?' · anillo de casada':''}`;}
function kidDesc(k){const L=kidLook(k),a=kidAge(k);return a<2?BHAIR[L.bhair][0]:`${KHAIR[L.hair][0]}${L.glass?' · gafas':''}`;}

/* --- retratos SVG (120×120, mismos píxeles que la ficha del jugador) --- */
const R_=(x,y,w,h,f,o='')=>`<rect x="${x}" y="${y}" width="${w}" height="${h}" fill="${f}"${o}/>`;
const printSvg=(p,x,y,c)=>({dino:R_(x,y+4,10,5,c)+R_(x+7,y,5,5,c)+R_(x+1,y+9,2,3,c)+R_(x+6,y+9,2,3,c),cohete:R_(x+4,y,4,10,c)+R_(x+2,y+7,2,4,c)+R_(x+8,y+7,2,4,c)+R_(x+5,y+10,2,3,'#ffb04a'),estrella:R_(x+4,y,4,12,c)+R_(x,y+4,12,4,c)+R_(x+2,y+2,8,8,c),rayo:R_(x+5,y,4,5,c)+R_(x+3,y+4,6,3,c)+R_(x+2,y+7,4,5,c),balon:R_(x+2,y,8,12,'#ffffff')+R_(x,y+2,12,8,'#ffffff')+R_(x+4,y+4,4,4,'#1b1022')})[p]||'';
function partnerSvg(F,size=96){const L=partnerLook(F),sk=SKIN[L.skin],hc=WHC[L.hairc],[d1,d2,pat]=PDRESS[L.dress],eye=PEYE[L.eye],lip=PLIP[L.lip],gold='#E8B83A',hd=shadeHex(hc,-.25);
  const hr=hairSvg(WHAIR[L.hair][1](),60,51,52,b=>hairTone(b[6],b[3],hc,sk,L.acc,L.ombre));
  const patt=pat==='lunares'?[[32,96],[48,104],[64,98],[80,106],[40,112],[72,114]].map(([x,y])=>R_(x,y,3,3,d2)).join(''):pat==='rayas'?[0,1,2,3].map(i=>R_(26,94+i*6,68,2,d2)).join(''):pat==='flores'?[[34,100],[58,108],[80,98]].map(([x,y])=>R_(x,y,5,5,d2)+R_(x+1,y+1,3,3,'#ffd84a')).join(''):pat==='cuadros'?[0,1,2,3,4].map(i=>R_(26+i*14,88,5,32,d2,' opacity=".55"')+R_(26,92+i*6,68,2,d2,' opacity=".55"')).join(''):R_(56,90,8,4,d2);
  const outfit={vestido:R_(24,86,72,34,d1)+patt+R_(24,86,14,8,sk)+R_(82,86,14,8,sk)+R_(38,84,4,10,d1)+R_(78,84,4,10,d1)+R_(50,82,20,10,sk)+R_(54,90,12,4,sk),
    vaqueros:R_(24,86,72,34,d1)+R_(24,86,12,14,sk)+R_(84,86,12,14,sk)+R_(24,98,12,4,shadeHex(d1,-.2))+R_(84,98,12,4,shadeHex(d1,-.2))+R_(48,84,24,6,sk)+printSvg(['estrella','rayo','cohete','balon','dino'][hsh(F.partner.n)%5],54,100,d2),
    falda:R_(24,86,72,34,'#f6f2ea')+R_(46,84,12,10,'#ffffff')+R_(62,84,12,10,'#ffffff')+R_(58,86,4,8,sk)+[96,104,112].map(y=>R_(59,y,2,2,'#c9c2b4')).join('')+R_(24,86,8,34,shadeHex('#f6f2ea',-.08))+R_(88,86,8,34,shadeHex('#f6f2ea',-.08)),
    mono:R_(24,86,72,34,d1)+R_(24,86,16,10,sk)+R_(80,86,16,10,sk)+R_(40,84,6,12,d1)+R_(74,84,6,12,d1)+R_(48,82,24,10,sk)+R_(56,106,8,4,gold)}[L.fit];
  const ears=[R_(31,62,3,3,gold)+R_(86,62,3,3,gold),R_(30,62,4,8,'none',` stroke="${gold}" stroke-width="1.6"`)+R_(86,62,4,8,'none',` stroke="${gold}" stroke-width="1.6"`),R_(31,62,3,3,'#e8f6ff')+R_(31,66,2,6,gold)+R_(87,62,3,3,'#e8f6ff')+R_(87,66,2,6,gold)][L.ear];
  return `<svg viewBox="0 0 120 120" width="${size}" height="${size}" role="img" aria-label="Retrato de ${esc(F.partner.n)}"><defs><clipPath id="pc${hsh(F.partner.n)}"><rect x="2" y="2" width="116" height="116" rx="14"/></clipPath></defs><rect x="2" y="2" width="116" height="116" rx="14" fill="#24102e"/>
   <g clip-path="url(#pc${hsh(F.partner.n)})">${R_(8,8,6,6,'#ff7fa8',' opacity=".25"')+R_(100,14,4,4,'#ff7fa8',' opacity=".25"')}
   ${hr.far}${outfit}${L.fit==='falda'?'':R_(48,86,24,2,gold)+R_(58,88,4,4,gold)+R_(59,89,2,2,'#ff5d8a')}${hr.back}
   ${R_(51,72,18,12,sk)}${R_(34,25,52,52,sk)}${R_(31,46,4,9,sk)}${R_(32,48,2,5,shadeHex(sk,-.18))}${R_(85,46,4,9,sk)}${R_(86,48,2,5,shadeHex(sk,-.18))}${ears}
   ${faceSvg(partnerFace(L),34,25,52)}
   ${hr.front}</g>
   ${F.married?`<g transform="translate(96 92)"><circle r="9" fill="#1a0c33" stroke="${gold}" stroke-width="1.4"/><circle cy="2" r="4" fill="none" stroke="${gold}" stroke-width="1.6"/><rect x="-2" y="-6" width="4" height="4" fill="#cfe9ff"/></g>`:''}</svg>`;}
function kidSvg(k,size=72){const a=kidAge(k),L=kidLook(k),sk=SKIN[L.skin],hc=kidHairC(k,L),hd=shadeHex(hc,-.25),eye=PEYE[L.eye],K=kidKit(k),id='kc'+hsh(k.n+k.b);let body='',head='',extra='';
  if(a<2){const hr=hairSvg(BHAIR[L.bhair][1](),60,55,60,b=>hairTone(b[6],b[3],hc,sk,L.acc,false));body=R_(26,88,68,32,'#f4d9e6')+[34,52,70,86].map(x=>R_(x,98,6,6,'#fff3a8')).join('')+R_(54,88,12,8,'#ffffff');
    head=hr.far+hr.back+R_(30,25,60,60,sk)+faceSvg(kidFace(k,L),30,25,60)+hr.front;}
  else{const fb=k.fb&&a>=6,top=a<6?'#f4f4f4':fb?K.c1:L.col,hr=hairSvg(KHAIR[L.hair][1](),60,53,56,b=>hairTone(b[6],b[3],hc,sk,L.acc,false));
    body=R_(26,88,68,32,top)+(a<6?[0,1,2,3].map(i=>R_(26,92+i*7,68,3,L.col)).join('')+R_(36,94,48,26,'#3b5a8a')+R_(40,88,6,10,'#3b5a8a')+R_(74,88,6,10,'#3b5a8a')+R_(41,96,4,4,'#E8B83A')+R_(75,96,4,4,'#E8B83A')
      :fb?R_(26,88,68,5,K.c2)+R_(52,88,16,7,K.c2)+`<text x="60" y="115" text-anchor="middle" font-family="Big Shoulders Display,Impact,sans-serif" font-weight="900" font-size="18" fill="${K.c2}">${(hsh(k.n)%30)+1}</text>`
      :L.fit==='sudadera'?R_(40,88,40,8,shadeHex(top,-.2))+R_(48,96,2,12,'#ffffff')+R_(70,96,2,12,'#ffffff')+R_(44,108,32,10,shadeHex(top,-.15))
      :L.fit==='camiseta'?R_(48,86,24,4,shadeHex(top,-.25))+printSvg(L.print,54,98,'#ffffff')
      :L.fit==='polo'?R_(44,86,14,8,'#ffffff')+R_(62,86,14,8,'#ffffff')+R_(58,90,4,14,shadeHex(top,-.2))+R_(59,94,2,2,'#ffffff')+R_(59,100,2,2,'#ffffff')
      :R_(26,88,8,32,'#ffffff')+R_(86,88,8,32,'#ffffff')+R_(58,88,4,32,'#c9c9d6')+R_(48,86,24,5,shadeHex(top,-.25)));
    body=hr.far+body;head=hr.back+R_(32,25,56,56,sk)+R_(29,46,4,9,sk)+R_(87,46,4,9,sk)+R_(30,48,2,5,shadeHex(sk,-.18))+R_(88,48,2,5,shadeHex(sk,-.18))+faceSvg(kidFace(k,L),32,25,56)+hr.front;
    if(L.cap&&a>=6&&a<16&&!['Afro','Cresta','Moño samurái','Melena con cinta'].includes(KHAIR[L.hair][0]))extra=R_(30,18,60,12,L.col2)+R_(30,28,72,4,shadeHex(L.col2,-.25))+R_(56,20,8,6,'#ffffff');
    if(a>=13)extra+=R_(24,60,8,16,'#1b1022')+R_(88,60,8,16,'#1b1022')+R_(26,82,68,4,'#1b1022');
    if(fb)extra+=`<g transform="translate(98 98)"><circle r="10" fill="#fff" stroke="#1b1022" stroke-width="1"/><path d="M0-4 4-1 2.5 4h-5L-4-1Z" fill="#1b1022"/></g>`;}
  return `<svg viewBox="0 0 120 120" width="${size}" height="${size}" role="img" aria-label="Retrato de ${esc(k.n)}"><defs><clipPath id="${id}"><rect x="2" y="2" width="116" height="116" rx="14"/></clipPath></defs><rect x="2" y="2" width="116" height="116" rx="14" fill="#14183a"/><g clip-path="url(#${id})">${body}${R_(50,78,20,12,sk)}${head}${extra}</g></svg>`;}

/* --- modelos 3D de vóxeles: misma escala y estilo que tu futbolista --- */
/* textura en el mismo espacio de color que los colores lisos, para que cara y brazos tengan el mismo tono */
function ptex(T,w,h,draw){const t=pixTex(T,w,h,draw);if('encoding' in t&&T.LinearEncoding!=null)t.encoding=T.LinearEncoding;return t;}
function buildPartner(T,fig,F){const L=partnerLook(F),skC=SKIN[L.skin],hC=WHC[L.hairc],[d1,d2,pat]=PDRESS[L.dress],lipC=PLIP[L.lip],eyeC=PEYE[L.eye],fit=L.fit;
  const M=(c,o={})=>new T.MeshStandardMaterial({color:new T.Color(c),roughness:.55,...o}),skin=M(skC,{roughness:.6});
  const gold=M('#E8B83A',{metalness:.35,roughness:.3,emissive:new T.Color('#6a4a00'),emissiveIntensity:.45}),shoe=M(shadeHex(d1,-.35),{roughness:.25,metalness:.2});
  const box=(p,w,h,d,m,x,y,z)=>{const o=new T.Mesh(new T.BoxGeometry(w,h,d),m);o.position.set(x,y,z);p.add(o);return o;};
  const tex=ptex(T,64,64,(g,W,H)=>{g.fillStyle=d1;g.fillRect(0,0,W,H);g.fillStyle=d2;
    if(pat==='lunares')for(let y=2;y<H;y+=10)for(let x=(y/10)%2?7:2;x<W;x+=10)g.fillRect(x,y,3,3);
    else if(pat==='rayas')for(let y=0;y<H;y+=8)g.fillRect(0,y,W,3);
    else if(pat==='cuadros'){g.globalAlpha=.55;for(let i=0;i<W;i+=12){g.fillRect(i,0,4,H);g.fillRect(0,i,W,4);}g.globalAlpha=1;}
    else if(pat==='flores')for(let y=4;y<H;y+=16)for(let x=(y/16)%2?12:4;x<W;x+=16){g.fillRect(x,y+2,6,2);g.fillRect(x+2,y,2,6);g.fillStyle='#ffd84a';g.fillRect(x+2,y+2,2,2);g.fillStyle=d2;}
    else{g.fillRect(0,H-4,W,2);}});
  const dm=M('#ffffff',{map:tex}),denim=M('#3b5a8a',{roughness:.8}),blouse=M('#f6f2ea'),plain=M(d1);
  /* calzado y piernas según el conjunto */
  [-1,1].forEach(sd=>{const x=sd*.11;
    if(fit==='vaqueros'){box(fig,.17,.1,.28,M('#ffffff',{roughness:.4}),x,.05,.04);box(fig,.18,.025,.29,M(d1),x,.015,.04);box(fig,.12,.02,.04,M('#cfcfd6'),x,.09,.17);box(fig,.16,.52,.18,denim,x,.36,0);box(fig,.165,.04,.185,M('#2b4a7a'),x,.12,0);}
    else if(fit==='mono'){box(fig,.15,.04,.24,M('#1b1022'),x,.02,.05);box(fig,.03,.06,.2,gold,x,.06,.05);box(fig,.22,.58,.24,plain,x,.35,0);}
    else{box(fig,.16,.07,.26,shoe,x,.06,.05);box(fig,.04,.12,.04,shoe,x,.06,-.06);box(fig,.17,.02,.27,M('#120c14'),x,.015,.05);box(fig,.14,.03,.02,gold,x,.09,.18);
      box(fig,.13,.42,.15,skin,x,.33,0);box(fig,.14,.12,.16,skin,x,.6,0);}});
  if(fit==='vestido'){[[.66,.08,.46,.62],[.6,.12,.4,.56],[.54,.14,.36,.72],[.48,.14,.32,.86]].forEach(([w,h,d,y])=>box(fig,w,h,d,dm,0,y,0));box(fig,.67,.025,.47,M(d2),0,.575,0);}
  else if(fit==='falda'){box(fig,.46,.44,.3,dm,0,.76,0);box(fig,.04,.2,.31,M(shadeHex(d1,-.25)),.1,.6,0);}
  else if(fit==='vaqueros')box(fig,.44,.22,.28,denim,0,.73,0);
  else box(fig,.46,.3,.29,plain,0,.75,0);
  box(fig,.44,.06,.29,fit==='vaqueros'?M('#5a3220'):gold,0,.97,0);box(fig,.08,.07,.3,M('#fff6d8',{metalness:.6,roughness:.3}),0,.97,.01);
  /* cuerpo: escote y collar, camiseta con dibujo o blusa con cuello y botones */
  const front=ptex(T,64,64,(g,W,H)=>{
    if(fit==='falda'){g.fillStyle='#f6f2ea';g.fillRect(0,0,W,H);g.fillStyle='#ffffff';g.fillRect(14,0,14,10);g.fillRect(36,0,14,10);g.fillStyle=skC;g.fillRect(28,0,8,10);g.fillStyle='#c9c2b4';[16,28,40,52].forEach(y=>g.fillRect(31,y,3,3));return;}
    if(fit==='vaqueros'){g.fillStyle=d1;g.fillRect(0,0,W,H);g.fillStyle=skC;g.fillRect(22,0,20,6);g.fillStyle=d2;g.fillRect(20,22,24,22);g.fillStyle=d1;g.fillRect(24,26,16,14);g.fillStyle=d2;g.fillRect(28,30,8,6);return;}
    g.drawImage(tex.image,0,0);if(fit==='mono'){g.fillStyle=d1;g.fillRect(0,0,W,H);}g.fillStyle=skC;g.beginPath();g.moveTo(14,0);g.lineTo(32,26);g.lineTo(50,0);g.fill();
    g.fillStyle='#E8B83A';for(let i=0;i<22;i++){const t=i/21,x=18+t*28,y=4+Math.sin(t*Math.PI)*14;g.fillRect(x|0,y|0,2,2);}g.fillStyle='#ff5d8a';g.fillRect(30,18,5,5);g.fillStyle='#ffd0de';g.fillRect(31,19,2,2);});
  const tm=fit==='falda'?blouse:fit==='vestido'?dm:plain,torso=new T.Mesh(new T.BoxGeometry(.46,.52,.27),[tm,tm,tm,tm,M('#ffffff',{map:front}),tm]);torso.position.set(0,1.24,0);torso.name='chest';fig.add(torso);
  if(fit==='vestido'||fit==='mono')[-1,1].forEach(sd=>box(fig,.07,.04,.27,tm,sd*.15,1.51,0));box(fig,.38,.04,.26,fit==='falda'?blouse:fit==='vaqueros'?tm:skin,0,1.52,0);box(fig,.17,.09,.17,skin,0,1.56,0);
  /* brazos: tirantes, manga corta o manga larga; pulseras, anillo y bolso */
  [-1,1].forEach(sd=>{const arm=new T.Group();arm.position.set(sd*.31,1.48,0);arm.name=sd<0?'armL':'armR';fig.add(arm);const sl=fit==='falda'?blouse:fit==='vaqueros'?tm:skin;
    box(arm,.14,.3,.16,sl,0,-.15,0);box(arm,.13,.3,.15,fit==='falda'?blouse:skin,0,-.44,0);box(arm,.15,.035,.17,gold,0,-.54,0);box(arm,.15,.11,.15,skin,0,-.64,0);
    if(sd<0&&F.married){box(arm,.04,.03,.05,gold,.06,-.66,.06);const dia=new T.Mesh(new T.OctahedronGeometry(.022),M('#e8f6ff',{metalness:.3,roughness:.05,emissive:new T.Color('#9fd8ff'),emissiveIntensity:.6}));dia.position.set(.06,-.63,.08);arm.add(dia);}
    if(sd>0&&fit!=='vaqueros'){const bag=new T.Group();bag.position.set(.12,-.5,0);arm.add(bag);box(bag,.12,.2,.28,M(shadeHex(d1,-.3),{roughness:.35}),.04,-.12,0);box(bag,.125,.05,.29,M(shadeHex(d1,-.45)),.04,-.03,0);box(bag,.02,.04,.06,gold,.11,-.06,0);
      const strap=new T.Mesh(new T.TorusGeometry(.1,.012,6,18,Math.PI),gold);strap.rotation.y=Math.PI/2;strap.position.set(.04,0,0);bag.add(strap);}});
  if(fit==='vaqueros'){box(fig,.38,.42,.12,M(shadeHex(d1,-.4),{roughness:.4}),0,1.2,-.2);[-1,1].forEach(sd=>box(fig,.04,.46,.04,M('#1b1022'),sd*.13,1.24,-.13));}
  /* cabeza: ojos con pestañas, sombra, colorete y labios pintados */
  const H=1.84,hs=.5,face=faceTex(T,partnerFace(L));
  const head=new T.Mesh(new T.BoxGeometry(hs,hs,hs*.94),[skin,skin,skin,skin,M('#ffffff',{map:face,roughness:.6}),skin]);head.position.set(0,H,0);fig.add(head);
  [-1,1].forEach(sd=>{box(fig,.04,.09,.07,skin,sd*(hs/2+.02),H-.02,0);const er=L.ear===1?new T.Mesh(new T.TorusGeometry(.035,.009,6,14),gold):new T.Mesh(new T.SphereGeometry(.022,8,6),L.ear===2?M('#e8f6ff',{emissive:new T.Color('#9fd8ff'),emissiveIntensity:.5}):gold);er.position.set(sd*(hs/2+.03),H-.1,.02);er.rotation.y=Math.PI/2;fig.add(er);});
  /* peinado: el mismo que en el retrato */
  hair3D(T,fig,WHAIR[L.hair][1](),H,hs,b=>hairTone(b[6],b[3],hC,skC,L.acc,L.ombre),M);}
function buildKid(T,fig,k){const a=kidAge(k),L=kidLook(k),skC=SKIN[L.skin],hC=kidHairC(k,L),eyeC=PEYE[L.eye],K=kidKit(k);
  const M=(c,o={})=>new T.MeshStandardMaterial({color:new T.Color(c),roughness:.6,...o}),skin=M(skC);
  const box=(p,w,h,d,m,x,y,z)=>{const o=new T.Mesh(new T.BoxGeometry(w,h,d),m);o.position.set(x,y,z);p.add(o);return o;};
  const faceT=()=>faceTex(T,kidFace(k,L));
  const headAt=(H,hs,baby)=>{const h=new T.Mesh(new T.BoxGeometry(hs,hs,hs*.94),[skin,skin,skin,skin,M('#ffffff',{map:faceT()}),skin]);h.position.set(0,H,0);fig.add(h);
    [-1,1].forEach(sd=>box(fig,.05,.1,.08,skin,sd*(hs/2+.02),H-.02,0));return h;};
  const hairOn=(hd,hs,set)=>{const g=new T.Group();g.position.copy(hd.position);g.rotation.copy(hd.rotation);fig.add(g);hair3D(T,g,set[1](),0,hs,b=>hairTone(b[6],b[3],hC,skC,L.acc,false),M);};
  if(a<2){/* cuna con barrotes, colchón, manta, chupete, osito y móvil colgante */
    const wood=M('#d9b48a',{roughness:.5});box(fig,1.3,.06,.8,wood,0,.62,0);[-1,1].forEach(sd=>{box(fig,.06,1.1,.06,wood,sd*.62,.55,.37);box(fig,.06,1.1,.06,wood,sd*.62,.55,-.37);box(fig,.06,.5,.8,wood,sd*.62,.85,0);});
    for(let i=-5;i<=5;i++)[-1,1].forEach(sd=>box(fig,.03,.4,.03,wood,i*.11,.85,sd*.37));[-1,1].forEach(sd=>box(fig,1.3,.05,.05,wood,0,1.06,sd*.37));
    box(fig,1.18,.1,.7,M('#ffffff'),0,.7,0);const blk=ptex(T,32,32,(g)=>{g.fillStyle='#f4d9e6';g.fillRect(0,0,32,32);g.fillStyle='#fff3a8';for(let y=2;y<32;y+=8)for(let x=(y/8)%2?6:2;x<32;x+=8){g.fillRect(x,y,2,2);}});
    box(fig,.7,.08,.66,M('#ffffff',{map:blk}),.18,.78,0);box(fig,.32,.16,.3,M('#f4d9e6'),-.25,.82,0);const hd=headAt(.88,.3,true);hd.rotation.y=Math.PI/2;hd.position.x=-.48;hd.rotation.z=-.25;hairOn(hd,.3,BHAIR[L.bhair]);
    const pac=new T.Mesh(new T.TorusGeometry(.04,.012,6,14),M('#7fc8ff'));pac.position.set(-.48,.86,.17);fig.add(pac);
    const bear=new T.Group();bear.position.set(.42,.78,.2);fig.add(bear);const bm=M('#a8743e',{roughness:.85});[[0,.08,0,.09],[0,.2,0,.07],[-.06,.26,0,.03],[.06,.26,0,.03]].forEach(([x,y,z,r])=>{const s_=new T.Mesh(new T.SphereGeometry(r,10,8),bm);s_.position.set(x,y,z);bear.add(s_);});
    box(fig,.03,.6,.03,wood,.6,1.35,-.37);box(fig,.4,.03,.03,wood,.42,1.64,-.37);const mob=new T.Group();mob.position.set(.25,1.62,-.37);mob.name='mobile';fig.add(mob);
    [['#ffd84a',.15,0],['#7fc8ff',-.15,0],['#ff8aa8',0,.15],['#b5e3a0',0,-.15]].forEach(([c,x,z],i)=>{box(mob,.005,.18,.005,M('#ffffff'),x,-.09,z);const st=new T.Mesh(i%2?new T.SphereGeometry(.04,8,6):new T.OctahedronGeometry(.05),M(c,{emissive:new T.Color(c),emissiveIntensity:.25}));st.position.set(x,-.2,z);mob.add(st);});
    return;}
  const toddler=a<6,teen=a>=13,fb=k.fb&&a>=6,fit=fb?'kit':toddler?'peto':L.fit,hs=toddler?.5:.48,legH=toddler?.32:teen?.5:.42,top=fb?K.c1:toddler?'#f4f4f4':L.col;
  const legC=fb?K.c2:toddler?'#3b5a8a':fit==='chandal'?L.col:teen?'#2a2a33':'#4a6a9a';
  /* zapatillas con cordones o velcro; pantalón, chándal con banda o medias de fútbol */
  [-1,1].forEach(sd=>{const x=sd*.12;box(fig,.2,.1,.3,M(fb?'#1b1022':'#ffffff',{roughness:.4}),x,.05,.04);box(fig,.21,.03,.31,M(fb?'#C99BFF':L.col2),x,.02,.04);box(fig,.14,.025,.04,M(toddler?'#ffd84a':'#cfcfd6'),x,.09,.17);
    if(fb){box(fig,.18,legH*.5,.2,M(K.c2),x,.1+legH*.25,0);box(fig,.185,.12,.205,M('#e6e6ee'),x,.22,.01);}
    else{box(fig,.18,legH,.2,M(legC),x,.1+legH/2,0);if(fit==='chandal')box(fig,.02,legH,.21,M('#ffffff'),x+sd*.09,.1+legH/2,0);}});
  const hip=.1+legH;box(fig,.42,.14,.24,M(fb?'#1b1022':legC),0,hip,0);
  const T0=hip+.07,th=toddler?.38:.46;
  const tt=ptex(T,64,64,(g,W,Hh)=>{g.fillStyle=top;g.fillRect(0,0,W,Hh);
    if(toddler){g.fillStyle=L.col;for(let y=4;y<Hh;y+=10)g.fillRect(0,y,W,4);g.fillStyle='#3b5a8a';g.fillRect(12,26,40,38);g.fillRect(14,0,8,26);g.fillRect(42,0,8,26);g.fillStyle='#E8B83A';g.fillRect(16,22,4,4);g.fillRect(44,22,4,4);g.fillStyle='#2b4a7a';g.fillRect(24,36,16,12);}
    else if(fb){g.fillStyle=K.c2;g.fillRect(0,0,W,6);g.fillRect(26,0,12,10);g.fillRect(8,18,10,12);g.fillStyle=top;g.fillRect(10,20,6,8);}
    else if(fit==='camiseta'){g.fillStyle=shadeHex(top,-.25);g.fillRect(22,0,20,5);const c='#ffffff',P_={dino:[[18,30,22,10],[34,22,10,10],[20,40,4,8],[32,40,4,8]],cohete:[[28,16,8,26],[22,34,6,10],[36,34,6,10],[29,42,6,6]],estrella:[[28,16,8,30],[18,26,28,8],[22,20,20,20]],rayo:[[30,14,10,12],[24,24,14,6],[22,30,10,14]],balon:[[22,18,20,26],[18,22,28,18]]}[L.print];g.fillStyle=c;P_.forEach(([x,y,w,h])=>g.fillRect(x,y,w,h));if(L.print==='balon'){g.fillStyle='#1b1022';g.fillRect(28,26,8,8);}}
    else if(fit==='polo'){g.fillStyle='#ffffff';g.fillRect(16,0,14,8);g.fillRect(34,0,14,8);g.fillStyle=shadeHex(top,-.2);g.fillRect(30,0,4,22);g.fillStyle='#ffffff';g.fillRect(31,8,2,2);g.fillRect(31,15,2,2);g.fillStyle=L.col2;g.fillRect(44,16,6,6);}
    else if(fit==='chandal'){g.fillStyle='#c9c9d6';g.fillRect(30,0,4,Hh);g.fillStyle='#ffffff';g.fillRect(0,0,6,Hh);g.fillRect(58,0,6,Hh);g.fillStyle=shadeHex(top,-.25);g.fillRect(20,0,24,6);}
    else{g.fillStyle=shadeHex(top,-.2);g.fillRect(14,40,36,20);g.fillStyle='#ffffff';g.fillRect(24,0,2,18);g.fillRect(38,0,2,18);g.fillStyle=shadeHex(top,.35);g.font='bold 14px sans-serif';g.textAlign='center';g.fillText(teen?'PDH':'★',32,32);}});
  const bk=ptex(T,64,64,(g,W,Hh)=>{g.fillStyle=top;g.fillRect(0,0,W,Hh);if(fb){g.fillStyle=K.c2;g.font='900 34px Impact,sans-serif';g.textAlign='center';g.fillText(String((hsh(k.n)%30)+1),32,50);g.font='900 10px Impact,sans-serif';g.fillText(k.n.toUpperCase(),32,14);}
    else if(fit==='sudadera'){g.fillStyle=shadeHex(top,-.2);g.fillRect(0,0,W,12);}else if(fit==='chandal'){g.fillStyle='#ffffff';g.fillRect(0,0,6,Hh);g.fillRect(58,0,6,Hh);}});
  const ts=M(top),torso=new T.Mesh(new T.BoxGeometry(.46,th,.26),[ts,ts,ts,ts,M('#ffffff',{map:tt}),M('#ffffff',{map:bk})]);torso.position.set(0,T0+th/2,0);torso.name='chest';fig.add(torso);
  const longSl=fit==='sudadera'||fit==='chandal';
  [-1,1].forEach(sd=>{const arm=new T.Group();arm.position.set(sd*.32,T0+th-.04,0);arm.name=sd<0?'armL':'armR';fig.add(arm);box(arm,.15,th*.55,.17,ts,0,-th*.27,0);box(arm,.14,th*.4,.16,longSl?ts:skin,0,-th*.72,0);box(arm,.14,.1,.15,skin,0,-th*.97,0);
    if(fit==='chandal')box(arm,.02,th*.95,.18,M('#ffffff'),sd*.075,-th*.48,0);
    if(sd>0&&teen){box(arm,.04,.16,.09,M('#141018'),.08,-th*.97,.04);box(arm,.01,.13,.07,M('#6ab0ff',{emissive:new T.Color('#6ab0ff'),emissiveIntensity:.9}),.105,-th*.97,.04);}
    if(sd<0&&toddler){const bear=new T.Group();bear.position.set(-.05,-th-.04,.1);arm.add(bear);const bm=M('#a8743e',{roughness:.85});[[0,0,0,.08],[0,.11,0,.06],[-.05,.16,0,.025],[.05,.16,0,.025]].forEach(([x,y,z,r])=>{const s_=new T.Mesh(new T.SphereGeometry(r,10,8),bm);s_.position.set(x,y,z);bear.add(s_);});}});
  box(fig,.16,.08,.16,skin,0,T0+th+.03,0);const hd=headAt(T0+th+.07+hs/2,hs,false);hairOn(hd,hs,KHAIR[L.hair]);
  const capOk=!['Afro','Cresta','Moño samurái','Melena con cinta','Tupé'].includes(KHAIR[L.hair][0]);
  if(L.cap&&capOk&&!toddler&&!teen){box(fig,hs+.08,.1,hs+.06,M(L.col2),0,hd.position.y+hs/2+.08,0);box(fig,hs*.8,.03,.2,M(shadeHex(L.col2,-.25)),0,hd.position.y+hs/2+.04,-hs/2-.1);}
  if(teen){const hp=new T.Mesh(new T.TorusGeometry(.17,.02,6,20,Math.PI),M('#1b1022'));hp.position.set(0,T0+th+.03,0);hp.rotation.x=Math.PI/2;fig.add(hp);[-1,1].forEach(sd=>box(fig,.06,.1,.1,M('#1b1022'),sd*.17,T0+th+.02,0));}
  if(!toddler&&!teen&&!fb){box(fig,.36,.4,.14,M(shadeHex(L.col2,-.35),{roughness:.4}),0,T0+th/2+.02,-.21);box(fig,.3,.12,.03,M(shadeHex(L.col2,-.15)),0,T0+th/2-.05,-.29);[-1,1].forEach(sd=>box(fig,.04,.44,.04,M('#1b1022'),sd*.14,T0+th/2+.04,-.14));}
  if(fb||(!toddler&&!teen)){const bt=ptex(T,32,16,(g)=>{g.fillStyle='#ffffff';g.fillRect(0,0,32,16);g.fillStyle='#1b1022';[[4,4],[14,9],[24,3],[9,12]].forEach(([x,y])=>g.fillRect(x,y,4,4));});
    const ball=new T.Mesh(new T.IcosahedronGeometry(.13,1),M('#ffffff',{map:bt,roughness:.4}));ball.position.set(.32,.13,.32);ball.castShadow=true;fig.add(ball);}}

/* ---------- caras de la familia: un solo dibujo en una rejilla de 64×64 que sirve para el retrato y para el modelo 3D.
   px(x,y,w,h,color,opacidad) pinta un píxel o un bloque de la rejilla. ---------- */
const EYESH={almendra:[[3,6],[1,10],[0,12],[0,12],[1,10],[3,6]],redondos:[[2,8],[1,10],[0,12],[0,12],[0,12],[1,10],[2,8]],caidos:[[1,10],[0,12],[0,12],[1,10],[3,6]],rasgados:[[1,10],[0,12],[0,12],[2,8]],
  nino:[[2,8],[1,10],[0,12],[0,12],[0,12],[0,12],[1,10],[2,8]],bebe:[[3,6],[1,10],[0,12],[0,12],[0,12],[0,12],[0,12],[1,10],[3,6]]};
const EYEN=['almendra','redondos','caidos','rasgados'];
function faceArt(px,o){const sk=o.skin,dk=c=>shadeHex(sk,c),kid=o.kind!=='w',baby=o.kind==='b',ink='#1b1022';
  /* volumen de la cara: laterales, mandíbula y barbilla */
  px(0,0,64,64,sk);px(0,0,3,64,dk(-.1),.6);px(61,0,3,64,dk(-.1),.6);px(0,58,64,6,dk(-.1),.5);px(0,54,4,10,dk(-.18),.6);px(60,54,4,10,dk(-.18),.6);
  px(26,57,12,3,dk(.1),.6);px(10,35,7,3,dk(.14),.55);px(47,35,7,3,dk(.14),.55);px(4,4,56,3,dk(.06),.4);
  /* ojos */
  const shape=EYESH[baby?'bebe':kid?(o.eyeS%2?'almendra':'nino'):EYEN[o.eyeS%4]],eh=shape.length,ey=baby?27:kid?27:28,gaze=o.gaze||0;
  [[14,0],[38,1]].forEach(([ex,mir])=>{const X=(x,w)=>mir?ex+12-x-w:ex+x;
    if(!baby&&o.eyeS%4!==3)px(X(2,8),ey-3,8,1,dk(-.18),.7);
    if(o.shadow)px(X(1,10),ey-2,10,2,o.shadow,.45);
    shape.forEach(([s,l],r)=>px(X(s,l),ey+r,l,1,'#f8f4f0'));
    const ir=baby||kid?4:3,cx=ex+6+gaze,cy=ey+Math.floor(eh/2);
    shape.forEach(([s,l],r)=>{const y=ey+r,dy=Math.abs(y+.5-cy);if(dy>ir)return;const half=Math.round(Math.sqrt(ir*ir-dy*dy)),x0=Math.max(cx-half,X(s,l)),x1=Math.min(cx+half,X(s,l)+l);if(x1>x0)px(x0,y,x1-x0,1,r===0?shadeHex(o.eye,-.35):o.eye);});
    px(cx-1,cy-1,2,baby?3:2,'#120a14');px(cx-2,cy-2,2,2,'#ffffff');px(cx+1,cy+1,1,1,'#ffffff',.8);
    /* párpado, pestañas, raya y línea inferior */
    const lidW=o.eyeS%4===2?2:1;px(X(1,10),ey-lidW,10,lidW,ink,.9);px(X(0,2),ey,2,1,ink,.6);
    if(!kid){px(X(10,3),ey-2,3,1,ink);px(X(12,1),ey-3,1,1,ink);px(X(8,1),ey-2,1,1,ink);if(o.liner){px(X(11,3),ey-3,3,1,ink);px(X(13,2),ey-4,2,1,ink);}}
    else if(!baby)px(X(10,2),ey-1,2,1,ink,.7);
    px(X(2,8),ey+eh,8,1,dk(-.25),.35);
    /* cejas */
    if(!baby){const bc=o.brow,by=ey-7,b=o.browC;
      if(bc===0){px(X(0,4),by+1,4,1,b);px(X(4,4),by,4,1,b);px(X(8,3),by,3,1,b);px(X(11,2),by+1,2,1,b);}
      else if(bc===1){px(X(-1,13),by,13,2,b);px(X(11,2),by+2,2,1,b,.8);}
      else if(bc===2){px(X(0,12),by+1,12,2,b,.85);px(X(3,7),by,7,1,b,.7);}
      else{px(X(0,3),by+2,3,1,b);px(X(2,4),by,4,2,b);px(X(6,4),by-1,4,2,b);px(X(10,3),by,3,1,b);}}});
  /* nariz: puente con brillo, sombra lateral, punta y aletas */
  const nw=o.nose||0,ny=baby?40:kid?39:38;
  if(baby){px(29,ny,6,3,dk(.08));px(29,ny+3,2,1,dk(-.3),.5);px(33,ny+3,2,1,dk(-.3),.5);}
  else{px(31,ny-8,2,9,dk(.12),.6);px(34,ny-7,1,9,dk(-.25),.35);px(28-nw,ny+1,8+nw*2,3,dk(.07));px(27-nw,ny+4,3,1,dk(-.35),.55);px(34+nw,ny+4,3,1,dk(-.35),.55);px(29,ny+5,6,1,dk(-.2),.3);}
  /* colorete y pecas */
  px(7,40,10,5,o.blushC||'#ff6f8a',kid?.32:.22);px(47,40,10,5,o.blushC||'#ff6f8a',kid?.32:.22);
  if(o.freck)[[14,38],[17,40],[20,37],[22,40],[42,37],[45,40],[48,38],[50,41],[30,34],[33,35]].forEach(([x,y])=>px(x,y,1,1,dk(-.35),.75));
  if(o.mole)px(45,47,2,2,'#4a2a20');
  /* boca */
  const my=baby?47:kid?48:48,L1=o.lip,LD=shadeHex(L1,-.35),LL=shadeHex(L1,.3);
  if(baby){px(25,my-1,14,7,'#7fc8ff');px(28,my+1,8,3,'#ffffff');px(30,my+6,4,3,'#7fc8ff');}
  else if(!kid){const m=o.mouth%3;
    px(25,my,5,1,L1);px(34,my,5,1,L1);px(24,my+1,16,1,L1);px(31,my,2,1,dk(.05));
    if(m===1){px(25,my+2,14,2,'#fbf7f0');px(23,my+2,1,2,LD);px(40,my+2,1,2,LD);px(24,my+4,16,1,LD);px(25,my+5,14,1,L1);px(27,my+6,10,1,L1);px(29,my+5,5,1,LL);}
    else{px(23,my+2,18,1,LD);if(m===0){px(22,my+1,1,1,LD);px(41,my+1,1,1,LD);}px(24,my+3,16,2,L1);px(26,my+5,12,1,L1);px(28,my+3,6,1,LL);}
    px(27,my+8,10,1,dk(-.15),.35);}
  else{const m=o.mouth%4,D='#6a2430';
    if(m===0){px(23,my-1,2,1,D);px(25,my,14,2,D);px(39,my-1,2,1,D);px(27,my,10,1,'#ffffff');px(29,my+1,6,1,'#e0607a');}
    else if(m===1){px(23,my-1,1,1,D);px(24,my,16,3,D);px(40,my-1,1,1,D);px(25,my,6,1,'#ffffff');px(33,my,6,1,'#ffffff');}
    else if(m===2){px(26,my,12,1,D);px(25,my-1,1,1,D);px(38,my-1,1,1,D);}
    else{px(28,my-1,8,6,D);px(28,my-1,8,1,'#ffffff');px(29,my+3,6,2,'#e0607a');}
    if(o.dimple){px(21,my,1,2,dk(-.25),.5);px(42,my,1,2,dk(-.25),.5);}}
  /* gafas */
  if(o.glass&&!baby){[[11,0],[37,1]].forEach(([x])=>{px(x,ey-3,16,1,ink);px(x,ey+eh+1,16,1,ink);px(x,ey-3,1,eh+5,ink);px(x+15,ey-3,1,eh+5,ink);px(x+1,ey-2,14,eh+3,'#9fc8ff',.12);});px(27,ey,10,1,ink);px(0,ey-1,11,1,ink);px(53,ey-1,11,1,ink);}}
const faceSvg=(o,x0,y0,size)=>{const s=size/64;let out='';faceArt((x,y,w,h,c,a)=>{out+=R_((x0+x*s).toFixed(2),(y0+y*s).toFixed(2),(w*s+.05).toFixed(2),(h*s+.05).toFixed(2),c,a!=null&&a<1?` opacity="${a}"`:'');},o);return out;};
const faceTex=(T,o)=>ptex(T,64,64,(g)=>faceArt((x,y,w,h,c,a)=>{g.globalAlpha=a==null?1:a;g.fillStyle=c;g.fillRect(x,y,w,h);},o));
function partnerFace(L){const hc=WHC[L.hairc];return{kind:'w',skin:SKIN[L.skin],eye:PEYE[L.eye],lip:PLIP[L.lip],browC:shadeHex(hc,L.hairc>=10?-.55:-.3),eyeS:L.eyeS,brow:L.brow,mouth:L.mouth,nose:L.nose,liner:L.liner,shadow:L.shadow,mole:L.mole,freck:L.freck,glass:L.glass,blushC:'#ff6f8a'};}
function kidFace(k,L){const a=kidAge(k);return{kind:a<2?'b':'k',skin:SKIN[L.skin],eye:PEYE[L.eye],lip:'#c24a5a',browC:shadeHex(kidHairC(k,L),-.3),eyeS:L.eyeS,brow:L.brow,mouth:L.mouth,nose:L.nose,freck:L.freck,dimple:L.dimple,glass:L.glass&&a>=2,blushC:'#ff6f8a'};}

/* ---------- tu casa por dentro: salón (según el nivel de la casa) y garaje con tus coches ---------- */
function housePanel(){if(!hasHome())return'';const L=homeLevel(P.home);
  return `<div class="j-panel j-v3"><h3>Tu casa por dentro</h3>${v3Box('house',340,'El interior de tu casa en 3D')}<div class="j-acts" style="margin-top:10px"><button class="btn small" data-act="jHouseView" data-k="salon">Salón</button><button class="btn small" data-act="jHouseView" data-k="garaje">Garaje</button></div>
  <p class="j-hint">${L>=13?'Un salón de revista: domótica, chimenea y vistas.':L>=6?'Cada mejora de la casa se nota también dentro.':'Una casa sencilla. Mejora la estructura, la fachada y la tecnología para amueblarla mejor.'} ${P.pet?`${esc(P.pet.n)} vive aquí contigo.`:''}</p></div>`;}
function buildHouse(T,V){const sc=V.scene,h=P.home.parts,L=homeLevel(P.home),tier=L>=13?2:L>=6?1:0,Mt=(c,o={})=>new T.MeshStandardMaterial({color:new T.Color(c),roughness:.75,...o});
  const glow=(c,i=1.2)=>new T.MeshStandardMaterial({color:new T.Color(c),emissive:new T.Color(c),emissiveIntensity:i,roughness:.4});
  sc.background=new T.Color('#0c0618');sc.add(new T.HemisphereLight(0xfff2e6,0x2a1a3a,.7));const sun=new T.DirectionalLight(0xffe6c8,.8);sun.position.set(-4,8,8);sun.castShadow=true;sun.shadow.mapSize.set(1024,1024);Object.assign(sun.shadow.camera,{left:-14,right:24,top:12,bottom:-12});sc.add(sun);
  const add=(geo,m,x,y,z,g=sc)=>{const o=new T.Mesh(geo,m);o.position.set(x,y,z);o.castShadow=o.receiveShadow=true;g.add(o);return o;},bx=(w,hh,d,m,x,y,z,g)=>add(new T.BoxGeometry(w,hh,d),m,x,y,z,g);
  /* salón */
  const wood=stripes(T,['#8a6a4a','#a07a52','#3a2a22'][tier],['#7d5f42','#93704b','#33251e'][tier],6);wood.repeat.set(6,1);
  const fl=add(new T.PlaneGeometry(14,10),Mt('#ffffff',{map:wood,roughness:tier===2?.25:.6}),0,0,0);fl.rotation.x=-Math.PI/2;
  const wcol=['#d8cfc2','#efe9df','#cbb79a','#f2f2f0'][h.fachada||0],wall=Mt(wcol,{roughness:.9});
  bx(14,4,.2,wall,0,2,-5);bx(.2,4,10,wall,-7,2,0);
  const win=new T.MeshStandardMaterial({color:'#9fc4e8',emissive:new T.Color(h.piscina?'#3ab8e0':'#ffcf9a'),emissiveIntensity:.55,roughness:.05,transparent:true,opacity:.85});
  if(tier===2)bx(8,3.2,.08,win,1,1.9,-4.88);else{bx(2.2,1.6,.08,win,-2.6,2.1,-4.88);bx(2.2,1.6,.08,win,2.2,2.1,-4.88);}
  if(tier>=1){const rug=add(new T.PlaneGeometry(5,3.2),Mt(tier===2?'#3b2a5a':'#7a5a8a',{roughness:1}),-.5,.01,.4);rug.rotation.x=-Math.PI/2;}
  /* sofá */
  const sofaC=['#6b4a3a','#5d6370','#efeee9'][tier],sofa=Mt(sofaC,{roughness:.95}),cush=Mt(tier===2?'#B57BFF':'#8a8f9a');
  const sw=[2.6,3.6,4.2][tier];bx(sw,.5,1.1,sofa,-.5,.35,1.9);bx(sw,.9,.3,sofa,-.5,.75,2.4);[-1,1].forEach(s=>bx(.3,.7,1.1,sofa,-.5+s*(sw/2-.15),.5,1.9));
  if(tier===2){bx(1.1,.5,2.4,sofa,-.5-sw/2+.55,.35,.4);}[-1,0,1].slice(0,tier+1).forEach(i=>bx(.6,.45,.15,cush,-.5+i*1.1,.8,2.2));
  bx(1.6,.08,.9,Mt(tier===2?'#1a1a1f':'#7a5a3e',{roughness:.3}),-.5,.45,.3);[-.7,.7].forEach(x=>bx(.06,.4,.06,Mt('#333'),-.5+x,.22,.3));
  /* tele */
  const tvW=[1.4,2.6,4][tier];bx(tvW+.6,.5,.5,Mt('#2a2a30'),-.5,.25,-4.5);const tv=bx(tvW,tvW*.56,.08,glow('#2b3a8a',.6),-.5,1.1+tvW*.18,-4.75);
  if(tier===2)bx(tvW+.3,.05,.05,glow('#B57BFF',2),-.5,.62,-4.72);
  /* estantería con mini trofeos */
  bx(2.6,2.2,.4,Mt('#4a3428'),-5.2,1.1,-4.6);[0,1,2].forEach(i=>bx(2.5,.05,.38,Mt('#6a4e3a'),-5.2,.45+i*.7,-4.55));
  const tr=Math.min(8,P.titles.length+P.awards.filter(a=>a.n==='Balón de Oro').length),gold=Mt('#E8B83A',{metalness:1,roughness:.25});
  for(let i=0;i<tr;i++){const x=-6.2+(i%4)*.62,y=.48+Math.floor(i/4)*.7;add(new T.CylinderGeometry(.08,.05,.28,10),gold,x,y+.14,-4.5);add(new T.SphereGeometry(.09,10,8),gold,x,y+.32,-4.5);}
  /* plantas, lámpara, chimenea y domótica según la casa */
  if((h.jardin||0)>=1)[[-6.3,-3.4],[5.6,-4.3],[-6.3,3.6]].slice(0,1+tier).forEach(([x,z])=>{add(new T.CylinderGeometry(.25,.2,.45,10),Mt('#b0866a'),x,.22,z);add(new T.IcosahedronGeometry(.45,0),Mt('#3f8a4f',{roughness:.9}),x,.85,z);});
  add(new T.CylinderGeometry(.03,.03,1.8,6),Mt('#333'),2.6,.9,2.4);add(new T.ConeGeometry(.3,.35,12,1,true),Mt('#f2e6d0',{side:T.DoubleSide}),2.6,1.85,2.4);const lp=new T.PointLight(0xffd9a8,.8,7);lp.position.set(2.6,1.7,2.4);sc.add(lp);
  if(tier===2){bx(2.2,1.4,.5,Mt('#2b2e33',{roughness:.4}),4.2,.7,-4.7);bx(1.4,.5,.1,glow('#ff8a3a',2.2),4.2,.55,-4.42);const fp=new T.PointLight(0xff8a3a,.9,6);fp.position.set(4.2,.8,-3.9);sc.add(fp);}
  if((h.tecnologia||0)>=3){bx(13.6,.05,.05,glow('#B57BFF',2),0,3.9,-4.88);bx(.05,.05,9.6,glow('#B57BFF',2),-6.88,3.9,0);}
  if((h.tecnologia||0)>=2)add(new T.CylinderGeometry(.09,.09,.22,12),glow('#7bff9a',.8),1,.6,.3);
  /* familia y mascota */
  const fig=(Lk,x,z,ry,s)=>{const o=new T.Group(),inn=new T.Group();o.add(inn);buildFigure(T,inn,Lk);inn.traverse(q=>{if(q.isMesh)q.castShadow=true;});o.scale.setScalar(s);o.position.set(x,0,z);o.rotation.y=ry;sc.add(o);return{o,inn};};
  const casual=(c1,c2)=>({s:c1,t:c2,p:'#2a2a33',m:'#f2f2f2'}),F=fam(),fs=[];
  fs.push(fig({...P,kitC:casual('#3a2a5a','#C99BFF'),last:'',num:''},1.6,.9,-.5,.85));
  const figB=(b,x,z,ry,s)=>{const o=new T.Group(),inn=new T.Group();o.add(inn);b(inn);inn.traverse(q=>{if(q.isMesh)q.castShadow=true;});o.scale.setScalar(s);o.position.set(x,0,z);o.rotation.y=ry;sc.add(o);return{o,inn};};
  if(F.partner)fs.push(figB(g=>buildPartner(T,g,F),2.4,1.6,-.8,.82));
  F.kids.slice(0,3).forEach((k,i)=>{const a=kidAge(k);fs.push(figB(g=>buildKid(T,g,k),-2.8+i*1.4,a<2?-2.2:-1,a<2?0:.3,a<2?.75:a<6?.7:a<13?.8:.92));});
  let pet=null;if(P.pet){petMesh(T,sc,P.pet.k);pet=sc.getObjectByName('pet');if(pet)pet.scale.setScalar(1.2);}
  /* garaje con tus coches, tras una pared de cristal */
  const gfl=add(new T.PlaneGeometry(16,10),Mt('#4a4a52',{roughness:.6}),15,0,0);gfl.rotation.x=-Math.PI/2;
  bx(.12,4,10,new T.MeshStandardMaterial({color:'#cfe2ff',transparent:true,opacity:.18,roughness:.05}),7.05,2,0);bx(16,4,.2,Mt('#3a3a42'),15,2,-5);bx(.2,4,10,Mt('#3a3a42'),23,2,0);
  [11,15,19].forEach(x=>{bx(1.8,.05,.4,new T.MeshBasicMaterial({color:'#fff6e6'}),x,3.95,0);const l=new T.PointLight(0xffffff,.6,9);l.position.set(x,3.6,0);sc.add(l);});
  const gg=new T.Group();gg.position.set(15.3,-.2,-7.4);sc.add(gg);if((P.cars||[]).length)homeCars(T,gg,(c,o={})=>Mt(c,o),glow,P.cars);
  else{const pt=pixTex(T,128,32,g=>{g.fillStyle='#14141a';g.fillRect(0,0,128,32);g.fillStyle='#C99BFF';g.font='bold 13px sans-serif';g.textAlign='center';g.fillText('GARAJE VACÍO',64,20);});pt.magFilter=T.LinearFilter;bx(3,.75,.04,new T.MeshBasicMaterial({map:pt}),15,2,-4.88);}
  V.view=V.view||'salon';const cp=new T.Vector3(),lk=new T.Vector3();
  return ms=>{const t=ms/1000;if(pet){const a=t*.5,dx=-Math.sin(a)*1.6,dz=Math.cos(a)*1.1;pet.position.set(-.5+Math.cos(a)*1.6,0,-.6+Math.sin(a)*1.1);pet.rotation.y=Math.atan2(-dz,dx);}
    fs.forEach((f,i)=>{const mb=f.inn.getObjectByName('mobile');if(mb){mb.rotation.y=t*.6;return;}f.inn.position.y=Math.abs(Math.sin(t*1.3+i))*.015;});
    const g=V.view==='garaje',a=clamp(V.rot,-.7,.7);cp.set((g?15:0)+Math.sin(a)*8,g?4.6:6,(g?6:7.2)+Math.cos(a)*1.5);lk.set(g?15:-.3,1,-1.2);
    V.cam.position.lerp(cp,ms?.06:1);V.cam.lookAt(lk);};}

Object.assign(ACT,{
  jTalkPre(d){const m=mister(),cap=P.captain?2:1;if(talkNow()||!m)return;P.talk={w:P.week,s:P.season,k:d.k};
    if(d.k==='motivar'){P.chem=clamp(P.chem+2*cap,0,100);P.mor=clamp(P.mor+2,0,100);if(m.k==='Motivador')m.rel+=1.5;}
    else if(d.k==='conc'){if(m.k==='Táctico'||m.k==='Exigente')m.rel+=1.5;}
    else{P.mor=clamp(P.mor+3,0,100);P.chem=clamp(P.chem+cap,0,100);if(m.k==='Exigente')m.rel-=2;else if(m.k==='Motivador')m.rel+=1;}
    m.rel=clamp(m.rel,0,100);save();rr();},
  jHouseView(d){if(V3.house)V3.house.view=d.k;},
});
const css6=document.createElement('style');css6.textContent=`.j-mst{display:flex;gap:12px;align-items:center;margin-bottom:10px}.j-mst svg{border-radius:10px}.j-mst small{display:block;color:var(--muted);font-size:12.5px;margin-top:2px}`;document.head.appendChild(css6);

/* ====== competiciones reales: copa nacional, Champions / Europa League / Conference con fase de liga,
   Nations League en los parones, Mundial / Eurocopa / Copa América en verano y Mundial de Clubes cada 4 años.
   El calendario es una lista de partidos: entre semana (sl 0) y fin de semana (sl 1); P.fx apunta al siguiente. ====== */
const COPAN={'España':'Copa del Rey','Inglaterra':'FA Cup','Italia':'Coppa Italia','Alemania':'DFB-Pokal','Francia':'Coupe de France','Portugal':'Taça de Portugal','Países Bajos':'KNVB Beker','Bélgica':'Copa de Bélgica','Escocia':'Scottish Cup','Turquía':'Copa de Turquía','Argentina':'Copa Argentina','Brasil':'Copa do Brasil','México':'Copa MX','Estados Unidos':'US Open Cup','Colombia':'Copa Colombia','Arabia Saudí':'Copa del Rey de Campeones','Japón':'Copa del Emperador'};
const TOP5=['España','Inglaterra','Italia','Alemania','Francia'];
const UEFAC=c=>(NAT[c]||[])[1]==='UEFA';
const CN={ucl:'Champions League',uel:'Europa League',uecl:'Conference League',cwc:'Mundial de Clubes'};
/* las rondas de copa ('c:Nombre') llevan su nombre dentro: así sobreviven a recargar la página */
const STN=new Proxy({lp:'Fase de liga',po:'Playoff',r64:'Treintaidosavos',r32:'Dieciseisavos',r16:'Octavos',qf:'Cuartos',sf:'Semifinales',f:'Final',grp:'Fase de grupos'},{get:(o,k)=>k in o?o[k]:typeof k==='string'&&k.startsWith('c:')?k.slice(2):undefined});
const EUWK={lp:[3,5,8,11,13,16,18,21],po:[23,24],r16:[25,26],qf:[29,31],sf:[32,33],f:{ucl:37,uel:36,uecl:35}};
const CUPWK=[[2,'r64'],[7,'r32'],[14,'r16'],[19,'qf'],[27,'sf',1],[28,'sf',2],[34,'f']];
const SELWK=[10,20,30];
const fem=n=>/^(Copa|Eurocopa|Nations)/.test(n),elN=n=>(fem(n)?'la ':'el ')+n,deN=n=>(fem(n)?'de la ':'del ')+n,alN=n=>(fem(n)?'a la ':'al ')+n;
const isNat=e=>!!e&&['sel','natT','nlf'].includes(e.type);
const teamFx=e=>!!e&&(['copa','eur','cwc','sup'].includes(e.type)||(e.type==='liga'&&P.squad!=='cantera'));
const leagueGames=()=>Math.max(1,(P.cal||[]).filter(e=>e.type==='liga'&&e.w<=38).length);
const ent=x=>x&&(x.id||x.n);
const entStr=x=>CLUBS[x]?clubStr(x):(NAT[x]?NAT[x][0]:70);
function stName(e){if(!e)return'';const b=e.st==='lp'||e.st==='grp'?`${STN[e.st]} · J${e.md}`:STN[e.st]||'';return b+(e.leg===1?' (ida)':e.leg===2?' (vuelta)':'');}
function euroFor(cid){const k=club(cid),ctry=LG[k.league].country;if(k.tier>0||!UEFAC(ctry))return null;
  if(P.qual&&P.qual.club===cid&&P.qual.s===P.season)return P.qual.comp;
  const ids=LG[k.league].pyr[0].slice().sort((a,b)=>clubStr(b)-clubStr(a)),r=ids.indexOf(cid)+1;
  return TOP5.includes(ctry)?(r<=4?'ucl':r===5?'uel':r===6?'uecl':null):(r===1?'ucl':r===2?'uel':r===3?'uecl':null);}
function euroPool(eu){const k=club(P.club),[lo,hi]={ucl:[74,99],uel:[66,82],uecl:[56,75]}[eu];
  const p=ALL().filter(x=>x.tier===0&&x.id!==P.club&&x.league!==k.league&&UEFAC(LG[x.league].country)&&x.base>=lo&&x.base<=hi).map(x=>x.id).sort(()=>Math.random()-.5);return p.slice(0,35);}
function nlSetup(){const n=P.nat,lv=(NAT[n]||[80])[0],cf=(NAT[n]||[0,'UEFA'])[1],uefa=cf==='UEFA';
  const pool=Object.keys(NAT).filter(x=>x!==n&&(uefa?NAT[x][1]==='UEFA':NAT[x][1]===cf)).sort((a,b)=>Math.abs(NAT[a][0]-lv)-Math.abs(NAT[b][0]-lv));
  const riv=pool.slice(0,6).sort(()=>Math.random()-.5).slice(0,3);while(riv.length<3){const x=pk(Object.keys(NAT).filter(y=>y!==n&&!riv.includes(y)));riv.push(x);}
  P.comp.nl={key:'nl',name:uefa?'Nations League':'Eliminatorias del Mundial',uefa,nat:true,alive:true,res:[],grp:[{n,p:0,gd:0,me:1},...riv.map(r=>({n:r,p:0,gd:0}))],gN:0,gT:6,gRR:2};
  return[[riv[0],1],[riv[1],0],[riv[2],1],[riv[0],0],[riv[1],1],[riv[2],0]];}
/* formato real de la copa de cada liga: [ronda, partidos, sede neutral]; e = ronda de entrada por categoría; low = el de menor categoría juega en casa */
const CUPF={laliga:{v:'La Cartuja (Sevilla)',low:1,r:[['Primera ronda',1],['Segunda ronda',1],['Dieciseisavos',1],['Octavos',1],['Cuartos',1],['Semifinal',2],['Final',1,1]],e:[0,0,0,0]},
  premier:{v:'Wembley',r:[['Primera ronda',1],['Segunda ronda',1],['Tercera ronda',1],['Cuarta ronda',1],['Quinta ronda',1],['Cuartos',1],['Semifinal',1,1],['Final',1,1]],e:[2,2,0,0]},
  seriea:{v:'Estadio Olímpico (Roma)',r:[['Treintaidosavos',1],['Dieciseisavos',1],['Octavos',1],['Cuartos',1],['Semifinal',2],['Final',1,1]],e:[0,0,0,0]},
  bundesliga:{v:'Olympiastadion (Berlín)',low:1,r:[['Primera ronda',1],['Segunda ronda',1],['Octavos',1],['Cuartos',1],['Semifinal',1],['Final',1,1]],e:[0,0,0,0]},
  ligue1:{v:'Stade de France',low:1,r:[['Treintaidosavos',1],['Dieciseisavos',1],['Octavos',1],['Cuartos',1],['Semifinal',1],['Final',1,1]],e:[0,0,0,0]},
  argentina:{v:'sede neutral',all:1,r:[['Treintaidosavos',1],['Dieciseisavos',1],['Octavos',1],['Cuartos',1],['Semifinal',1],['Final',1]],e:[0,0,0,0]},
  brasil:{r:[['Tercera fase',2],['Octavos',2],['Cuartos',2],['Semifinal',2],['Final',2]],e:[0,0,0,0]},
  mls:{r:[['Dieciseisavos',1],['Octavos',1],['Cuartos',1],['Semifinal',1],['Final',1]],e:[0]},
  saudi:{v:'Yeda',r:[['Dieciseisavos',1],['Octavos',1],['Cuartos',1],['Semifinal',1],['Final',1,1]],e:[0]},
  mexico:{r:[['Octavos',1],['Cuartos',1],['Semifinal',1],['Final',1]],e:[0,0,0,0]},
  colombia:{r:[['Primera fase',2],['Octavos',2],['Cuartos',2],['Semifinal',2],['Final',2]],e:[1,0,0,0]}};
const CUPSL=[2,7,9,12,14,19,22,27,28,34];
const SUPNM={laliga:'Supercopa de España',premier:'Community Shield',seriea:'Supercoppa Italiana',bundesliga:'DFL-Supercup',ligue1:'Trophée des Champions',argentina:'Supercopa Argentina',brasil:'Supercopa do Brasil',mls:'Campeones Cup',saudi:'Supercopa Saudí',mexico:'Campeón de Campeones',colombia:'Superliga BetPlay'};
const SUP4={laliga:'Riad',seriea:'Riad',saudi:'Yeda'};
/* competición continental fuera de Europa: liga → [competición, plazas] */
const CONTL={brasil:['lib',6],argentina:['lib',5],colombia:['lib',3],mls:['ccc',6],mexico:['ccc',6],saudi:['acl',3]};
const CONTP={lib:['brasil','argentina','colombia'],ccc:['mls','mexico'],acl:['saudi']};
Object.assign(CN,{lib:'Copa Libertadores',ccc:'Concacaf Champions Cup',acl:'AFC Champions League Elite'});
const tier0By=lg=>LG[lg].pyr[0].slice().sort((a,b)=>clubStr(b)-clubStr(a));
/* temporada anterior del club (para supercopas): lo vivido con tu club o, si no, por nivel de plantilla */
function prevHon(cid){const k=club(cid),q=P.prevS&&P.prevS.club===cid&&P.prevS.s===P.season?P.prevS:null;
  if(q)return q;const r=tier0By(k.league).indexOf(cid)+1;return{pos:r||99,cupW:false,cupF:false,ucl:false};}
function supFor(cid){const k=club(cid);if(k.tier>0||!SUPNM[k.league])return null;const h=prevHon(cid);
  const four=!!SUP4[k.league],ok=four?(h.pos<=2||h.cupW||h.cupF):(h.pos===1||h.cupW||(h.pos===2&&!P.prevS));return ok?{four}:null;}
function contFor(cid){const k=club(cid),c=CONTL[k.league];if(!c||k.tier>0)return null;
  if(P.qual&&P.qual.club===cid&&P.qual.s===P.season)return P.qual.comp;const r=tier0By(k.league).indexOf(cid)+1;return r&&r<=c[1]?c[0]:null;}
function contPool(key){const k=club(P.club),lgs=CONTP[key],own=k.league;
  return lgs.flatMap(l=>tier0By(l).slice(0,10)).filter(id=>id!==P.club&&(lgs.length===1||club(id).league!==own)).sort(()=>Math.random()-.5);}
/* liga a doble vuelta: cada rival dos veces; si no caben en los fines de semana, alguna jornada entre semana */
function leagueSched(cal){const c=club(P.club),ids=LG[c.league].pyr[c.tier].slice().sort(()=>Math.random()-.5);if(ids.length%2)ids.push(null);
  const n=ids.length,half=[];for(let r=0;r<n-1;r++){for(let i=0;i<n/2;i++){const x=ids[i],y=ids[n-1-i];if(x===P.club||y===P.club){const o=x===P.club?y:x;half.push(o?{opp:o,home:(r%2===0)===(x===P.club)}:null);}}ids.splice(1,0,ids.pop());}
  let rounds=[...half,...half.map(x=>x&&{opp:x.opp,home:!x.home})];const wk=[];for(let w=1;w<=38;w++)if(!SELWK.includes(w))wk.push(w);
  let slots=wk.map(w=>({w,sl:1}));const used=new Set(cal.filter(e=>e.sl===0).map(e=>e.w));
  if(rounds.length<slots.length){let k=slots.length-rounds.length;[19,37,18,36,17,35].forEach(w=>{if(k>0){slots=slots.filter(s=>s.w!==w);cal.push({w,sl:1,type:'libre'});k--;}});}
  else if(rounds.length>slots.length){const cand=wk.filter(w=>w>2&&w<38&&!used.has(w)),need=rounds.length-slots.length;
    for(let i=0;i<need&&cand.length;i++)slots.push({w:cand.splice(Math.min(cand.length-1,Math.floor((i+.5)*cand.length/need)),1)[0],sl:0});
    slots.sort((a,b)=>a.w-b.w||a.sl-b.sl);rounds=rounds.slice(0,slots.length);}
  slots.forEach((s,i)=>{const x=rounds[i];if(x)cal.push({w:s.w,sl:s.sl,type:'liga',opp:x.opp,home:x.home});else if(s.sl===1)cal.push({w:s.w,sl:1,type:'libre'});});}
function buildCal(){const c=club(P.club),ctry=LG[c.league].country,cal=[],div=LG[c.league].pyr[c.tier].filter(i=>i!==P.club);P.comp={};
  const sup=supFor(P.club);if(sup){const nm=SUPNM[c.league];P.comp.sup={key:'sup',name:nm,alive:true,res:[],used:[]};
    if(sup.four){cal.push({w:15,sl:0,type:'sup',comp:'sup',st:'sf',ko:true,leg:0,neutral:true,home:true},{w:17,sl:0,type:'sup',comp:'sup',st:'f',ko:true,leg:0,neutral:true,home:true});}
    else cal.push({w:1,sl:0,type:'sup',comp:'sup',st:'f',ko:true,leg:0,neutral:true,home:true});}
  if(c.tier===0&&UEFAC(ctry)&&P.prevS&&P.prevS.club===P.club&&P.prevS.s===P.season&&P.prevS.ucl){P.comp.usc={key:'usc',name:'Supercopa de Europa',alive:true,res:[],used:[]};cal.push({w:4,sl:0,type:'sup',comp:'usc',st:'f',ko:true,leg:0,neutral:true,home:true});}
  const F=CUPF[c.league];P.comp.copa={key:'copa',name:COPAN[ctry]||'Copa',alive:true,res:[],low:!!(F&&F.low),v:F&&F.v};
  if(F){let e0=(F.e||[])[c.tier]??0;if(c.league==='laliga'&&sup&&sup.four)e0=2;if(c.league==='seriea'&&c.tier===0&&tier0By('seriea').indexOf(P.club)<8)e0=2;
    const rd=F.r.slice(Math.min(e0,F.r.length-1)),L=rd.reduce((a,r)=>a+r[1],0),sl=CUPSL.slice(-L);let k=0;
    rd.forEach(([n,legs,neu],ci)=>{const st=ci===rd.length-1?'f':'c:'+n;STN[st]=STN[st]||n;
      for(let l=0;l<legs;l++)cal.push({w:sl[k++],sl:0,type:'copa',comp:'copa',st,ci,cn:rd.length,ko:true,leg:legs===2?l+1:0,home:legs===2?l===1:ch(.5),neutral:legs===1&&(!!neu||!!F.all)});});}
  else CUPWK.forEach(([w,st,leg])=>{if(st==='r64'&&c.tier===0)return;if(leg===2)return;cal.push({w,sl:0,type:'copa',comp:'copa',st,ko:true,leg:0,home:st==='f'?false:ch(.5),neutral:st==='f'});});
  const eu=euroFor(P.club);if(eu){const lpT=eu==='uecl'?6:8,pool=euroPool(eu);P.comp[eu]={key:eu,name:CN[eu],alive:true,res:[],pts:0,gd:0,lpN:0,lpT,pool,avgB:avg(pool.map(clubStr))||75};
    EUWK.lp.slice(0,lpT).forEach((w,i)=>cal.push({w,sl:0,type:'eur',comp:eu,st:'lp',md:i+1,home:i%2===0}));
    [['po',EUWK.po],['r16',EUWK.r16],['qf',EUWK.qf],['sf',EUWK.sf]].forEach(([st,ws])=>ws.forEach((w,i)=>cal.push({w,sl:0,type:'eur',comp:eu,st,ko:true,leg:i+1,home:i===1})));
    cal.push({w:EUWK.f[eu],sl:0,type:'eur',comp:eu,st:'f',ko:true,leg:0,home:false,neutral:true});}
  const co=!eu&&contFor(P.club);if(co){const pool=contPool(co),C=P.comp[co]={key:co,name:CN[co],alive:true,res:[],pool,avgB:avg(pool.map(clubStr))||72};
    if(co==='lib'){C.grp=[{id:P.club,p:0,gd:0,me:1},...pool.slice(0,3).map(id=>({id,p:0,gd:0}))];C.gN=0;C.gT=6;C.gRR=2;C.pool=pool.slice(3);EUWK.lp.slice(0,6).forEach((w,i)=>cal.push({w,sl:0,type:'eur',comp:co,st:'grp',md:i+1,home:i%2===0}));}
    if(co==='acl'){C.pts=0;C.gd=0;C.lpN=0;C.lpT=8;EUWK.lp.forEach((w,i)=>cal.push({w,sl:0,type:'eur',comp:co,st:'lp',md:i+1,home:i%2===0}));}
    (co==='acl'?[['r16',EUWK.r16]]:[['r16',EUWK.r16],['qf',EUWK.qf],['sf',EUWK.sf]]).forEach(([st,ws])=>ws.forEach((w,i)=>cal.push({w,sl:0,type:'eur',comp:co,st,ko:true,leg:i+1,home:i===1})));
    if(co==='acl')[['qf',29],['sf',32]].forEach(([st,w])=>cal.push({w,sl:0,type:'eur',comp:co,st,ko:true,leg:0,neutral:true,home:true}));
    cal.push({w:{lib:37,ccc:36,acl:35}[co],sl:0,type:'eur',comp:co,st:'f',ko:true,leg:0,home:co==='ccc'?ch(.5):false,neutral:co!=='ccc'});}
  leagueSched(cal);
  const sch=nlSetup();SELWK.forEach((w,wi)=>[0,1].forEach(s=>{const[o,h]=sch[wi*2+s];cal.push({w,sl:s,type:'sel',comp:'nl',st:'grp',md:wi*2+s+1,oppN:o,home:!!h});}));
  return cal.sort((a,b)=>a.w-b.w||a.sl-b.sl);}
/* rival del partido: fijo en fases de liga y grupos; sorteado al llegar la eliminatoria; la vuelta repite el de la ida */
function drawOpp(e){if(!e||e.opp||e.oppN||e.skip||!e.comp||!P.comp)return;const C=P.comp[e.comp];if(!C)return;
  if(e.leg===2){const l1=P.cal.find(x=>x.comp===e.comp&&x.st===e.st&&x.leg===1);if(l1&&(l1.opp||l1.oppN)){e.opp=l1.opp;e.oppN=l1.oppN;return;}}
  const used=C.used||(C.used=[]),take=(pool,fb)=>{const p=pool.filter(i=>!used.includes(i));const x=pk(p.length?p:fb);used.push(x);return x;};
  if(e.comp==='copa'){const k=club(P.club),all=LG[k.league].pyr.flat().filter(i=>i!==P.club),si=e.ci!=null?e.ci/Math.max(1,e.cn-1)*5:['r64','r32','r16','qf','sf','f'].indexOf(e.st),t=46+si*6+(k.base-60)*.25;e.opp=take(all.filter(i=>Math.abs(clubStr(i)-t)<=8),all);
    if(C.low&&!e.leg&&!e.neutral&&club(e.opp).tier!==k.tier)e.home=k.tier>club(e.opp).tier;}
  else if(e.comp==='sup'){const k=club(P.club);e.opp=take(tier0By(k.league).filter(i=>i!==P.club).slice(0,e.st==='sf'?4:3),tier0By(k.league).filter(i=>i!==P.club));}
  else if(e.comp==='usc'){const k=club(P.club),p=ALL().filter(x=>x.tier===0&&x.league!==k.league&&UEFAC(LG[x.league].country)&&x.base>=76&&x.base<=84).map(x=>x.id);e.opp=take(p,p);}
  else if(C.pool&&e.st==='lp')e.opp=C.pool[(e.md-1)%C.pool.length];
  else if(C.grp&&e.st==='grp'){const g=C.grp[(e.md-1)%3+1];if(g.id)e.opp=g.id;else e.oppN=g.n;}
  else if(C.pool){const si=['po','r16','qf','sf','f'].indexOf(e.st),cand=C.pool.slice().sort((a,b)=>clubStr(b)-clubStr(a)).slice(0,Math.max(4,22-si*4));e.opp=take(cand,C.pool);}
  else if(C.nat){const conf=(NAT[P.nat]||[0,'UEFA'])[1],si=['r32','r16','qf','sf','f'].indexOf(e.st),pool=Object.keys(NAT).filter(n=>n!==P.nat&&(C.wc||e.comp==='nlf'?(e.comp!=='nlf'||NAT[n][1]==='UEFA'):NAT[n][1]===conf||(conf==='CONMEBOL'&&NAT[n][1]==='CONCACAF'))).sort((a,b)=>NAT[b][0]-NAT[a][0]);
    e.oppN=take(pool.slice(0,Math.max(4,18-si*3)),pool.length?pool:Object.keys(NAT).filter(n=>n!==P.nat));}}
function compOut(C,lbl){C.alive=false;C.out=lbl;P.cal.forEach(x=>{if(x.comp===C.key&&!x.done)x.skip=true;});}
function simPair(a,b,neutral){const sa=entStr(a)+(neutral?0:1),sb=entStr(b);return[poisson(xg(sa-sb)),poisson(xg(sb-sa))];}
function grpPlay(a,b){const[x,y]=simPair(ent(a),ent(b),true);a.p+=x>y?3:x===y?1:0;b.p+=y>x?3:x===y?1:0;a.gd+=x-y;b.gd+=y-x;a.pj=(a.pj||0)+1;b.pj=(b.pj||0)+1;}
function groupEnd(C){const o=C.grp.filter(g=>!g.me),pairs=[];for(let i=0;i<o.length;i++)for(let j=i+1;j<o.length;j++)pairs.push([o[i],o[j]]);
  /* partidas antiguas: los partidos entre rivales que aún no se jugaron se simulan ahora */
  let miss=pairs.length*(C.gRR||1)-(C.gSim||0);for(let r=0;miss>0&&r<8;r++)for(const[a,b]of pairs){if(miss<=0)break;grpPlay(a,b);miss--;}
  C.grp.sort((a,b)=>b.p-a.p||b.gd-a.gd);C.rank=C.grp.findIndex(g=>g.me)+1;
  if(C.key==='nl'){news(C.rank===1?`${P.nat} gana su grupo de la ${C.name}.`:`${P.nat} acaba ${C.rank}.º en su grupo de la ${C.name}.`,C.rank===1?'hot':'');return;}
  if(C.rank<=2)news(`${C.name}: ${C.nat?P.nat:cname(P.club)} pasa la fase de grupos.`,'hot');else{compOut(C,'Fase de grupos');news(`${C.name}: ${C.nat?P.nat:cname(P.club)} cae en la fase de grupos.`,'bad');}}
function lpStep(C){if(!C.pool)return;C.oth=C.oth||{};C.pool.forEach(id=>{const o=C.oth[id]||(C.oth[id]={p:0,gd:0,pj:0});const b=clubStr(id),pw=clamp(.34+(b-C.avgB)*.03,.08,.8),r=Math.random();
  if(r<pw){o.p+=3;o.gd+=R(1,3);}else if(r<pw+.25)o.p+=1;else o.gd-=R(1,3);o.pj++;});}
function lpRows(C){const o=C.oth||{};return[...C.pool.map(id=>({id,p:o[id]?o[id].p:0,gd:o[id]?o[id].gd:0})),{id:P.club,p:C.pts,gd:C.gd,me:1}].sort((a,b)=>b.p-a.p||b.gd-a.gd||(a.me?-1:b.me?1:0));}
function leagueEnd(C){if(C.oth){let g=0;while(C.pool.some(id=>!C.oth[id]||C.oth[id].pj<C.lpT)&&g++<20)lpStep(C);}
  const others=C.oth?C.pool.map(id=>({id,p:C.oth[id].p,gd:C.oth[id].gd})):C.pool.map(id=>{const b=clubStr(id);let p=0;for(let i=0;i<C.lpT;i++){const pw=clamp(.34+(b-C.avgB)*.03,.08,.8),r=Math.random();p+=r<pw?3:r<pw+.25?1:0;}return{id,p,gd:R(-6,9)+Math.round((b-C.avgB)/3)};});
  const all=[...others,{id:P.club,p:C.pts,gd:C.gd,me:1}].sort((a,b)=>b.p-a.p||b.gd-a.gd);C.table=all.map(x=>({id:x.id,p:x.p,gd:x.gd}));C.rank=all.findIndex(x=>x.me)+1;
  if(C.key==='acl'){if(C.rank<=8)news(`${C.name}: ${cname(P.club)} acaba ${C.rank}.º y pasa a octavos.`,'hot');else{compOut(C,'Fase de liga');news(`${C.name}: ${cname(P.club)} acaba ${C.rank}.º y queda eliminado.`,'bad');}return;}
  if(C.rank<=8){P.cal.forEach(x=>{if(x.comp===C.key&&x.st==='po'){x.skip=true;x.bye=true;}});news(`${C.name}: ${cname(P.club)} acaba ${C.rank}.º y pasa directo a octavos.`,'hot');}
  else if(C.rank<=24)news(`${C.name}: ${cname(P.club)} acaba ${C.rank}.º y jugará el playoff.`);
  else{compOut(C,'Fase de liga');news(`${C.name}: ${cname(P.club)} acaba ${C.rank}.º y queda eliminado.`,'bad');}}
function compAfter(e,gf,ga,pw,rt){if(!e||!e.comp||!P.comp)return;const C=P.comp[e.comp];if(!C)return;
  C.res.push({st:e.st,md:e.md||0,leg:e.leg||0,opp:e.opp||e.oppN,gf,ga,pw:pw==null?null:!!pw});
  if(e.st==='lp'){C.pts+=gf>ga?3:gf===ga?1:0;C.gd+=gf-ga;C.lpN++;lpStep(C);if(C.lpN>=C.lpT)leagueEnd(C);return;}
  if(e.st==='grp'){const me=C.grp.find(g=>g.me),o=C.grp.find(g=>ent(g)===(e.opp||e.oppN));me.p+=gf>ga?3:gf===ga?1:0;me.gd+=gf-ga;if(o){o.p+=ga>gf?3:gf===ga?1:0;o.gd+=ga-gf;}
    const rest=C.grp.filter(g=>!g.me&&g!==o);if(rest.length===2){grpPlay(rest[0],rest[1]);C.gSim=(C.gSim||0)+1;}C.gN++;if(C.gN>=C.gT)groupEnd(C);return;}
  if(e.leg===1){const l2=P.cal.find(x=>x.comp===e.comp&&x.st===e.st&&x.leg===2);if(l2){l2.aggF=gf;l2.aggA=ga;l2.opp=e.opp;l2.oppN=e.oppN;}return;}
  const tf=gf+(e.aggF||0),ta=ga+(e.aggA||0),q=pw!=null?!!pw:tf>ta,who=C.nat?P.nat:cname(P.club),rival=e.opp?cname(e.opp):e.oppN;
  if(!q){compOut(C,STN[e.st]);news(`${C.name}: ${who} cae en ${STN[e.st].toLowerCase()} ante ${rival}.`,'bad');if(e.comp==='copa')P.sea.cup=STN[e.st];else if(e.type==='eur')P.sea.eur=STN[e.st];return;}
  if(e.st!=='f'){news(`${C.name}: ${who} elimina a ${rival} y pasa de ronda.`,'hot');return;}
  C.alive=false;C.won=true;
  if(C.nat){if(C.called){P.titles.push({n:C.name.replace(' · Final Four','').replace(/ \d{4}$/,''),s:String(P.season+1),c:P.nat});news(`¡${P.nat} campeona ${deN(C.name)}! ${P.last} levanta el trofeo.`,'hot');P.fame=clamp(P.fame+10,0,100);if(C.wc&&P.dream==='mundial')dream();}else news(`${P.nat} gana ${elN(C.name)}.`);return;}
  title(C.name.replace(/ \d{4}$/,''));if(e.comp==='copa')P.sea.cup='Campeón';else if(e.type==='eur')P.sea.eur='Campeón';
  if(rt>=8)award(`Mejor jugador de la final de ${C.name}`);if(e.comp==='ucl'&&P.dream==='champions')dream();}
/* resultado del equipo cuando tú no juegas (lesión, sanción, banquillo, cantera) */
function simTeam(e){drawOpp(e);const own=club(P.club).base+(e.neutral?0:e.home?2:-1),os=e.opp?clubStr(e.opp):70;let gf=poisson(xg(own-os)),ga=poisson(xg(os-own)),pw=null;
  const tie=()=>gf+(e.aggF||0)===ga+(e.aggA||0);if(e.ko&&e.leg!==1&&tie()){if(ch(.5)){if(ch(.5))gf++;else ga++;}if(tie())pw=ch(.5);}
  if(e.type==='liga'){P.pld++;P.pts+=gf>ga?3:gf===ga?1:0;lgRec(e,gf,ga);}compAfter(e,gf,ga,pw,0);e.done=true;e.tsim=1;}
function simNatFx(e){drawOpp(e);const s=(NAT[P.nat]||[78])[0],o=(NAT[e.oppN]||[75])[0];let gf=poisson(xg(s-o)),ga=poisson(xg(o-s)),pw=null;
  if(e.ko&&gf===ga)pw=ch(.5);compAfter(e,gf,ga,pw,0);e.done=true;}
/* avance de la semana: si quedan más partidos en la misma semana, no se repite el trabajo semanal */
function weekFx(){if(P.fx==null)return false;const e=P.cal[P.fx];
  if(e&&!e.done&&!e.skip){if(teamFx(e))simTeam(e);else if(isNat(e)&&e.comp)simNatFx(e);}if(e)e.done=true;
  const n2=P.cal[P.fx+1];if(n2&&e&&n2.w===e.w){if(P.banNew)P.banNew=false;else if(P.ban>0&&isMatch(e))P.ban--;P.fx++;checkCallup();save();return true;}
  return false;}
function weekEnd(){P.fx=(P.fx==null?P.week-1:P.fx)+1;if(P.fx>=P.cal.length&&!P.summer)buildSummer();if(P.fx>=P.cal.length)endSeason();else P.week=P.cal[P.fx].w;}
/* ---------- verano: Final Four de la Nations League, Mundial / Eurocopa / Copa América y Mundial de Clubes ---------- */
const natCalled=()=>natLevel()==='Absoluta'&&ovr()+P.form/20-2>=(NAT[P.nat]||[80])[0]-12&&P.inj===0;
function natQualifies(wc){const lv=(NAT[P.nat]||[75])[0],cf=(NAT[P.nat]||[0,'UEFA'])[1];return wc?(lv>=76||ch(clamp((lv-66)/12,.1,.9))):(cf==='CONMEBOL'||lv>=74||ch(.55));}
function cwcQualifies(){const k=club(P.club),ctry=LG[k.league].country;if(k.tier>0)return false;
  const contW=['Champions League','Copa Libertadores','Concacaf Champions Cup','AFC Champions League Elite'];if(P.titles.some(t=>contW.includes(t.n)&&t.c===k.name&&+t.s.slice(0,4)>=P.season-1))return true;
  if(UEFAC(ctry)){const top=ALL().filter(x=>x.tier===0&&UEFAC(LG[x.league].country)).sort((a,b)=>b.base-a.base).slice(0,12).map(x=>x.id);return top.includes(P.club);}
  return tier0By(k.league).slice(0,2).includes(P.club);}
function simWholeNat(C){const s=(NAT[P.nat]||[78])[0];if(!ch(clamp(.4+(s-76)*.035,.12,.92))){news(`${P.nat} cae en la fase de grupos ${deN(C.name)}.`);return;}
  const ks=(C.wc?['r32']:[]).concat(['r16','qf','sf','f']);for(const k of ks){if(!ch(clamp(.5+(s-82)*.025,.15,.8))){news(`${P.nat} cae en ${STN[k].toLowerCase()} ${deN(C.name)}.`);return;}}news(`¡${P.nat} gana ${elN(C.name)}!`,'hot');}
function buildSummer(){P.summer=true;const endY=P.season+1,add=[],conf=(NAT[P.nat]||[0,'UEFA'])[1];let w=39;
  const nl=P.comp&&P.comp.nl;if(nl&&nl.uefa&&endY%2===1&&nl.rank===1){P.comp.nlf={key:'nlf',name:'Nations League · Final Four',alive:true,res:[],nat:true,called:natCalled()};
    if(P.comp.nlf.called)['sf','f'].forEach(st=>add.push({w:w++,sl:0,type:'nlf',comp:'nlf',st,ko:true,leg:0,neutral:true}));else{const s=(NAT[P.nat]||[80])[0];news(ch(clamp(.3+(s-82)*.03,.1,.7))?`¡${P.nat} gana la Final Four de la Nations League!`:`${P.nat} cae en la Final Four de la Nations League.`);}}
  if(endY%2===0){const wc=endY%4===2,name=wc?`Mundial ${endY}`:`${CONT[conf]} ${endY}`;
    if(natQualifies(wc)){const used=[P.nat],rv=[];const pool=Object.keys(NAT).filter(n=>n!==P.nat&&(wc||NAT[n][1]===conf||(conf==='CONMEBOL'&&NAT[n][1]==='CONCACAF')));
      while(rv.length<3&&pool.length){const x=pk(pool.filter(n=>!used.includes(n)));if(!x)break;used.push(x);rv.push(x);}
      const C=P.comp.natT={key:'natT',name,wc,alive:true,res:[],nat:true,called:natCalled(),grp:[{n:P.nat,p:0,gd:0,me:1},...rv.map(n=>({n,p:0,gd:0}))],gN:0,gT:3,gRR:1};
      if(C.called){news(`${P.last} va convocado ${alN(name)} con ${P.nat}.`,'hot');[1,2,3].forEach(md=>add.push({w:w++,sl:0,type:'natT',comp:'natT',st:'grp',md,neutral:true}));(wc?['r32']:[]).concat(['r16','qf','sf','f']).forEach(st=>add.push({w:w++,sl:0,type:'natT',comp:'natT',st,ko:true,leg:0,neutral:true}));}
      else{news(`${P.last} se queda fuera de la lista de ${P.nat} para ${elN(name)}.`,'bad');simWholeNat(C);}}
    else news(`${P.nat} no se clasifica para ${elN(name)}.`,'bad');}
  if(endY%4===1&&cwcQualifies()){const k=club(P.club),pool=ALL().filter(x=>x.tier===0&&x.id!==P.club&&x.league!==k.league&&x.base>=68).map(x=>x.id).sort(()=>Math.random()-.5);
    const C=P.comp.cwc={key:'cwc',name:`${CN.cwc} ${endY}`,alive:true,res:[],pool:pool.slice(0,30),grp:[{id:P.club,p:0,gd:0,me:1},...pool.slice(30,33).map(id=>({id,p:0,gd:0}))],gN:0,gT:3,gRR:1};
    news(`${k.name} jugará ${elN(C.name)}.`,'hot');[1,2,3].forEach(md=>add.push({w:w++,sl:0,type:'cwc',comp:'cwc',st:'grp',md,neutral:true}));['r16','qf','sf','f'].forEach(st=>add.push({w:w++,sl:0,type:'cwc',comp:'cwc',st,ko:true,leg:0,neutral:true}));}
  add.forEach(x=>P.cal.push(x));return add.length>0;}
/* partidas guardadas con el calendario antiguo */
function migrateCal(){const w=P.week,s=P.sea,pts=P.pts,pld=P.pld;newSeason();P.sea=s;P.pts=pts;P.pld=pld;const i=P.cal.findIndex(x=>x.w>=w);P.fx=i<0?P.cal.length-1:i;P.week=P.cal[P.fx].w;save();}
/* ---------- pestaña Competiciones ---------- */
function calTag(e){return e.type==='liga'?(P.squad==='cantera'?'Juvenil':'Liga'):e.type==='copa'?'Copa':e.type==='eur'?{ucl:'Champions',uel:'Europa L.',uecl:'Conference',lib:'Libertadores',ccc:'Concachampions',acl:'ACL Elite'}[e.comp]:e.type==='sel'?(P.comp&&P.comp.nl&&P.comp.nl.uefa?'Nations L.':'Selección'):e.type==='natT'?(P.comp.natT&&P.comp.natT.wc?'Mundial':'Selección'):e.type==='nlf'?'Final Four':e.type==='cwc'?'Mundial Clubes':e.type==='sup'?'Supercopa':e.type==='libre'?'Descanso':'';}
function flagI(n){const k=NATK[n]||['#888','#ccc'];return `<i class="j-flag" style="--a:${k[0]};--b:${k[1]}" aria-hidden="true"></i>`;}
function compBlock(C){const st=C.won?'<b class="j-neon">Campeón</b>':C.out==='Final'?'Subcampeón':C.out?`Eliminado en ${esc(String(C.out).toLowerCase())}`:C.key==='nl'?(C.rank?`Grupo terminado: ${C.rank}.º`:'Fase de grupos en juego'):'En juego';let b='';
  const cut=C.key==='acl'?[8]:[8,24],cutHint=C.key==='acl'?'1-8: octavos · 9-10: eliminados':'1-8: octavos directos · 9-24: playoff · 25-36: eliminados';
  const lpT=(rows,prov)=>`${prov?`<p class="j-hint" style="margin-top:0">Clasificación provisional · jornada ${C.lpN} de ${C.lpT}</p>`:''}<div class="j-tblw j-tall"><table class="j-t"><thead><tr><th class="num">#</th><th class="l">Club</th><th class="num">DG</th><th class="num">Pts</th></tr></thead><tbody>${rows.map((x,i)=>`<tr class="${x.id===P.club?'me':''}${cut.includes(i+1)?' cut':''}"><td class="num">${i+1}</td><td class="l"><span class="j-tc">${crest(club(x.id),14)}${esc(cname(x.id))}</span></td><td class="num">${x.gd>0?'+':''}${x.gd}</td><td class="num"><b>${x.p}</b></td></tr>`).join('')}</tbody></table></div><p class="j-hint">${cutHint}</p>`;
  if(C.table)b+=lpT(C.table,false);
  else if(C.lpT&&C.pool)b+=C.lpN?lpT(lpRows(C),true):`<p class="muted">Fase de liga: ${C.lpT} jornadas contra ${C.pool.length} rivales. La clasificación aparece tras la primera jornada.</p>`;
  if(C.grp)b+=`<table class="j-t"><thead><tr><th class="num">#</th><th class="l">${C.nat?'Selección':'Club'}</th><th class="num">DG</th><th class="num">Pts</th></tr></thead><tbody>${C.grp.slice().sort((a,c)=>c.p-a.p||c.gd-a.gd).map((g,i)=>`<tr class="${g.me?'me':''}"><td class="num">${i+1}</td><td class="l">${g.n?flagI(g.n)+esc(g.n):`<span class="j-tc">${crest(club(g.id),14)}${esc(cname(g.id))}</span>`}</td><td class="num">${g.gd>0?'+':''}${g.gd}</td><td class="num"><b>${g.p}</b></td></tr>`).join('')}</tbody></table>`;
  if(C.res.length)b+=`<div class="j-res">${C.res.slice(-6).map(r=>`<p class="j-n"><b>${esc(STN[r.st]||'')}${r.md?' J'+r.md:''}${r.leg===1?' (ida)':r.leg===2?' (vuelta)':''}</b>${esc(CLUBS[r.opp]?cname(r.opp):r.opp||'')} · <span class="num">${r.gf}-${r.ga}</span>${r.pw!=null?(r.pw?' · gana en penaltis':' · pierde en penaltis'):''}</p>`).join('')}</div>`;
  return `<div class="j-panel"><h3>${esc(C.name)}</h3><p class="j-hint" style="margin-top:0">${st}</p>${b}</div>`;}
function vComp(){const c=club(P.club),tb=P.squad!=='cantera'?table():[],me=tb.findIndex(t=>t.me)+1,endY=P.season+1,conf=(NAT[P.nat]||[0,'UEFA'])[1];
  const up=[];if(endY%4===2)up.push(`Mundial ${endY}`);if(endY%4===0)up.push(`${CONT[conf]} ${endY}`);if(endY%2===1&&P.comp&&P.comp.nl&&P.comp.nl.uefa)up.push('Final Four de la Nations League (si ganas tu grupo)');if(endY%4===1)up.push(`Mundial de Clubes ${endY} (si tu club se clasifica)`);
  const blocks=[`<div class="j-panel j-wide"><h3>${esc(divOf(c))} <span class="j-hint">· Clasificación</span></h3>${P.squad==='cantera'?'<p class="muted">Sigues en la cantera: el primer equipo compite sin ti.</p>':`<p>Vais <b class="num">${me}.º</b> con <b class="num">${P.pts}</b> puntos en ${P.pld} partidos.</p>${fullTable()}`}<p class="j-hint">${c.tier>0?'Los dos primeros suben de categoría. Desde esta división no hay plazas europeas.':TOP5.includes(LG[c.league].country)?'Plazas: 1-4 Champions · 5.º Europa League · 6.º Conference. El campeón de copa va a la Europa League.':UEFAC(LG[c.league].country)?'Plazas: 1.º Champions · 2.º Europa League · 3.º Conference.':'Esta liga no reparte plazas europeas.'}</p></div>`];
  Object.values(P.comp||{}).forEach(C=>blocks.push(compBlock(C)));
  return `<div class="j-eyebrow">${seasonLabel(P.season)}</div><h2 class="j-h">Competiciones</h2>${up.length?`<p class="muted">Este verano: ${up.map(esc).join(' · ')}.</p>`:''}<div class="j-comps">${blocks.join('')}</div>`;}
const css7=document.createElement('style');css7.textContent=`.j-comps{display:grid;grid-template-columns:repeat(auto-fill,minmax(300px,1fr));gap:16px;margin-top:16px}.j-comps>.j-wide{grid-column:1/-1;min-width:0}.j-comps>.j-panel{min-width:0}.j-tblw{overflow-x:auto;-webkit-overflow-scrolling:touch;margin:0 -4px;padding:0 4px}.j-tall{max-height:520px;overflow-y:auto}.j-tall thead th{position:sticky;top:0;background:#170c2b;z-index:1}.j-full{width:100%;min-width:560px}.j-t th.num,.j-t td.num{text-align:right}.j-t th.l,.j-t td.l{text-align:left}.j-tc{display:inline-flex;align-items:center;gap:6px;white-space:nowrap}.j-tc .crest{flex:none}.j-z{width:4px;padding:0!important}.j-z.zup,.j-z.zcl,.j-t tr td.j-z.zup,.j-t tr td.j-z.zcl{background:#46D38C}.j-z.zel,.j-t tr td.j-z.zel{background:#3DA5FF}.j-z.zco,.j-t tr td.j-z.zco{background:#3DE0C2}.j-z.zrel,.j-t tr td.j-z.zrel{background:#F0605A}.j-zl{display:flex;flex-wrap:wrap;gap:6px 14px;margin-top:10px;font-size:12px;opacity:.85}.j-zl span{display:inline-flex;align-items:center;gap:6px}.j-zl i.j-z{display:inline-block;width:10px;height:10px;border-radius:2px}.j-fm{display:inline-flex;gap:3px}.j-fm i{font-style:normal;font-size:10px;font-weight:700;width:16px;height:16px;line-height:16px;text-align:center;border-radius:3px;color:#0b0518}.j-fm i.V{background:#46D38C}.j-fm i.E{background:#A9BBAF}.j-fm i.D{background:#F0605A}@media (max-width:640px){.j-fcol,.j-gcol{display:none}.j-full{min-width:0;font-size:13px}.j-full td,.j-full th{padding:7px 4px}.j-full .j-tc{white-space:normal}}.j-comps .j-t tr.cut td{border-bottom:2px solid rgba(201,155,255,.5)}
.j-tag.t-cwc{background:#3a2a05;color:#FFD24A}.j-tag.t-sup{background:#2a2438;color:#F1E9FF}.j-tag.t-libre{opacity:.6}.j-tag.t-natT,.j-tag.t-nlf,.j-tag.t-sel{background:#08303a;color:#7FD1FF}.j-res{margin-top:8px}`;document.head.appendChild(css7);

/* ---------- partidos de selección en directo y en 3D ----------
   Las selecciones entran en el motor 3D como clubes temporales (colores de la camiseta nacional y el estadio del
   club más grande del país anfitrión); se quitan de CLUBS al acabar el partido. */
const NATCODE={'España':'ESP','Argentina':'ARG','Brasil':'BRA','Francia':'FRA','Inglaterra':'ENG','Portugal':'POR','Alemania':'GER','Italia':'ITA','Países Bajos':'NED','Bélgica':'BEL','Croacia':'CRO','Uruguay':'URU','Colombia':'COL','Marruecos':'MAR','Senegal':'SEN','México':'MEX','Estados Unidos':'USA','Japón':'JPN','Chile':'CHI','Arabia Saudí':'KSA','Escocia':'SCO','Turquía':'TUR','Suiza':'SUI','Dinamarca':'DEN','Austria':'AUT','Polonia':'POL','Serbia':'SRB','Ucrania':'UKR','Noruega':'NOR','Suecia':'SWE','Gales':'WAL','Corea del Sur':'KOR','Australia':'AUS','Nigeria':'NGA','Egipto':'EGY','Ecuador':'ECU','Perú':'PER','Paraguay':'PAR','Ghana':'GHA','Camerún':'CMR','Canadá':'CAN','Irán':'IRN'};
const natCode=n=>NATCODE[n]||n.normalize('NFD').replace(/[̀-ͯ]/g,'').replace(/[^A-Za-z]/g,'').slice(0,3).toUpperCase();
/* selección real de cada futbolista (solo las selecciones que existen en el juego) */
const NATP={"España":"Joan García;Lamine Yamal;Pedri;Pau Cubarsí;Fermín López;Álex Baena;Koke;Robin Le Normand;Unai Simón;Nico Williams;Oihan Sancet;Gerard Moreno;Santi Comesaña;Isco;Álex Remiro;Mikel Oyarzabal;Iago Aspas;Borja Iglesias;Isaac Romero;José Gayà;Hugo Duro;Julen Agirrezabala;Sergio Herrera;Aimar Oroz;Isi Palazón;Álvaro García;David Soria;Javi Puado;Pere Milla;Antonio Sivera;Toni Martínez;Rafa Mir;Roger Brugué;Andrés Martín;Íñigo Vicente;Pablo Ramón;Yeremay Hernández;Mario Soriano;Diego Villares;Alfonso Herrero;Dani Lorenzo;Chupe;Einar Galilea;Rodri;Álvaro Morata;Alejandro Grimaldo;Sergio Canales;Sergi Darder;Leo Román;Santi Cazorla;Álvaro Carreras;Raúl Asencio;Fran García;Dani Ceballos;Alejandro Balde;Eric García;Gerard Martín;Marc Casadó;Dani Olmo;Gavi;Marc Bernal;Marc Pubill;Pablo Barrios;Marcos Llorente;Dani Vivian;Yeray Álvarez;Aitor Paredes;Óscar de Marcos;Yuri Berchiche;Jesús Areso;Andoni Gorosabel;Mikel Jauregizar;Iñigo Ruiz de Galarreta;Mikel Vesga;Álex Berenguer;Gorka Guruzeta;Robert Navarro;Arnau Tenas;Sergi Cardona;Dani Parejo;Alberto Moleiro;Ayoze Pérez;Álvaro Valles;Héctor Bellerín;Diego Llorente;Marc Bartra;Marc Roca;Pablo Fornals;Rodrigo Riquelme;Aitor Ruibal;Unai Marrero;Igor Zubeldia;Jon Martín;Sergio Gómez;Aihen Muñoz;Beñat Turrientes;Carlos Soler;Jon Gorrotxategi;Pablo Marín;Ander Barrenetxea;Iván Villar;Marcos Alonso;Javi Rodríguez;Sergio Carreira;Fran Beltrán;Hugo Sotelo;Pablo Durán;Bryan Zaragoza;Ferran Jutglà;José Ángel Carmona;Kike Salas;César Tárrega;Pepelu;Javi Guerra;Luis Rioja;Diego López;Dani Raba;Alejandro Catena;Juan Cruz;Jorge Herrando;Abel Bretones;Lucas Torró;Jon Moncayola;Moi Gómez;Rubén García;Raúl García de Haro;Kike Barja;Óscar Valentín;Unai López;Jorge de Frutos;Sergio Camello;Juan Iglesias;Diego Rico;Borja Mayoral;Juanmi;David López;Arnau Martínez;Iván Martín;Bryan Gil;Abel Ruiz;Antonio Raíllo;Pablo Maffeo;Manu Morlanes;Antonio Sánchez;Abdón Prats;Jan Virgili;Mateo Joseph;Carlos Romero;Fernando Calero;Edu Expósito;Pol Lozano;Urko González;Roberto Fernández;Kike García;Víctor Parada;Jonny Otto;Antonio Blanco;Carles Aleñá;Jon Guridi;Carlos Vicente;Pedro Bigas;Marc Aguado;Aleix Febas;Germán Valera;Unai Elgezabal;Oriol Rey;Pablo Martínez;Carlos Álvarez;Iván Romero;Aarón Escandell;David Costas;Dani Calvo;Alberto Reina;Marc Cucurella;Adama Traoré;Angeliño;Alberto Moreno;Aarón Martín;Dean Huijsen;Brais Méndez;Riqui Puig;Sergi Roberto;Pep Biel;David Raya;Robert Sánchez;Gonzalo García;Óscar Mingueza;Juanlu Sánchez;Víctor Muñoz;Pep Chavarría;Kepa Arrizabalaga;Cristhian Mosquera;Martín Zubimendi;Mikel Merino;Nico González;Yéremy Pino;Chema Andrés;Unai Gómez;Alfonso Pedraza;Luis Milla;Álex Jiménez;Josep Martínez;Adrián Bernabé;David de Gea;Mario Hermoso;Mario Gila;Jesús Rodríguez;Toni Fernández;Iñigo Martínez;Álvaro Medrán;Aleix García;Lucas Vázquez;Ferran Torres;Ansu Fati;Saúl Ñíguez;Sergio Ramos;Óliver Torres;Ander Herrera;Fabián Ruiz;Pau Torres;Pedro Porro;Stefan Bajcetic","Argentina":"Julián Álvarez;Augusto Batalla;Cristian Romero;Paulo Gazzaniga;Juan Musso;Giuliano Simeone;Juan Foyth;Giovani Lo Celso;Lucas Boyé;Facundo Garcés;Facundo Buonanotte;Lionel Messi;Rodrigo De Paul;Tadeo Allende;Mateo Silvetti;Óscar Ustari;Pedro de la Vega;Maxi Moralez;Martín Ojeda;Agustín Marchesín;Leandro Paredes;Franco Armani;Gonzalo Montiel;Marcos Acuña;Maximiliano Salas;Adrián Martínez;Santiago Sosa;Santiago Ascacíbar;Guido Carrillo;Rodrigo Rey;Santiago Montiel;Tomás Marchiori;Braian Romero;Jorge Broun;Ángel Di María;Walter Bou;Eduardo Salvio;Guido Herrera;Alan Lescano;Ever Banega;Lucas Passerini;Thiago Almada;Chimy Ávila;Ayrton Costa;Marcos Rojo;Lautaro Blanco;Rodrigo Battaglia;Kevin Zenón;Milton Giménez;Lucas Martínez Quarta;Fabricio Bustos;Lautaro Rivero;Enzo Pérez;Ignacio Fernández;Giuliano Galoppo;Santiago Lencina;Facundo Colidio;Sebastián Driussi;Marco Di Césare;Facundo Mura;Agustín Almendra;Baltasar Rodríguez;Leandro González Pírez;Eric Meza;Cristian Medina;Tiago Palacios;José Sosa;Emiliano Martínez;Alexis Mac Allister;Enzo Fernández;Exequiel Palacios;Gerónimo Rulli;Valentín Barco;Lisandro Martínez;Alejandro Garnacho;Nicolás Domínguez;Marcos Senesi;Guido Rodríguez;Emiliano Buendía;Lautaro Martínez;Paulo Dybala;Matías Soulé;Nico Paz;Santiago Castro;Franco Mastantuono;Nahuel Molina;Nicolás González;Taty Castellanos;Máximo Perrone;Giovanni Simeone;Mateo Pellegrino;Nicolás Valentini;Franco Vázquez;Leonardo Balerdi;Exequiel Zeballos;Mariano Troilo;Ezequiel Fernández;Nicolás Capaldo;Facundo Medina;Julián Malatini;Nicolás Tagliafico;Joaquín Panichelli;Santiago Hidalgo;Agustín Rossi;Germán Cano;Pablo Vegetti;Aníbal Moreno;Flaco López;Lucas Romero;Rodrigo Garro;Enzo Díaz;Alexandro Bernabei;Benjamín Rollheiser;Walter Kannemann;Franco Cristaldo;Alexander Barboza;Álvaro Barreal;Lucas Ocampos;Ángel Correa;Juan Brunetta;Nahuel Guzmán;Carlos Rotondi;Francisco Fydriszewski","Brasil":"Vinícius Júnior;Luiz Júnior;Antony;Éder Militão;Rodrygo;Endrick;Raphinha;Natan;Gabriel Jesus;Gabriel Pec;Evander;Casemiro;Alisson;Gabriel Magalhães;João Pedro;Bruno Guimarães;Matheus Cunha;Evanilson;Igor Thiago;João Gomes;Andrey Santos;Estêvão;Joelinton;Igor Julio;Murillo;Igor Jesus;Savinho;André;Rodrigo Muniz;Lucas Perri;Gleison Bremer;Éderson;Wesley;Dodô;Juan Jesus;Luis Henrique;Carlos Augusto;Giovane;Yan Couto;Douglas Luiz;Diego Carlos;Malcom;Marcos Leonardo;Bento;Roger Ibañez;Galeno;Ângelo Gabriel;Fabinho;Gabriel Martinelli;Andrei Girotto;Arthur;Rômulo;Kauã Santos;Bernardo;Lucas Beraldo;Vanderson;Caio Henrique;Igor Paixão;Dante;Lucas Paquetá;Samuel Lino;Pedro;Weverton;Andreas Pereira;Vitor Roque;Cássio;Matheus Pereira;Kaio Jorge;Alex Telles;Arthur Cabral;Hugo Souza;Yuri Alberto;Rafael;Lucas Moura;Everson;Gustavo Scarpa;Hulk;Fábio;Alan Patrick;Gabriel Brazão;Neymar;Everton Ribeiro;Willian José;Philippe Coutinho;Carlos Vinícius;Cleiton;Danilo;Léo Pereira;Léo Ortiz;Alex Sandro;Ayrton Lucas;Everton Cebolinha;Bruno Henrique;Luiz Araújo;Bruno Fuchs;Murilo;Khellven;Lucas Evangelista;Maurício;Felipe Anderson;Neto;Marçal;Marlon Freitas;Danilo Barbosa;Artur;Matheus Martins;Gustavo Henrique;Matheus Bidu;Raniele;Marcos Antônio;Luciano;Ferreirinha;Guilherme Arana;Igor Gomes;Bernard;Rony;Dudu;Fabrício Bruno;William;Lucas Silva;Christian;Gabriel Barbosa;Ignácio;Samuel Xavier;Martinelli;Hércules;Paulo Henrique Ganso;John Kennedy;Vitão;Thiago Maia;Bruno Tabata;Vitinho;Zé Rafael;Guilherme;Tiquinho Soares;Léo Jardim;Paulo Henrique;Hugo Moura;Marcos Felipe;Jean Lucas;Erick;Ademir;Tiago Volpi;Edenilson;Paulinho;Helinho;Marquinhos;Richarlison;David Neres","Francia":"Kylian Mbappé;Aurélien Tchouaméni;Ferland Mendy;Eduardo Camavinga;Jules Koundé;Antoine Griezmann;Hugo Lloris;Lucien Agoumé;Florian Lejeune;Thomas Lemar;Romain Del Castillo;Moussa Diaby;Ibrahima Konaté;Youssouf Fofana;William Saliba;Rayan Cherki;Jean-Philippe Mateta;Enzo Le Fée;Alphonse Areola;Wesley Fofana;Malo Gusto;Leny Yoro;Wilson Odobert;Maxence Lacroix;Adrien Truffert;Eli Junior Kroupi;Illan Meslier;Lesley Ugochukwu;Loum Tchaouna;Bradley Barcola;Mohamed-Ali Cho;Melvin Bard;Jérémy Jacquet;Sidiki Chérif;Jean-Mattéo Bahoya;Thierno Barry;Mike Maignan;Adrien Rabiot;Manu Koné;Marcus Thuram;Khéphren Thuram;Benoît Badiashile;Pierre Kalulu;Matteo Guendouzi;Armand Laurienté;Andy Diouf;Ange-Yoan Bonny;Jean Butez;Benjamin Pavard;Randal Kolo Muani;Willem Geubbels;Theo Hernández;Karim Benzema;Kingsley Coman;Enzo Millot;Moussa Dembélé;Alexandre Lacazette;Nabil Fekir;Mohamed Simakan;Malang Sarr;Michael Olise;Dayot Upamecano;Christopher Nkunku;Maxime Estève;Loïc Badé;Castello Lukeba;Martin Terrier;Sacha Boey;Lilian Brassier;Lucas Chevalier;Ousmane Dembélé;Désiré Doué;Paul Pogba;Olivier Giroud;Corentin Tolisso;Florian Thauvin;Brice Samba;Guillaume Restes;Lucas Digne;Lucas Hernández;Warren Zaïre-Emery;Tanguy Nianzou;Elye Wahi;Ethan Mbappé;Maghnes Akliouche;Benjamin André;Jonathan Clauss;Morgan Sanson;Tanguy Ndombele;Valentin Rongier;Francis Coquelin;Djibril Sidibé;Matthis Abline;Rémy Descamps;Félix Lemaréchal;Wesley Saïd;Odsonne Édouard;Quentin Merlin;Johann Lepenant;Gautier Lloris;Ludovic Ajorque;Mahdi Camara;Ludovic Blas;Hugo Magnetti;Théo Le Bris;Senny Mayulu;Esteban Lepaul;Kevin Danois;Hugo Ekitiké;Boubacar Kamara","Inglaterra":"Jude Bellingham;Trent Alexander-Arnold;Anthony Gordon;Marcus Rashford;Conor Gallagher;Bukayo Saka;Declan Rice;Phil Foden;Cole Palmer;Reece James;Nick Pope;Morgan Rogers;Danny Welbeck;Dean Henderson;Adam Wharton;Morgan Gibbs-White;Elliot Anderson;Emile Smith Rowe;Jordan Pickford;Jack Grealish;Dominic Calvert-Lewin;Jarrod Bowen;Kyle Walker;Ben White;Myles Lewis-Skelly;Eberechi Eze;Noni Madueke;James Trafford;Rico Lewis;Nico O'Reilly;Joe Gomez;Curtis Jones;Levi Colwill;Josh Acheampong;Jamie Gittens;Liam Delap;Aaron Ramsdale;Kieran Trippier;Tino Livramento;Dan Burn;Lewis Hall;Jacob Ramsey;Harvey Barnes;Harry Maguire;Luke Shaw;Kobbie Mainoo;Mason Mount;Ezri Konsa;Tyrone Mings;Jadon Sancho;Archie Gray;James Maddison;Dominic Solanke;Lewis Dunk;Jack Hinshelwood;Callum Hudson-Odoi;James McAtee;Marcus Tavernier;Jordan Henderson;Jarrad Branthwaite;Tyler Dibling;Kiernan Dewsbury-Hall;Dwight McNeil;Jayden Bogle;Sean Longstaff;Chris Rigg;Taylor Harwood-Bellis;Ben Chilwell;Hayden Hackney;Jack Butland;Carl Rushworth;Tosin Adarabioyo;Ethan Nwaneri;Harvey Elliott;Ollie Watkins;Ivan Toney;Harry Kane;Jobe Bellingham;Carney Chukwuemeka;Jamie Vardy;John Stones;Trevoh Chalobah;Djed Spence;Ruben Loftus-Cheek;Fikayo Tomori;Lloyd Kelly;Jonathan Rowe;Callum Wilson;Charlie Cresswell;CJ Egan-Riley;Angel Gomes;Tyler Morton;Rio Ngumoha;Jack Clarke;Josh Brownhill;Eric Dier;Ainsley Maitland-Niles","Portugal":"Bernardo Silva;João Cancelo;Renato Veiga;Gonçalo Guedes;André Almeida;Félix Correia;Rúben Dias;Pedro Neto;Diogo Dalot;Matheus Nunes;Mateus Fernandes;Toti Gomes;Rodrigo Gomes;Fábio Carvalho;Florentino Luís;Dário Essugo;Bruno Fernandes;José Sá;Francisco Conceição;Nuno Tavares;Gonçalo Ramos;Rúben Neves;Cristiano Ronaldo;João Félix;Samú Costa;Danilo Pereira;Francisco Trincão;Fábio Silva;Tiago Tomás;Vitinha;Nuno Mendes;João Neves;Afonso Moreira;Anthony Lopes;Nuno Moreira;Fábio Vieira;António Silva;Geovany Quenda;Domingos Duarte;Thierry Correia;Danilo Veiga;Tiago Gabriel;Costinha","Alemania":"Antonio Rüdiger;Karim Adeyemi;Thomas Müller;Marco Reus;Florian Wirtz;Nick Woltemade;Malick Thiaw;Leon Goretzka;Manuel Neuer;Jamal Musiala;Joshua Kimmich;Nico Schlotterbeck;David Raum;Mario Götze;Angelo Stiller;Deniz Undav;Noah Atubolu;Christian Günter;Oliver Baumann;Nadiem Amiri;Robin Zentner;Tim Kleindienst;Finn Dahmen;Kevin Müller;Niclas Füllkrug;Robin Gosens;Jonas Urbig;Sven Ulreich;Jonathan Tah;Aleksandar Pavlović;Tom Bischof;Lennart Karl;Serge Gnabry;Alexander Meyer;Waldemar Anton;Emre Can;Felix Nmecha;Pascal Groß;Maximilian Beier;Janis Blaswich;Robert Andrich;Lukas Klostermann;Benjamin Henrichs;Ridle Baku;Assan Ouédraogo;Robin Koch;Nathaniel Brown;Jonathan Burkardt;Finn Jeltsch;Maximilian Mittelstädt;Josha Vagnoman;Chris Führich;Jamie Leweling;Matthias Ginter;Maximilian Eggestein;Kevin Schade;Florian Neuhaus;Julian Weigl;Rocco Reitz;Grischa Prömel;Merlin Röhl;Anton Stach;Saïd El Mala;Maximilian Arnold;Benedict Hollerbach;Eric Martel;Mio Backhaus;Lukas Ullrich;Kilian Fischer;Moritz Nicolas;Kai Havertz;Thilo Kehrer;Yann Bisseck","Italia":"Gianluigi Donnarumma;Sandro Tonali;Riccardo Calafiori;Federico Chiesa;Destiny Udogie;Giacomo Raspadori;Matteo Ruggeri;Matteo Prati;Giovanni Leoni;Michele Di Gregorio;Guglielmo Vicario;Nicolò Barella;Alessandro Bastoni;Alex Meret;Giovanni Di Lorenzo;Marco Carnesecchi;Gianluca Scamacca;Riccardo Orsolini;Ivan Provedel;Mattia Zaccagni;Alessio Romagnoli;Moise Kean;Domenico Berardi;Elia Caprile;Sebastiano Esposito;Wladimiro Falcone;Lorenzo Montipò;Wilfried Gnonto;Federico Dimarco;Davide Frattesi;Pio Esposito;Alessandro Buongiorno;Leonardo Spinazzola;Matteo Politano;Lorenzo Lucca;Matteo Gabbia;Davide Bartesaghi;Samuele Ricci;Federico Gatti;Andrea Cambiaso;Manuel Locatelli;Raoul Bellanova;Davide Zappacosta;Gianluca Mancini;Bryan Cristante;Lorenzo Pellegrini;Niccolò Pisilli;Manuel Lazzari;Nicolò Rovella;Mattéo Cancellieri;Pietro Comuzzo;Luca Ranieri;Fabiano Parisi;Rolando Mandragora;Nicolò Fagioli;Cher Ndour;Roberto Piccoli;Nicolò Casale;Tommaso Pobega;Federico Bernardeschi;Cesare Casadei;Nicolò Zaniolo;Nicolò Bertola;Nicola Leali;Alessandro Marcandalli;Patrizio Masini;Lorenzo Colombo;Sebastiano Luperto;Gabriele Zappa;Gianluca Gaetano;Mattia Felici;Enrico Delprato;Emanuele Valeri;Hans Nicolussi Caviglia;Antonino Gallo;Cristian Volpato;Andrea Pinamonti;Antonio Caracciolo;Simone Canestrelli;Stefano Moreo;Federico Baschirotto;Matteo Bianchetti;Giuseppe Pezzella;Alberto Grassi;Michele Collocolo;Federico Bonazzoli;Manuel De Luca;Francesco Camarda;Michael Folorunsho;Mateo Retegui;Jorginho;Vincenzo Grifo;Marco Palestra","Países Bajos":"Frenkie de Jong;Donny van de Beek;Daley Blind;Quilindschy Hartman;Denzel Dumfries;Virgil van Dijk;Micky van de Ven;Xavi Simons;Bart Verbruggen;Justin Kluivert;Robin Roefs;Milan van Ewijk;Jurriën Timber;Ryan Gravenberch;Cody Gakpo;Matthijs de Ligt;Joshua Zirkzee;Jan Paul van Hecke;Joël Veltman;Mats Wieffer;Kenny Tete;Joël Piroe;Lutsharel Geertruida;Quinten Timber;Crysencio Summerville;Steven Bergwijn;Tijjani Reijnders;Wesley Hoedt;Teun Koopmeiners;Noa Lang;Marten de Roon;Jayden Addai;Danilho Doekhi;Donyell Malen;Thijs Dallinga;Mark Flekken;Jeffrey Gouweleeuw;Ramon Hendriks;Wouter Burger;Joey Veerman;Memphis Depay;Arnaut Danjuma;Zian Flemming;Kjell Scherpen;Marco Bizot;Martijn Kaars;Sam Beukema;Ian Maatsen;Jeremie Frimpong","Bélgica":"Thibaut Courtois;Axel Witsel;Leander Dendoncker;Orel Mangala;Youri Tielemans;Senne Lammens;Amadou Onana;Jérémy Doku;Maxim De Cuyper;Thomas Meunier;Malick Fofana;Kevin De Bruyne;Charles De Ketelaere;Koni De Winter;Alexis Saelemaekers;Arthur Theate;Ignace Van der Brempt;Cyril Ngonge;Samuel Mbangula;Michy Batshuayi;Yannick Carrasco;Koen Casteels;Johan Bakayoko;Maarten Vandevoordt;Loïs Openda;Mika Godts;Matías Fernández-Pardo;Christian Kabasele;Senne Lynen;Mike Penders;Nathan Ngoy;Romeo Lavia;Albert Sambi Lokonga","Croacia":"Luka Modrić;Joško Gvardiol;Mateo Kovačić;Dominik Livaković;Ante Budimir;Duje Ćaleta-Car;Andrej Kramarić;Josip Stanišić;Petar Sučić;Nikola Vlašić;Mario Pašalić;Martin Baturina;Marin Pongračić;Toma Bašić;Kristijan Jakić;Luka Vušković;Nikola Moro;Igor Matanović","Uruguay":"Federico Valverde;José María Giménez;Ronald Araújo;Darwin Núñez;Manuel Ugarte;Rodrigo Bentancur;Luis Suárez;Diego Rossi;Maximiliano Falcón;Mauro Arambarri;Miguel Merentiel;Edinson Cavani;Fernando Muslera;Gastón Martirena;Leandro Cabrera;Federico Viñas;Santiago Mouriño;Santiago Bueno;Franco Israel;Matías Vecino;Gastón Álvarez;Nahitan Nández;Giorgian de Arrascaeta;Sergio Rochet;Guillermo Varela;Joaquín Piquerez;Facundo Torres;Agustín Canobbio;Brian Rodríguez;Ignacio Rivero;Martín Satriano;Álvaro Rodríguez;Mathías Olivera","Colombia":"Cucho Hernández;Johan Mojica;Luis Díaz;Daniel Muñoz;Jefferson Lerma;Jhon Lucumí;Yerry Mina;Juan Cabal;Duván Zapata;Juan Cuadrado;Luis Muriel;Eddie Segura;Juan Fernando Quintero;Kevin Castaño;Miguel Borja;Duván Vergara;Edwuin Cetré;Roger Martínez;Jorge Carrascal;Kevin Serna;Rafael Borré;Camilo Vargas;Kevin Mier;Carlos Bacca;David Ospina;Edwin Cardona;Alfredo Morelos;Jorman Campuzano;David Mackalister Silva;Leonardo Castro;Cristian Barrios;Guillermo Celis;Hugo Rodallega;Andrés Mosquera Marmolejo;Dayro Moreno;Aldair Quintana","Marruecos":"Achraf Hakimi;Yassine Bounou;Sofyan Amrabat;Abde Ezzalzouli;Omar El Hilali;Ilyas Chaira;Noussair Mazraoui;Neil El Aynaoui;Eliesse Ben Seghir;Bilal El Khannouss;Hamza Igamane;Osame Sahraoui;Ismael Saibari;Youssef En-Nesyri;Abderrazak Hamdallah;Amine Adli;Chemsdine Talbi;Abdou Harroui;Bilal Nadir;Brahim Díaz;Sofiane Diop;Mourad Batna","Senegal":"Pape Gueye;Ismaïla Sarr;Iliman Ndiaye;Pape Matar Sarr;Habib Diarra;El Hadji Malick Diouf;Kalidou Koulibaly;Sadio Mané;Édouard Mendy;Idrissa Gueye;Lamine Camara;Moussa Niakhaté;Boulaye Dia;Nicolas Jackson;Habib Diallo;Bamba Dieng;Cheikh Sabaly;Pathé Ciss;Ibrahim Mbaye;Moustapha Mbow;Assane Diao","México":"Raúl Jiménez;Álex Padilla;Hirving Lozano;Johan Vásquez;Julián Quiñones;Luis Ángel Malagón;Henry Martín;Israel Reyes;Erick Sánchez;Diego Lainez;Javier Aquino;Alexis Vega;Marcel Ruiz;Hugo González;Erik Lira;Jorge Sánchez;Ángel Sepúlveda;Raúl Rangel;Roberto Alvarado;Fernando Beltrán;Armando González;Alan Pulido;Guillermo Martínez;Elías Montiel;Alfonso Alvarado;Carlos Acevedo;Aldo Rocha","Estados Unidos":"Christian Pulisic;Weston McKennie;Tyler Adams;Antonee Robinson;Chris Richards;Timothy Weah;Mark McKenzie;Malik Tillman;Joe Scally;Folarin Balogun;Haji Wright;Brenden Aaronson;Sebastian Berhalter;Brian White;Miles Robinson;Walker Zimmerman;Matt Freese;Jordan Morris;Timothy Tillman;Cristian Roldan;Brandon Vazquez;Cole Campbell","Japón":"Takefusa Kubo;Takuma Asano;Maya Yoshida;Yohei Takaoka;Kaoru Mitoma;Tatsuhiro Sakamoto;Zion Suzuki;Wataru Endo;Daichi Kamada;Ao Tanaka;Takehiro Tomiyasu;Hidemasa Morita;Daizen Maeda;Ritsu Doan;Hiroki Itō;Yuito Suzuki;Ko Itakura;Kaishu Sano;Shūto Machino;Joel Chima Fujita;Takumi Minamino","Chile":"Gabriel Suazo;Marcelino Núñez;Guillermo Maripán;Erick Pulgar;Gabriel Arias;Carlos Palacios;Paulo Díaz","Arabia Saudí":"Ali Lajami;Hassan Tambakti;Moteb Al-Harbi;Mohamed Kanno;Nasser Al-Dawsari;Salem Al-Dawsari;Sultan Al-Ghannam;Nawaf Boushal;Abdulelah Al-Amri;Ayman Yahya;Ziyad Al-Johani;Firas Al-Buraikan;Hamed Al-Ghamdi;Abdulrahman Al-Oboud","Suiza":"Rubén Vargas;Granit Xhaka;Gregor Kobel;Yvon Mvogo;Philipp Köhn;Manuel Akanji;Djibril Sow;Michel Aebischer;Dan Ndoye;Noah Okafor;Ardon Jashari;Denis Zakaria;Nico Elvedi;Aurèle Amenda;Miro Muheim;Johan Manzambi;Leon Avdullahu;Fabian Schär;Vincent Sierro","Dinamarca":"Mikkel Damsgaard;Rasmus Højlund;Frederik Rønnow;Pierre-Emile Højbjerg;Anders Dreyer;Andreas Christensen;Christian Nørgaard;Filip Jørgensen;Patrick Dorgu;Joachim Andersen;Mathias Jensen;Gustav Isaksen;Jens Odgaard;Thomas Kristensen;Morten Frendrup;Victor Nelsson;Mads Hermansen;Joakim Mæhle;Christian Eriksen;Jonas Wind;Jens Stage;Yussuf Poulsen;Conrad Harder;Mika Biereth;Matt O'Riley;Morten Hjulmand;Rasmus Nicolaisen;Oscar Højlund","Austria":"Marcel Sabitzer;Konrad Laimer;Christoph Baumgartner;Romano Schmid;Marco Grüll;Xaver Schlager;Nicolas Seiwald;Patrick Wimmer;Kevin Danso;Philipp Lienhart;Marco Friedl;Leopold Querfeld;Florian Grillitsch;Michael Gregoritsch;Maximilian Wöber;Christopher Trimmel;Junior Adamu","Polonia":"Robert Lewandowski;Łukasz Skorupski;Piotr Zieliński;Kamil Grabara;Wojciech Szczęsny;Matty Cash;Arkadiusz Milik;Nicola Zalewski;Jakub Piotrowski;Przemysław Frankowski;Sebastian Szymański;Radosław Majecki","Suecia":"Viktor Gyökeres;Alexander Isak;Emil Forsberg;Roony Bardghji;Carl Starfelt;Williot Swedberg;Lucas Bergvall;Dejan Kulusevski;Yasin Ayari;Anthony Elanga;Hjalmar Ekdal;Gabriel Gudmundsson;Isak Hien;Emil Holm;Jesper Karlström;Daniel Svensson;Hugo Larsson;Mattias Svanberg;Sebastian Nanasi;Amin Sarr","Noruega":"Martin Ødegaard;Erling Haaland;Alexander Sørloth;Ørjan Nyland;Oscar Bobb;Kristoffer Ajer;Sander Berge;Leo Østigård;Morten Thorsby;Kristian Thorstvedt;Antonio Nusa;Julian Ryerson;Aron Dønnum;Kristoffer Velde;Stian Gregersen","Turquía":"Arda Güler;Hakan Çalhanoğlu;Kenan Yıldız;Can Uzun;Kenan Karaman;Berke Özer;Merih Demiral;Altay Bayındır;Ferdi Kadıoğlu;Zeki Çelik;Ozan Kabak;Enes Ünal","Serbia":"Marko Dmitrović;Đorđe Petrović;Sergej Milinković-Savić;Predrag Rajković;Andrej Ilić;Nemanja Gudelj;Nikola Milenković;Saša Lukić;Vanja Milinković-Savić;Strahinja Pavlović;Lazar Samardžić;Nemanja Matić","Ucrania":"Vladyslav Vanat;Andriy Lunin;Yehor Yarmoliuk;Vitaliy Mykolenko;Artem Dovbyk;Illia Zabarnyi","Escocia":"Scott McTominay;Che Adams;Andrew Robertson;Billy Gilmour;Ryan Christie;Aaron Hickey;John McGinn;Lewis Ferguson;Josh Doig","Gales":"Ethan Ampadu;Brennan Johnson;Neco Williams;Joe Rodon;Harry Wilson;Daniel James;David Brooks","Irlanda":"Caoimhín Kelleher;Nathan Collins;Jake O'Brien;Séamus Coleman;Matt Doherty;Josh Cullen;Evan Ferguson;Troy Parrott;Andrew Omobamidele;Dara O'Shea","Grecia":"Odysseas Vlachodimos;Konstantinos Mavropanos;Stefanos Tzimas;Anastasios Douvikas;Konstantinos Koulierakis;Manolis Saliakas;Christos Tzolis;Konstantinos Karetsas","Chequia":"Patrik Schick;Pavel Šulc;Antonín Kinský;Tomáš Souček;Vladimír Coufal;Ladislav Krejčí;Adam Karabec","Ecuador":"Moisés Caicedo;Hernán Galíndez;Piero Hincapié;Pervis Estupiñán;Willian Pacho;Kendry Páez;Gonzalo Plata;Félix Torres;Robert Arboleda;Alan Franco;Pedro Vite","Paraguay":"Orlando Gill;Gustavo Gómez;Miguel Almirón;Omar Alderete;Diego Gómez;Julio Enciso;Ramón Sosa;Ángel Romero;Damián Bobadilla;Junior Alonso","Perú":"Luis Advíncula;André Carrillo","Venezuela":"Salomón Rondón;Yangel Herrera;Jon Aramburu;Telasco Segovia;Jefferson Savarino;José Martínez;Cristian Cásseres Jr.","Nigeria":"Ademola Lookman;Maduka Okoye;Terem Moffi;Akor Adams;Chidera Ejuke;Ola Aina;Calvin Bassey;Alex Iwobi;Samuel Chukwueze;Tolu Arokodare;Christantus Uche;Taiwo Awoniyi","Egipto":"Omar Marmoush;Mostafa Mohamed","Ghana":"Iñaki Williams;Antoine Semenyo;Mohammed Kudus;Thomas Partey;Kamaldeen Sulemana;Caleb Ekuban;Mohammed Salisu;Ernest Nuamah;Gideon Mensah;Joseph Paintsil;André Ayew;Abdul Fatawu;Christopher Bonsu Baah;Caleb Yirenkyi;Ransford Königsdörffer","Costa de Marfil":"Franck Kessié;Evan Ndicka;Yan Diomande;Nicolas Pépé;Odilon Kossounou;Evann Guessand;Seko Fofana;Jean-Philippe Krasso;Ousmane Diomande;Hamed Junior Traorè;Ibrahim Sangaré;Wilfried Zaha;Guéla Doué;Bazoumana Touré;Emmanuel Latte Lath;Sinaly Diomandé","Argelia":"Riyad Mahrez;Houssem Aouar;Saïd Benrahma;Mohamed Amoura;Abderrahman Rebbach;Rayan Aït-Nouri;Ramy Bensebaini;Ibrahim Maza;Farès Chaïbi;Amine Gouiri;Aïssa Mandi;Nabil Bentaleb;Hicham Boudaoui;Haris Belkebla;Himad Abdelli;Rafik Belghali","Túnez":"Hannibal Mejbri;Ellyes Skhiri;Montassar Talbi","Camerún":"Carlos Baleba;Bryan Mbeumo;André-Frank Zambo Anguissa;Christian Kofane;Jackson Tchatchoua;Darlin Yongwa;Frank Magri","Corea del Sur":"Son Heung-min;Lee Kang-in;Hwang Hee-chan;Kim Min-jae;Lee Jae-sung","Australia":"Jackson Irvine;Mathew Ryan;Connor Metcalfe","Canadá":"Jonathan David;Tajon Buchanan;Tani Oluwaseyi;Alphonso Davies;Moïse Bombito;Dayne St. Clair","Costa Rica":"Keylor Navas;Francisco Calvo;Alonso Martínez","Jamaica":"Andre Blake;Ethan Pinnock","Panamá":"Amir Murillo"};
let _natOf=null;const natOf=name=>{if(!_natOf){_natOf={};Object.entries(NATP).forEach(([n,v])=>v.split(';').forEach(x=>{_natOf[x]=n;}));}return _natOf[name]||null;};
window.pFlag=name=>{const n=natOf(name);return n?` <span title="${esc(n)}">${flagI(n)}</span>`:'';};
/* convocatoria: los mejores futbolistas reales de ese país; si no llegan, se completa con nombres genéricos */
function natSquad(n){const seen=new Set();return SEED.filter(p=>p.real&&natOf(p.name)===n&&!seen.has(p.name)&&seen.add(p.name)).sort((a,b)=>b.ovr-a.ovr);}
function natNames(n,exclude){const cv=n===P.nat&&P.sel&&P.sel.conv;let pool=cv&&cv.list?cv.list.filter(x=>!x.me&&x.pos!=='POR').map(x=>x.name):natSquad(n).filter(p=>p.pos!=='POR').slice(0,20).map(p=>p.name);
  if(n===P.nat)pool=pool.concat((P.rivals||[]).filter(r=>r.nat===n).map(r=>r.name));
  pool=pool.filter(x=>x!==exclude);for(let i=0;pool.length<8&&i<20;i++){const g=genName(n);if(!pool.includes(g))pool.push(g);}return pool;}
function natClub(n,lvl,str,host){const tops=ALL().filter(k=>k.tier===0&&LG[k.league]&&LG[k.league].country===host).sort((a,b)=>(b.cap||0)-(a.cap||0)||b.base-a.base);
  const tpl=tops[0]||ALL().filter(k=>k.tier===0).sort((a,b)=>(b.cap||0)-(a.cap||0))[0],k=NATK[n]||['#888888','#DDDDDD','#333333'];
  const id='__nat_'+natCode(n)+(lvl&&lvl!=='Absoluta'?'_'+lvl:'');
  CLUBS[id]={...tpl,id,natN:n,name:n+(lvl&&lvl!=='Absoluta'?' '+lvl:''),short:natCode(n),c1:k[0],c2:k[1],base:str,crest:null,custom:false,cap:Math.max(tpl.cap||0,45000)};return id;}
function natCleanup(){Object.keys(CLUBS).forEach(id=>{if(id.startsWith('__nat_'))delete CLUBS[id];});}
function natMatch(){const e=nextEv(),lvl=P.sel.lvl,abs=lvl==='Absoluta',fx=e&&e.comp&&abs?e:null;
  if(e&&e.comp&&!abs&&!e.done)simNatFx(e);
  const oppN=fx&&fx.oppN?fx.oppN:pk(Object.keys(NAT).filter(x=>x!==P.nat&&NATK[x]));if(!NAT[oppN]||!NAT[P.nat]){natMatchQuick();return;}
  const st=abs?NAT[P.nat][0]:NAT[P.nat][0]-14,os=abs?NAT[oppN][0]:NAT[oppN][0]-14;
  const neutral=!!(fx&&fx.neutral),home=fx?(neutral?true:!!fx.home):ch(.5);
  const host=neutral?(fx.type==='natT'||fx.type==='nlf'?pk(TOP5):P.nat):home?P.nat:oppN;
  natCleanup();try{if(typeof rivMap==='function')rivMap();}catch(e){}const myId=natClub(P.nat,lvl,st,host),opId=natClub(oppN,abs?'':lvl,os,host);
  const min=ovr()>=st-6?90:R(15,35),from=min<90?90-min:0;
  const n=clamp(Math.round(min/90*({POR:3,DEF:2,MED:2,EXT:3,DEL:3}[P.pos])+R(0,1)),1,4);
  const mom=makeMoments(n).map(m=>({...m,m:clamp(from+Math.round((m.m/90)*(90-from)),from+1,89)})).sort((a,b)=>a.m-b.m);
  const ev0=fx||{type:'sel',home,neutral,opp:opId};
  UI.jm={e:ev0,r:'Selección',min,oppS:os,youth:false,interactive:true,mom,i:0,res:{g:0,a:0,ok:0,ko:0,saves:0,log:[]},nat:{oppN,lvl,abs,fx,st,os}};
  const mySide=home?'h':'a',hId=home?myId:opId,aId=home?opId:myId,H=club(hId),A=club(aId);
  const own=st+(ovr()-st)*.07*min/90+(neutral?0:home?2:-1),oppS=os+(neutral?0:home?-1:2);
  const ev=[],mates=natNames(P.nat,P.last),rivals=natNames(oppN);
  const other=poisson(xg(own-oppS)*.72),conc=poisson(xg(oppS-own));
  for(let i=0;i<other;i++)ev.push({m:R(3,89),kind:'goal',side:mySide,n:pk(mates)});
  for(let i=0;i<conc;i++)ev.push({m:R(3,89),kind:'goal',side:mySide==='h'?'a':'h',n:pk(rivals)});
  for(let i=0;i<R(2,5);i++)ev.push({m:R(3,89),kind:'chance',side:ch(.5)?'h':'a'});
  mom.forEach(m=>ev.push({m:m.m,kind:'moment',mo:m}));if(P.sel.captain&&abs&&min>0)ev.push({m:R(Math.max(from+5,30),80),kind:'cap'});
  if(from)ev.push({m:from,kind:'enter'});ev.sort((a,b)=>a.m-b.m||(a.kind==='moment'?1:-1));
  const L={ev,mySide,hId,aId,myId,nat:true,hg:0,ag:0,m:0,speed:1,timer:null,paused:false,M:null,on:min>0&&!from,stop:R(1,5)};UI.jl=L;
  const use3d=typeof hasGL15==='function'&&hasGL15()&&!!window.THREE&&!reduced();
  const lbl=fx?evLabel(fx):`Amistoso · ${lvl&&lvl!=='Absoluta'?lvl:'Selección absoluta'}`;
  modal(`<div class="hd j-mhd"><h3>${esc(lbl)}</h3><p class="j-hint" style="margin:4px 0 0">${neutral?'Sede neutral':home?'En casa':'Fuera'} · ${esc(H.stadium||'')}</p></div>
   <div class="bd"><div class="scoreboard${use3d?' sb-3d':''}"><div class="t">${flagI(H.natN)}<b>${esc(H.name)}</b></div><div><div class="digits" id="sc">0-0</div><div class="clock" id="clk">0'</div></div><div class="t">${flagI(A.natN)}<b>${esc(A.name)}</b></div></div>
   ${use3d?`<div class="bc15" id="bc15"><div class="bc15-slot" id="bc15-slot"></div><div class="bc15-bug" aria-hidden="true"><span class="bug-t" style="--k:${H.c1}">${esc(H.short)}</span><span class="bug-s" id="bc-sc">0–0</span><span class="bug-t" style="--k:${A.c1}">${esc(A.short)}</span><span class="bug-c" id="bc-clk">0'</span></div><div class="bc15-side" aria-hidden="true"><span class="bc15-live">Directo</span><span class="j-star-k">★ ${esc(P.last)}</span></div><button type="button" class="bc15-rep" id="bc-rep" data-act="skipRep" hidden>Repetición <small>Saltar</small></button><div class="bc15-l3" id="bc-l3" hidden></div><div class="j-dec j-dec-3d" id="jdec" hidden></div></div>`:'<div class="j-dec" id="jdec" hidden></div>'}
   <div class="feed" id="feed" aria-live="polite"></div></div>
   <div class="ft"><button class="btn" data-act="jLiveSpeed" id="jspd">Velocidad ×2</button><button class="btn" data-act="jLiveSim">Simular el resto</button></div>`);
  const mr=document.querySelector('#modal-root .modal');if(mr&&use3d)mr.classList.add('m15');
  if(use3d){const prevS=S;try{S={club:'__jugador__',season:P.season,week:P.week,cap:0};
      L.M=match3D15(document.getElementById('bc15-slot'),{r:{h:hId,a:aId},home,cup:true});}catch(err){console.error(err);L.M=null;}finally{S=prevS;}
    UI.m15=L.M;if(L.M)addStar(L.M);else{const b=document.getElementById('bc15');if(b)b.remove();}}
  const fig=x=>natSquad(x).filter(p=>p.name!==P.last).slice(0,4).map(p=>p.name);const fm=fig(P.nat),fo=fig(oppN);
  if(fo.length)feed(`${oppN} sale con ${fo.join(', ')}.`);if(fm.length)feed(`En ${P.nat} juegas junto a ${fm.join(', ')}.`);
  feed(`Suena el himno. Arranca el partido${from?'. Empiezas en el banquillo':'. Sales de titular'}.`);
  liveRun();}
function natFinish(){const M=UI.jm,N=M.nat,R0=M.res,L=UI.jl;natCleanup();
  let min=M.min;if(R0.redMin)min=Math.max(1,Math.min(M.min,R0.redMin-(90-M.min)));
  const gf=M.pre?M.pre.gf:0,ga=M.pre?M.pre.ga:0,g=R0.g;
  let rt=6+R0.g*1.1+R0.a*.75+R0.ok*.3-R0.ko*.28+(gf>ga?.3:gf<ga?-.3:0)+(P.form-50)/100+(Math.random()-.5)*.8;
  if(P.pos==='POR')rt+=ga===0?.8:-ga*.3;if(P.pos==='DEF'&&ga===0)rt+=.4;if(R0.redMin)rt-=1.6;rt=+f1(clamp(rt,1,10));
  const fx=N.fx;let pw=null,pens='';
  if(fx&&fx.ko&&gf===ga){pw=ch(.5+(P.at.tir-70)/400);pens=pw?' · gana en los penaltis':' · pierde en los penaltis';}
  if(fx&&!fx.done){compAfter(fx,gf,ga,pw,rt);fx.done=true;}
  if(N.abs){P.sel.caps++;P.sel.g+=g;if(P.sel.caps===1)news(`Debut con la selección absoluta de ${P.nat}.`,'hot');if(P.sel.caps>=40&&ovr()>=85&&!P.sel.captain){P.sel.captain=true;news(`${P.last} es el nuevo capitán de ${P.nat}.`,'hot');}}
  if(g)news(`${P.last} marca con ${P.nat}${N.abs||!N.lvl?'':' '+N.lvl} ante ${N.oppN} (${gf}-${ga}).`,'hot');
  P.fat=clamp(P.fat+min/90*12,0,100);P.fame=clamp(P.fame+(N.abs?1.5:.6)+g,0,100);P.form=clamp(P.form+(rt-6.2)*3,10,99);save();
  const nm=`${P.nat}${N.abs||!N.lvl?'':' '+N.lvl}`;
  modal(`<div class="hd j-mhd"><h3>${esc(nm)} ${gf}-${ga} ${esc(N.oppN)}${pens}</h3>${fx?`<p class="j-hint" style="margin:4px 0 0">${esc(evLabel(fx))}</p>`:''}</div><div class="bd"><div class="j-note"><b class="num">${f1(rt)}</b><span>${min} minutos${g?` · ${g>1?g+' goles':'¡gol'} con tu país${g>1?'':'!'}`:''}${R0.a?` · ${R0.a} asistencia${R0.a>1?'s':''}`:''}</span></div>${R0.log.length?`<div class="j-res">${R0.log.map(t=>`<p class="j-n">${esc(t)}</p>`).join('')}</div>`:''}<p class="j-hint">Partidos internacionales: ${P.sel.caps} · Goles: ${P.sel.g}</p><div style="margin-top:14px"><button class="btn primary" data-act="jAfterNat" data-focus>Seguir</button></div></div>`);}

/* ---------- convocatoria: lista real por posiciones y presentación en 3D (saltable) ---------- */
/* nombres para completar convocatorias de países con pocos jugadores reales en el juego */
const GENN={'Japón':[['Kaito','Haruto','Ren','Sota','Yuma','Riku','Daiki','Shun','Kenta','Takumi'],['Sato','Suzuki','Takahashi','Tanaka','Watanabe','Ito','Yamamoto','Nakamura','Kobayashi','Kato']],
 'Corea del Sur':[['Min-jun','Seo-jun','Ji-ho','Hyun-woo','Jun-young','Dong-hyun','Sung-min','Jae-won'],['Kim','Lee','Park','Choi','Jung','Kang','Cho','Yoon']],
 'Arabia Saudí':[['Abdullah','Fahad','Saud','Turki','Faisal','Khalid','Nawaf','Yasser'],['Al-Shehri','Al-Qahtani','Al-Otaibi','Al-Mutairi','Al-Zahrani','Al-Malki','Al-Harbi','Al-Shamrani']],
 'Irán':[['Ali','Reza','Mehdi','Saman','Milad','Alireza','Hossein','Amir'],['Rezaei','Ahmadi','Hosseini','Karimi','Mohammadi','Ghoddos','Jahanbakhsh','Nourollahi']],
 'Australia':[['Jack','Riley','Mitchell','Harry','Lachlan','Connor','Cameron','Aiden'],['Smith','Wilson','Taylor','Brown','Mabil','Kuol','McGree','Burgess']],
 'Chile':[['Matías','Diego','Felipe','Vicente','Benjamín','Cristóbal','Ignacio','Darío'],['Valdés','Vidal','Isla','Medel','Aránguiz','Brereton','Osorio','Echeverría']],
 'Perú':[['Renato','Christian','Edison','Yoshimar','Piero','Bryan','Joao','Raziel'],['Flores','Cueva','Tapia','Quispe','Reyna','Grimaldo','López','Zambrano']],
 'Jamaica':[['Leon','Shamar','Kasey','Demarai','Dexter','Damion','Joel','Kaheim'],['Bailey','Nicholson','Palmer','Gray','Lembikisa','Lowe','Latibeaudiere','Dixon']],
 'Panamá':[['Adalberto','José','Édgar','Ismael','Cecilio','Aníbal','Fidel','Yoel'],['Carrasquilla','Córdoba','Fariña','Díaz','Waterman','Godoy','Escobar','Bárcenas']],
 'Costa Rica':[['Joel','Manfred','Brandon','Jeyland','Orlando','Kendall','Juan Pablo','Óscar'],['Campbell','Ugalde','Aguilera','Mitchell','Galo','Waston','Vargas','Duarte']],
 'Egipto':[['Mohamed','Ahmed','Mostafa','Omar','Mahmoud','Hamdi','Emam','Trezeguet'],['Hegazi','Elneny','Fathi','Ashour','Abdelmonem','Hamdy','Zizo','Kahraba']],
 'Túnez':[['Aïssa','Elias','Ali','Yan','Sayfallah','Dylan','Mohamed Ali','Youssef'],['Laïdouni','Achouri','Abdi','Valery','Ltaief','Bronn','Ben Romdhane','Msakni']]};
const genName=n=>{const g=GENN[n];return g?pk(g[0])+' '+pk(g[1]):pk(FIRSTN)+' '+pk(LASTN);};
const CONVN={POR:3,DEF:8,MED:7,DEL:5},CONVL={POR:'Porteros',DEF:'Defensas',MED:'Centrocampistas',DEL:'Delanteros'};
const convPos=x=>x==='EXT'?'DEL':CONVN[x]?x:'MED';
function convKey(e){if(!e||!isNat(e)||!P.sel.called)return null;return e.type==='sel'?`${P.season}-w${e.w}-${P.sel.lvl}`:`${P.season}-${e.type}`;}
function buildConv(key){const lvl=P.sel.lvl||'Absoluta',lim={'Sub-17':17,'Sub-19':19,'Sub-21':21}[lvl]||99,nl=(NAT[P.nat]||[78])[0]-(lim<99?14:0);
  const mine=convPos(P.pos),pool=natSquad(P.nat).filter(p=>p.age<=lim&&p.name!==P.name+' '+P.last),used=new Set(),list=[];
  Object.keys(CONVN).forEach(pos=>{const need=CONVN[pos]-(pos===mine?1:0);const got=pool.filter(p=>convPos(p.pos)===pos&&!used.has(p.name)).slice(0,need);
    got.forEach(p=>{used.add(p.name);list.push({name:p.name,pos,ovr:p.ovr,club:p.club,age:p.age});});
    for(let i=got.length;i<need;i++){let nm,g=0;do{nm=genName(P.nat);}while(used.has(nm)&&g++<40);used.add(nm);list.push({name:nm,pos,ovr:clamp(nl-R(6,14),45,90),club:'',age:lim<99?R(lim-2,lim):R(21,31),gen:1});}});
  list.push({name:`${P.name} ${P.last}`,pos:mine,ovr:ovr(),club:P.club,age:P.age,me:1});
  const ord=Object.keys(CONVN);list.sort((a,b)=>ord.indexOf(a.pos)-ord.indexOf(b.pos)||b.ovr-a.ovr);
  const free=[...Array(26)].map((_,i)=>i+1),take=n=>{const i=free.indexOf(n);if(i<0)return null;free.splice(i,1);return n;};
  const me=list.find(x=>x.me);me.num=take(+P.num||9)||null;list.filter(x=>x.pos==='POR'&&!x.me).forEach((x,i)=>{x.num=take([1,13,23][i])||null;});
  list.forEach(x=>{if(!x.num)x.num=free.shift();});
  const cap=P.sel.captain&&lvl==='Absoluta'?me:list.filter(x=>!x.gen&&!x.me).sort((a,b)=>b.age-a.age||b.ovr-a.ovr)[0]||me;cap.cap=1;
  return{key,lvl,list};}
function showConv(go){const e=nextEv(),key=convKey(e)||(P.sel.conv&&P.sel.conv.key);if(!key){natMatch();return;}
  if(!P.sel.conv||P.sel.conv.key!==key)P.sel.conv=buildConv(key);const C=P.sel.conv;C.seen=1;save();
  const lbl=e&&isNat(e)?evLabel(e):'Selección',nm=`${P.nat}${C.lvl&&C.lvl!=='Absoluta'?' '+C.lvl:''}`,k=NATK[P.nat]||['#888','#ddd'];
  const anim=typeof loadThree==='function'&&typeof hasGL15==='function'&&hasGL15()&&!reduced();
  const row=x=>`<li class="${x.me?'me':''}"><b class="num jc-n">${x.num}</b><span class="jc-nm">${esc(x.name)}${x.cap?' <i class="jc-cap" title="Capitán">C</i>':''}${x.me?' <em class="jc-you">Tú</em>':''}</span><span class="jc-cl">${x.club&&CLUBS[x.club]?`${crest(club(x.club),14)}${esc(cname(x.club))}`:'<span class="muted">Sin club en el juego</span>'}</span><b class="num">${x.ovr}</b></li>`;
  modal(`<div class="hd j-mhd"><div class="eyebrow">${esc(lbl)}</div><h3>${flagI(P.nat)} Convocatoria de ${esc(nm)}</h3></div>
   <div class="bd">${anim?`<div class="jc-stage" id="jc-stage" style="--a:${k[0]};--b:${k[1]}"><canvas id="jc-cv" role="img" aria-label="Presentación en 3D de los convocados de ${esc(nm)}"></canvas>
     <div class="jc-l3" id="jc-l3" hidden></div><div class="jc-end" id="jc-end" hidden><span>${esc(nm)}</span><b>${C.list.length} convocados</b></div>
     <button type="button" class="jc-skip" id="jc-skip" data-act="jConvSkip">Saltar <small>▶▶</small></button></div>`:''}
    <div class="jc-list">${Object.keys(CONVN).map(pos=>`<section><h4>${CONVL[pos]}</h4><ul>${C.list.filter(x=>x.pos===pos).map(row).join('')}</ul></section>`).join('')}</div>
    ${C.list.some(x=>x.gen)?'<p class="j-hint">Los nombres sin club son futbolistas generados: no hay suficientes jugadores reales de esta selección en el juego.</p>':''}</div>
   <div class="ft">${go?'<button class="btn primary" data-act="jConvGo" id="jc-go">Jugar el partido</button>':'<button class="btn primary" data-act="close" id="jc-go">Cerrar</button>'}</div>`);
  requestAnimationFrame(()=>{const bd=document.querySelector('#modal-root .bd');if(bd)bd.scrollTop=0;const m=document.querySelector('#modal-root .modal');if(m)m.scrollTop=0;const g=document.getElementById('jc-go');if(g)g.focus({preventScroll:true});});
  if(anim)loadThree().then(ok=>{const cv=document.getElementById('jc-cv');if(!ok||!window.THREE||!cv){const st=document.getElementById('jc-stage');if(st)st.remove();return;}try{mountConv(cv,C.list);}catch(err){console.error(err);const st=document.getElementById('jc-stage');if(st)st.remove();}});}
let CV3D=null;
function unmountConv(){if(!CV3D)return;const G=CV3D;CV3D=null;cancelAnimationFrame(G.raf);G.ro&&G.ro.disconnect();
  G.scene.traverse(o=>{o.geometry&&o.geometry.dispose();if(o.material)(Array.isArray(o.material)?o.material:[o.material]).forEach(m=>{m.map&&m.map.dispose();m.dispose();});});G.r.dispose();try{G.r.forceContextLoss();}catch(e){}}
function mountConv(cv,list){unmountConv();const T=window.THREE,box=cv.parentElement,K=NATK[P.nat]||['#888888','#dddddd','#333333'];
  const r=new T.WebGLRenderer({canvas:cv,antialias:true});r.setPixelRatio(Math.min(devicePixelRatio||1,2));if('outputEncoding' in r)r.outputEncoding=T.sRGBEncoding;
  const scene=new T.Scene();scene.background=new T.Color('#07040f');scene.fog=new T.Fog('#07040f',16,30);
  const cam=new T.PerspectiveCamera(32,16/9,.1,80);
  scene.add(new T.HemisphereLight(0xEDE2FF,0x120a24,.7));const key=new T.DirectionalLight(0xffffff,.9);key.position.set(3,6,8);scene.add(key);
  const rim=new T.DirectionalLight(new T.Color(K[0]),1.2);rim.position.set(-5,4,-6);scene.add(rim);
  /* suelo, gradas para la foto y pared con los colores de la selección */
  const M=(c,o={})=>new T.MeshStandardMaterial({color:new T.Color(c),roughness:.7,...o});
  const floor=new T.Mesh(new T.CircleGeometry(14,64),M('#120b22',{roughness:.9}));floor.rotation.x=-Math.PI/2;scene.add(floor);
  const glow=new T.Mesh(new T.RingGeometry(4.6,5,80),new T.MeshBasicMaterial({color:new T.Color(K[0]),transparent:true,opacity:.5,side:T.DoubleSide}));glow.rotation.x=-Math.PI/2;glow.position.y=.01;scene.add(glow);
  const rows=[[0,0,1.4],[1,.42,0],[2,.84,-1.4]];rows.forEach(([i,y,z])=>{if(!y)return;const st=new T.Mesh(new T.BoxGeometry(7.6,y,1.3),M('#1d1236'));st.position.set(0,y/2,z);scene.add(st);});
  const wallT=pixTex(T,512,128,(g,W,H)=>{g.fillStyle=K[0];g.fillRect(0,0,W,H);g.fillStyle=K[1];g.fillRect(0,H*.38,W,H*.24);g.fillStyle=hexLum(K[1])>.6?'#0b0716':'#ffffff';g.globalAlpha=.9;g.font='900 34px Impact,"Big Shoulders Display",sans-serif';g.textAlign='center';g.fillText('CONVOCATORIA · '+P.nat.toUpperCase(),W/2,H*.6);});
  const wall=new T.Mesh(new T.PlaneGeometry(14,3.5),new T.MeshStandardMaterial({map:wallT,roughness:.8,emissive:new T.Color('#ffffff'),emissiveIntensity:.12,emissiveMap:wallT}));wall.position.set(0,3.4,-3.2);scene.add(wall);
  /* futbolistas: 23 figuras cúbicas con la camiseta de la selección; tú, con tu aspecto */
  const order=list.slice();const meI=order.findIndex(x=>x.me);if(meI>=0)order.push(order.splice(meI,1)[0]);
  const slots=[];[[2,8],[1,8],[0,7]].forEach(([ri,n])=>{const[,y,z]=rows[ri];for(let i=0;i<n;i++)slots.push({x:(i-(n-1)/2)*.9,y,z});});
  const front=[...slots.slice(16)],mid=slots.slice(8,16),back=slots.slice(0,8);
  const meSlot=front[3],others=[...back,...mid,...front.filter(s=>s!==meSlot)];
  const figs=order.map((x,i)=>{const g=new T.Group(),inner=new T.Group();g.add(inner);
    const L=x.me?{...lookSrc(),kit:'seleccion',nat:P.nat,num:x.num}:{nat:P.nat,kit:'seleccion',skin:R(0,SKIN.length-1),hair:R(0,HAIR.length-1),hairc:R(0,5),beard:R(0,3),boots:R(0,BOOTS.length-1),bootm:R(0,BOOTM.length-1),socks:ch(.7)?0:R(1,2),accs:ch(.35)?[pk([2,3,4,8,10,11,1,6])]:[],last:x.name.split(' ').slice(-1)[0],num:x.num};
    buildFigure(T,inner,L);g.scale.setScalar(.42);const sl=x.me?meSlot:others[i]||others[others.length-1];g.userData={sl,t:x.me?6.1:.5+i*.22,x};g.visible=false;scene.add(g);return g;});
  const spot=new T.Mesh(new T.CylinderGeometry(.25,1.1,6,32,1,true),new T.MeshBasicMaterial({color:0xF3E6FF,transparent:true,opacity:0,side:T.DoubleSide,depthWrite:false}));spot.position.set(meSlot.x,3,meSlot.z);scene.add(spot);
  const ring=new T.Mesh(new T.RingGeometry(.32,.42,40).rotateX(-Math.PI/2),new T.MeshBasicMaterial({color:0xD9B3FF,transparent:true,opacity:0}));ring.position.set(meSlot.x,meSlot.y+.02,meSlot.z);scene.add(ring);
  const END=8.4,l3=document.getElementById('jc-l3'),endEl=document.getElementById('jc-end'),skipB=document.getElementById('jc-skip');let shown=-1;
  const G={r,scene,raf:0,t0:null,last:0,done:false};CV3D=G;
  G.skip=()=>{G.t0=performance.now()-END*1000;G.last=performance.now();};
  box.addEventListener('dblclick',G.skip);
  const size=()=>{const w=box.clientWidth||640,h=box.clientHeight||360;r.setSize(w,h,false);cam.aspect=w/h;cam.updateProjectionMatrix();};size();if(window.ResizeObserver){G.ro=new ResizeObserver(size);G.ro.observe(box);}
  const ease=u=>1-Math.pow(1-clamp(u,0,1),3),lerp=(a,b,u)=>a+(b-a)*u;
  const loop=now=>{if(CV3D!==G)return;if(!document.body.contains(cv)){unmountConv();return;}G.raf=requestAnimationFrame(loop);
    /* el reloj arranca tras el primer fotograma (compilar sombreadores tarda) y no salta tramos si el equipo va a tirones */
    if(G.t0==null){cam.position.set(-5,2.2,8);cam.lookAt(-2,1,0);r.render(scene,cam);G.t0=performance.now();G.last=G.t0;return;}
    now=performance.now();const gap=now-G.last;if(gap>250)G.t0+=gap-50;G.last=now;
    const t=(now-G.t0)/1000,k=now/1000;let cur=-1;
    figs.forEach((g,i)=>{const d=g.userData,u=(t-d.t)/.7;if(u<0){g.visible=false;return;}g.visible=true;const e=ease(u),sl=d.sl;
      g.position.set(sl.x,sl.y+(1-e)*2.6+(u>=1?Math.sin(k*1.4+i)*.004:0),sl.z);g.rotation.y=u<.35?Math.PI:lerp(Math.PI,0,ease((u-.35)/.65));if(u<1.6)cur=i;});
    if(t<END&&cur>=0&&cur!==shown){shown=cur;const x=figs[cur].userData.x;l3.hidden=false;l3.innerHTML=`<b class="num">${x.num}</b><span><strong>${esc(x.name)}${x.me?' · Tú':''}</strong><small>${CONVL[x.pos].slice(0,-1).replace(/e$/,'e')} · ${x.club&&CLUBS[x.club]?esc(cname(x.club)):'—'}</small></span>`;l3.classList.toggle('me',!!x.me);}
    if(t>=END&&!G.done){G.done=true;l3.hidden=true;endEl.hidden=false;if(skipB)skipB.hidden=true;}
    const meT=6.1,a=clamp((t-meT)/.8,0,1),b=clamp((t-(meT+1.5))/.9,0,1);spot.material.opacity=a*(1-b*.6)*.16;ring.material.opacity=a*(.6+Math.sin(k*4)*.3);
    /* cámara: barrido lateral mientras salen, acercamiento a ti y foto de grupo */
    const sweep=ease(t/5.6);let cx=lerp(-5,3,sweep),cy=lerp(2.2,2.6,sweep),cz=lerp(8,10.5,sweep),tx=lerp(-2,1,sweep),ty=1,tz=0;
    if(t>5.6){const u=ease((t-5.6)/1.1),v=ease((t-7.4)/1);cx=lerp(lerp(3,meSlot.x+.6,u),Math.sin(k*.25)*.8,v);cy=lerp(lerp(2.6,1.3,u),2.5,v);cz=lerp(lerp(10.5,4.2,u),11.5,v);tx=lerp(lerp(1,meSlot.x,u),0,v);ty=lerp(lerp(1,.75,u),1.05,v);tz=lerp(lerp(0,meSlot.z,u),0,v);}
    cam.position.set(cx,cy,cz);cam.lookAt(tx,ty,tz);glow.material.opacity=.35+Math.sin(k*2)*.15;r.render(scene,cam);};
  G.raf=requestAnimationFrame(loop);}
const css9=document.createElement('style');css9.textContent=`.jc-stage{position:relative;width:100%;aspect-ratio:16/9;max-height:52vh;border-radius:8px;overflow:hidden;border:1px solid rgba(201,155,255,.4);background:#07040f;margin-bottom:16px}
.jc-stage canvas{display:block;width:100%;height:100%}
.jc-skip{position:absolute;top:10px;right:10px;background:rgba(10,6,20,.75);border:1px solid rgba(241,233,255,.35);color:#F1E9FF;border-radius:999px;padding:6px 14px;font-weight:700;font-size:13px;backdrop-filter:blur(4px)}
.jc-skip small{font-size:10px;margin-left:4px;opacity:.8}.jc-skip:hover{background:rgba(181,123,255,.35)}
.jc-l3{position:absolute;left:14px;bottom:14px;display:flex;align-items:center;gap:10px;background:linear-gradient(90deg,rgba(10,6,20,.92),rgba(10,6,20,.6));border-left:4px solid var(--a);padding:8px 14px 8px 10px;border-radius:4px;color:#F1E9FF;animation:jcIn .25s ease-out}
.jc-l3 b{font-size:26px;line-height:1;min-width:34px;text-align:center;color:var(--a);text-shadow:0 0 1px #fff}.jc-l3 span{display:flex;flex-direction:column}.jc-l3 strong{font-size:15px}.jc-l3 small{font-size:12px;opacity:.75}
.jc-l3.me{border-left-color:#C99BFF;box-shadow:0 0 24px rgba(181,123,255,.5)}
.jc-end{position:absolute;left:50%;bottom:12px;transform:translateX(-50%);display:flex;flex-direction:column;align-items:center;background:rgba(10,6,20,.7);padding:6px 18px;border-radius:6px;color:#F1E9FF;animation:jcIn .4s ease-out}
.jc-end span{font-family:var(--display);font-size:22px;text-transform:uppercase;letter-spacing:.04em}.jc-end b{font-size:12px;opacity:.8;font-weight:600}
@keyframes jcIn{from{opacity:0;transform:translateY(6px)}to{opacity:1;transform:none}}.jc-end{transform:translateX(-50%)}
.jc-list{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,250px),1fr));gap:14px}
.jc-list h4{font-family:var(--mono);font-size:11px;letter-spacing:.12em;text-transform:uppercase;color:var(--muted);margin:0 0 6px}
.jc-list ul{list-style:none;margin:0;padding:0}.jc-list li{display:grid;grid-template-columns:28px 1fr auto;grid-template-rows:auto auto;column-gap:8px;align-items:center;padding:6px 6px;border-bottom:1px solid var(--line)}
.jc-list li>b:last-child{grid-row:1/3;grid-column:3;font-size:15px}.jc-n{grid-row:1/3;color:var(--muted);text-align:center}.jc-nm{font-weight:600;font-size:14px}.jc-cl{grid-column:2;font-size:12px;color:var(--muted);display:inline-flex;align-items:center;gap:5px}
.jc-list li.me{background:rgba(181,123,255,.14);border-radius:4px}.jc-you{font-style:normal;font-size:10px;font-weight:700;background:#B57BFF;color:#0b0518;border-radius:3px;padding:1px 5px;margin-left:4px}
.jc-cap{font-style:normal;font-size:10px;font-weight:800;border:1.5px solid #FFD24A;color:#FFD24A;border-radius:3px;padding:0 4px;margin-left:4px}
@media (prefers-reduced-motion:reduce){.jc-l3,.jc-end{animation:none}}
@media (max-width:560px){.jc-end{padding:3px 10px;bottom:8px}.jc-end span{font-size:14px}.jc-end b{font-size:10px}.jc-l3{left:8px;bottom:8px;padding:5px 10px 5px 8px;gap:8px}.jc-l3 b{font-size:18px;min-width:24px}.jc-l3 strong{font-size:13px}.jc-l3 small{font-size:11px}.jc-skip{top:6px;right:6px;padding:4px 10px;font-size:12px}}`;document.head.appendChild(css9);

/* ---------- acciones ---------- */
function rr(){if(typeof keepY==='function')keepY(render);else render();}
Object.assign(ACT,{
  jStart(){if(!PLAYER_MODE_ON)return;if(P){UI.screen='jgame';}else UI.screen='jcreate';render();scrollTo(0,0);},
  jExit(){UI.screen='modes';render();scrollTo(0,0);},
  jcf(d,el){if(LOOK.includes(d.k)){setLook(UI.jc,d,el);return;}UI.jc[d.k]=d.n||['age'].includes(d.k)?+d.v:d.v;rr();},
  jLook(d,el){setLook(P,d,el);save();},
  jFound(){const c=UI.jc;if(!c.name.trim()||!c.last.trim()){toast('Escribe nombre y apellido.');return;}
    P=build(c);P.at0=ovr();P.peak=ovr();genRivals();
    const big=ALL().filter(k=>k.tier===0&&k.base>=80),mid=ALL().filter(k=>k.tier===0&&k.base>=70&&k.base<79),low=ALL().filter(k=>k.tier>=1&&k.tier<=2);
    const home=ALL().filter(k=>LG[k.league].country===c.nat);
    const pick3=[pk(home.filter(k=>k.base>=76).length?home.filter(k=>k.base>=76):big),pk(mid),pk(low)];
    P.offers=pick3.map((k,i)=>({...contractFor(k.id,i<2?'cantera':'primer'),squad:i<2?'cantera':'primer',note:['Cantera de élite: debut difícil, techo alto','Filial con opciones reales de subir','Minutos desde el primer día'][i]}));
    save();UI.screen='jgame';UI.jt='despacho';render();scrollTo(0,0);},
  jSign(d){const o=P.offers[+d.i];P.club=o.club;P.origin0=o.club;P.squad=o.squad;P.contract={...o};delete P.contract.note;P.offers=[];P.tru=o.squad==='cantera'?42:48;
    P.agent=null;newSeason();addCard('debut','Debut');news(`${P.name} ${P.last} firma por ${cname(o.club)}${o.squad==='cantera'?' y se incorpora a la cantera':''}.`,'hot');checkCallup();save();render();scrollTo(0,0);},
  jTab(d){UI.jt=d.id;render();document.getElementById('jmain')?.focus({preventScroll:true});scrollTo(0,0);},
  jObj(d){UI.jobj=d.k;rr();},
  jPlay(){liveMatch();},
  jLiveMo(d){const L=UI.jl;if(!L||!L.decide)return;liveResolve(L.decide,+d.j);},
  jLiveSpeed(d,el){const L=UI.jl;if(!L)return;L.speed=L.speed===1?2:1;if(el)el.textContent=L.speed===1?'Velocidad ×2':'Velocidad normal';if(L.timer)liveRun();},
  jLiveSim(){const L=UI.jl;if(!L||L.ended)return;L.fast=true;livePause();if(L.M&&L.M.busy&&L.M.endSeq)L.M.endSeq();if(L.capOpen){L.capOpen=false;const dd=document.getElementById('jdec');if(dd){dd.hidden=true;dd.innerHTML='';}}if(L.decide){const mo=L.decide;L.decide=null;autoMoment(mo);}let g=0;while(!L.ended&&g++<400){if(L.M)L.M.busy=false;liveStep();}},jSim(){startMatch(false);},
  jMo(d){const M=UI.jm,r=resolveMoment(M.mom[M.i],+d.j);M.last=r.t;M.i++;if(M.i<M.mom.length)showMoment();else finishMatch();},
  jPen(d){const F=UI.jm.final,keeper=R(0,2),p=+d.j===keeper?.22:clamp(.72+P.at.tir/400,.7,.95),scored=ch(p);F.won=ch(scored?.62:.32);UI.jm.res.log.push(scored?'Tu penalti: ¡dentro!':'Tu penalti: parado.');applyMatch();},
  jAfter(){closeModal();week();render();if(UI.jEnd){UI.jEnd=false;seasonModal();}else if(P.pending.length)showEvent();},
  jWeek(){week();render();if(UI.jEnd){UI.jEnd=false;seasonModal();}else if(P.pending.length)showEvent();},
  jNat(){const e=nextEv(),k=convKey(e);if(k&&(!P.sel.conv||P.sel.conv.key!==k||!P.sel.conv.seen)){showConv(true);return;}natMatch();},
  jConv(){showConv(false);},
  jConvSkip(){if(CV3D)CV3D.skip();},
  jConvGo(){unmountConv();natMatch();},
  jAfterNat(){closeModal();week();render();if(UI.jEnd){UI.jEnd=false;seasonModal();}else if(P.pending.length)showEvent();},
  jEvent(){showEvent();},
  jDecide(d){const ev=P.pending.shift();if(!ev||!EV[ev.id]){closeModal();render();return;}{const E=EV[ev.id],EO=typeof E.o==='function'?E.o(ev):E.o;EO[+d.j][1](ev);}['tru','mor','chem','fame','fat'].forEach(k=>P[k]=clamp(P[k],0,100));P.lp=clamp(P.lp,0,100);save();render();if(P.pending.length)showEvent();else closeModal();},
  jFocus(d){P.focus=d.k;save();rr();},jInt(d){P.intensity=d.k;save();rr();},jFree(d){P.free=d.k;save();rr();},
  jMini(d){if(!P.miniDone)mini(d.k);},jMiniHit(){miniHit();},jClose(){closeModal();render();},
  jAgent(){P.agent=pk(['Marta Ríos','Jorge Bel','Ana Sáez','Kofi Mensah','Lucas Prado']);news(`${P.last} contrata a ${P.agent} como agente.`);save();rr();},
  jLeave(){P.tru=clamp(P.tru-15,0,100);P.mor=clamp(P.mor-3,0,100);if(role()==='Titular'||role()==='Capitán')P.lp-=1.5;else P.lp+=.5;window_(false);if(!P.offers.length)toast('De momento nadie llama. Tu agente sigue buscando.');save();rr();},
  jTalk(){const r=role();const good=P.tru>=50;modal(`<div class="hd j-mhd"><h3>Reunión con el entrenador</h3></div><div class="bd"><p class="j-sit">«${r==='Titular'||r==='Capitán'?'Eres pieza clave. Sigue así.':r==='Rotación'?'Vas a tener minutos si mantienes el nivel en los entrenamientos.':r==='Cantera'?'Te seguimos de cerca. Entrena con nosotros y gánatelo.':'Ahora mismo hay otros por delante. Demuéstrame que me equivoco.'}»</p><div class="j-opts col"><button class="j-op" data-act="jTalkOk"><b>Entendido, trabajaré más</b></button><button class="j-op" data-act="jTalkDemand"><b>Exigir más minutos</b></button>${P.pos2!==P.pos?'<button class="j-op" data-act="jTalkPos"><b>Pedir jugar de '+POS[P.pos2].toLowerCase()+'</b></button>':''}</div></div>`);},
  jTalkOk(){P.tru=clamp(P.tru+3,0,100);P.lp+=.5;save();closeModal();rr();},
  jTalkDemand(){if(ovr()>=clubStr(P.club)-3&&P.tru>=45){P.promise='minutos';P.tru+=2;toast('El míster te promete minutos.');}else{P.tru=clamp(P.tru-8,0,100);P.lp-=1;toast('Al míster no le sienta bien.');}save();closeModal();rr();},
  jTalkPos(){if(ch(.5)){const a=P.pos;P.pos=P.pos2;P.pos2=a;toast('Probarás en tu nueva posición.');}else{P.tru=clamp(P.tru-3,0,100);toast('De momento, no.');}save();closeModal();rr();},
  jAccept(d){const o=P.offers.splice(+d.i,1)[0];
    if(o.renew){P.contract={...P.contract,...o,club:P.club};news(`${P.last} renueva con ${cname(P.club)}.`);P.lp+=1;}
    else if(o.loan){P.loan={from:P.club,contract:P.contract,wage:o.wage};P.moves.push({s:seasonLabel(P.season),from:cname(P.club),to:cname(o.club),t:'Cesión',wage:o.wage});const fromC=P.club;move(o.club,o,'Cesión');P.moves.pop();P.loan.from=fromC;P.lp+=2;news(`${P.last} se marcha cedido a ${cname(o.club)}.`);}
    else{const r=role(),money=o.wage>(P.contract?P.contract.wage*1.5:0);news(`${P.last} se despide de su afición tras confirmar su salida a ${cname(o.club)}.`);
      if(o.role==='Suplente'&&money)P.lp-=2;else if(o.role!=='Suplente'&&(r==='Suplente'||r==='Descartado'))P.lp+=2;move(o.club,o,'Traspaso');P.offers=[];}
    P.promise=o.promise||P.promise;save();render();},
  jNeg(d){const o=P.offers[+d.i];o.neg=true;const odds=P.agent?.7:.45;
    if(ch(odds)){o.wage=Math.round(o.wage*(1.1+Math.random()*.15)/100)*100;if(!o.promise&&ch(.5))o.promise='minutos';toast('Mejoran la oferta.');}
    else if(ch(.4)){P.offers.splice(+d.i,1);toast('El club retira la oferta.');}else toast('No se mueven de su propuesta.');save();rr();},
  jReject(d){const o=P.offers.splice(+d.i,1)[0];if(o.renew){P.tru-=5;news(`${P.last} rechaza renovar con ${cname(P.club)}.`,'bad');}save();rr();},
  jBuy(d){const it=SHOP.find(s=>s[0]===d.k);if(!it||P.money<it[2])return;P.money-=it[2];P.assets.push(it[0]);P.mor=clamp(P.mor+it[3],0,100);P.rep.mediatico+=it[2]>1e6?1:0;if(it[2]>P.money*2&&P.age<22)P.lp-=1;news(`${P.last} se compra: ${it[1].toLowerCase()}.`);save();rr();},
  jHouseBuy(){const price=plotPrice(P.club);if(P.money<price||hasHome())return;P.money-=price;
    P.home={club:P.club,spent:price,since:seasonLabel(P.season),parts:{estructura:1,fachada:0,jardin:0,piscina:0,garaje:0,tecnologia:0}};
    news(`${P.last} se compra una casa en ${cname(P.club)}.`,'hot');P.mor=clamp(P.mor+6,0,100);save();rr();C3D&&C3D.rebuildHouse();},
  jHouseUp(d){if(!hasHome())return;const h=P.home,L=h.parts[d.k];if(L>=3)return;const cost=upCost(P.club,d.k,L);if(P.money<cost)return;
    P.money-=cost;h.spent+=cost;h.parts[d.k]=L+1;if(homeLevel(h)>=18)news(`${P.last} termina su casa moderna en ${cname(P.club)}.`,'hot');
    P.mor=clamp(P.mor+2,0,100);save();rr();C3D&&C3D.rebuildHouse();},
  jCityView(d){if(C3D)C3D.fly(d.k);},
  jRetire(){retire();render();scrollTo(0,0);},
  jResetAsk(){modal(`<div class="hd j-mhd"><h3>¿Reiniciar la partida?</h3></div><div class="bd"><p>Se borrará la carrera de <b>${esc(P.name)} ${esc(P.last)}</b>: temporadas, títulos, dinero, casa, familia y cartas. No se puede deshacer.</p><p class="j-hint">El Salón de la fama con tus leyendas retiradas se conserva.</p>
    <div class="j-acts" style="margin-top:14px"><button class="btn primary" data-act="jResetYes">Sí, borrar y empezar de cero</button><button class="btn" data-act="jClose" data-focus>Cancelar</button></div></div>`);},
  jResetYes(){closeModal();UI.jt='despacho';ACT.jNew();},
  jNew(){P=null;try{localStorage.removeItem(KEY);}catch(e){}UI.screen='jcreate';render();scrollTo(0,0);},
});
function seasonModal(){const h=P.hist[P.hist.length-1];if(!h)return;const nc=(P.cards||[]).slice(-1)[0];
  modal(`<div class="hd j-mhd"><h3>Fin de la temporada ${h.s}</h3></div><div class="bd"><div class="j-kv"><div><small>Media</small><b class="num">${ovr()}</b></div><div><small>Partidos</small><b class="num">${h.pj}</b></div><div><small>Goles</small><b class="num">${h.g}</b></div><div><small>Asist.</small><b class="num">${h.a}</b></div><div><small>Nota</small><b class="num">${h.n}</b></div></div>
   ${nc&&nc.s===h.s?`<div class="j-newcard">${cardBox(nc)}</div>`:''}${votesBlock(h.s)}<p class="j-hint">Potencial estimado: ${potText()}. ${P.offers.length?`Tienes ${P.offers.length} oferta${P.offers.length>1?'s':''} en la mesa de tu agente.`:''}</p><button class="btn primary" data-act="jClose" data-focus>Empezar la nueva temporada</button></div>`);}
/* inputs (nombre, fecha, altura…) sin inline handlers */
document.addEventListener('input',e=>{const t=e.target;if(!(t instanceof HTMLElement)||!t.dataset.in)return;const k=t.dataset.in;
  if(UI.screen==='jcreate'){let v=t.value;if(['day','month','num','height'].includes(k))v=+v||1;if(k==='day')v=clamp(v,1,28);if(k==='month')v=clamp(v,1,12);if(k==='num')v=clamp(v,1,99);UI.jc[k]=v;
    if(k==='height'){const b=t.closest('.j-range')?.querySelector('b');if(b)b.textContent=v+' cm';G3D&&G3D.rebuild();}
    const prev=document.getElementById('jc-prev');if(prev)prev.innerHTML=card({...build(UI.jc),club:null},true);}
  else if(P&&k==='firstTrain'){P.firstTrain=t.checked;save();}else if(P&&P.coach&&k==='coachYouth'){P.coach.youth=t.checked;save();}});
document.addEventListener('change',e=>{const t=e.target;if(t instanceof HTMLSelectElement&&t.dataset.in==='nat'&&UI.screen==='jcreate'){UI.jc.nat=t.value;}});

/* ---------- integración con el juego ---------- */
const _r=render,_vm=vModes,_vi=vIntro;
render=function(){const p=UI.screen==='jcreate'||UI.screen==='jgame';document.body.dataset.mode=p?'player':'';if(!p){unmount3D();unmountCity();disposeV('train');disposeV('trophy');disposeV('locker');disposeV('house');return _r();}{const m=()=>{mountAspect();mountCity();mountV('train',buildTrain);mountV('trophy',buildTrophy);mountV('locker',buildLocker);mountV('house',buildHouse);};requestAnimationFrame(m);setTimeout(m,150);}
  const bg=document.getElementById('bg');if(bg)bg.className='off';try{setAnim(false);}catch(e){}app.innerHTML=UI.screen==='jcreate'?vCreate():vGame();};
vModes=function(){let h=_vm();if(!PLAYER_MODE_ON)return h;h=h.replace('class="mode locked" aria-disabled="true" data-act="locked"','class="mode pm" data-act="jStart"').replace('En desarrollo','Disponible').replace('class="tag ','class="tag on ').replace('Próximamente','Empezar').replace('<span aria-hidden="true"></span>','<span aria-hidden="true">→</span>');return h;};
vIntro=function(){const h=_vi();const co=P&&P.retired&&P.coach&&!P.coach.done;if(!PLAYER_MODE_ON||!P||!P.club||(P.retired&&!co))return h;return h.replace('<div class="facts',`<div class="j-cont"><button class="btn" data-act="jStart">${co?'Continuar como entrenador':'Continuar carrera'} · ${esc(P.name)} ${esc(P.last)}</button></div>\n    <div class="facts`);};

const css=document.createElement('style');css.textContent=`
body[data-mode=player]{--night:#08040F;--turf:#140927;--turf-2:#1C0E36;--turf-3:#2A1650;--chalk:#F3ECFF;--muted:#B3A0D6;--faint:#8571AC;--line:rgba(214,190,255,.13);--line-2:rgba(214,190,255,.28);--sodium:#B57BFF;--sodium-soft:rgba(181,123,255,.16);--sodium-ink:#13062B;--win:#7CE0B0;--loss:#FF7A9A;--neon:#C99BFF;accent-color:#B57BFF;caret-color:#D2A8FF;scrollbar-color:#5B3A9E #08040F}
body[data-mode=player] ::selection{background:#B57BFF;color:#13062B}
body[data-mode=player] #app{background:radial-gradient(1000px 560px at 88% -10%,rgba(150,80,255,.32),transparent 62%),radial-gradient(760px 520px at -8% 108%,rgba(110,50,210,.26),transparent 60%),#08040F;min-height:100vh}
body[data-mode=player] .btn.primary{background:linear-gradient(180deg,#CFA6FF,#9D62F2);color:#13062B;border-color:#D2A8FF;box-shadow:0 0 0 1px rgba(210,168,255,.35),0 10px 30px -10px rgba(170,100,255,.85)}
body[data-mode=player] .btn.primary:hover{background:linear-gradient(180deg,#DDBDFF,#AE78F7)}
body[data-mode=player] .modal .sheet{background:#120824;border:1px solid rgba(210,168,255,.35);box-shadow:0 0 0 1px rgba(181,123,255,.2),0 0 60px -10px rgba(160,90,255,.55)}
.mode.pm{border-color:rgba(181,123,255,.55)}.mode.pm:hover{border-color:#C99BFF;box-shadow:0 0 0 1px #B57BFF,0 24px 60px -24px rgba(160,90,255,.85)}
.j-cont{margin-top:10px}
.j-eyebrow{font-family:var(--mono);font-size:11px;letter-spacing:.18em;text-transform:uppercase;color:var(--neon);margin-bottom:8px}
.j-h{font-size:clamp(36px,5.4vw,68px);letter-spacing:-.005em;margin-bottom:10px;text-shadow:0 0 28px rgba(181,123,255,.35)}
.j-neon{color:#E4CCFF;text-shadow:0 0 12px rgba(201,155,255,.9),0 0 30px rgba(160,90,255,.6)}
.j-hud{position:sticky;top:0;z-index:20;background:rgba(9,4,18,.9);backdrop-filter:blur(12px);border-bottom:1px solid rgba(181,123,255,.35);box-shadow:0 1px 0 rgba(181,123,255,.15),0 10px 30px -18px rgba(160,90,255,.7)}
.j-hud-in{max-width:1320px;margin:0 auto;padding:10px max(16px,env(safe-area-inset-left));display:flex;align-items:center;gap:18px}
.j-hud .back{margin:0}.j-brand{font-family:var(--display);font-weight:900;font-size:22px;letter-spacing:.04em;white-space:nowrap}.j-brand span{margin-left:8px;color:var(--neon);text-shadow:0 0 14px rgba(201,155,255,.8)}
.j-ind{display:flex;align-items:center;gap:clamp(10px,1.6vw,22px);margin-left:auto}.j-ind>div{display:grid;line-height:1.05}.j-ind small{font-family:var(--mono);font-size:9.5px;letter-spacing:.12em;text-transform:uppercase;color:var(--muted)}.j-ind b{font-size:16px}.j-ind b.bad{color:var(--loss)}
.j-big{padding:4px 12px;border:1px solid rgba(201,155,255,.6);border-radius:4px;box-shadow:0 0 18px -4px rgba(181,123,255,.7),inset 0 0 14px -6px rgba(181,123,255,.7)}.j-big b{font-family:var(--display);font-size:30px!important;color:#F1E3FF;text-shadow:0 0 14px rgba(201,155,255,.9)}
.j-hclub{display:flex;align-items:center;gap:10px;font-weight:600;white-space:nowrap}.j-hclub span{display:grid;line-height:1.1}.j-hclub small{color:var(--muted);font-size:11.5px}
.j-shell{max-width:1320px;margin:0 auto;display:grid;grid-template-columns:220px minmax(0,1fr);gap:clamp(20px,3vw,40px);padding:28px max(16px,env(safe-area-inset-left)) 90px}
.j-rail{position:sticky;top:86px;align-self:start;display:grid;gap:4px}
.j-reset{margin-top:18px;color:#ff8aa8!important;border-color:rgba(255,93,162,.3)!important}.j-reset:hover{background:rgba(255,93,162,.1)!important}
.j-rl{display:flex;align-items:center;gap:12px;text-align:left;padding:11px 12px;border:1px solid transparent;border-radius:4px;background:transparent;font-weight:600;color:var(--muted);transition:background .15s,color .15s,border-color .15s}
.j-rl span{font-size:11px;color:var(--faint)}.j-rl:hover{color:var(--chalk);background:rgba(181,123,255,.08)}
.j-rl.on{color:#F6EEFF;border-color:rgba(201,155,255,.55);background:linear-gradient(90deg,rgba(181,123,255,.22),rgba(181,123,255,.04));box-shadow:inset 3px 0 0 #C99BFF,0 0 22px -10px rgba(181,123,255,.9)}
.j-rl.on span{color:var(--neon)}.j-dot{margin-left:auto;font-style:normal;font-family:var(--mono);font-size:11px;min-width:20px;height:20px;display:grid;place-items:center;border-radius:10px;background:#B57BFF;color:#13062B;box-shadow:0 0 10px rgba(181,123,255,.9)}
.j-main{min-width:0;outline:0;animation:jin .5s cubic-bezier(.16,1,.3,1)}@keyframes jin{from{opacity:0;transform:translateY(10px)}}
.j-dg{display:grid;grid-template-columns:minmax(250px,330px) minmax(0,1fr);gap:clamp(20px,3vw,44px);align-items:start}
.j-hero{position:sticky;top:96px;display:grid;gap:12px;justify-items:center}.j-cap{margin:0;font-family:var(--mono);font-size:12px;letter-spacing:.14em;text-transform:uppercase;color:var(--neon)}
.j-col{display:grid;gap:18px;min-width:0}.j-two{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,340px),1fr));gap:18px;margin-top:18px;align-items:start}
.j-panel{background:linear-gradient(180deg,rgba(28,14,54,.92),rgba(18,9,36,.92));border:1px solid var(--line-2);border-radius:6px;padding:18px 20px}
.j-panel h3{font-size:22px;margin-bottom:12px}.j-alert{border-color:#C99BFF;box-shadow:0 0 0 1px rgba(201,155,255,.35),0 0 32px -10px rgba(181,123,255,.85)}
.j-next{position:relative;overflow:hidden;padding:22px 24px;border-radius:6px;border:1px solid rgba(201,155,255,.5);background:radial-gradient(600px 220px at 85% 0%,rgba(181,123,255,.28),transparent 70%),#160A2D;box-shadow:0 0 40px -18px rgba(181,123,255,.9)}
.j-next h3{font-size:clamp(26px,3.4vw,40px);margin:6px 0 8px}.j-inj{border-color:rgba(255,122,154,.55)}
.j-vs{display:flex;align-items:center;gap:18px;margin:8px 0}.j-vs>b{font-family:var(--display);font-size:32px;color:var(--neon);text-shadow:0 0 14px rgba(201,155,255,.9)}.j-yt{font-family:var(--mono);font-size:12px;letter-spacing:.1em;text-transform:uppercase;color:var(--muted);border:1px dashed var(--line-2);padding:10px 12px;border-radius:4px}
.j-role{color:var(--muted);margin:4px 0 14px}.j-role b{color:var(--chalk)}
.j-acts{display:flex;gap:10px;flex-wrap:wrap;margin-top:14px}
.j-grp{display:grid;gap:8px}.j-grp h4{font-family:var(--mono);font-size:11px;letter-spacing:.14em;text-transform:uppercase;color:var(--muted);margin:0;font-weight:600}
.j-chips{display:flex;flex-wrap:wrap;gap:6px}.j-chip{border:1px solid var(--line-2);background:transparent;padding:8px 13px;border-radius:999px;font-weight:600;font-size:13.5px;transition:background .15s,border-color .15s,box-shadow .15s}
.j-chip:hover{border-color:#E4CCFF}.j-chip.on{background:#B57BFF;border-color:#D2A8FF;color:#13062B;box-shadow:0 0 16px -2px rgba(181,123,255,.9)}.j-chip[disabled]{opacity:.4;cursor:not-allowed}
.j-hint{font-size:13px;color:var(--muted);margin:6px 0 0}
.j-m{display:grid;grid-template-columns:minmax(110px,170px) 1fr 34px;gap:12px;align-items:center;font-size:13.5px;color:var(--muted);padding:5px 0}
.j-m i{height:6px;background:var(--turf-3);border-radius:3px;overflow:hidden}.j-m u{display:block;height:100%;background:linear-gradient(90deg,#7F45E0,#D2A8FF);border-radius:3px;box-shadow:0 0 10px rgba(181,123,255,.8);transition:width .8s cubic-bezier(.16,1,.3,1)}.j-m u.lo{background:var(--loss);box-shadow:none}.j-m b{color:var(--chalk);text-align:right}
.j-n{margin:0;padding:9px 0;border-top:1px solid var(--line);display:flex;gap:10px;align-items:baseline}.j-n:first-of-type{border-top:0}.j-n>b{color:var(--neon);font-size:12px;white-space:nowrap}.j-n.hot>b{text-shadow:0 0 10px rgba(201,155,255,.9)}.j-n.bad>b{color:var(--loss)}
.j-t{width:100%;border-collapse:collapse;font-size:14px}.j-t th{font-family:var(--mono);font-size:10.5px;letter-spacing:.12em;text-transform:uppercase;color:var(--muted);text-align:left;padding:8px 6px;border-bottom:1px solid var(--line-2)}.j-t td{padding:8px 6px;border-bottom:1px solid var(--line)}.j-t tr.me td{color:#F1E3FF;background:rgba(181,123,255,.14)}
.j-kv{display:grid;grid-template-columns:repeat(auto-fit,minmax(110px,1fr));gap:14px}.j-kv>div{display:grid;gap:3px}.j-kv small{font-family:var(--mono);font-size:10px;letter-spacing:.12em;text-transform:uppercase;color:var(--muted)}.j-kv b{font-size:17px}
.j-card{position:relative;overflow:hidden;width:100%;max-width:330px;aspect-ratio:3/4.3;padding:22px;display:flex;flex-direction:column;justify-content:flex-end;gap:12px;background:radial-gradient(120% 70% at 72% 0%,#9551F0,transparent 60%),linear-gradient(160deg,#4B26A0,#1E0F45 55%,#120828);clip-path:polygon(0 7%,7% 0,100% 0,100% 93%,93% 100%,0 100%);box-shadow:inset 0 0 0 1px rgba(214,190,255,.45),inset 0 0 40px -10px rgba(201,155,255,.7)}
.j-card.big{animation:jpin .9s cubic-bezier(.16,1,.3,1) backwards}@keyframes jpin{from{opacity:0;transform:translateY(24px) rotate(-2deg)}}
.j-sheen{position:absolute;inset:0;background:linear-gradient(115deg,transparent 35%,rgba(255,255,255,.2) 48%,transparent 60%);background-size:260% 100%;background-position:130% 0;animation:jsh 5.5s 1s ease-in-out infinite;pointer-events:none}@keyframes jsh{0%,55%{background-position:130% 0}100%{background-position:-60% 0}}
.j-dorsal{position:absolute;right:-8px;top:4px;font-family:var(--display);font-weight:900;font-size:220px;line-height:.8;color:transparent;-webkit-text-stroke:2px rgba(226,205,255,.25);pointer-events:none}
.j-ovr{position:absolute;left:22px;top:24px;display:grid;font-family:var(--display);font-weight:900;line-height:.85}.j-ovr b{font-family:var(--display);font-size:74px;color:#F6EEFF;text-shadow:0 0 18px rgba(201,155,255,.95)}.j-ovr span{font-size:20px;letter-spacing:.14em;color:#E0C9FF}
.j-cl{position:absolute;left:22px;top:122px}.j-free{font-family:var(--mono);font-size:10px;letter-spacing:.14em;color:#E0C9FF;border:1px solid rgba(214,190,255,.4);padding:3px 6px}
.j-av{position:absolute;right:16px;top:70px;filter:drop-shadow(0 0 18px rgba(181,123,255,.55))}.j-av svg path:first-of-type{stroke:var(--boot)}
.j-nm{position:relative;border-top:1px solid rgba(226,205,255,.35);padding-top:12px}.j-nm small{font-size:13px;color:#E0C9FF}.j-nm h3{font-size:42px;overflow-wrap:anywhere}
.j-six{position:relative;display:grid;grid-template-columns:repeat(6,1fr);gap:4px;text-align:center}.j-six b{display:block;font-size:18px}.j-six small{font-family:var(--mono);font-size:9.5px;letter-spacing:.1em;color:#CDB5F5;text-transform:uppercase}
.j-radar{display:flex;gap:26px;align-items:center;flex-wrap:wrap}.j-attrs{flex:1;min-width:240px}.j-rad{transform-origin:100px 100px;animation:jrd 1.1s .2s cubic-bezier(.16,1,.3,1) backwards}@keyframes jrd{from{transform:scale(.15);opacity:0}}
.j-stars{display:inline-flex;gap:3px}.j-stars i{width:12px;height:12px;clip-path:polygon(50% 0,62% 36%,100% 38%,70% 60%,80% 100%,50% 76%,20% 100%,30% 60%,0 38%,38% 36%);background:var(--turf-3)}.j-stars i.on{background:#D2A8FF;filter:drop-shadow(0 0 4px rgba(201,155,255,.9))}
.j-skills{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:10px}.j-skills>div{padding:12px;border:1px solid rgba(201,155,255,.45);border-radius:4px;display:grid;gap:4px;box-shadow:inset 0 0 18px -10px rgba(181,123,255,.9)}.j-skills small{color:var(--muted)}
.j-foc{display:grid;gap:8px}.j-fo{display:grid;grid-template-columns:1fr 44px;gap:4px 12px;text-align:left;padding:12px 14px;background:var(--turf);border:1px solid var(--line);border-radius:4px}.j-fo.on{border-color:#C99BFF;background:var(--turf-2);box-shadow:0 0 18px -8px rgba(181,123,255,.9)}.j-fo span{font-weight:600}.j-fo b{text-align:right}.j-fo i{grid-column:1/-1;height:4px;background:var(--turf-3);border-radius:2px}.j-fo u{display:block;height:100%;background:#B57BFF;border-radius:2px}
.j-check{display:flex;gap:10px;align-items:center;margin-top:14px;font-size:14px}
.j-cal{display:grid;margin-top:16px;max-width:820px}.j-cr{display:grid;grid-template-columns:48px 96px 28px minmax(0,1fr) auto;gap:14px;align-items:center;padding:12px 8px;border-top:1px solid var(--line)}.j-cr.now{background:var(--sodium-soft);border:1px solid #C99BFF;border-radius:4px;box-shadow:0 0 20px -10px rgba(181,123,255,.9)}.j-cr b{color:var(--neon)}.j-cr em{font-style:normal;color:var(--muted);font-size:13px;white-space:nowrap}
.j-tag{font-family:var(--mono);font-size:10px;letter-spacing:.12em;text-transform:uppercase;padding:3px 8px;border-radius:999px;border:1px solid var(--line-2);text-align:center}.t-copa{border-color:#FFD24A;color:#FFE08A}.t-eur{border-color:#C99BFF;color:#E4CCFF;box-shadow:0 0 10px -2px rgba(181,123,255,.8)}.t-sel{border-color:#3DE0C2;color:#9CF2E2}
.j-offers{display:grid;gap:12px;margin-top:22px;max-width:860px}.j-offer{display:grid;grid-template-columns:58px 1fr auto;gap:18px;align-items:center;text-align:left;padding:18px 20px;background:var(--turf);border:1px solid var(--line-2);border-radius:6px;transition:transform .2s cubic-bezier(.16,1,.3,1),border-color .2s,box-shadow .2s}
.j-offer:hover,.j-offer:focus-visible{transform:translateX(6px);border-color:#C99BFF;box-shadow:0 0 30px -12px rgba(181,123,255,.95)}.j-offer h3{font-size:28px}.j-offer p{margin:2px 0 0}.j-offer-r{display:grid;text-align:right}.j-offer-r small{font-size:11.5px;color:var(--muted)}
.j-of{display:grid;grid-template-columns:44px 1fr;gap:12px 14px;align-items:center;padding:12px 0;border-top:1px solid var(--line)}.j-of:first-of-type{border-top:0}.j-of small{display:block;color:var(--muted);font-size:12.5px}.j-ofb{grid-column:1/-1;display:flex;gap:8px;flex-wrap:wrap}
.j-bigs{display:flex;flex-wrap:wrap;gap:clamp(18px,4vw,54px);margin:14px 0 6px}.j-bigs>div{display:grid;font-size:13px;color:var(--muted)}.j-bigs b{font-family:var(--display);font-size:clamp(44px,6vw,84px);line-height:.9;color:#F6EEFF;text-shadow:0 0 22px rgba(181,123,255,.55)}
.j-bars{width:100%;max-width:520px}
.j-feed{max-height:420px;overflow:auto;margin-top:14px}
.j-shop{display:grid;gap:8px}.j-buy{display:flex;justify-content:space-between;gap:12px;padding:11px 14px;border:1px solid var(--line-2);border-radius:4px;background:transparent;text-align:left}.j-buy:not([disabled]):hover{border-color:#C99BFF}.j-buy[disabled]{opacity:.5;cursor:not-allowed}
.j-panel details{border-top:1px solid var(--line);padding:8px 0}.j-panel details:first-of-type{border-top:0}.j-panel summary{cursor:pointer;padding:4px 0}.j-panel details .list{margin-top:8px}
.j-gal{display:grid;grid-template-columns:repeat(auto-fill,minmax(130px,1fr));gap:12px}.j-tro{display:grid;justify-items:center;text-align:center;gap:6px;padding:16px 10px;border:1px solid var(--line-2);border-radius:6px;color:#FFD24A}.j-tro.a{color:#D2A8FF}.j-tro svg{filter:drop-shadow(0 0 10px currentColor)}.j-tro b{color:var(--chalk);font-size:13.5px}.j-tro small{color:var(--muted);font-size:11.5px}
.j-riv{display:grid;grid-template-columns:30px 1fr auto;gap:12px;align-items:center;padding:10px 0;border-top:1px solid var(--line)}.j-riv small{display:block;color:var(--muted);font-size:12px}.j-riv>b{font-family:var(--display);font-size:28px;color:var(--neon)}
.j-mhd h3{font-size:24px}.j-sit{font-size:17px;margin:0 0 14px}.j-opts{display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:10px}.j-opts.col{grid-template-columns:1fr}
.j-op{display:grid;gap:4px;text-align:left;padding:14px 16px;border:1px solid rgba(201,155,255,.45);border-radius:6px;background:#1A0D33;transition:border-color .15s,box-shadow .15s,transform .15s}.j-op:hover,.j-op:focus-visible{border-color:#E4CCFF;box-shadow:0 0 24px -8px rgba(181,123,255,.95);transform:translateY(-2px)}.j-op b{font-size:16px}.j-op small{font-family:var(--mono);font-size:11.5px;color:var(--muted)}
.j-last{margin:14px 0 0;padding:10px 12px;border-left:2px solid #C99BFF;background:rgba(181,123,255,.08);font-size:14px}
.j-note{display:flex;align-items:baseline;gap:16px;margin-bottom:16px}.j-note b{font-family:var(--display);font-size:84px;line-height:.85;color:#F1E3FF;text-shadow:0 0 22px rgba(201,155,255,.95)}.j-note span{display:grid;font-weight:600}.j-note small{color:var(--muted);font-weight:400}
.j-log{max-height:190px;overflow:auto;margin-top:14px;border-top:1px solid var(--line);padding-top:8px}.j-log p{margin:0;padding:4px 0;font-size:13.5px;color:var(--muted)}
.j-bar{position:relative;height:38px;border-radius:6px;background:#1A0D33;border:1px solid rgba(201,155,255,.4);overflow:hidden;margin:6px 0 10px}.j-bar .z{position:absolute;top:0;bottom:0;background:rgba(181,123,255,.35);box-shadow:inset 0 0 14px rgba(201,155,255,.9)}.j-bar .c{position:absolute;top:0;bottom:0;width:2px;background:#F1E3FF}
.j-bar span{position:absolute;top:4px;bottom:4px;width:6px;border-radius:3px;background:#FFD24A;box-shadow:0 0 12px #FFD24A;animation:jmk var(--dur) ease-in-out infinite alternate}@keyframes jmk{from{left:0}to{left:calc(100% - 6px)}}
.j-create .j-cgrid{display:grid;grid-template-columns:minmax(0,1fr) minmax(260px,360px);gap:clamp(24px,5vw,70px);align-items:start;padding-bottom:80px}.j-form{display:grid;gap:22px}
.j-fs{border:1px solid var(--line-2);border-radius:6px;padding:16px 18px 18px;display:grid;gap:16px;margin:0;background:rgba(20,9,39,.7)}.j-fs legend{font-family:var(--display);font-weight:800;text-transform:uppercase;font-size:20px;padding:0 6px;color:var(--neon)}
.j-row2{display:grid;grid-template-columns:1fr 1fr;gap:12px}.j-row3{display:grid;grid-template-columns:1.2fr 1.4fr .7fr;gap:12px}.j-form label{display:grid;gap:6px;font-size:12.5px;color:var(--muted)}
.j-form input:not([type=range]):not([type=checkbox]),.j-form select{background:var(--turf);border:1px solid var(--line-2);color:var(--chalk);padding:11px 12px;border-radius:4px;font:inherit;font-size:16px;min-width:0}
.j-form input:focus,.j-form select:focus{outline:2px solid #C99BFF;border-color:transparent;box-shadow:0 0 18px -4px rgba(181,123,255,.9)}
.j-date{display:flex;align-items:center;gap:6px;color:var(--muted)}.j-date input{width:64px}
.j-range{display:grid;gap:8px}.j-range input{width:100%}
.j-sw{display:flex;gap:8px}.j-sw button{width:34px;height:34px;border-radius:50%;border:2px solid transparent}.j-sw button.on{border-color:#F1E3FF;box-shadow:0 0 14px rgba(201,155,255,.9)}
.j-go{justify-self:start;padding:14px 24px;font-size:16px}
.j-stage{position:sticky;top:24px;display:grid;place-items:center;padding:30px 10px;background:radial-gradient(closest-side,rgba(150,80,255,.35),transparent)}
.j-legend{padding-block:40px 90px}
.j-city{display:grid;grid-template-columns:minmax(0,1fr);gap:18px;margin-top:18px}
.j-city3d{position:relative;height:clamp(420px,74vh,880px);border-radius:8px;overflow:hidden;border:1px solid rgba(201,155,255,.45);box-shadow:0 0 44px -16px rgba(170,100,255,.9);cursor:grab;touch-action:pan-y;background:#0B0518}
.j-city3d:active{cursor:grabbing}.j-city-slot{position:absolute;inset:0}.j-city3d canvas{position:absolute;inset:0;width:100%!important;height:100%!important;display:block}
.j-city-fb{position:absolute;inset:0;display:grid;place-items:center}
.j-city-ui{position:absolute;left:12px;bottom:12px;display:flex;gap:6px;flex-wrap:wrap}.j-city-ui .btn{background:rgba(14,6,30,.82);backdrop-filter:blur(6px)}
.j-hlist{display:grid;grid-template-columns:repeat(auto-fill,minmax(min(100%,300px),1fr));column-gap:28px;margin-top:14px}.j-hrow{display:grid;grid-template-columns:1fr auto auto;gap:12px;align-items:center;padding:10px 0;border-top:1px solid var(--line)}
.j-hrow small{display:block;color:var(--muted);font-size:12.5px}.j-hrow em{font-style:normal;font-size:12.5px}
.j-pips{display:flex;gap:4px}.j-pips i{width:14px;height:6px;border-radius:3px;background:var(--turf-3)}.j-pips i.on{background:#C99BFF;box-shadow:0 0 8px rgba(201,155,255,.9)}
.j-house>.j-kv{max-width:620px}
.j-dec{margin:14px 0 4px;padding:14px 16px;border:1px solid #C99BFF;border-radius:8px;background:radial-gradient(500px 160px at 50% 0%,rgba(181,123,255,.25),transparent 70%),#170A2E;box-shadow:0 0 30px -10px rgba(181,123,255,.95);animation:jdec .35s cubic-bezier(.16,1,.3,1)}
@keyframes jdec{from{opacity:0;transform:translateY(10px)}}
.j-dec .j-sit b{color:var(--neon);margin-right:6px}
.j-dec-3d{position:absolute;left:12px;right:12px;bottom:12px;margin:0;z-index:6;background:rgba(18,8,38,.9);backdrop-filter:blur(6px)}
@media(max-width:640px){.j-dec-3d{left:6px;right:6px;bottom:6px;padding:10px}.j-dec-3d .j-opts{grid-template-columns:repeat(3,1fr);gap:6px}.j-dec-3d .j-op{padding:8px}.j-dec-3d .j-op small{font-size:10px}.j-dec-3d .j-sit{font-size:13.5px;margin-bottom:8px}}
.j-star-k{color:#E4CCFF;text-shadow:0 0 10px rgba(201,155,255,.95)}
body[data-mode=player] .feed p.j-hot{color:#F1E3FF;text-shadow:0 0 10px rgba(201,155,255,.8)}
.j-stage{position:static;display:grid;gap:22px;justify-items:center;align-content:start;min-width:0;width:100%}.j-stage>*{max-width:100%;min-width:0}#jc-prev{width:100%;display:grid;justify-items:center}
.j-aspect{width:100%;max-width:min(100%,380px);box-sizing:border-box;border:1px solid rgba(201,155,255,.5);border-radius:8px;background:radial-gradient(420px 260px at 50% 0%,rgba(150,80,255,.28),transparent 70%),#110722;box-shadow:0 0 0 1px rgba(181,123,255,.15),0 0 44px -16px rgba(170,100,255,.9);padding:16px 16px 18px;display:grid;gap:14px}
.j-panel .j-aspect{max-width:none;border:0;box-shadow:none;background:none;padding:0}
.j-asp-h{display:flex;align-items:baseline;justify-content:space-between;gap:12px}.j-asp-h h3{font-size:26px;text-shadow:0 0 16px rgba(201,155,255,.6)}.j-asp-h small{font-family:var(--mono);font-size:10.5px;letter-spacing:.12em;text-transform:uppercase;color:var(--muted)}
.j-3d{position:relative;height:340px;border-radius:6px;overflow:hidden;background:radial-gradient(closest-side at 50% 72%,rgba(181,123,255,.32),transparent),linear-gradient(180deg,#1a0c33,#0b0518);cursor:grab;touch-action:pan-y}
.j-3d:active{cursor:grabbing}.j-3d canvas{display:block;width:100%!important;height:100%!important;max-width:100%;position:absolute;inset:0}.j-3d-fb{position:absolute;inset:0;display:grid;place-items:center}
.j-asp-c{display:grid;gap:12px}.j-asp-c .j-grp h4{font-size:10.5px}
.j-sw.sm button{width:28px;height:28px}
.j-asp-row{display:grid;grid-template-columns:minmax(0,1fr);gap:12px}.j-aspect{grid-template-columns:minmax(0,1fr)}.j-sw{flex-wrap:wrap}
@media(max-width:980px){.j-ind>div:not(.j-big):nth-child(n+5){display:none}.j-brand{display:none}}
@media(max-width:820px){.j-shell{grid-template-columns:1fr;padding-top:0}.j-rail{position:sticky;top:62px;z-index:10;display:flex;overflow-x:auto;gap:4px;margin:0 calc(-1*max(16px,env(safe-area-inset-left)));padding:8px max(16px,env(safe-area-inset-left));background:rgba(9,4,18,.94);border-bottom:1px solid var(--line);scrollbar-width:none}.j-rl{white-space:nowrap;padding:8px 12px}.j-reset{margin-top:0!important}.j-rl span{display:none}.j-rl.on{box-shadow:inset 0 -2px 0 #C99BFF}
 .j-dg,.j-create .j-cgrid{grid-template-columns:1fr}.j-hero,.j-stage{position:static}.j-stage{order:-1;padding:6px}.j-row3{grid-template-columns:1fr 1fr}.j-cr{grid-template-columns:40px 80px 26px 1fr}.j-cr em{display:none}.j-hclub span{display:none}.j-ind{gap:12px}.j-ind>div:not(.j-big):nth-child(n+4){display:none}.j-m{grid-template-columns:110px 1fr 30px}.j-offer{grid-template-columns:44px 1fr}.j-offer-r{grid-column:2;text-align:left}}
@media(prefers-reduced-motion:reduce){.j-sheen,.j-card.big,.j-main,.j-rad{animation:none}.j-bar span{animation-duration:2.4s!important}}`;
document.head.appendChild(css);
if(UI.screen==='intro')render();
})();
