/* ====== Palco de Honor · MODO JUGADOR v2 · «El túnel morado» ======
   Carrera completa de un futbolista: creación, cantera, partidos con decisiones, entrenamiento, vestuario,
   contratos y agente, selección, premios, vida fuera del campo, noticias con decisiones, rivales de generación
   y modo leyenda. Usa los datos y utilidades del juego (CLUBS, LG, crest, esc, modal, money, render…).
   La media máxima de la carrera queda siempre entre 83 y 94: la fijan las decisiones (lp, oculto). */
(()=>{
'use strict';
/* Interruptor: true = el modo Jugador está disponible para todo el mundo (false lo deja «En desarrollo»). */
/* Acceso de prueba: abrir el juego con #probar-429d9da35498 lo activa en ese navegador (y #salir-pruebas lo desactiva). */
const TESTER_KEY='pdh-tester',TESTER_HASH='#probar-429d9da35498';
try{if(location.hash===TESTER_HASH)localStorage.setItem(TESTER_KEY,'1');if(location.hash==='#salir-pruebas')localStorage.removeItem(TESTER_KEY);}catch(e){}
const PLAYER_MODE_ON=true||(()=>{try{return localStorage.getItem(TESTER_KEY)==='1';}catch(e){return false;}})();
const KEY='pdh-player2',HALL='pdh-hall2';
const AT=['rit','tir','pas','reg','def','fis'];
const AN={rit:'Ritmo',tir:'Tiro',pas:'Pase',reg:'Regate',def:'Defensa',fis:'Físico'};
const ANP={...AN,def:'Paradas',rit:'Reflejos',tir:'Saque'};
const W={POR:[.15,0,.1,0,.55,.2],DEF:[.15,0,.1,.05,.45,.25],MED:[.1,.1,.35,.25,.1,.1],EXT:[.3,.15,.15,.3,0,.1],DEL:[.15,.35,.1,.2,0,.2]};
const POS={POR:'Portero',DEF:'Defensa',MED:'Centrocampista',EXT:'Extremo',DEL:'Delantero'};
const PERS={Líder:'Arrastra al vestuario. Más química y opciones de capitanía.',Humilde:'Cae bien a todos. Menos polémicas, menos focos.',Ambicioso:'Quiere más, siempre. Crece rápido, choca con el banquillo.',Rebelde:'Talento y carácter. Polémicas y momentos de genio.',Profesional:'Cuida cada detalle. Menos lesiones, carrera larga.'};
const STY={Regateador:'reg',Organizador:'pas',Goleador:'tir',Velocista:'rit',Todoterreno:'*'};
const ORIG={Cantera:'Academia de un club. Técnica y táctica, menos físico.','Equipo pequeño':'Un club humilde te vio crecer. Constancia y físico.','Fútbol callejero':'Barrio y cemento. Regate alto, táctica por pulir.','Promesa internacional':'Todos te conocen. Techo alto y presión máxima.'};
const DREAMS={champions:'Ganar la Champions',balon:'Ganar el Balón de Oro',capitan:'Ser capitán de mi club',mundial:'Ganar el Mundial',record:'Superar los 400 goles de carrera'};
const NAT={'España':[88,'UEFA'],'Argentina':[88,'CONMEBOL'],'Brasil':[87,'CONMEBOL'],'Francia':[89,'UEFA'],'Inglaterra':[87,'UEFA'],'Portugal':[86,'UEFA'],'Alemania':[86,'UEFA'],'Italia':[85,'UEFA'],'Países Bajos':[85,'UEFA'],'Bélgica':[83,'UEFA'],'Croacia':[82,'UEFA'],'Uruguay':[82,'CONMEBOL'],'Colombia':[81,'CONMEBOL'],'Marruecos':[81,'CAF'],'Senegal':[80,'CAF'],'México':[79,'CONCACAF'],'Estados Unidos':[78,'CONCACAF'],'Japón':[79,'AFC'],'Chile':[76,'CONMEBOL'],'Arabia Saudí':[72,'AFC']};
const CONT={UEFA:'Eurocopa',CONMEBOL:'Copa América',CONCACAF:'Copa Oro',CAF:'Copa África',AFC:'Copa Asiática'};
const SKIN=['#F6DCC8','#EBC0A0','#D4A07A','#B07850','#8A5A3B','#5E3B26','#3E271B'],HAIR=['Fade texturizado','Buzz cut','Rizos con fade','Melena','Man bun','Mohicano','Calvo','Crop francés','Tupé','Raya al lado','Edgar','Mullet','Trenzas','Rastas','Twists','Afro'],
HAIRC=['#16101C','#3B2416','#6E4424','#B07A3E','#D9B26A','#A8321E','#D9D4CC','#B57BFF'],BEARD=['Sin barba','Perilla','Barba corta','Barba poblada'],BOOTS=['#B57BFF','#F1E9FF','#FF5DA2','#3DE0C2','#FFD24A'],ACC=['Nada','Cinta','Muñequera','Mangas largas','Guantes'];
const FIRSTN=['Leo','Marco','Iker','Tomás','Nico','Joao','Hugo','Rafa','Enzo','Kai','Luca','Theo','Ilyas','Mateo','Bruno','Ansu','Dani','Ruben'];
const LASTN=['Ferreira','Moreau','Okafor','Lindqvist','Barros','Kovač','Santoro','Haddad','Müller','Ibarra','Dembélé','Rojas','Novak','Costa','Achraf','Vidal','Navarro','Gómez'];
const CUPW=[7,15,23,29,35],CUPN=['Dieciseisavos','Octavos','Cuartos','Semifinal','Final'];
const EURW=[4,9,13,26,32,37],EURN=['Fase de liga','Fase de liga','Fase de liga','Octavos','Semifinal','Final'];
const NATW=[10,20,30];

let P=null;try{P=JSON.parse(localStorage.getItem(KEY));if(P&&P.v!==2)P=null;}catch(e){P=null;}
if(P&&P.assets&&P.assets.includes('coche')){P.assets=P.assets.filter(a=>a!=='coche');P.cars=(P.cars||[]).concat('gt');}
const save=()=>{if(P&&P.st&&!save.busy){save.busy=1;try{achCheck();}catch(e){}save.busy=0;}try{localStorage.setItem(KEY,JSON.stringify(P));}catch(e){}};
const hall=()=>{try{return JSON.parse(localStorage.getItem(HALL))||[];}catch(e){return[];}};

const R=(a,b)=>a+Math.floor(Math.random()*(b-a+1)),pk=a=>a[R(0,a.length-1)],ch=p=>Math.random()<p;
const avg=a=>a.length?a.reduce((x,y)=>x+y,0)/a.length:0;
const f1=v=>(Math.round(v*10)/10).toFixed(1);
const eur=v=>v>=1e6?(v/1e6).toFixed(v>=1e7?0:1).replace('.',',')+' M€':v>=1e3?Math.round(v/1e3)+' K€':Math.round(v)+' €';
const poisson=l=>{let L=Math.exp(-l),k=0,p=1;do{k++;p*=Math.random();}while(p>L);return k-1;};
const club=id=>CLUBS[id];
/* solo clubes de las ligas jugables (el juego añade clubes UEFA sin liga propia) */
let _all=null;const ALL=()=>_all||(_all=Object.values(CLUBS).filter(k=>LG[k.league]&&LG[k.league].pyr&&(LG[k.league].pyr[k.tier]||[]).includes(k.id)));
const cname=id=>CLUBS[id]?CLUBS[id].name:'Sin club';
const clubStr=id=>CLUBS[id]?CLUBS[id].base:55;
const ovr=(p=P)=>Math.round(AT.reduce((s,k,i)=>s+p.at[k]*W[p.pos][i],0));
const ceil=()=>83+Math.round(11*clamp(P.lp,0,100)/100);
const natLevel=()=>P.age<17?'Sub-17':P.age<19?'Sub-19':P.age<21?'Sub-21':'Absoluta';
const country=id=>LG[CLUBS[id].league].country;
const reduced=()=>matchMedia('(prefers-reduced-motion: reduce)').matches;

/* ---------- creación ---------- */
UI.jc=UI.jc||{name:'',last:'',nat:'España',age:17,day:14,month:3,height:180,foot:'Derecha',pos:'DEL',pos2:'EXT',num:9,pers:'Ambicioso',style:'Goleador',origin:'Cantera',dream:'balon',skin:2,hair:0,hairc:0,beard:0,boots:0,acc:0};
UI.jt=UI.jt||'despacho';UI.jobj=UI.jobj||'auto';
function build(c){
  const base={Cantera:{pas:3,def:2,fis:-3},'Equipo pequeño':{fis:4,rit:1,reg:-2},'Fútbol callejero':{reg:6,def:-4,pas:-1},'Promesa internacional':{tir:2,reg:2,rit:2}}[c.origin];
  const posB={POR:{def:12,fis:4,rit:4},DEF:{def:10,fis:5},MED:{pas:8,reg:2},EXT:{rit:7,reg:5},DEL:{tir:8,rit:2}}[c.pos];
  const at={};AT.forEach(k=>{at[k]=clamp(54+R(-3,3)+(base[k]||0)+(posB[k]||0)+(STY[c.style]==='*'?3:STY[c.style]===k?8:0)+(c.age-17)*2,40,82);});
  if(c.height>=190){at.fis+=3;at.rit-=2;}else if(c.height<=170){at.reg+=3;at.fis-=2;}
  const lp0={Profesional:58,Humilde:53,Líder:52,Ambicioso:50,Rebelde:45}[c.pers];
  const p={v:2,...c,at,startAge:+c.age,lp:lp0,wf:c.origin==='Fútbol callejero'?3:2,sk:c.style==='Regateador'?3:2,xp:{},
    season:2026,week:1,squad:null,club:null,origin0:null,loan:null,contract:null,form:55,fat:10,mor:72,tru:45,fame:c.origin==='Promesa internacional'?22:6,chem:50,adapt:100,
    kit:'local',celeb:0,money:15000,assets:[],sponsors:[],followers:0,rep:{humilde:0,polemico:0,lider:0,mediatico:0},inj:0,focus:STY[c.style]==='*'?'fis':STY[c.style],intensity:'normal',free:'descanso',firstTrain:false,
    offers:[],news:[],pending:[],evCool:0,cal:[],cupAlive:true,eurAlive:true,pts:0,pld:0,
    st:{pj:0,tit:0,sup:0,g:0,a:0,cs:0,rt:[]},sea:null,hist:[],titles:[],awards:[],moves:[],sel:{caps:0,g:0,lvl:'',called:false,captain:false},
    rivals:[],captain:false,peak:0,dreamDone:false,retired:false,yearsAt:0,miniDone:false,promise:null,log:[]};
  /* media inicial fija: 60 */
  let g=0;while(ovr(p)!==60&&g++<300){const k=pk(AT),d=ovr(p)<60?1:-1;p.at[k]=clamp(p.at[k]+d,35,85);}
  return p;
}
function newSeason(){
  P.sea={club:P.club,pj:0,tit:0,sup:0,g:0,a:0,cs:0,rt:[],min:0,cup:'',eur:'',finalBest:0};
  P.pts=0;P.pld=0;P.cupAlive=true;P.eurAlive=eurQualified();P.week=1;P.miniDone=false;P.promise=null;
  const c=club(P.club),div=LG[c.league].pyr[c.tier].filter(i=>i!==P.club);
  P.cal=[];for(let w=1;w<=38;w++){
    if(NATW.includes(w)){P.cal.push({w,type:'sel'});continue;}
    const ci=CUPW.indexOf(w),ei=EURW.indexOf(w);
    if(ci>=0){const all=LG[c.league].pyr.flat().filter(i=>i!==P.club),strong=all.filter(i=>clubStr(i)>=62+ci*5),pool=strong.length?strong:all;P.cal.push({w,type:'copa',r:ci,opp:pk(pool),home:ch(.5)});continue;}
    if(ei>=0&&P.eurAlive){const pool=ALL().filter(k=>k.tier===0&&k.base>=77&&k.league!==c.league).map(k=>k.id);P.cal.push({w,type:'eur',r:ei,opp:pk(pool),home:ch(.5)});continue;}
    P.cal.push({w,type:'liga',opp:pk(div),home:w%2===0});
  }
}
const eurQualified=()=>{const c=club(P.club);return c.tier===0&&c.base>=78;};
function genRivals(){const used=new Set();P.rivals=[0,1,2].map(i=>{let n;do{n=pk(FIRSTN)+' '+pk(LASTN);}while(used.has(n));used.add(n);
  const natN=pk(Object.keys(NAT).filter(x=>x!==P.nat)),pos=pk(['DEL','EXT','MED','DEL']);
  const pool=ALL().filter(k=>k.tier<=1&&k.base<74).map(k=>k.id);
  return{name:n,nat:natN,pos,ovr:ovr()+R(-3,3),ceil:R(84,95),club:pk(pool),g:0,seaG:0,awards:[],titles:0};});}

/* ---------- utilidades de estado ---------- */
function news(t,kind){P.news.unshift({s:P.season,w:P.week,t,k:kind||''});P.news=P.news.slice(0,40);}
function grow(k,n=1){for(let i=0;i<n;i++){if(P.at[k]>=99)return;P.at[k]++;if(ovr()>ceil()){P.at[k]--;return;}}}
function role(){
  if(P.inj>0)return'Lesionado';if(P.ban>0)return'Sancionado';
  if(P.squad==='cantera')return'Cantera';
  const c=club(P.club),d=ovr()-(c.base-4)+(P.tru-50)/10-P.fat/25+(P.promise==='minutos'?3:0);
  if(P.captain&&d>=0)return'Capitán';
  return d>=2?'Titular':d>=-4?'Rotación':d>=-12||P.tru>=25?'Suplente':'Descartado';
}
const wageWeek=()=>P.contract?P.contract.wage:0;
function contractFor(cid,squad,extra={}){const b=clubStr(cid),o=ovr();
  const wage=Math.round(Math.max(squad==='cantera'?600:1500,Math.pow(Math.max(o-45,4),2.15)*(b/70)*6)/100)*100;
  return{club:cid,years:squad==='cantera'?3:R(2,5),wage,bonus:Math.round(wage*.3),clause:Math.round(wage*52*(squad==='cantera'?8:R(10,30))),promise:null,...extra};}
function rep(){const r=P.rep,k=Object.keys(r).sort((a,b)=>r[b]-r[a])[0];return r[k]<3?'Por definir':{humilde:'Humilde',polemico:'Polémico',lider:'Líder',mediatico:'Estrella mediática'}[k];}
function potText(){const s=P.hist.length,lo=83,hi=94,c=ceil();if(s===0)return'¿?';const spread=Math.max(0,5-s);return spread===0?String(c):`${clamp(c-spread,lo,hi)}–${clamp(c+spread,lo,hi)}`;}

/* ---------- vista: creación ---------- */
/* peinados actuales por vóxeles: la misma definición alimenta la figura 3D y el avatar 2D.
   Cada estilo dice qué celdas de una rejilla de 12 vóxeles por lado de cabeza llevan pelo (capa L, cara top/front/side/back,
   altura t de 0 a 1 sobre la cabeza) y qué degradado lleva el cuero cabelludo (fade). */
const HSTY=[
  {fade:'mid',hl:3,f:c=>c.top?c.L<=2+(c.r>.55)+(c.w>.3&&c.cr>.5):c.front?c.t>.9&&c.L===1&&c.r>.3:c.t>.82&&c.L===1},
  {fade:'buzz',hl:3},
  {fade:'high',hl:2,f:c=>c.top?c.L<=3+(c.cr>.5)+(c.r>.7):c.front?c.t>.76&&c.cr>.35&&c.L<=1+(c.r>.6):c.t>.8&&c.L===1},
  {fade:'full',hl:3,f:c=>c.top?c.L<=2+(c.r>.8):c.front?c.t>.86&&c.u>-.2&&c.L===1:c.side?c.t>-.15&&c.L<=(c.t>.35?2:1):c.t>-.55&&c.L<=2},
  {fade:'low',hl:3,bun:1,f:c=>c.top?c.L===1:c.front?false:c.t>(c.back?.3:.5)&&c.L===1},
  {fade:'skin',hl:0,hlc:1,f:c=>Math.abs(c.x)<2*c.v&&(c.top?c.L<=2+Math.round((c.w+1)*1.2)+(c.r>.6):c.back?c.t>.55&&c.L===1:false)},
  {fade:'bald',hl:0},
  {fade:'skin',hl:2,f:c=>c.top?c.L<=2+(c.r>.75):c.front?c.t>.8&&c.L===1&&c.r>.2:c.t>.9&&c.L===1},
  {fade:'mid',hl:2,f:c=>c.top?c.L<=1+Math.round((c.w+1)*1.6)+(c.r>.7):c.front?false:c.t>.8&&c.L===1},
  {fade:'low',hl:3,f:c=>c.top?(c.ix===-3?false:c.ix<-3?c.L===1:c.L<=2+(c.w>.4&&c.r>.5)):c.front?c.t>.9&&c.ix>-3&&c.L===1&&c.r>.25:c.t>.65&&c.L===1},
  {fade:'skin',hl:2,f:c=>c.top?c.L<=2:c.front?c.t>.73&&c.L===1:c.t>.9&&c.L===1},
  {fade:'mid',hl:3,f:c=>c.top?c.L<=2+(c.r>.6):c.front?c.t>.85&&c.L===1&&c.r>.4:c.side?c.t>.7&&c.L===1:c.t>-.45&&c.L<=(c.t<.4?2:1)&&Math.abs(c.u)<.85},
  {fade:'scalp',hl:2,shade:c=>(c.iz&1?.06:-.04),f:c=>c.L===1&&(c.top?(c.ix&1)===0:c.back?(c.ix&1)===0&&c.t>.1:c.side?(c.iz&1)===0&&c.t>.6:false)},
  {fade:'full',hl:2,shade:c=>((c.iy&1)?.05:-.03),f:c=>c.top?c.L<=2:c.front?c.t>.8&&(c.ix&1)===0&&c.L===1:c.side?(c.iz&1)===0&&c.t>-.15&&c.L===1:(c.ix&1)===0&&c.t>-.55&&c.L===1},
  {fade:'high',hl:2,shade:c=>(c.L>1?(c.iy&1?.06:-.02):-.05),f:c=>c.top?c.L===1||(((c.ix^c.iz)&1)===0&&c.L<=2+Math.floor(c.cr2*3)):c.front?c.t>.86&&(c.ix&1)===0&&c.L===1:c.t>.85&&c.L===1},
  {fade:'low',hl:2,afro:1,f:c=>{if(c.front&&c.t<.86||c.t<.38)return false;const v=c.v,e=(c.x/(c.hw+3.2*v))**2+((c.y-.12*c.hs)/(c.hh+3.6*v))**2+((c.z+.4*v)/(c.hd+3.2*v))**2;return e<=1&&!(e>.86&&c.r<.3);}}
];
function hairVox(style,hs){const S=HSTY[style]||HSTY[0];if(!S.f&&!S.bun)return [];
  const v=hs/12,hw=hs/2,hd=hs*.47,hh=hs/2,out=[];
  const hr=(a,b,c)=>{let h=(a*73856093)^(b*19349663)^(c*83492791);h=Math.imul(h^(h>>>13),1274126177);return ((h^(h>>>16))>>>0)/4294967296;};
  for(let ix=-9;ix<9;ix++)for(let iy=-14;iy<13;iy++)for(let iz=-9;iz<9;iz++){
    const x=(ix+.5)*v,y=(iy+.5)*v,z=(iz+.5)*v;
    const ex=Math.max(0,Math.abs(x)-hw)/v,ez=Math.max(0,Math.abs(z)-hd)/v,ey=Math.max(0,y-hh)/v,o=Math.max(ex,ey,ez);if(o<=0)continue;
    const top=ey>0&&ex===0&&ez===0,bun=S.bun&&Math.hypot(x,y-hh-2.2*v,z+hd-.4*v)<2.5*v;if(ey>0&&!top&&!S.afro&&!bun)continue;
    const L=Math.ceil(o-1e-6)+(top&&Math.max(Math.abs(x)/hw,Math.abs(z)/hd)>.8?1:0);
    const c={L,u:Math.max(-1,Math.min(1,x/hw)),w:Math.max(-1,Math.min(1,z/hd)),t:(y+hh)/hs,ix,iy,iz,x,y,z,v,hw,hd,hh,hs,top,
      front:!top&&z>hd&&ez>=ex,back:!top&&z<-hd&&ez>=ex,side:!top&&Math.abs(x)>hw&&ex>ez,r:hr(ix,iy,iz),cr:hr(ix>>1,3,iz>>1),cr2:hr(ix,11,iz)};
    if(bun||(S.f&&S.f(c)))out.push({x,y,z,L,r:c.r,k:(S.shade?S.shade(c):0)+(c.r-.5)*.1-(L===1?.04:0)+(top&&L>2?.03:0)+(bun?.03:0),ix,iy});}
  return out;}
/* aclara u oscurece un color hex (k en -1..1) */
function shadeHex(h,k){const n=parseInt(h.slice(1),16),f=x=>Math.max(0,Math.min(255,Math.round(k<0?x*(1+k):x+(255-x)*k)));
  return '#'+[n>>16,(n>>8)&255,n&255].map(f).map(x=>x.toString(16).padStart(2,'0')).join('');}
/* degradado del cuero cabelludo (fade) en píxeles con tramado ordenado */
const BAYER4=[0,8,2,10,12,4,14,6,3,11,1,9,15,7,13,5];
function fadeAt(S,t,px,py){const R={low:[.04,.3],mid:[.22,.58],high:[.42,.78],skin:[.56,.86],full:[-1,-.5],buzz:[-1,-.5],scalp:[-1,-.5],bald:[2,3]}[S.fade]||[2,3];
  const cov=Math.max(0,Math.min(1,(t-R[0])/(R[1]-R[0])));return cov>(BAYER4[(py&3)*4+(px&3)]+.5)/16;}
function avatar(p,size=120){const sk=SKIN[p.skin]??SKIN[2],K=kitOf(p),c={c1:K.s,c2:K.t},st=+p.hair||0,S=HSTY[st]||HSTY[0],hc=HAIRC[p.hairc||0],bd=+p.beard||0;
  const r=(x,y,w,h,f,o='')=>`<rect x="${x}" y="${y}" width="${w}" height="${h}" fill="${f}"${o}/>`;
  /* vista frontal de los mismos vóxeles del modelo 3D: solo lo que asoma por delante o fuera de la silueta de la cabeza */
  const k=52/.54,vs=k*.54/12,fr=new Map();hairVox(st,.54).forEach(q=>{if(!(q.z>.2538||Math.abs(q.x)>.27||q.y>.27))return;const id=q.ix+','+q.iy,o=fr.get(id);if(!o||q.z>o.z)fr.set(id,q);});
  const hair=[...fr.values()].sort((a,b)=>a.z-b.z).map(q=>r((60+q.x*k-vs/2).toFixed(1),(51-q.y*k-vs/2).toFixed(1),(vs+.4).toFixed(1),(vs+.4).toFixed(1),shadeHex(hc,q.k*2.2-(q.L>1?0:.04)))).join('');
  const line=S.hl?(S.hlc?r(53,25,14,S.hl*1.6+2,hc):r(34,25,52,S.hl*1.6,hc)+r(34,25,5,S.hl*1.6+3,hc)+r(81,25,5,S.hl*1.6+3,hc)):'';
  const beard=['',r(54,66,12,6,hc),r(36,62,48,10,hc,' opacity=".85"'),r(34,58,52,18,hc)][bd];
  return `<svg viewBox="0 0 120 120" width="${size}" height="${size}" role="img" aria-label="Aspecto del jugador"><rect x="2" y="2" width="116" height="116" rx="14" fill="#1a0c33"/>
  ${r(26,84,68,34,c.c1)}${r(26,84,68,5,c.c2)}${r(52,84,16,8,c.c2)}<text x="60" y="113" text-anchor="middle" font-family="Big Shoulders Display,Impact,sans-serif" font-weight="900" font-size="20" fill="${c.c2}">${p.num||9}</text>
  ${r(50,72,20,14,sk)}${r(34,25,52,52,sk)}${r(30,44,5,10,sk)}${r(85,44,5,10,sk)}${line}
  ${r(41,42,9,3,hc)}${r(70,42,9,3,hc)}${r(42,47,8,8,'#fff')}${r(70,47,8,8,'#fff')}${r(45,48,5,7,'#1b1430')}${r(73,48,5,7,'#1b1430')}
  ${r(58,56,4,6,'rgba(0,0,0,.18)')}${r(50,65,20,3,'#5a2430')}${r(48,63,3,2,'#5a2430')}${r(69,63,3,2,'#5a2430')}
  ${hair}${beard}${+p.acc===1?r(30,33,60,6,'#B57BFF'):''}</svg>`;}
function card(p,big){const o=ovr(p),cl=club(p.club);
  return `<div class="j-card${big?' big':''}" style="--boot:${BOOTS[p.boots]||BOOTS[0]}"><div class="j-sheen" aria-hidden="true"></div><div class="j-dorsal" aria-hidden="true">${p.num}</div>
  <div class="j-ovr"><b class="num">${o}</b><span>${p.pos}</span></div><div class="j-cl">${cl?crest(cl,34):'<span class="j-free">LIBRE</span>'}</div>
  <div class="j-av">${avatar(p,big?132:96)}</div>
  <div class="j-nm"><small>${esc(p.name||'Nombre')}</small><h3>${esc(p.last||'Apellido')}</h3></div>
  <div class="j-six">${AT.map(k=>`<div><b class="num">${p.at[k]}</b><small>${(p.pos==='POR'?ANP:AN)[k].slice(0,3)}</small></div>`).join('')}</div></div>`;}
function vCreate(){const c=UI.jc,chip=(k,arr,lab)=>`<div class="j-chips" role="radiogroup" aria-label="${lab}">${arr.map(v=>`<button class="j-chip${String(c[k])===String(v)?' on':''}" role="radio" aria-checked="${String(c[k])===String(v)}" data-act="jcf" data-k="${k}" data-v="${v}">${k==='pos'||k==='pos2'?POS[v]:v}</button>`).join('')}</div>`;
  const sw=(k,arr,lab)=>`<div class="j-sw" role="radiogroup" aria-label="${lab}">${arr.map((col,i)=>`<button class="${c[k]===i?'on':''}" role="radio" aria-checked="${c[k]===i}" aria-label="${lab} ${i+1}" data-act="jcf" data-k="${k}" data-v="${i}" data-n="1" style="background:${col}"></button>`).join('')}</div>`;
  const by=2026-c.age;
  return `<section class="screen wrap j-create"><button class="back" data-act="jExit">← Modos</button>
  <div class="j-cgrid"><div class="j-form">
   <div><div class="j-eyebrow">Modo Jugador · Ficha de alta</div><h2 class="j-h">Crea tu futbolista</h2><p class="muted" style="max-width:56ch">Empiezas entre los 16 y los 18 años con una media de 60. Tu techo está escondido: lo irán marcando tus decisiones, dentro y fuera del campo.</p></div>
   <fieldset class="j-fs"><legend>Identidad</legend>
    <div class="j-row2"><label>Nombre<input value="${esc(c.name)}" maxlength="14" autocomplete="off" data-in="name"></label><label>Apellido<input value="${esc(c.last)}" maxlength="16" autocomplete="off" data-in="last"></label></div>
    <div class="j-row3"><label>Nacionalidad<select data-in="nat">${Object.keys(NAT).map(n=>`<option${n===c.nat?' selected':''}>${n}</option>`).join('')}</select></label>
     <label>Nacimiento<span class="j-date"><input type="number" min="1" max="28" value="${c.day}" data-in="day" aria-label="Día">/<input type="number" min="1" max="12" value="${c.month}" data-in="month" aria-label="Mes">/<b class="num">${by}</b></span></label>
     <label>Dorsal<input type="number" min="1" max="99" value="${c.num}" data-in="num"></label></div>
    <div class="j-grp"><h4>Edad de inicio</h4>${chip('age',[16,17,18],'Edad')}</div></fieldset>
   <fieldset class="j-fs"><legend>Físico y posición</legend>
    <label class="j-range">Altura <b class="num">${c.height} cm</b><input type="range" min="160" max="200" value="${c.height}" data-in="height"></label>
    <div class="j-grp"><h4>Pierna dominante</h4>${chip('foot',['Derecha','Izquierda'],'Pierna')}</div>
    <div class="j-grp"><h4>Posición principal</h4>${chip('pos',Object.keys(POS),'Posición principal')}</div>
    <div class="j-grp"><h4>Posición secundaria</h4>${chip('pos2',Object.keys(POS),'Posición secundaria')}</div></fieldset>
   <fieldset class="j-fs"><legend>Carácter</legend>
    <div class="j-grp"><h4>Personalidad</h4>${chip('pers',Object.keys(PERS),'Personalidad')}<p class="j-hint">${PERS[c.pers]}</p></div>
    <div class="j-grp"><h4>Estilo de juego</h4>${chip('style',Object.keys(STY),'Estilo')}</div>
    <div class="j-grp"><h4>Historia de origen</h4>${chip('origin',Object.keys(ORIG),'Origen')}<p class="j-hint">${ORIG[c.origin]}</p></div>
    <div class="j-grp"><h4>Tu sueño</h4><div class="j-chips" role="radiogroup" aria-label="Sueño">${Object.entries(DREAMS).map(([k,v])=>`<button class="j-chip${c.dream===k?' on':''}" role="radio" aria-checked="${c.dream===k}" data-act="jcf" data-k="dream" data-v="${k}">${v}</button>`).join('')}</div></div></fieldset>
   <button class="btn primary j-go" data-act="jFound">Firmar la ficha y buscar club →</button></div>
  <div class="j-stage"><div id="jc-prev">${card({...build(c),club:null},true)}</div>${lookPanel(c,false)}</div></div></section>`;}

/* ---------- vista: juego ---------- */
const TABS=[['despacho','Despacho'],['jugador','Mi jugador'],['entreno','Entrenamiento'],['calendario','Calendario'],['agente','Agente y contratos'],['stats','Estadísticas'],['vida','Noticias y vida'],['familia','Familia y patrimonio'],['ciudad','Ciudad'],['palmares','Palmarés'],['album','Álbum de cartas']];
function meter(l,v,warn){v=clamp(v,0,100);return `<div class="j-m"><span>${l}</span><i><u style="width:${v}%" class="${warn&&v<35?'lo':''}"></u></i><b class="num">${Math.round(v)}</b></div>`;}
function hud(){const c=club(P.club);
  return `<header class="j-hud"><div class="j-hud-in">
   <button class="back" data-act="jExit">← Modos</button>
   <div class="j-brand">PALCO<span>JUGADOR</span></div>
   <div class="j-ind"><div class="j-big"><b class="num">${ovr()}</b><small>Media</small></div>
    <div><small>Forma</small><b class="num">${Math.round(P.form)}</b></div><div><small>Energía</small><b class="num ${P.fat>70?'bad':''}">${Math.round(100-P.fat)}</b></div>
    <div><small>Moral</small><b class="num">${Math.round(P.mor)}</b></div><div><small>Confianza</small><b class="num">${Math.round(P.tru)}</b></div>
    <div><small>Fama</small><b class="num">${Math.round(P.fame)}</b></div><div><small>Ahorros</small><b class="num">${eur(P.money)}</b></div></div>
   <div class="j-hclub">${c?crest(c,28):''}<span>${c?esc(c.name):'Sin club'}<small class="num">${seasonLabel(P.season)} · Semana ${P.week}</small></span></div></div></header>`;}
function rail(){return `<nav class="j-rail" aria-label="Secciones del modo Jugador">${TABS.map(([k,l],i)=>`<button class="j-rl${UI.jt===k?' on':''}" data-act="jTab" data-id="${k}" ${UI.jt===k?'aria-current="page"':''}><span class="num">${String(i+1).padStart(2,'0')}</span>${l}${k==='vida'&&P.pending.length?`<em class="j-dot" aria-label="${P.pending.length} decisiones pendientes">${P.pending.length}</em>`:''}${k==='agente'&&P.offers.length?`<em class="j-dot">${P.offers.length}</em>`:''}</button>`).join('')}</nav>`;}
function vGame(){if(P.retired)return P.coach&&!P.coach.done?vCoach():vLegend();
  const body=!P.club?vTrial():({despacho:vDesp,jugador:vJug,entreno:vEnt,calendario:vCal,agente:vAgent,stats:vStats,vida:vVida,ciudad:vCiudad,palmares:vPalm,familia:vFam,album:vAlbum})[UI.jt]();
  return hud()+`<div class="j-shell">${P.club?rail():''}<main class="j-main" id="jmain" tabindex="-1">${body}</main></div>`;}
function vTrial(){return `<div class="j-eyebrow">Semana de pruebas</div><h2 class="j-h">Tres clubes quieren verte</h2><p class="muted" style="max-width:60ch">Cada club ofrece un camino distinto. En un grande empiezas en la cantera y tendrás que ganarte el debut; en uno pequeño juegas antes, pero la vitrina queda lejos.</p>
  <div class="j-offers">${P.offers.map((o,i)=>`<button class="j-offer" data-act="jSign" data-i="${i}">${crest(club(o.club),58)}<div><h3>${esc(cname(o.club))}</h3><p class="muted">${esc(LG[club(o.club).league].country)} · ${o.squad==='cantera'?'Cantera · juvenil A':'Primer equipo'} · ${esc(o.note)}</p></div><div class="j-offer-r"><b class="num">${eur(o.wage)}</b><small>por semana · ${o.years} años</small></div></button>`).join('')}</div>`;}
const OBJ={auto:'Que decida el míster',marcar:'Marcar',asistir:'Dar una asistencia',recuperar:'Recuperar balones',posicion:'Mantener la posición'};
function nextEv(){return P.cal[P.week-1];}
const isMatch=e=>!!e&&(e.type==='liga'||(P.squad!=='cantera'&&((e.type==='copa'&&P.cupAlive)||(e.type==='eur'&&P.eurAlive))));
function evLabel(e){if(!e)return'';return e.type==='liga'?(P.squad==='cantera'?'Liga juvenil':LG[club(P.club).league].name):e.type==='copa'?'Copa · '+CUPN[e.r]:e.type==='eur'?'Champions · '+EURN[e.r]:e.type==='sel'?'Ventana de selecciones':'Semana sin partido';}
function vDesp(){const e=nextEv(),r=role(),c=club(P.club);
  const opp=e&&e.opp?club(e.opp):null;const youth=P.squad==='cantera'&&e&&e.type==='liga';
  let match='';
  if(P.inj>0)match=`<div class="j-next j-inj"><h3>Lesionado</h3><p>Te quedan <b class="num">${P.inj}</b> semana${P.inj>1?'s':''} de recuperación. Sigue el plan del fisio.</p><button class="btn primary" data-act="jWeek">Avanzar semana</button></div>`;
  else if(P.ban>0&&isMatch(e))match=`<div class="j-next j-inj"><h3>Sancionado</h3><p>Te quedan <b class="num">${P.ban}</b> partido${P.ban>1?'s':''} de sanción. Esta semana lo ves desde la grada.</p><button class="btn primary" data-act="jWeek">Avanzar semana</button></div>`;
  else if(!isMatch(e))match=`<div class="j-next"><div class="j-eyebrow">${e&&e.type==='sel'?evLabel(e):'Semana sin partido para ti'}</div><h3>${e&&e.type==='sel'?(P.sel.called?'Convocado con '+esc(P.nat_)+'':'Semana de entrenamiento'):'Semana de entrenamiento'}</h3><p class="muted">${e&&e.type==='sel'&&P.sel.called?'Juegas con la selección esta semana.':'Sin partido para ti: el trabajo de la semana cuenta igual.'}</p><button class="btn primary" data-act="${e&&e.type==='sel'&&P.sel.called?'jNat':'jWeek'}">${e&&e.type==='sel'&&P.sel.called?'Jugar con la selección':'Avanzar semana'}</button></div>`;
  else match=`<div class="j-next"><div class="j-eyebrow">${evLabel(e)} · ${e.home?'En casa':'Fuera'}</div>
    <div class="j-vs">${crest(c,64)}<b>VS</b>${youth?`<span class="j-yt">Juvenil<br>${esc(opp.short)}</span>`:crest(opp,64)}</div><h3>${youth?'Juvenil A':esc(c.short)} – ${youth?'Juvenil ':''}${esc(opp.name)}</h3>
    <p class="j-role">Tu rol · <b>${r}</b>${P.squad==='cantera'?'':` · ${r==='Titular'||r==='Capitán'?'sales de inicio':r==='Rotación'?'puedes salir de inicio':r==='Suplente'?'saldrás desde el banquillo si hay hueco':'no entras en la convocatoria'}`}</p>
    <div class="j-grp"><h4>Objetivo personal</h4><div class="j-chips">${Object.entries(OBJ).map(([k,v])=>`<button class="j-chip${UI.jobj===k?' on':''}" data-act="jObj" data-k="${k}">${v}</button>`).join('')}</div></div>
    <div class="j-acts"><button class="btn primary" data-act="jPlay">Jugar el partido</button><button class="btn" data-act="jSim">Simular</button></div></div>`;
  const dream=DREAMS[P.dream],tbl=table().slice(0,5);
  return `<div class="j-dg"><div class="j-hero">${card(P,true)}<p class="j-cap">${r==='Capitán'?'Capitán del equipo':r}${P.loan?` · cedido por ${esc(cname(P.loan.from))}`:''}</p></div>
  <div class="j-col">${match}
   <div class="j-panel"><h3>Estado</h3>${meter('Forma',P.form)}${meter('Energía',100-P.fat,1)}${meter('Moral',P.mor,1)}${meter('Confianza del míster',P.tru,1)}${meter('Química con el vestuario',P.chem,1)}${P.adapt<100?meter('Adaptación al país',P.adapt,1):''}</div>
   ${P.pending.length?`<div class="j-panel j-alert"><h3>Tienes ${P.pending.length} decisión${P.pending.length>1?'es':''} pendiente${P.pending.length>1?'s':''}</h3><button class="btn primary" data-act="jEvent">Decidir ahora</button></div>`:''}
   <div class="j-panel"><h3>Tu sueño</h3><p>${dream}${P.dreamDone?' · <b class="j-neon">cumplido</b>':''}</p></div>
   ${P.squad!=='cantera'?`<div class="j-panel"><h3>${esc(LG[c.league].name)} · ${c.tier===0?'1ª':c.tier+1+'ª'} categoría</h3><table class="j-t"><tbody>${tbl.map((t,i)=>`<tr class="${t.me?'me':''}"><td class="num">${i+1}</td><td>${esc(t.name)}</td><td class="num">${t.pts}</td></tr>`).join('')}</tbody></table></div>`:''}
   <div class="j-panel"><h3>Últimas noticias</h3>${P.news.slice(0,4).map(n=>`<p class="j-n"><b class="num">S${n.w}</b>${esc(n.t)}</p>`).join('')||'<p class="muted">Aún no hablan de ti.</p>'}</div>
  </div></div>`;}
function table(){const c=club(P.club);const ids=LG[c.league].pyr[c.tier];const prog=P.pld?P.pld/ (38-CUPW.length-NATW.length-(eurQualified()?EURW.length:0)):0;
  const rows=ids.map(id=>{if(id===P.club)return{name:club(id).name,pts:P.pts,me:true};const k=club(id),h=[...id+P.season].reduce((x,ch)=>(x*31+ch.charCodeAt(0))>>>0,7),rng=(h%1000)/1000-.5;return{name:k.name,pts:Math.round((1.3+(k.base-avgBase(ids))*.05+rng*.55)*P.pld)};});
  return rows.sort((a,b)=>b.pts-a.pts);}
const _ab={};function avgBase(ids){const k=ids.join();return _ab[k]??(_ab[k]=avg(ids.map(clubStr)));}
function skills(){const s=[];const a=P.at;
  if(a.tir>=80&&P.st.g>=30)s.push(['Disparo lejano','Tus tiros desde fuera del área entran más.']);
  if(a.pas>=80&&P.st.a>=25)s.push(['Pase al hueco','Ves líneas de pase que nadie ve.']);
  if(a.reg>=80&&P.sk>=4)s.push(['Regate en carrera','Superas rivales sin perder velocidad.']);
  if(a.def>=80)s.push([P.pos==='POR'?'Reflejos felinos':'Muro','Pocas cosas pasan por tu zona.']);
  if(a.fis>=80)s.push(['Pulmón','Te cansas menos en cada partido.']);
  if(a.rit>=85)s.push(['Bala','Tu arrancada rompe defensas.']);
  if(P.captain)s.push(['Brazalete','Tu voz pesa en el vestuario.']);
  if(P.st.pj>=150)s.push(['Veteranía','Lees el partido antes que los demás.']);
  return s;}
function stars(n){return '<span class="j-stars" aria-label="'+n+' de 5">'+[1,2,3,4,5].map(i=>`<i class="${i<=n?'on':''}"></i>`).join('')+'</span>';}
function radar(a,sz=240){const c=100,r=70,pt=(i,v)=>{const g=-Math.PI/2+i*Math.PI/3;return[(c+Math.cos(g)*r*v/99).toFixed(1),(c+Math.sin(g)*r*v/99).toFixed(1)];};const N=P.pos==='POR'?ANP:AN;
  const ring=v=>`<polygon points="${AT.map((k,i)=>pt(i,v).join(',')).join(' ')}" fill="none" stroke="rgba(214,190,255,.16)"/>`;
  return `<svg viewBox="0 0 200 200" width="${sz}" height="${sz}" role="img" aria-label="Radar de atributos">${[33,66,99].map(ring).join('')}${AT.map((k,i)=>{const e=pt(i,99),l=pt(i,118);return `<line x1="100" y1="100" x2="${e[0]}" y2="${e[1]}" stroke="rgba(214,190,255,.12)"/><text x="${l[0]}" y="${l[1]}" text-anchor="middle" dominant-baseline="middle" fill="#C9B4EE" font-size="9" font-family="JetBrains Mono,monospace">${N[k].slice(0,3).toUpperCase()}</text>`;}).join('')}<polygon class="j-rad" points="${AT.map((k,i)=>pt(i,a[k]).join(',')).join(' ')}" fill="rgba(181,123,255,.32)" stroke="#D2A8FF" stroke-width="2" stroke-linejoin="round"/></svg>`;}
function vJug(){const N=P.pos==='POR'?ANP:AN,sk=skills();
  return `<div class="j-dg"><div class="j-hero">${card(P,true)}</div><div class="j-col">
   <div><div class="j-eyebrow">${POS[P.pos]} · secundaria ${POS[P.pos2]}</div><h2 class="j-h">${esc(P.name)} ${esc(P.last)}</h2>
   <p class="muted">${P.age} años · nacido el ${P.day}/${P.month}/${2026-P.startAge} · ${esc(P.nat)} · ${P.height} cm · pierna ${P.foot.toLowerCase()} · ${P.style} · ${P.pers} · ${P.origin}</p></div>
   <div class="j-panel j-radar">${radar(P.at,250)}<div class="j-attrs">${AT.map(k=>meter(N[k],P.at[k])).join('')}</div></div>
   <div class="j-panel j-kv"><div><small>Pierna mala</small>${stars(P.wf)}</div><div><small>Filigranas</small>${stars(P.sk)}</div><div><small>Potencial</small><b class="num j-neon">${potText()}</b></div><div><small>Reputación</small><b>${rep()}</b></div></div>
   ${lookPanel(P,true)}${traitPanel()}${posPanel()}${chemPanel()}
   <div class="j-panel"><h3>Habilidades especiales</h3>${sk.length?`<div class="j-skills">${sk.map(s=>`<div><b>${s[0]}</b><small>${s[1]}</small></div>`).join('')}</div>`:'<p class="muted">Se desbloquean con experiencia: goles, asistencias, partidos y atributos por encima de 80.</p>'}</div>
  </div></div>`;}
const FOCUS={rit:['Velocidad','Ritmo'],fis:['Fuerza y resistencia','Físico'],tir:['Finalización','Tiro'],pas:['Técnica y pase','Pase'],reg:['Regate','Regate'],def:['Táctica y defensa','Defensa'],wf:['Pierna mala','Estrellas de pierna mala'],sk:['Filigranas','Estrellas de filigranas']};
const MINI={pases:['Pases','pas'],libres:['Tiros libres','tir'],penaltis:['Penaltis','tir'],regates:['Regates','reg']};
function vEnt(){const c=P.squad==='cantera';
  return `<div class="j-eyebrow">Plan de la semana</div><h2 class="j-h">Entrenamiento</h2><p class="muted" style="max-width:62ch">El foco y la intensidad se aplican cada semana. Entrenar fuerte acelera la mejora, pero la fatiga acumulada baja tu rendimiento y dispara el riesgo de lesión.</p>
  <div class="j-two"><div class="j-panel"><h3>Foco</h3><div class="j-foc">${Object.entries(FOCUS).map(([k,[l,s]])=>`<button class="j-fo${P.focus===k?' on':''}" data-act="jFocus" data-k="${k}"><span>${l}</span><b class="num">${k==='wf'?P.wf+'★':k==='sk'?P.sk+'★':P.at[k]}</b><i><u style="width:${k==='wf'||k==='sk'?(P[k]/5*100):P.at[k]}%"></u></i></button>`).join('')}</div></div>
  <div class="j-col"><div class="j-panel"><h3>Intensidad</h3><div class="j-chips">${['suave','normal','intensa'].map(v=>`<button class="j-chip${P.intensity===v?' on':''}" data-act="jInt" data-k="${v}">${v[0].toUpperCase()+v.slice(1)}</button>`).join('')}</div>
   ${c?`<label class="j-check"><input type="checkbox" data-in="firstTrain" ${P.firstTrain?'checked':''}> Entrenar con el primer equipo (más confianza, más fatiga)</label>`:''}
   <div style="margin-top:14px">${meter('Fatiga acumulada',P.fat)}</div></div>
   <div class="j-panel"><h3>Minijuego de la semana</h3><p class="muted">Un intento por semana. Para el marcador dentro de la zona: cuanto más centrado, más experiencia.</p><div class="j-chips">${Object.entries(MINI).map(([k,[l]])=>`<button class="j-chip" data-act="jMini" data-k="${k}" ${P.miniDone?'disabled':''}>${l}</button>`).join('')}</div>${P.miniDone?'<p class="j-hint">Ya has hecho el minijuego esta semana.</p>':''}</div></div></div>`;}
function vCal(){const rows=P.cal.slice(P.week-1,P.week+11);
  return `<div class="j-eyebrow">${seasonLabel(P.season)}</div><h2 class="j-h">Calendario</h2><div class="j-cal">${rows.map((e,i)=>{const o=e.opp&&club(e.opp);const off=e.type!=='sel'&&!isMatch(e)&&e.type!=='liga';
   return `<div class="j-cr${i?'':' now'}"><b class="num">S${e.w}</b><span class="j-tag t-${e.type}">${e.type==='liga'?(P.squad==='cantera'?'Juvenil':'Liga'):e.type==='copa'?'Copa':e.type==='eur'?'Champions':'Selección'}</span>${o&&!off?crest(o,26):'<i></i>'}<span>${off?'Eliminado · semana de entrenamiento':o?(P.squad==='cantera'&&e.type==='liga'?'Juvenil '+esc(o.short):esc(o.name)):(P.sel.called?'Convocatoria '+esc(P.sel.lvl):'Descanso y entrenamiento')}</span><em>${o&&!off?(e.home?'Local':'Visitante'):''}${e.r!=null&&!off?' · '+(e.type==='copa'?CUPN[e.r]:EURN[e.r]):''}</em></div>`;}).join('')}</div>`;}
function vAgent(){const k=P.contract;
  return `<div class="j-eyebrow">Tu agente: ${esc(P.agent||'Sin agente')}</div><h2 class="j-h">Agente y contratos</h2>
  <div class="j-two"><div class="j-panel"><h3>Contrato actual</h3>${k?`<div class="j-kv"><div><small>Club</small><b>${esc(cname(k.club))}</b></div><div><small>Años restantes</small><b class="num">${k.years}</b></div><div><small>Salario</small><b class="num">${eur(k.wage)}/sem</b></div><div><small>Prima por gol/asist.</small><b class="num">${eur(k.bonus)}</b></div><div><small>Cláusula</small><b class="num">${eur(k.clause)}</b></div><div><small>Promesa</small><b>${k.promise?{minutos:'Minutos',posicion:'Tu posición',titular:'Titularidad'}[k.promise]:'Ninguna'}</b></div></div>`:'<p class="muted">Sin contrato.</p>'}
   <div class="j-acts" style="margin-top:16px">${!P.agent?'<button class="btn" data-act="jAgent">Contratar un agente (10 % del salario)</button>':''}${P.squad!=='cantera'&&!P.loan?'<button class="btn" data-act="jLeave">Pedir salir del club</button>':''}<button class="btn" data-act="jTalk">Reunión con el entrenador</button></div></div>
  <div class="j-panel"><h3>Ofertas sobre la mesa</h3>${P.offers.length?P.offers.map((o,i)=>`<div class="j-of">${crest(club(o.club),44)}<div><b>${esc(cname(o.club))}</b><small>${o.loan?'Cesión de una temporada':o.renew?'Renovación':'Traspaso'} · ${esc(LG[club(o.club).league].country)} · rol ${o.role}${eurQualifiedId(o.club)?' · juega Champions':''}</small><small class="num">${eur(o.wage)}/sem · ${o.years} año${o.years>1?'s':''}${o.promise?' · promete '+{minutos:'minutos',posicion:'tu posición',titular:'titularidad'}[o.promise]:''}</small></div><div class="j-ofb"><button class="btn primary small" data-act="jAccept" data-i="${i}">Aceptar</button>${!o.neg?`<button class="btn small" data-act="jNeg" data-i="${i}">${P.agent?'Que negocie mi agente':'Negociar'}</button>`:''}<button class="btn small" data-act="jReject" data-i="${i}">Rechazar</button></div></div>`).join(''):'<p class="muted">No hay ofertas ahora. Llegan en las ventanas (semana 19 y fin de temporada) según tu nivel y tu fama.</p>'}</div></div>
  <div class="j-panel"><h3>Historial de traspasos</h3>${P.moves.length?`<table class="j-t"><thead><tr><th>Temporada</th><th>De</th><th>A</th><th>Tipo</th><th>Salario</th></tr></thead><tbody>${P.moves.map(m=>`<tr><td class="num">${m.s}</td><td>${esc(m.from)}</td><td>${esc(m.to)}</td><td>${m.t}</td><td class="num">${eur(m.wage)}/sem</td></tr>`).join('')}</tbody></table>`:'<p class="muted">Aún no has cambiado de club.</p>'}</div>`;}
const eurQualifiedId=id=>{const k=club(id);return k.tier===0&&k.base>=78;};
function vStats(){const s=P.st,av=s.rt.length?f1(avg(s.rt)):'—',best=P.hist.slice().sort((a,b)=>(b.g+b.a+b.n*3)-(a.g+a.a+a.n*3))[0];
  return `<div class="j-eyebrow">Carrera</div><h2 class="j-h">Estadísticas</h2>
  <div class="j-bigs"><div><b class="num">${s.pj}</b>partidos</div><div><b class="num">${s.g}</b>goles</div><div><b class="num">${s.a}</b>asistencias</div><div><b class="num">${av}</b>nota media</div><div><b class="num">${s.tit}</b>de titular</div><div><b class="num">${P.sel.caps}</b>internacional</div></div>
  <div class="j-two"><div class="j-panel"><h3>Últimas notas</h3><svg class="j-bars" viewBox="0 0 300 96" role="img" aria-label="Notas de los últimos partidos">${s.rt.slice(-12).map((v,i)=>`<rect x="${i*25+3}" y="${92-v*8.4}" width="19" height="${v*8.4}" rx="2" fill="${v>=7.5?'#D2A8FF':v>=6.5?'#9A63E8':'#4A2F86'}"/><text x="${i*25+12.5}" y="${86-v*8.4}" text-anchor="middle" font-size="8" fill="#E5D6FF" font-family="JetBrains Mono,monospace">${f1(v)}</text>`).join('')||'<text x="8" y="44" fill="#9C88C4" font-size="11">Sin partidos todavía</text>'}</svg></div>
  <div class="j-panel"><h3>Temporada actual</h3><div class="j-kv"><div><small>Partidos</small><b class="num">${P.sea.pj}</b></div><div><small>Goles</small><b class="num">${P.sea.g}</b></div><div><small>Asistencias</small><b class="num">${P.sea.a}</b></div><div><small>Nota</small><b class="num">${P.sea.rt.length?f1(avg(P.sea.rt)):'—'}</b></div><div><small>Minutos</small><b class="num">${P.sea.min}</b></div><div><small>Tarjetas</small><b class="num">${P.sea.yel||0} A · ${P.sea.red||0} R</b></div>${P.pos==='POR'?`<div><small>Porterías a cero</small><b class="num">${P.sea.cs}</b></div>`:''}</div></div></div>
  <div class="j-panel"><h3>Temporada a temporada</h3>${P.hist.length?`<table class="j-t"><thead><tr><th>Temporada</th><th>Club</th><th>Media</th><th>PJ</th><th>Tit.</th><th>Sup.</th><th>G</th><th>A</th><th>Nota</th></tr></thead><tbody>${P.hist.map(h=>`<tr class="${best===h?'me':''}"><td class="num">${h.s}</td><td>${esc(h.c)}</td><td class="num">${h.o}</td><td class="num">${h.pj}</td><td class="num">${h.tit}</td><td class="num">${h.sup}</td><td class="num">${h.g}</td><td class="num">${h.a}</td><td class="num">${h.n}</td></tr>`).join('')}</tbody></table>${best?`<p class="j-hint">Mejor temporada: ${best.s} en ${esc(best.c)}.</p>`:''}`:'<p class="muted">La primera temporada todavía no ha terminado.</p>'}</div>`;}
const SHOP=[['piso','Piso en la ciudad',60000,4],['casa','Casa con jardín',450000,6],['mansion','Mansión',2500000,8],['yate','Yate',6000000,5]];
const FREE={descanso:'Descansar',familia:'Familia y amigos',idioma:'Clases de idioma',benefico:'Evento benéfico',fiesta:'Salir de fiesta'};
function vVida(){return `<div class="j-eyebrow">Fuera del campo</div><h2 class="j-h">Noticias y vida</h2>
  ${P.pending.length?`<div class="j-panel j-alert"><h3>${P.pending.length} decisión${P.pending.length>1?'es':''} pendiente${P.pending.length>1?'s':''}</h3><button class="btn primary" data-act="jEvent">Decidir ahora</button></div>`:''}
  <div class="j-two"><div class="j-panel"><h3>Prensa y redes</h3><div class="j-kv"><div><small>Seguidores</small><b class="num">${P.followers.toLocaleString('es-ES')}</b></div><div><small>Fama</small><b class="num">${Math.round(P.fame)}</b></div><div><small>Reputación</small><b>${rep()}</b></div></div>
   <div class="j-feed">${P.news.slice(0,12).map(n=>`<p class="j-n ${n.k}"><b class="num">${seasonLabel(n.s).slice(2)} · S${n.w}</b>${esc(n.t)}</p>`).join('')||'<p class="muted">Sin noticias.</p>'}</div>${postsBlock()}</div>
  <div class="j-col"><div class="j-panel"><h3>Tiempo libre</h3><div class="j-chips">${Object.entries(FREE).map(([k,v])=>`<button class="j-chip${P.free===k?' on':''}" data-act="jFree" data-k="${k}">${v}</button>`).join('')}</div><p class="j-hint">${{descanso:'Recuperas más energía.',familia:'Sube la moral.',idioma:'Te adaptas antes si juegas fuera de tu país.',benefico:'Sube tu fama y tu imagen.',fiesta:'Subidón de moral… y de fatiga. El míster se entera.'}[P.free]}</p></div>
   <div class="j-panel"><h3>Patrocinadores</h3>${P.sponsors.length?P.sponsors.map(s=>`<p class="j-n"><b>${esc(s.brand)}</b>${eur(s.pay)}/temporada</p>`).join(''):'<p class="muted">Las marcas llegan con la fama.</p>'}</div>
   <div class="j-panel"><h3>Ahorros: <span class="num">${eur(P.money)}</span></h3><div class="j-shop">${SHOP.map(([k,l,price])=>`<button class="j-buy" data-act="jBuy" data-k="${k}" ${P.assets.includes(k)||P.money<price?'disabled':''}><span>${l}</span><b class="num">${P.assets.includes(k)?'Tuyo':eur(price)}</b></button>`).join('')}</div></div></div></div>`;}
const TROPHY='<svg viewBox="0 0 40 48" width="40" height="48" aria-hidden="true"><path d="M10 4h20v10a10 10 0 0 1-20 0z" fill="currentColor"/><path d="M10 7H4a6 6 0 0 0 6 8M30 7h6a6 6 0 0 1-6 8" stroke="currentColor" stroke-width="2.5" fill="none"/><rect x="17" y="24" width="6" height="10" fill="currentColor"/><rect x="11" y="34" width="18" height="6" rx="1" fill="currentColor"/></svg>';
function vPalm(){const T=P.titles,A=P.awards;
  return `<div class="j-eyebrow">Legado</div><h2 class="j-h">Palmarés</h2>
  <div class="j-bigs"><div><b class="num">${T.length}</b>títulos</div><div><b class="num">${A.length}</b>premios</div><div><b class="num">${P.peak||ovr()}</b>media máxima</div><div><b class="num">${P.sel.g}</b>goles con ${esc(P.nat_||P.nat)}</div></div>
  <div class="j-panel"><h3>Vitrina</h3>${T.length||A.length?`<div class="j-gal">${[...T.map(t=>({n:t.n,s:t.s,c:t.c,k:'t'})),...A.map(a=>({n:a.n,s:a.s,c:'',k:'a'}))].map(x=>`<div class="j-tro ${x.k}">${TROPHY}<b>${esc(x.n)}</b><small>${x.s}${x.c?' · '+esc(x.c):''}</small></div>`).join('')}</div>`:'<p class="muted">La vitrina espera su primer trofeo.</p>'}</div>
  ${achPanel()}<div class="j-two"><div class="j-panel"><h3>Récords</h3>${records().map(r=>`<p class="j-n"><b>${r[0]}</b>${r[1]}</p>`).join('')}</div>
  <div class="j-panel"><h3>Rivales de tu generación</h3>${P.rivals.map(r=>`<div class="j-riv">${crest(club(r.club),30)}<div><b>${esc(r.name)}</b><small>${esc(r.nat)} · ${r.pos} · ${esc(cname(r.club))}</small></div><b class="num">${Math.round(r.ovr)}</b></div>`).join('')}</div></div>
  <div class="j-acts">${P.age>=33?'<button class="btn" data-act="jRetire">Anunciar la retirada</button>':''}</div>`;}
function records(){const r=[];const bySeason=P.hist.slice().sort((a,b)=>b.g-a.g)[0];
  r.push(['Máximo goleador de una temporada',bySeason?`${bySeason.g} goles (${bySeason.s})`:'—']);
  const clubs={};P.hist.forEach(h=>{clubs[h.c]=(clubs[h.c]||0)+h.g;});const top=Object.entries(clubs).sort((a,b)=>b[1]-a[1])[0];
  r.push(['Club donde más has marcado',top?`${esc(top[0])} · ${top[1]} goles`:'—']);
  r.push(['Partidos internacionales',`${P.sel.caps} (${P.sel.g} goles)`]);
  if(P.st.g>=200)r.push(['Leyenda goleadora','Más de 200 goles en tu carrera']);
  return r;}
function vLegend(){const H=hall();
  return `<section class="screen wrap j-legend"><div class="j-eyebrow">Modo leyenda</div><h2 class="j-h">${esc(P.name)} ${esc(P.last)}</h2>
  <p class="muted" style="max-width:60ch">Colgaste las botas a los ${P.retAge||P.age} años. Tu media máxima fue <b class="j-neon num">${P.peak}</b>.</p>
  <div class="j-bigs"><div><b class="num">${P.st.pj}</b>partidos</div><div><b class="num">${P.st.g}</b>goles</div><div><b class="num">${P.st.a}</b>asistencias</div><div><b class="num">${P.titles.length}</b>títulos</div><div><b class="num">${P.awards.length}</b>premios</div></div>
  <div class="j-two"><div class="j-panel"><h3>Lo que dejaste atrás</h3>${(P.after||[]).map(a=>`<p class="j-n">${esc(a)}</p>`).join('')}</div>
  <div class="j-panel"><h3>Salón de leyendas</h3>${H.map(h=>`<p class="j-n"><b class="num">${h.peak}</b>${esc(h.name)} · ${h.g} goles · ${h.t} títulos</p>`).join('')}</div></div>
  ${legendExtra()}<div class="j-acts"><button class="btn" data-act="jDoc" data-i="0">Ver el documental de tu carrera</button>${!P.coach?'<button class="btn primary" data-act="jCoachStart">Empezar como entrenador</button>':''}<button class="btn${P.coach?' primary':''}" data-act="jNew">Empezar otra carrera</button><button class="btn" data-act="jExit">Volver a los modos</button></div></section>`;}

/* ---------- partido ---------- */
function minutesFor(r,e){if(r==='Lesionado'||r==='Descartado'||r==='Sancionado')return 0;
  if(P.squad==='cantera')return e.type==='liga'?(ovr()>=62?R(75,90):R(30,90)):0;
  if(r==='Titular'||r==='Capitán')return 90;if(r==='Rotación')return ch(.55)?90:R(15,35);return ch(.4)?R(5,25):0;}
function chanceP(k,bonus=0){const a=P.at[k],opp=UI.jm?UI.jm.oppS:65;return clamp(.3+(a-opp)/110+(P.form-50)/320-P.fat/650+bonus+xBonus(k)-(100-P.adapt)/400,.06,.72);}
function makeMoments(n){const out=[],att=P.pos!=='DEF'&&P.pos!=='POR',ms=[];for(let i=0;i<n;i++)ms.push(R(4,88));ms.sort((a,b)=>a-b);
  ms.forEach(m=>{const def=P.pos==='POR'||P.pos==='DEF'||(P.pos==='MED'&&ch(.4))||(!att&&ch(.7));
    const fm=fpMoment(m,att&&!def);if(fm){out.push(fm);return;}
    if(P.pos==='POR')out.push({m,kind:'gk',text:pk(['Mano a mano: el delantero rival se planta solo.','Disparo raso y potente desde la frontal.','Centro bombeado al segundo palo.']),opts:[['Estirada','def',0],['Salir a por ella','rit',-.04],['Aguantar de pie','def',.05]]});
    else if(def)out.push({m,kind:'def',text:pk(['El rival conduce hacia tu zona.','Contra rápida por tu banda.','Balón dividido en el centro del campo.']),opts:[['Entrada','def',.04],['Temporizar','def',.08],['Anticipar','rit',0]]});
    else out.push({m,kind:'att',text:pk(['Recibes de espaldas en la frontal.','Te quedas solo en la banda con espacio.','Rechace en el área: el balón cae a tus pies.','Contraataque: vas lanzado hacia la portería.']),opts:[['Chutar','tir',0],['Pasar','pas',.12],['Regatear','reg',.02]]});});
  return out;}
function startMatch(interactive){const e=nextEv(),r=role(),opp=club(e.opp),youth=P.squad==='cantera';
  const min=minutesFor(r,e),oppS=youth?clamp(opp.base-14,40,70):opp.base;
  const n=min?clamp(Math.round(min/90*({POR:3,DEF:2,MED:2,EXT:3,DEL:3}[P.pos])+R(0,1)),1,4):0;
  UI.jm={e,r,min,oppS,youth,interactive,mom:makeMoments(n),i:0,res:{g:0,a:0,ok:0,ko:0,saves:0,log:[]}};
  if(!interactive||!n){UI.jm.mom.forEach(mo=>{if(UI.jm.res.redMin)return;const pref={DEL:{Chutar:1,Pasar:.55,Regatear:.75},EXT:{Chutar:.7,Pasar:.95,Regatear:.95},MED:{Chutar:.5,Pasar:1.15,Regatear:.7},DEF:{},POR:{}}[P.pos];
    const best=mo.opts.map((o,j)=>[j,chanceP(o[1],o[2])*(pref[o[0]]??1)*(.85+Math.random()*.3)]).sort((a,b)=>b[1]-a[1])[0][0];resolveMoment(mo,best);});finishMatch();}
  else showMoment();}
function resolveMoment(mo,j){const R0=UI.jm.res,g0=R0.g;if(mo.kind==='fp')return fpResolve(mo,R0);const o=mo.opts[j],p=chanceP(o[1],o[2]),ok=Math.random()<p;
  let t='';
  if(mo.kind==='att'){if(o[0]==='Chutar'){if(ok&&ch(.5)){R0.g++;t=`¡GOL! ${P.last} define con la ${P.foot==='Derecha'?'derecha':'izquierda'}.`;}else if(ok){R0.ok++;t='Disparo a puerta: el portero la saca con una gran parada.';}else{R0.ko+=.5;t='El disparo se marcha fuera por poco.';}}
    else if(o[0]==='Pasar'){if(ok&&ch(.5)){R0.a++;const mt=pickMate();mt.c=clamp(mt.c+6,0,100);R0.mate=mt.n;t=`Pase de gol: ${mt.n} solo tiene que empujarla.`;}else if(ok){R0.ok++;t='Buen pase, la jugada sigue viva.';}else{R0.ko++;t='Pase interceptado.';}}
    else{if(ok){R0.ok++;if(Math.random()<chanceP('tir',.06)*.55){R0.g++;t='Regate, recorte y gol. Golazo.';}else t='Te quitas a dos, pero el portero tapa el remate.';}else{R0.ko++;t='Te roban el balón en la conducción.';}}}
  else if(mo.kind==='def'){if(ok){R0.ok++;t=o[0]==='Entrada'?'Entrada limpia: balón recuperado.':o[0]==='Anticipar'?'Lees el pase y lo cortas.':'Temporizas y el rival se queda sin opciones.';}else{R0.ko++;if(o[0]==='Entrada'&&ch(.35)){if(ch(.04+Math.min(8,P.rep.polemico)/200)){R0.redMin=mo.m;t='Entrada a destiempo: ¡tarjeta roja directa!';}else{R0.yel=(R0.yel||0)+1;if(R0.yel>=2){R0.redMin=mo.m;t='Llegas tarde otra vez: segunda amarilla y a la calle.';}else t='Llegas tarde: tarjeta amarilla.';}}else t='El rival se te escapa.';}}
  else{if(ok){R0.saves++;R0.ok++;t='¡Paradón!';}else{R0.ko++;t='No llegas: gol del rival.';R0.conc=(R0.conc||0)+1;}}
  if(R0.g>g0)t+=` Lo celebra: ${celebName()}.`;
  R0.log.push(`${mo.m}' ${t}`);return{ok,t};}
function showMoment(){const M=UI.jm,mo=M.mom[M.i];
  if(mo.kind==='fp'){modal(`<div class="hd j-mhd"><h3>${evLabel(M.e)} · minuto ${mo.m}'</h3></div><div class="bd"><p class="j-sit">${mo.text}</p><div id="fpbox"></div></div>`);startFp(document.getElementById('fpbox'),mo.fk,out=>{mo.out=out;ACT.jMo({j:0});});return;}
  modal(`<div class="hd j-mhd"><h3>${evLabel(M.e)} · minuto ${mo.m}'</h3></div><div class="bd"><p class="j-sit">${mo.text}</p>
   <div class="j-opts">${mo.opts.map((o,j)=>`<button class="j-op" data-act="jMo" data-j="${j}"><b>${o[0]}</b><small>${(P.pos==='POR'?ANP:AN)[o[1]]} · ${Math.round(chanceP(o[1],o[2])*100)} %</small></button>`).join('')}</div>
   <p class="j-hint">Momento ${M.i+1} de ${M.mom.length}. Controlas solo a tu futbolista.</p>${M.last?`<p class="j-last">${M.last}</p>`:''}</div>`);}
function finishMatch(){const M=UI.jm,e=M.e,c=club(P.club),opp=club(e.opp),R0=M.res,youth=M.youth;
  let min=M.min;if(R0.redMin)min=Math.max(1,Math.min(M.min,R0.redMin-(90-M.min)));const own=(youth?clamp(c.base-14,40,72):c.base)+(min?(ovr()-c.base)*.07*min/90:0)+(e.home?2:-1),oS=M.oppS;
  let gf=Math.max(poisson(1.3*Math.exp((own-oS)/14)),R0.g+R0.a),ga=poisson(1.3*Math.exp((oS-own)/14));if(P.pos==='POR')ga=Math.max(ga-R0.saves+(R0.conc||0),R0.conc||0);if(M.pre){gf=M.pre.gf;ga=M.pre.ga;}
  let rt=0,obj=UI.jobj,met=false,sub=0;
  if(min){rt=6+R0.g*1.1+R0.a*.75+R0.ok*.3-R0.ko*.28+(gf>ga?.3:gf<ga?-.3:0)+(P.form-50)/100+(P.chem-50)/150-(100-P.adapt)/170+(Math.random()-.5)*.8;
    if(P.pos==='POR')rt+=ga===0?.8:-ga*.3;if(P.pos==='DEF'&&ga===0)rt+=.4;
    if(obj==='auto')obj=P.pos==='DEL'?'marcar':P.pos==='MED'||P.pos==='EXT'?'asistir':'recuperar';
    met=obj==='marcar'?R0.g>0:obj==='asistir'?R0.a>0:obj==='recuperar'?R0.ok>=2:R0.ko===0&&min>=60;rt+=met?.5:-.2;if(R0.redMin)rt-=1.6;rt=clamp(rt,1,10);
    if(min===90&&(rt<5.2||P.fat>80)&&!youth&&ch(.7)){sub=R(58,72);min=sub;}}
  const knock=e.type==='copa'||(e.type==='eur'&&e.r>=3);let et='',pens=null;
  if(knock&&gf===ga){if(ch(.5)){gf+=ch(.5)?1:0;ga+=gf===ga?(ch(.5)?1:0):0;et=' (prórroga)';}if(gf===ga)pens={me:min>0};}
  const stop=R(1,6);
  UI.jm.final={gf,ga,rt:+f1(rt),min,met,obj,sub,stop,et,pens,knock};
  if(pens){showPens();return;}
  applyMatch();}
function showPens(){const F=UI.jm.final;
  if(!F.pens.me){F.won=ch(.5);applyMatch();return;}
  modal(`<div class="hd j-mhd"><h3>Tanda de penaltis</h3></div><div class="bd"><p class="j-sit">Te toca tirar el quinto. Todo depende de ti.</p><div id="fpbox"></div></div>`);
  startFp(document.getElementById('fpbox'),'pen',out=>{const scored=out==='goal';if(scored)flag('pen');F.won=ch(scored?.62:.32);UI.jm.res.log.push(scored?'Tu penalti en la tanda: ¡dentro!':'Tu penalti en la tanda: fallado.');applyMatch();});}
function applyMatch(){const M=UI.jm,F=M.final,e=M.e,R0=M.res,c=club(P.club),opp=club(e.opp);
  const won=F.pens?F.won:F.gf>F.ga,draw=!F.pens&&F.gf===F.ga,res=won?'V':draw?'E':'D';
  if(F.min){P.st.pj++;P.sea.pj++;P.sea.min+=F.min;P.st.rt.push(F.rt);P.sea.rt.push(F.rt);P.st.g+=R0.g;P.sea.g+=R0.g;P.st.a+=R0.a;P.sea.a+=R0.a;
    if(M.min===90){P.st.tit++;P.sea.tit++;}else{P.st.sup++;P.sea.sup++;}if(F.ga===0&&(P.pos==='POR'||P.pos==='DEF')){P.st.cs++;P.sea.cs++;}
    P.money+=(R0.g+R0.a)*(P.contract?P.contract.bonus:0);}
  if(e.type==='liga'&&!M.youth){P.pld++;P.pts+=won?3:draw?1:0;}
  if(e.type==='copa'){if(!won){P.cupAlive=false;P.sea.cup=CUPN[e.r];}else if(e.r===4){P.sea.cup='Campeón';title('Copa');if(F.rt>=8)award('Mejor jugador de la final de Copa');}}
  if(e.type==='eur'&&e.r>=3){if(!won){P.eurAlive=false;P.sea.eur=EURN[e.r];}else if(e.r===5){P.sea.eur='Campeón';title('Champions League');if(F.rt>=8)award('Mejor jugador de la final de Champions');if(P.dream==='champions')dream();}}
  cardsAfter(R0);if(R0.g>=3)flag('hat');if(F.min&&F.rt>=9.5)flag('perfect');
  if(F.min){chemAfterMatch();if(e.type!=='liga'&&!M.youth)(P.sea.big=P.sea.big||[]).push(F.rt);if(R0.g>0)celebFx(e);}
  // efectos personales
  const k=F.min?F.rt-6.2:0;
  P.form=clamp(P.form+(F.min?k*5*(hasT('irregular')?1.6:1):-2),10,99);P.mor=clamp(P.mor+(F.min?(F.rt>=7?4:F.rt<5.5?-4:1):-3)+(won?2:draw?0:-1),5,100);
  P.tru=clamp(P.tru+(F.min?(F.rt>=7?3:F.rt<5.5?-3:1)+(F.met?2:0):-1),0,100);P.fame=clamp(P.fame+(F.min?Math.max(0,F.rt-6.5)*(M.youth?.3:1)+R0.g*.6:0)+(e.type==='eur'?.5:0),0,100);
  P.fat=clamp(P.fat+F.min/90*14,0,100);
  xp(P.focus,F.min?(F.min/90*1.2+(F.rt-6)*.8):0);
  if(M.youth&&F.min&&F.rt>=7.5)P.tru=clamp(P.tru+2,0,100);
  const lines=[...R0.log];if(F.sub)lines.push(`${F.sub}' El entrenador te sustituye${P.fat>80?' por cansancio':''}.`);lines.push(`90+${F.stop}' Final${F.et}.`);
  const verdict=!F.min?'No has jugado':F.rt>=8.5?'Actuación de leyenda':F.rt>=7.5?'Partidazo':F.rt>=6.5?'Buen partido':F.rt>=5.5?'Cumples sin brillar':'Noche para olvidar';
  const comment=!F.min?'Te quedas en el banquillo. El míster espera más de ti en los entrenamientos.':F.rt>=8?`La prensa habla de ti: ${P.last} fue el mejor sobre el césped.`:F.rt<5.5?'Partido gris. Toca levantarse el lunes.':'Partido correcto. Sigues sumando.';
  if(F.min&&F.rt>=8.5)news(`Exhibición de ${P.last} ante ${opp.name}: nota ${f1(F.rt)}.`,'hot');if(R0.g>=3)news(`¡Hat-trick de ${P.last}!`,'hot');
  const passes=F.min?Math.round(F.min/90*(18+P.at.pas/3)):0,acc=F.min?clamp(Math.round(60+P.at.pas/3+R(-6,6)),40,98):0;
  modal(`<div class="hd j-mhd"><h3>${({V:'Victoria',E:'Empate',D:'Derrota'})[res]} · ${M.youth?'Juvenil':esc(c.short)} ${F.gf}-${F.ga} ${esc(opp.short)}${F.pens?` · ${F.won?'gana':'pierde'} en penaltis`:''}</h3></div><div class="bd">
   <div class="j-note"><b class="num" id="j-rt">${F.min?f1(F.rt):'–'}</b><span>${verdict}${F.min?`<small>${F.met?'Objetivo cumplido':'Objetivo no cumplido'}: ${OBJ[F.obj]}</small>`:''}</span></div>
   <div class="j-kv"><div><small>Minutos</small><b class="num">${F.min}</b></div><div><small>Goles</small><b class="num">${R0.g}</b></div><div><small>Asistencias</small><b class="num">${R0.a}</b></div><div><small>Pases</small><b class="num">${passes} · ${acc} %</b></div><div><small>Duelos ganados</small><b class="num">${R0.ok}</b></div><div><small>Errores</small><b class="num">${Math.round(R0.ko)}</b></div></div>
   <div class="j-log">${lines.map(l=>`<p>${esc(l)}</p>`).join('')}</div><p class="j-hint">${comment}</p>${socialBlock(F,won)}
   <div style="margin-top:14px"><button class="btn primary" data-act="jAfter" data-focus>Seguir</button></div></div>`);
  const el=document.getElementById('j-rt');if(el&&F.min&&!reduced()){const t0=performance.now(),go=t=>{const q=Math.min(1,(t-t0)/900);el.textContent=f1(F.rt*(1-Math.pow(1-q,4)));if(q<1)requestAnimationFrame(go);};requestAnimationFrame(go);}
  UI.jm.done=true;}

/* ---------- semana, temporada ---------- */
function xp(k,amt){if(amt<=0)return;const ageF=P.age<20?1.35:P.age<24?1.1:P.age<28?.8:.45;P.xp[k]=(P.xp[k]||0)+amt*ageF;
  const need=k==='wf'||k==='sk'?40:10;while(P.xp[k]>=need){P.xp[k]-=need;if(k==='wf'||k==='sk'){if(P[k]<5){P[k]++;news(`${P.last} mejora ${k==='wf'?'su pierna mala':'sus filigranas'}: ${P[k]} estrellas.`);}}else grow(k);}}
function week(){
  const mult={suave:.6,normal:1,intensa:1.5}[P.intensity];
  {const e0=nextEv();if(P.banNew)P.banNew=false;else if(P.ban>0&&isMatch(e0))P.ban--;}if(P.intensity==='intensa')P.sea.hard=(P.sea.hard||0)+1;if(P.free==='fiesta')P.sea.party=(P.sea.party||0)+1;petWeek();
  if(P.inj>0){P.inj--;P.fat=clamp(P.fat-15,0,100);if(!P.inj)news(`${P.last} recibe el alta médica.`);}
  else{const fk=P.focus;xp(fk,2.2*mult);if(fk!=='wf'&&fk!=='sk'&&ch(.3))xp(pk(AT),1);
    P.fat=clamp(P.fat+{suave:3,normal:8,intensa:15}[P.intensity]+(P.firstTrain?5:0)-(P.free==='descanso'?17:12)-(P.at.fis>=80?3:0)-(hasT('pulmon')?3:0),0,100);
    if(P.firstTrain&&P.squad==='cantera')P.tru=clamp(P.tru+2,0,100);
    if(P.intensity==='normal')P.lp+=.03;
    const risk=(P.fat>72?(P.fat-70)/120*(P.pers==='Profesional'?.6:1):0)*(hasT('cristal')?1.6:1)+(hasT('cristal')?.008:0);
    if(ch(risk)){P.sea.inj=(P.sea.inj||0)+1;P.inj=R(1,6)+(P.fat>90?3:0);P.fat=40;P.mor-=8;if(P.intensity==='intensa')P.lp-=2;news(`Una lesión apartará a ${P.last} ${P.inj} semanas de los terrenos de juego.`,'bad');
      event('lesion');}}
  // tiempo libre
  ({familia:()=>{P.mor=clamp(P.mor+3+(fam().partner||fam().kids.length?2:0),0,100);P.lp+=.04;},idioma:()=>{P.adapt=clamp(P.adapt+10,0,100);P.lp+=.03;},benefico:()=>{P.fame=clamp(P.fame+.8,0,100);P.rep.humilde+=.3;P.lp+=.05;},fiesta:()=>{P.mor=clamp(P.mor+5,0,100);P.fat=clamp(P.fat+8,0,100);P.lp-=1;P.rep.polemico+=.4;if(ch(.25)){P.tru=clamp(P.tru-6,0,100);news(`Polémica: ${P.last} fotografiado de fiesta a dos días del partido.`,'bad');}},descanso:()=>{P.lp+=.02;}})[P.free]();
  P.adapt=clamp(P.adapt+6,0,100);
  {const f=posF();f[P.pos]=Math.min(100,f[P.pos]+1.5);if(P.learn&&P.learn!==P.pos){f[P.learn]=Math.min(100,(f[P.learn]||20)+3);if(f[P.learn]>=100){news(`${P.last} ya domina la posición de ${POS[P.learn].toLowerCase()}.`);P.learn=null;}}}
  if(fam().partner)P.mor=clamp(P.mor+.15,0,100);
  if(hasHome()){P.mor=clamp(P.mor+.3+homeLevel(P.home)*.04,0,100);P.fat=clamp(P.fat-homeLevel(P.home)*.08,0,100);}else if(P.club&&P.week>4)P.mor=clamp(P.mor-.4,0,100);
  const sal=wageWeek()*(P.agent?.9:1),spend=P.assets.reduce((s,a)=>s+(SHOP.find(x=>x[0]===a)||[0,0,0])[2]*.002,0)+(P.cars||[]).reduce((s,k)=>s+(CARS.find(c=>c[0]===k)||[0,0,0])[2]*.002,0);P.money+=sal-spend;
  if(P.money<0){P.mor=clamp(P.mor-5,0,100);P.lp-=.5;}
  P.followers=Math.round(800*Math.pow(1.095,P.fame));
  P.sponsors.forEach(s=>{P.money+=s.pay/38*(hasT('mediatico')?1.2:1);});
  // ascenso desde la cantera
  if(P.squad==='cantera'&&P.week>=6&&ovr()>=club(P.club).base-13&&P.tru>=58){P.squad='primer';news(`${P.name} ${P.last} debuta en la convocatoria del primer equipo de ${cname(P.club)}.`,'hot');P.tru=50;P.lp+=1;}
  if(P.squad==='cantera'&&P.week===2&&!P.offers.length)news(`«La joven promesa ${P.last} podría debutar pronto», dicen en la ciudad deportiva.`);
  // selección
  const e=nextEv();
  // ventana de invierno
  if(P.week===19)window_(false);
  if(P.evCool>0)P.evCool--;else if(ch(.3))randomEvent();
  P.miniDone=false;P.week++;
  if(P.week>38)endSeason();
  checkCallup();save();}
function checkCallup(){const e=P.cal[P.week-1];P.sel.called=false;if(!e||e.type!=='sel')return;
  const lvl=natLevel(),need={'Sub-17':62,'Sub-19':66,'Sub-21':72,'Absoluta':NAT[P.nat][0]-12}[lvl];
  if(ovr()+P.form/20-2>=need&&P.inj===0){P.sel.called=true;P.sel.lvl=lvl;P.nat_=`${P.nat} ${lvl==='Absoluta'?'':lvl}`.trim();news(`${P.last} entra en la convocatoria de la selección ${lvl==='Absoluta'?'absoluta':lvl} de ${P.nat}.`,'hot');
    if(P.fat>65)P.pending.push({id:'cansado-sel'});}}
function natMatch(){const lvl=P.sel.lvl,oppN=pk(Object.keys(NAT).filter(x=>x!==P.nat));const st=lvl==='Absoluta'?NAT[P.nat][0]:NAT[P.nat][0]-14,os=lvl==='Absoluta'?NAT[oppN][0]:NAT[oppN][0]-14;
  const play=ovr()>=st-6?R(60,90):R(10,30),g=ch(chanceP('tir')*(P.pos==='DEL'?.7:P.pos==='EXT'?.45:.2))?1:0,gf=Math.max(poisson(1.3*Math.exp((st-os)/14)),g),ga=poisson(1.3*Math.exp((os-st)/14));
  const rt=+f1(clamp(6.2+g+(gf>ga?.3:-.2)+(Math.random()-.5),3,10));
  if(lvl==='Absoluta'){P.sel.caps++;P.sel.g+=g;if(P.sel.caps===1)news(`Debut con la selección absoluta de ${P.nat}.`,'hot');if(P.sel.caps>=40&&ovr()>=85&&!P.sel.captain){P.sel.captain=true;news(`${P.last} es el nuevo capitán de ${P.nat}.`,'hot');}}
  P.fat=clamp(P.fat+play/90*12,0,100);P.fame=clamp(P.fame+(lvl==='Absoluta'?1.5:.6)+g,0,100);
  modal(`<div class="hd j-mhd"><h3>${esc(P.nat)} ${lvl==='Absoluta'?'':lvl} ${gf}-${ga} ${esc(oppN)}</h3></div><div class="bd"><div class="j-note"><b class="num">${f1(rt)}</b><span>${play} minutos${g?' · ¡gol con tu país!':''}</span></div><p class="j-hint">Partidos internacionales: ${P.sel.caps} · Goles: ${P.sel.g}</p><div style="margin-top:14px"><button class="btn primary" data-act="jAfterNat" data-focus>Seguir</button></div></div>`);}
function window_(summer){
  const o=ovr(),pool=ALL().filter(k=>Math.abs(k.base-(o+2+P.fame/25))<=6&&k.id!==P.club);
  const n=clamp(Math.round((P.fame/30)+(o>=75?1:0)+(P.sea&&avg(P.sea.rt)>=7?1:0)),0,4);
  for(let i=0;i<n&&pool.length;i++){const k=pool.splice(R(0,pool.length-1),1)[0],r=k.base<=o-2?'Titular':k.base<=o+3?'Rotación':'Suplente';
    P.offers.push({...contractFor(k.id,'primer'),role:r,promise:ch(.35)?pk(['minutos','posicion','titular']):null});}
  const r=role();
  if((r==='Suplente'||r==='Descartado'||P.squad==='cantera')&&P.age<23&&!P.loan&&ch(.7)){const lpool=ALL().filter(k=>k.base<clubStr(P.club)-4&&k.base>=ovr()-6).map(k=>k.id);if(lpool.length){const lid=pk(lpool);P.offers.push({...contractFor(lid,'primer'),loan:true,years:1,role:'Titular',promise:'minutos'});news(`${cname(lid)} pregunta por la cesión de ${P.last}.`);}}
  if(n)news(n>=3?`Tres grandes clubes siguen los pasos de ${P.last}.`:`${pool.length?'Llegan ofertas':'Hay interés'} por ${P.last}.`,'hot');
  P.offers=P.offers.slice(-5);}
function title(n){P.titles.push({n,s:seasonLabel(P.season),c:cname(P.club)});news(`¡${cname(P.club)} gana la ${n}!`,'hot');P.fame=clamp(P.fame+6,0,100);}
function award(n){P.awards.push({n,s:seasonLabel(P.season)});news(`${P.last} gana: ${n}.`,'hot');P.fame=clamp(P.fame+5,0,100);P.lp+=.5;}
function dream(){if(!P.dreamDone){P.dreamDone=true;news(`Sueño cumplido: ${DREAMS[P.dream]}.`,'hot');P.mor=100;}}
function endSeason(){const c=club(P.club),n=P.sea.rt.length?+f1(avg(P.sea.rt)):0,o=ovr();
  // liga
  if(P.squad!=='cantera'&&P.pld){const tb=table(),pos=tb.findIndex(t=>t.me)+1;P.sea.pos=pos;
    if(pos===1)title(c.tier===0?LG[c.league].name:`${LG[c.league].name} · ascenso`);else if(c.tier>0&&pos<=2)news(`${c.name} asciende de categoría.`,'hot');}
  P.hist.push({s:seasonLabel(P.season),c:c.name,o,pj:P.sea.pj,tit:P.sea.tit,sup:P.sea.sup,g:P.sea.g,a:P.sea.a,n:n?f1(n):'—'});
  // premios
  const score=n*10+P.sea.g*1.2+P.sea.a*.8+(o-70)*1.5+P.titles.filter(t=>t.s===seasonLabel(P.season)).length*8;
  P.rivals.forEach(r=>{r.seaG=Math.round((r.pos==='DEL'?18:r.pos==='EXT'?11:6)*(r.ovr/80)+R(-4,6));r.g+=r.seaG;r.score=(r.ovr-70)*3+r.seaG*1.2+R(0,40)+60;});
  const bestRival=Math.max(...P.rivals.map(r=>r.score));
  if(o>=88&&n>=7.5&&c.tier===0&&score>bestRival+8&&score>=155&&ch(.6)){award('Balón de Oro');if(P.dream==='balon')dream();}
  else if(P.rivals.some(r=>r.ovr>=88&&r.score===bestRival&&ch(.6))){const r=P.rivals.find(x=>x.score===bestRival);r.awards.push('Balón de Oro '+seasonLabel(P.season));news(`${r.name}, rival de tu generación, gana el Balón de Oro.`);}
  if(P.sea.g>=Math.max(32,...P.rivals.map(r=>r.seaG+4))&&c.tier===0&&ch(.7))award('Bota de Oro');
  if(n>=7.4&&o>=80&&P.squad!=='cantera')award(`Mejor jugador de ${LG[c.league].name}`);
  if(P.age<=21&&n>=7&&P.sea.pj>=15)award('Mejor joven de la temporada');
  if(n>=7.4&&c.tier===0&&P.sea.pj>=24)award('Once ideal de la temporada');
  if(P.pos==='POR'&&P.sea.cs>=14&&c.tier===0)award('Guante de Oro');
  traitsTick();seasonCard(n,o);lockerVotes(n);if(P.sea.pj>=30&&!P.sea.yel&&!P.sea.red)flag('clean');
  // decisiones de la temporada → techo
  if(n>=7.2)P.lp+=3;else if(n&&n<6.2)P.lp-=2;
  if(P.sea.tit>=20)P.lp+=2;if(P.squad!=='cantera'&&P.sea.pj<8&&P.age>=20)P.lp-=2;
  P.lp=clamp(P.lp,0,100);
  // torneo de selecciones
  const endYear=P.season+1;if(P.sel.caps>0&&endYear%2===0){const t=endYear%4===2?'Mundial':CONT[NAT[P.nat][1]];const s=NAT[P.nat][0]+(ovr()-84)*.2;const win=ch(clamp((s-80)/40,.04,.45));
    if(win){P.titles.push({n:t,s:String(endYear),c:P.nat});news(`¡${P.nat} campeona del ${t}! ${P.last} levanta el trofeo.`,'hot');P.fame=clamp(P.fame+10,0,100);if(t==='Mundial'&&P.dream==='mundial')dream();}
    else news(`${P.nat} cae en el ${t}.`);}
  if(P.dream==='record'&&P.st.g>=400)dream();
  // edad y evolución: la media máxima acaba entre 83 y 94 (techo = ceil())
  P.age++;P.yearsAt++;const cap=ceil();
  if(P.age<=27){const t=P.startAge,exp=Math.round(P.at0+(cap-P.at0)*Math.min(1,(P.age-t)/(27-t)));let guard=0;while(ovr()<exp-(P.age<27?2:0)&&guard++<300)grow(pk(AT));}
  else if(P.age>=31){const hard=P.age>=34?2:1;AT.forEach(k=>{if(k==='rit'||k==='fis')P.at[k]-=R(1,2)*hard;else if(ch(.45))P.at[k]-=hard;});if(ch(.4))grow(pk(['pas','def']));}
  P.peak=Math.max(P.peak||0,ovr());
  // rivales
  P.rivals.forEach(r=>{r.ovr=Math.min(r.ceil,r.ovr+(P.age<=27?R(1,4):P.age>=32?-R(1,3):0));if(r.ovr>clubStr(r.club)+3){const up=ALL().filter(k=>k.base>=r.ovr-3&&k.base<=r.ovr+4&&k.id!==r.club);if(up.length){r.club=pk(up).id;news(`${r.name} ficha por ${cname(r.club)}.`);}}});
  // capitanía
  if(!P.captain&&P.yearsAt>=3&&o>=clubStr(P.club)&&P.squad!=='cantera')P.pending.push({id:'capitan'});
  // contrato
  if(P.contract){P.contract.years--;if(P.contract.years===1&&!P.loan)P.offers.push({...contractFor(P.club,'primer'),renew:true,role:role(),promise:null});
    if(P.contract.years<=0&&!P.loan){news(`${P.last} acaba contrato con ${cname(P.club)} y queda libre.`,'bad');P.contract=null;}}
  if(P.loan){const back=P.loan.from;P.moves.push({s:seasonLabel(P.season),from:cname(P.club),to:cname(back),t:'Vuelta de cesión',wage:P.loan.wage});P.club=back;P.contract=P.loan.contract;P.loan=null;P.squad='primer';news(`${P.last} vuelve a ${cname(back)} tras la cesión.`);}
  if(P.age>=31&&P.origin0&&P.club!==P.origin0&&ch(.35))P.pending.push({id:'casa'});
  window_(true);if(!P.contract&&!P.offers.length){P.offers.push({...contractFor(pk(ALL().filter(k=>k.base<=ovr()).map(k=>k.id)),'primer'),role:'Rotación'});}
  if(P.squad==='cantera'&&P.age>=19)P.squad='primer';
  P.season++;newSeason();familyTick();investTick();
  if(P.age>=39||(P.age>=34&&ovr()<76)){retire();return;}
  news(`Arranca la temporada ${seasonLabel(P.season)}. ${P.name} cumple ${P.age} años.`);
  P.pending.push({id:'pretemporada'});
  UI.jEnd=true;}
function retire(){P.retired=true;const after=[];P.rivals.forEach(r=>{const extra=R(1,4);after.push(`${r.name} juega ${extra} temporada${extra>1?'s':''} más y se retira con ${Math.round(r.ovr)} de media y ${r.g+extra*R(5,15)} goles.`);});
  const clubs=[...new Set(P.hist.map(h=>h.c))];clubs.slice(-3).forEach(c=>after.push(`${c} ${pk(['pelea por el título los años siguientes','vive una reconstrucción','retira tu dorsal en tu honor','pone tu nombre a una grada'])}.`));
  P.after=after;const H=hall();H.unshift({name:`${P.name} ${P.last}`,peak:P.peak,g:P.st.g,t:P.titles.length});try{localStorage.setItem(HALL,JSON.stringify(H.slice(0,12)));}catch(e){}
  P.retAge=P.age;addCard('icono','Retirada');news(`${P.name} ${P.last} anuncia su retirada.`);save();}

/* ---------- eventos con decisión ---------- */
const EV={
  confianza:{t:()=>`«El entrenador pierde la confianza en ${P.last}», titula la prensa local.`,o:[['Pedir una reunión',()=>{P.tru+=P.pers==='Líder'||P.pers==='Humilde'?9:5;P.lp+=1;P.rep.lider+=1;}],['Quejarse ante los medios',()=>{P.tru-=14;P.fame+=3;P.lp-=2;P.rep.polemico+=2;}],['Entrenar el doble y callar',()=>{P.tru+=4;P.fat+=12;P.lp+=1.5;P.rep.humilde+=1;}]]},
  aficion:{t:()=>`«La afición pide más minutos para ${P.last}».`,o:[['Agradecer el apoyo con humildad',()=>{P.tru+=3;P.rep.humilde+=1;P.lp+=.5;}],['Pedir públicamente más minutos',()=>{P.tru-=8;P.fame+=3;P.rep.polemico+=1;P.lp-=1;}],['Mantener silencio',()=>{P.lp+=.3;}]]},
  oferta:{t:()=>`«El club rechaza una oferta millonaria por ${P.last}».`,o:[['Aceptar la decisión del club',()=>{P.tru+=6;P.lp+=1;P.rep.humilde+=1;}],['Pedir que te dejen salir',()=>{P.tru-=12;P.mor-=4;P.lp-=1.5;window_(false);}],['Pedir una mejora de contrato',()=>{if(P.contract)P.contract.wage=Math.round(P.contract.wage*1.25);P.tru-=3;}]]},
  rueda:{t:()=>`Rueda de prensa tras el partido. Te preguntan por tus aspiraciones.`,o:[['«Solo pienso en el equipo»',()=>{P.rep.humilde+=1;P.tru+=2;P.lp+=.5;}],['«Quiero ganarlo todo, aquí o fuera»',()=>{P.rep.mediatico+=1;P.fame+=3;P.tru-=3;}],['Responder a una crítica del rival',()=>{P.rep.polemico+=2;P.fame+=4;P.lp-=1;P.tru-=4;}]]},
  redes:{t:()=>`Polémica en redes: un vídeo tuyo se saca de contexto y se hace viral.`,o:[['Pedir disculpas',()=>{P.rep.humilde+=1;P.fame-=1;P.lp+=.5;}],['Responder con ironía',()=>{P.rep.polemico+=2;P.fame+=4;P.lp-=1;}],['Ignorarlo',()=>{P.mor-=3;}]]},
  marca:{t:()=>`Una marca de botas quiere que seas su imagen.`,o:[['Firmar el contrato',()=>{const pay=Math.round(20000+P.fame*P.fame*120);P.sponsors.push({brand:pk(['Volta','Nexo','Kairo','Prisma','Lumen']),pay});P.rep.mediatico+=1;P.fat+=4;}],['Rechazarlo para centrarte',()=>{P.lp+=1;}]]},
  fiesta:{t:()=>`Un compañero te invita a una fiesta la víspera de un partido.`,o:[['Ir un rato',()=>{P.mor+=6;P.fat+=10;P.lp-=2;P.rep.polemico+=1;if(ch(.4)){P.tru-=10;news('El míster se entera de la fiesta. Multa y banquillo.','bad');}}],['Quedarte en casa',()=>{P.lp+=1;P.chem-=2;}]]},
  benefico:{t:()=>`Te proponen protagonizar una campaña benéfica.`,o:[['Aceptar',()=>{P.fame+=4;P.rep.humilde+=1;P.lp+=1;P.fat+=3;}],['No tienes tiempo',()=>{}]]},
  vestuario:{t:()=>`Bronca en el vestuario entre dos veteranos.`,o:[['Mediar entre ellos',()=>{P.chem+=10;P.rep.lider+=2;P.lp+=1;}],['Ponerte de un lado',()=>{P.chem-=8;P.rep.polemico+=1;}],['No meterte',()=>{}]]},
  fichaje:{t:()=>`Llega un fichaje joven que no habla el idioma.`,o:[['Ayudarle a integrarse',()=>{P.chem+=8;P.rep.lider+=1;P.lp+=.5;}],['Verlo como competencia',()=>{P.chem-=5;P.mor+=2;}]]},
  tactica:{t:()=>`El entrenador te pide jugar más abierto a banda y presionar arriba.`,o:[['Aceptar el plan',()=>{P.tru+=6;P.at.rit<99&&xp('rit',4);P.lp+=1;}],['Pedir jugar por dentro',()=>{P.tru-=4;xp('pas',3);}]]},
  posicion:{t:()=>`El míster te propone cambiar de posición a ${POS[P.pos2]}.`,o:[['Aceptar el cambio',()=>{const a=P.pos;P.pos=P.pos2;P.pos2=a;P.tru+=8;P.lp+=1;}],['Seguir en tu posición',()=>{P.tru-=3;}]]},
  promesa:{t:()=>`Reunión con el entrenador: te ofrece un rol de suplente esta temporada.`,o:[['Aceptar el rol y esperar tu momento',()=>{P.tru+=8;P.lp+=1.5;P.rep.humilde+=1;}],['Exigir protagonismo',()=>{if(ovr()>=clubStr(P.club)-2){P.promise='minutos';P.tru+=2;}else{P.tru-=10;P.lp-=1;}P.rep.lider+=1;}]]},
  lesion:{t:()=>`Lesión: el fisio propone dos caminos.`,o:[['Rehabilitación completa',()=>{P.inj+=1;P.lp+=1.5;P.at.fis<99&&xp('fis',3);}],['Forzar la vuelta',()=>{P.inj=Math.max(1,P.inj-2);P.lp-=2;if(ch(.35)){P.inj+=4;news('Recaída: la lesión se complica.','bad');}}]]},
  capitan:{t:()=>`«El vestuario elige a su nuevo capitán»: tu nombre suena con fuerza.`,o:[['Aceptar el brazalete',()=>{P.captain=true;P.lp+=2;P.rep.lider+=2;news(`${P.last}, nuevo capitán de ${cname(P.club)}.`,'hot');if(P.dream==='capitan')dream();}],['Cederlo a un veterano',()=>{P.chem+=6;P.rep.humilde+=1;}]]},
  casa:{t:()=>`${cname(P.origin0)}, tu primer club, te ofrece volver a casa.`,o:[['Volver a casa',()=>{move(P.origin0,{...contractFor(P.origin0,'primer'),years:2},'Vuelta a casa');P.captain=true;P.lp+=2;news(`${P.last} vuelve a casa: será capitán y mentor en ${cname(P.origin0)}.`,'hot');}],['Seguir donde estás',()=>{}]]},
  'cansado-sel':{t:()=>`Te llama la selección, pero llegas muy cansado.`,o:[['Acudir igualmente',()=>{if(ch(.3)){P.inj=R(2,4);P.lp-=1;news('Te lesionas con la selección por la sobrecarga.','bad');}}],['Pedir descanso',()=>{P.sel.called=false;P.fame-=2;P.fat-=15;}]]},
};
function event(id){if(!EV[id])return;P.pending.push({id});}
function randomEvent(){const r=role(),cands=['rueda','redes','marca','fiesta','benefico','vestuario','fichaje','tactica'];
  if(P.tru<38&&P.squad!=='cantera')cands.push('confianza','confianza');if((r==='Suplente'||r==='Rotación')&&P.sea.rt.length&&avg(P.sea.rt)>=6.8)cands.push('aficion','aficion');
  if(P.fame>=35)cands.push('oferta');if(P.pos2!==P.pos&&P.squad!=='cantera')cands.push('posicion');if(P.week<6&&P.squad!=='cantera'&&!P.promise)cands.push('promesa');
  if(P.fame<12)cands.splice(cands.indexOf('marca'),1);
  famCands(cands);P.pending.push(mkEv(pk(cands)));P.evCool=3;}
function showEvent(){const ev=P.pending[0];if(!ev){closeModal();return;}const E=EV[ev.id];if(!E){P.pending.shift();showEvent();return;}const EO=typeof E.o==='function'?E.o(ev):E.o;
  modal(`<div class="hd j-mhd"><h3>Decisión</h3></div><div class="bd"><p class="j-sit">${esc(E.t(ev))}</p><div class="j-opts col">${EO.map((o,j)=>`<button class="j-op" data-act="jDecide" data-j="${j}"><b>${o[0]}</b></button>`).join('')}</div><p class="j-hint">Cada decisión cuenta para tu carrera, aunque no siempre lo veas al momento.</p></div>`);}
function move(cid,k,t){if(P.home&&P.home.club!==cid)sellHome('cambio de equipo');P.moves.push({s:seasonLabel(P.season),from:cname(P.club),to:cname(cid),t,wage:k.wage});
  if(P.club&&country(P.club)!==country(cid)){P.adapt=P.free==='idioma'?55:35;if(fam().partner||fam().kids.length)P.pending.push({id:'mudanza'});}
  P.club=cid;P.contract={...k,club:cid};P.squad='primer';P.tru=45;P.chem=45;P.yearsAt=0;P.captain=false;if(P.cal&&P.cal.length)newSeasonKeep();}
function newSeasonKeep(){const w=P.week,s={...P.sea};newSeason();P.week=w;P.sea=s;P.sea.club=P.club;}

/* ---------- minijuego ---------- */
function mini(k){const [l,attr]=MINI[k],zone=clamp(10+P.at[attr]/7,12,26);UI.jmini={k,attr,zone,tries:0,score:0,center:R(30,70)};
  modal(`<div class="hd j-mhd"><h3>Minijuego · ${l}</h3></div><div class="bd"><p class="j-sit">Pulsa <b>¡Ya!</b> cuando el marcador esté dentro de la zona morada. Tres intentos.</p>
   <div class="j-bar" id="jbar"><i class="z" style="left:${UI.jmini.center-zone/2}%;width:${zone}%"></i><i class="c" style="left:${UI.jmini.center}%"></i><span id="jmk" style="--dur:${clamp(1.6-P.at[attr]/150,.8,1.4)}s"></span></div>
   <p class="j-hint" id="jmres">Intento 1 de 3</p><div class="j-acts"><button class="btn primary" data-act="jMiniHit" data-focus>¡Ya!</button></div></div>`);}
function miniHit(){const M=UI.jmini,bar=document.getElementById('jbar'),mk=document.getElementById('jmk');if(!bar||!mk)return;
  const b=bar.getBoundingClientRect(),m=mk.getBoundingClientRect(),pos=(m.left+m.width/2-b.left)/b.width*100,d=Math.abs(pos-M.center),pts=d<=M.zone/2?Math.round(10*(1-d/(M.zone/2)))+2:0;
  M.tries++;M.score+=pts;const res=document.getElementById('jmres');
  if(M.tries<3){res.textContent=`${pts?'¡Dentro! +'+pts:'Fuera'} · intento ${M.tries+1} de 3`;mk.style.animationDuration=(parseFloat(getComputedStyle(mk).animationDuration)*.85)+'s';return;}
  P.miniDone=true;xp(M.attr,M.score/3);P.lp+=M.score>=20?.5:0;save();
  modal(`<div class="hd j-mhd"><h3>Resultado</h3></div><div class="bd"><div class="j-note"><b class="num">${M.score}</b><span>puntos de 36<small>${M.score>=24?'Sesión brillante':M.score>=12?'Buena sesión':'Hoy no era tu día'}</small></span></div><p class="j-hint">Has sumado experiencia en ${AN[M.attr]}.</p><button class="btn primary" data-act="jClose" data-focus>Seguir</button></div>`);}

/* ---------- aspecto: panel y modelo 3D ---------- */
const LOOK=['skin','hairc','hair','beard','boots','acc'];
function lookPanel(src,isP){const act=isP?'jLook':'jcf';
  const sw=(k,arr,lab)=>`<div class="j-sw sm" role="radiogroup" aria-label="${lab}">${arr.map((col,i)=>`<button class="${(src[k]||0)===i?'on':''}" role="radio" aria-checked="${(src[k]||0)===i}" aria-label="${lab} ${i+1}" data-act="${act}" data-k="${k}" data-v="${i}" style="background:${col}"></button>`).join('')}</div>`;
  const chips=(k,arr,lab)=>`<div class="j-chips" role="radiogroup" aria-label="${lab}">${arr.map((t,i)=>`<button class="j-chip${(+src[k]||0)===i?' on':''}" role="radio" aria-checked="${(+src[k]||0)===i}" data-act="${act}" data-k="${k}" data-v="${i}">${t}</button>`).join('')}</div>`;
  return `<section class="j-aspect" aria-labelledby="asp-${isP?'p':'c'}"><div class="j-asp-h"><h3 id="asp-${isP?'p':'c'}">Aspecto</h3><small>Arrastra para girar</small></div>
  <div class="j-3d"><canvas id="j3d" role="img" aria-label="Modelo 3D de tu futbolista"></canvas><div class="j-3d-fb" hidden>${avatar(src,170)}</div></div>
  <div class="j-asp-c"><div class="j-asp-row"><div class="j-grp"><h4>Tono de piel</h4>${sw('skin',SKIN,'Tono de piel')}</div><div class="j-grp"><h4>Color de pelo</h4>${sw('hairc',HAIRC,'Color de pelo')}</div></div>
   <div class="j-grp"><h4>Peinado</h4>${chips('hair',HAIR,'Peinado')}</div>
   <div class="j-grp"><h4>Barba</h4>${chips('beard',BEARD,'Barba')}</div>
   <div class="j-asp-row"><div class="j-grp"><h4>Botas</h4>${sw('boots',BOOTS,'Color de botas')}</div><div class="j-grp"><h4>Accesorio</h4>${chips('acc',ACC,'Accesorio')}</div></div>${isP?lookExtra(src):''}</div></section>`;}
function setLook(obj,d,el){obj[d.k]=+d.v;
  const g=el&&el.closest('[role=radiogroup]');if(g)g.querySelectorAll('[role=radio]').forEach(b=>{const on=b===el;b.classList.toggle('on',on);b.setAttribute('aria-checked',String(on));});
  const prev=document.getElementById('jc-prev');if(prev&&obj===UI.jc)prev.innerHTML=card({...build(UI.jc),club:null},true);
  const fb=document.querySelector('.j-3d-fb');if(fb)fb.innerHTML=avatar(obj,170);
  if(G3D)G3D.rebuild();}

let G3D=null;
function unmount3D(){if(!G3D)return;cancelAnimationFrame(G3D.raf);G3D.ro&&G3D.ro.disconnect();
  G3D.scene.traverse(o=>{o.geometry&&o.geometry.dispose();if(o.material){(Array.isArray(o.material)?o.material:[o.material]).forEach(m=>{m.map&&m.map.dispose();m.dispose();});}});
  G3D.r.dispose();try{G3D.r.forceContextLoss();}catch(e){}G3D=null;}
function mountAspect(){const cv=document.getElementById('j3d');
  if(!cv){unmount3D();return;}if(G3D&&G3D.cv===cv)return;unmount3D();
  const fb=()=>{const f=cv.parentElement.querySelector('.j-3d-fb');if(f){f.hidden=false;cv.hidden=true;}};
  if(typeof loadThree!=='function'){fb();return;}
  loadThree().then(ok=>{if(!ok||!window.THREE||!document.body.contains(cv)){fb();return;}try{init3D(cv);}catch(e){console.error(e);fb();}});}
function lookSrc(){return UI.screen==='jcreate'?UI.jc:P;}
function init3D(cv){const T=window.THREE,box=cv.parentElement;
  const r=new T.WebGLRenderer({canvas:cv,antialias:true,alpha:true});r.setPixelRatio(Math.min(devicePixelRatio||1,2));
  if('outputEncoding' in r)r.outputEncoding=T.sRGBEncoding;
  const scene=new T.Scene(),cam=new T.PerspectiveCamera(30,1,.1,50);cam.position.set(0,1.2,3.55);cam.lookAt(0,1.02,0);
  scene.add(new T.HemisphereLight(0xEDE2FF,0x1A0C33,.85));
  const key=new T.DirectionalLight(0xffffff,.95);key.position.set(2.2,3.2,2.6);scene.add(key);
  const rim=new T.DirectionalLight(0xB57BFF,1.6);rim.position.set(-2.4,2.2,-2.6);scene.add(rim);
  const rim2=new T.DirectionalLight(0x8A4FE6,.7);rim2.position.set(2.6,1,-2);scene.add(rim2);
  // plataforma con anillo de neón
  const disc=new T.Mesh(new T.CircleGeometry(.62,48),new T.MeshStandardMaterial({color:0x1A0D33,roughness:.5,metalness:.2}));disc.rotation.x=-Math.PI/2;scene.add(disc);
  const ring=new T.Mesh(new T.RingGeometry(.6,.645,64),new T.MeshBasicMaterial({color:0xC99BFF,transparent:true,opacity:.95,side:T.DoubleSide}));ring.rotation.x=-Math.PI/2;ring.position.y=.002;scene.add(ring);
  const glow=new T.Mesh(new T.RingGeometry(.645,.8,64),new T.MeshBasicMaterial({color:0x9D62F2,transparent:true,opacity:.22,side:T.DoubleSide}));glow.rotation.x=-Math.PI/2;glow.position.y=.001;scene.add(glow);
  const fig=new T.Group();scene.add(fig);
  const G={cv,r,scene,cam,fig,raf:0,rotY:.45,drag:null,t0:performance.now()};G3D=G;
  G.rebuild=()=>{while(fig.children.length){const o=fig.children.pop();o.traverse(x=>{x.geometry&&x.geometry.dispose();if(x.material)(Array.isArray(x.material)?x.material:[x.material]).forEach(m=>{m.map&&m.map.dispose();m.dispose();});});}buildFigure(T,fig,lookSrc());};
  G.rebuild();
  const size=()=>{const w=box.clientWidth||300,h=box.clientHeight||340;r.setSize(w,h,false);cam.aspect=w/h;cam.updateProjectionMatrix();};size();
  if(window.ResizeObserver){G.ro=new ResizeObserver(size);G.ro.observe(box);}
  box.addEventListener('pointerdown',e=>{G.drag={x:e.clientX,r:G.rotY};box.setPointerCapture(e.pointerId);});
  box.addEventListener('pointermove',e=>{if(G.drag)G.rotY=G.drag.r+(e.clientX-G.drag.x)*.012;});
  const up=()=>{G.drag=null;};box.addEventListener('pointerup',up);box.addEventListener('pointercancel',up);
  const calm=reduced();
  const loop=t=>{if(G3D!==G)return;G.raf=requestAnimationFrame(loop);
    const tz=G.celeb?4.9:3.55;cam.position.z+=(tz-cam.position.z)*.08;cam.position.y+=((G.celeb?1.35:1.2)-cam.position.y)*.08;cam.lookAt(0,G.celeb?1.25:1.02,0);
    if(G.celeb){const u=(t-G.celeb.t0)/1000;if(u>3.2){G.celeb=null;fig.position.set(0,0,0);fig.rotation.set(0,G.rotY,0);}else{celebPose(G,fig,G.celeb.id,u);fig.rotation.y=G.rotY;r.render(scene,cam);return;}}
    if(!G.drag&&!calm)G.rotY+=.005;fig.rotation.y=G.rotY;
    const k=(t-G.t0)/1000;if(!calm){fig.position.y=Math.sin(k*1.6)*.006;const ch=fig.getObjectByName('chest');if(ch)ch.scale.set(1,1+Math.sin(k*1.6)*.012,1+Math.sin(k*1.6)*.02);const aL=fig.getObjectByName('armL'),aR=fig.getObjectByName('armR');if(aL){aL.rotation.x=Math.sin(k*1.6)*.07;aL.rotation.z=-.05;}if(aR){aR.rotation.x=-Math.sin(k*1.6)*.07;aR.rotation.z=.05;}ring.material.opacity=.75+Math.sin(k*2.2)*.2;}
    r.render(scene,cam);};
  G.raf=requestAnimationFrame(loop);}
/* futbolista cúbico (estilo bloques): cabeza con cara dibujada, camiseta con dorsal y apellido, pelo por bloques */
function pixTex(T,w_,h,draw){const c=document.createElement('canvas');c.width=w_;c.height=h;const g=c.getContext('2d');g.imageSmoothingEnabled=false;draw(g,w_,h);
  const t=new T.CanvasTexture(c);t.magFilter=T.NearestFilter;t.minFilter=T.LinearMipMapLinearFilter;if('encoding' in t)t.encoding=T.sRGBEncoding;return t;}
function buildFigure(T,fig,L){
  const K=kitOf(L),shirtC=K.s,trimC=K.t,shortsC=K.p,sockC=K.m;
  const skinC=SKIN[L.skin]??SKIN[2],hairC=HAIRC[L.hairc||0],bootC=BOOTS[L.boots||0];
  const M=(col,o={})=>new T.MeshStandardMaterial({color:new T.Color(col),roughness:.55,metalness:0,...o});
  const skin=M(skinC,{roughness:.6}),hair=M(hairC,{roughness:.75}),shirt=M(shirtC),shorts=M(shortsC),sock=M(sockC),boot=M(bootC,{roughness:.3,metalness:.1,emissive:new T.Color(bootC),emissiveIntensity:.12}),dark=M('#17111f',{roughness:.4});
  const neon=new T.MeshStandardMaterial({color:new T.Color('#C99BFF'),emissive:new T.Color('#B57BFF'),emissiveIntensity:.9,roughness:.3});
  const box=(par,w_,h,d,mat,x,y,z,name)=>{const m=new T.Mesh(new T.BoxGeometry(w_,h,d),mat);m.position.set(x,y,z);if(name)m.name=name;par.add(m);return m;};
  const long=+L.acc===3,gloves=+L.acc===4,last=(L.last||'').toUpperCase().slice(0,10),num=String(L.num||9);
  /* piernas: bota, media, rodilla y muslo con el pantalón */
  [-1,1].forEach(sd=>{const x=sd*.13;
    box(fig,.24,.12,.34,boot,x,.06,.04);box(fig,.235,.05,.05,M('#ffffff'),x,.1,.215);
    box(fig,.22,.36,.24,sock,x,.3,0);box(fig,.225,.06,.245,M(trimC),x,.45,0);
    box(fig,.22,.12,.24,skin,x,.54,0);box(fig,.24,.22,.26,shorts,x,.71,0);});
  box(fig,.5,.14,.28,shorts,0,.86,0);
  /* torso con textura: escudo, cuello en V y franja delante; dorsal y apellido detrás */
  const front=pixTex(T,128,128,(g,W,H)=>{g.fillStyle=shirtC;g.fillRect(0,0,W,H);g.fillStyle=trimC;g.fillRect(0,0,W,10);g.beginPath();g.moveTo(44,0);g.lineTo(64,26);g.lineTo(84,0);g.fill();
    g.fillStyle=shirtC;g.beginPath();g.moveTo(52,0);g.lineTo(64,16);g.lineTo(76,0);g.fill();g.fillStyle=trimC;g.fillRect(18,40,18,22);g.fillStyle=shirtC;g.fillRect(22,44,10,14);g.globalAlpha=.25;g.fillStyle=trimC;g.fillRect(0,92,W,8);g.globalAlpha=1;});
  const back=pixTex(T,128,128,(g,W,H)=>{g.fillStyle=shirtC;g.fillRect(0,0,W,H);g.fillStyle=trimC;g.fillRect(0,0,W,8);g.font=`900 ${last.length>7?13:16}px Impact,"Big Shoulders Display",sans-serif`;g.textAlign='center';g.fillText(last,64,30);
    g.font='900 74px Impact,"Big Shoulders Display",sans-serif';g.fillText(num,64,108);});
  const torsoMats=[shirt,shirt,shirt,shirt,M('#ffffff',{map:front}),M('#ffffff',{map:back})];
  const torso=new T.Mesh(new T.BoxGeometry(.52,.6,.3),torsoMats);torso.position.set(0,1.23,0);torso.name='chest';fig.add(torso);
  box(fig,.22,.08,.2,skin,0,1.565,0);
  /* brazos: hombro con manga, antebrazo y mano; pivotan en el hombro para animarlos */
  [-1,1].forEach(sd=>{const arm=new T.Group();arm.position.set(sd*.37,1.5,0);arm.name=sd<0?'armL':'armR';fig.add(arm);
    box(arm,.2,.26,.24,shirt,0,-.12,0);box(arm,.205,.04,.245,M(trimC),0,-.245,0);box(arm,.18,.28,.2,long?shirt:skin,0,-.39,0);
    box(arm,.19,.13,.2,gloves?dark:skin,0,-.6,0);if(+L.acc===2)box(arm,.2,.06,.21,neon,0,-.5,0);});
  /* cabeza: cara en píxeles con el nacimiento del pelo y cuero cabelludo con el degradado (fade) del corte */
  const H=1.86,hs=.54,hw=hs/2,hdp=hs*.47,st=+L.hair||0,HS=HSTY[st]||HSTY[0],hasHair=HS.fade!=='bald';
  const face=pixTex(T,32,32,(g)=>{g.fillStyle=skinC;g.fillRect(0,0,32,32);g.fillStyle=hairC;g.fillRect(7,10,6,2);g.fillRect(19,10,6,2);
    g.fillStyle='#ffffff';g.fillRect(8,13,5,5);g.fillRect(19,13,5,5);g.fillStyle='#1b1430';g.fillRect(10,14,3,4);g.fillRect(21,14,3,4);
    g.fillStyle='rgba(0,0,0,.18)';g.fillRect(15,18,2,4);g.fillStyle='#5a2430';g.fillRect(11,24,10,2);g.fillRect(10,23,2,1);g.fillRect(20,23,2,1);
    g.fillStyle='rgba(255,120,120,.25)';g.fillRect(6,20,4,2);g.fillRect(22,20,4,2);
    if(HS.hl){g.fillStyle=hairC;if(HS.hlc)g.fillRect(12,0,8,HS.hl+2);else{g.fillRect(0,0,32,HS.hl);g.fillRect(0,HS.hl,3,3);g.fillRect(29,HS.hl,3,3);}}});
  const stubC=shadeHex(hairC,HS.fade==='scalp'?-.3:-.08);
  const scalp=(isTop)=>pixTex(T,16,16,(g)=>{for(let py=0;py<16;py++)for(let px=0;px<16;px++){const t=isTop?(HS.hlc&&(px<5||px>10)?.7:1):1-(py+.5)/16;
    g.fillStyle=hasHair&&fadeAt(HS,t,px,py)?((px*7+py*3)%5?stubC:hairC):skinC;g.fillRect(px,py,1,1);}});
  const sideM=M('#ffffff',{map:scalp(false),roughness:.7}),topM=M('#ffffff',{map:scalp(true),roughness:.7});
  const headMats=[sideM,sideM,topM,skin,M('#ffffff',{map:face,roughness:.6}),sideM];
  const head=new T.Mesh(new T.BoxGeometry(hs,hs,hs*.94),headMats);head.position.set(0,H,0);fig.add(head);
  [-1,1].forEach(sd=>box(fig,.05,.1,.08,skin,sd*(hs/2+.02),H-.01,0));
  /* pelo: un vóxel instanciado por celda con su propio matiz para que se lea la textura del corte */
  const vx=hairVox(st,hs);
  if(vx.length){const v=hs/12,im=new T.InstancedMesh(new T.BoxGeometry(v,v,v),new T.MeshStandardMaterial({color:0xffffff,roughness:.78}),vx.length),m4=new T.Matrix4(),col=new T.Color();
    vx.forEach((q,i)=>{m4.makeTranslation(q.x,H+q.y,q.z);im.setMatrixAt(i,m4);col.set(hairC).offsetHSL(0,0,q.k);im.setColorAt(i,col);});
    im.instanceMatrix.needsUpdate=true;if(im.instanceColor)im.instanceColor.needsUpdate=true;fig.add(im);}
  /* barba */
  const bd=+L.beard||0,fz=hdp+.012;
  if(bd===1)box(fig,.12,.08,.04,hair,0,H-.17,fz);
  else if(bd===2){box(fig,hs+.01,.1,.04,M(hairC,{roughness:.9,transparent:true,opacity:.85}),0,H-.16,fz);[-1,1].forEach(sd=>box(fig,.04,.16,.2,hair,sd*(hw+.005),H-.12,.08));}
  else if(bd===3){box(fig,hs+.02,.16,.05,hair,0,H-.14,fz);box(fig,.2,.06,.05,hair,0,H-.06,fz+.005);[-1,1].forEach(sd=>box(fig,.05,.26,.24,hair,sd*(hw+.01),H-.08,.06));}
  /* cinta */
  if(+L.acc===1)box(fig,hs+.11,.05,hs*.94+.11,neon,0,H+.1,0);
  const h=(+L.height||180)/180;fig.scale.set(.96+(h-1)*.6,h,.96+(h-1)*.6);}
/* ---------- partido en directo: motor 3D del modo Clubes + estrella sobre tu futbolista ---------- */
const MYIDX={POR:0,DEF:2,MED:6,EXT:8,DEL:9};
function squadNames(id,exclude){const n=SEED.filter(p=>p.club===id&&p.pos!=='POR').map(p=>p.name).filter(x=>x!==exclude);return n.length?n:['un compañero'];}
function liveMatch(){
  const e=nextEv(),r=role(),opp=club(e.opp),youth=P.squad==='cantera',c=club(P.club);
  const min=minutesFor(r,e),oppS=youth?clamp(opp.base-14,40,70):opp.base,from=min&&min<90?90-min:0;
  const n=min?clamp(Math.round(min/90*({POR:3,DEF:2,MED:2,EXT:3,DEL:3}[P.pos])+R(0,1)),1,4):0;
  const mom=makeMoments(n).map(m=>({...m,m:clamp(from+Math.round((m.m/90)*(90-from)),from+1,89)})).sort((a,b)=>a.m-b.m);
  UI.jm={e,r,min,oppS,youth,interactive:true,mom,i:0,res:{g:0,a:0,ok:0,ko:0,saves:0,log:[]}};
  const mySide=e.home?'h':'a',hId=e.home?P.club:e.opp,aId=e.home?e.opp:P.club,H=club(hId),A=club(aId);
  const own=(youth?clamp(c.base-14,40,72):c.base)+(min?(ovr()-c.base)*.07*min/90:0)+(e.home?2:-1);
  // goles que no dependen de tu decisión: compañeros y rival
  const ev=[];const mates=squadNames(P.club),rivals=squadNames(e.opp);
  const other=poisson(1.3*Math.exp((own-oppS)/14)*.72),conc=poisson(1.3*Math.exp((oppS-own)/14));
  for(let i=0;i<other;i++)ev.push({m:R(3,89),kind:'goal',side:mySide,n:youth?'un compañero del juvenil':pk(mates)});
  for(let i=0;i<conc;i++)ev.push({m:R(3,89),kind:'goal',side:mySide==='h'?'a':'h',n:youth?'un juvenil rival':pk(rivals)});
  for(let i=0;i<R(2,5);i++)ev.push({m:R(3,89),kind:'chance',side:ch(.5)?'h':'a'});
  mom.forEach(m=>ev.push({m:m.m,kind:'moment',mo:m}));if(P.captain&&min>0)ev.push({m:R(Math.max(from+5,30),80),kind:'cap'});
  if(from)ev.push({m:from,kind:'enter'});
  ev.sort((a,b)=>a.m-b.m||(a.kind==='moment'?1:-1));
  const L={ev,mySide,hId,aId,hg:0,ag:0,m:0,speed:1,timer:null,paused:false,M:null,on:min>0&&!from,stop:R(1,5)};UI.jl=L;
  const use3d=typeof hasGL15==='function'&&hasGL15()&&!!window.THREE&&!reduced();
  modal(`<div class="hd j-mhd"><h3>${evLabel(e)}</h3><p class="j-hint" style="margin:4px 0 0">${e.home?'En casa':'Fuera'} · ${esc(H.stadium||'')}</p></div>
   <div class="bd"><div class="scoreboard${use3d?' sb-3d':''}"><div class="t">${crest(H,48)}<b>${youth?'Juvenil ':''}${esc(H.name)}</b></div><div><div class="digits" id="sc">0-0</div><div class="clock" id="clk">0'</div></div><div class="t">${crest(A,48)}<b>${youth?'Juvenil ':''}${esc(A.name)}</b></div></div>
   ${use3d?`<div class="bc15" id="bc15"><div class="bc15-slot" id="bc15-slot"></div><div class="bc15-bug" aria-hidden="true"><span class="bug-t" style="--k:${H.c1}">${esc(H.short)}</span><span class="bug-s" id="bc-sc">0–0</span><span class="bug-t" style="--k:${A.c1}">${esc(A.short)}</span><span class="bug-c" id="bc-clk">0'</span></div><div class="bc15-side" aria-hidden="true"><span class="bc15-live">Directo</span><span class="j-star-k">★ ${esc(P.last)}</span></div><button type="button" class="bc15-rep" id="bc-rep" data-act="skipRep" hidden>Repetición <small>Saltar</small></button><div class="bc15-l3" id="bc-l3" hidden></div><div class="j-dec j-dec-3d" id="jdec" hidden></div></div>`:'<div class="j-dec" id="jdec" hidden></div>'}
   <div class="feed" id="feed" aria-live="polite"></div></div>
   <div class="ft"><button class="btn" data-act="jLiveSpeed" id="jspd">Velocidad ×2</button><button class="btn" data-act="jLiveSim">Simular el resto</button></div>`);
  const mr=document.querySelector('#modal-root .modal');if(mr&&use3d)mr.classList.add('m15');
  if(use3d){const prevS=S;try{S={club:'__jugador__',season:P.season,week:P.week,cap:0};
      L.M=match3D15(document.getElementById('bc15-slot'),{r:{h:hId,a:aId},home:e.home,cup:e.type!=='liga'});}catch(err){console.error(err);L.M=null;}finally{S=prevS;}
    UI.m15=L.M;if(L.M)addStar(L.M);else{const b=document.getElementById('bc15');if(b)b.remove();}}
  feed(`Arranca el partido${from?'. Empiezas en el banquillo':r==='Titular'||r==='Capitán'?'. Sales de titular':''}.`);
  liveRun();}
function addStar(M){const w=M.w,T=w.T,idx=MYIDX[P.pos]+(UI.jl.mySide==='h'?0:11);
  const cv=document.createElement('canvas');cv.width=cv.height=128;const g=cv.getContext('2d');
  const star=(r1,r2)=>{g.beginPath();for(let i=0;i<10;i++){const a=-Math.PI/2+i*Math.PI/5,r=i%2?r2:r1;g.lineTo(64+Math.cos(a)*r,64+Math.sin(a)*r);}g.closePath();};
  g.shadowColor='#B57BFF';g.shadowBlur=26;star(50,21);g.fillStyle='#C99BFF';g.fill();g.shadowBlur=0;star(40,17);g.fillStyle='#F3E6FF';g.fill();
  const tex=new T.CanvasTexture(cv),sp=new T.Sprite(new T.SpriteMaterial({map:tex,transparent:true,depthTest:false,toneMapped:false,fog:false}));sp.scale.set(1.25,1.25,1.25);sp.renderOrder=999;w.root.add(sp);
  const ring=new T.Mesh(new T.RingGeometry(.42,.56,40).rotateX(-Math.PI/2),new T.MeshBasicMaterial({color:'#D9B3FF',transparent:true,opacity:.9,depthWrite:false,toneMapped:false,fog:false}));ring.renderOrder=998;w.root.add(ring);
  w.disp&&w.disp.push(tex,ring.geometry);myFigure(M,idx);
  const tick=w.tick;w.tick=(dt,t)=>{tick(dt,t);const p=M.P&&M.P[idx],vis=!!(p&&UI.jl&&UI.jl.on);sp.visible=ring.visible=vis;if(!vis)return;const k=t/1000;
    sp.position.set(p.x,2.6+Math.sin(k*3)*.12,p.z);ring.position.set(p.x,.05,p.z);ring.material.opacity=.55+Math.sin(k*4)*.3;};}
function feed(t,hot){const f=document.getElementById('feed');if(!f)return;const p=document.createElement('p');p.textContent=(UI.jl?UI.jl.m+"' ":'')+t;if(hot)p.className='j-hot';f.prepend(p);}
function score(){const L=UI.jl,s=`${L.hg}-${L.ag}`;const a=document.getElementById('sc'),b=document.getElementById('bc-sc'),k=document.getElementById('clk'),kb=document.getElementById('bc-clk');if(a)a.textContent=s;if(b)b.textContent=`${L.hg}–${L.ag}`;const cl=L.m>90?`90+${L.m-90}'`:`${L.m}'`;if(k)k.textContent=cl;if(kb)kb.textContent=cl;}
function liveRun(){const L=UI.jl;clearInterval(L.timer);L.timer=setInterval(liveStep,Math.round(380/L.speed));}
function livePause(){clearInterval(UI.jl.timer);UI.jl.timer=null;}
function liveGoal(side,name,assist,done){const L=UI.jl;if(side==='h')L.hg++;else L.ag++;score();
  const mine=side===L.mySide;feed(`¡Gol de ${name}!${assist?` Asistencia de ${assist}.`:''}`,mine);
  if(L.M&&!L.fast){livePause();L.M.goal({side,n:name,m:L.m,an:assist||'',...goalIdx(side,name,assist)},()=>{done&&done();if(!UI.jl.decide&&!UI.jl.ended)liveRun();});}else done&&done();}
function liveStep(){const L=UI.jl;if(!L||L.ended)return;if(!document.getElementById('feed')){clearInterval(L.timer);return;}
  if(L.M&&L.M.busy)return;
  L.m++;score();
  if(L.m>=90+L.stop){liveEnd();return;}
  while(L.ev.length&&L.ev[0].m<=L.m){const x=L.ev.shift();
    if(x.kind==='enter'){L.on=true;feed('Entras al campo. ¡A por ello!',true);L.M&&L.M.l3&&L.M.l3(`<span class="l3-tag">Cambio</span><b>Entra ${esc(P.last)}</b>`,2200);}
    else if(x.kind==='chance'){L.M&&L.M.chance&&L.M.chance({side:x.side});}
    else if(x.kind==='goal'){liveGoal(x.side,x.n);if(L.M&&!L.fast)return;}
    else if(x.kind==='cap'){if(!L.on||L.fast)continue;livePause();showCap();return;}
    else if(x.kind==='moment'){if(L.fast){autoMoment(x.mo);continue;}livePause();showDecision(x.mo);return;}}}
function autoMoment(mo){const pref={DEL:{Chutar:1,Pasar:.55,Regatear:.75},EXT:{Chutar:.7,Pasar:.95,Regatear:.95},MED:{Chutar:.5,Pasar:1.15,Regatear:.7},DEF:{},POR:{}}[P.pos];
  const j=mo.opts.map((o,j)=>[j,chanceP(o[1],o[2])*(pref[o[0]]??1)]).sort((a,b)=>b[1]-a[1])[0][0];liveResolve(mo,j,true);}
function showDecision(mo){const L=UI.jl,d=document.getElementById('jdec');if(!d)return;L.decide=mo;
  L.M&&L.M.l3&&L.M.l3(`<span class="l3-tag">Tu jugada</span><b>${esc(P.last)}</b><em>${L.m}'</em>`,2400);
  if(mo.kind==='fp'){d.classList.add('fp-on');d.innerHTML=`<p class="j-sit"><b class="num">${L.m}'</b> ${mo.text}</p><div id="fpbox"></div>`;d.hidden=false;startFp(d.querySelector('#fpbox'),mo.fk,out=>{if(mo.done)return;mo.out=out;liveResolve(mo,0);});return;}
  d.innerHTML=`<p class="j-sit"><b class="num">${L.m}'</b> ${mo.text}</p><div class="j-opts">${mo.opts.map((o,j)=>`<button class="j-op" data-act="jLiveMo" data-j="${j}"><b>${o[0]}</b><small>${(P.pos==='POR'?ANP:AN)[o[1]]} · ${Math.round(chanceP(o[1],o[2])*100)} %</small></button>`).join('')}</div>`;d.hidden=false;d.querySelector('button')?.focus({preventScroll:true});}
function liveResolve(mo,j,silent){if(mo.done)return;mo.done=true;const L=UI.jl,R0=UI.jm.res,g0=R0.g,a0=R0.a,c0=R0.conc||0;const r=resolveMoment(mo,j);if(R0.redMin&&!L.red){L.red=true;L.on=false;L.ev=L.ev.filter(x=>x.kind!=='moment'&&x.kind!=='cap');L.M&&L.M.l3&&L.M.l3('<span class="l3-tag">Roja</span><b>'+esc(P.last)+'</b>',2400);}
  const d=document.getElementById('jdec');if(d){d.hidden=true;d.innerHTML='';d.classList.remove('fp-on');}L.decide=null;feed(r.t,R0.g>g0||R0.a>a0);
  const after=()=>{if(!L.ended&&!L.fast)liveRun();};
  if(R0.g>g0)liveGoal(L.mySide,P.last,null,after);
  else if(R0.a>a0)liveGoal(L.mySide,R0.mate||pk(squadNames(P.club,P.last)),P.last,after);
  else if((R0.conc||0)>c0)liveGoal(L.mySide==='h'?'a':'h',pk(squadNames(L.mySide==='h'?L.aId:L.hId)),null,after);
  else if(!silent)after();}
function liveEnd(){const L=UI.jl;if(L.ended)return;L.ended=true;clearInterval(L.timer);feed('Final del partido.');
  const myG=L.mySide==='h'?L.hg:L.ag,thG=L.mySide==='h'?L.ag:L.hg;UI.jm.pre={gf:myG,ga:thG};
  setTimeout(()=>{UI.m15=null;finishMatch();},L.fast?0:900);}

/* ---------- ciudad: la ciudad de tu club en 3D, tu parcela y tu casa ---------- */
const HOUSE={
  estructura:['Solar vacío','Casa de una planta','Casa de dos plantas','Villa de diseño'],
  fachada:['Ladrillo visto','Pintura y estuco','Madera y piedra','Cristal y hormigón'],
  jardin:['Tierra','Césped','Jardín con árboles','Paisajismo con luces'],
  piscina:['Sin piscina','Piscina pequeña','Piscina con tumbonas','Piscina infinita'],
  garaje:['Sin garaje','Cochera','Garaje con coche','Garaje doble deportivo'],
  tecnologia:['Sin domótica','Placas solares','Casa inteligente','Neón y domótica total'],
};
const HPART={estructura:'Estructura',fachada:'Fachada',jardin:'Jardín',piscina:'Piscina',garaje:'Garaje',tecnologia:'Tecnología'};
const HW={estructura:1.4,fachada:.8,jardin:.6,piscina:1,garaje:.9,tecnologia:.8};
const citySize=id=>{const k=club(id);return clamp(((k?k.base:55)-52)/36-(k?k.tier:0)*.06,0,1);};
const cityName=id=>{const k=club(id);return k?k.name:'tu ciudad';};
function plotPrice(id){const k=club(id),b=k?k.base:55;return Math.round(12000*Math.pow(1.075,b-55)/500)*500;}
function upCost(id,part,lvl){return Math.round(plotPrice(id)*[.3,.65,1.3][lvl]*HW[part]/500)*500;}
const homeLevel=h=>h?Object.values(h.parts).reduce((a,b)=>a+b,0):0;
function hasHome(){return !!(P.home&&P.home.club===P.club);}
function sellHome(reason){if(!P.home)return;const v=Math.round(P.home.spent*.6);P.money+=v;P.homes=P.homes||[];P.homes.push({c:cname(P.home.club),lvl:homeLevel(P.home),s:seasonLabel(P.season),v});
  news(`${P.last} vende su casa en ${cname(P.home.club)} por ${eur(v)}${reason?' ('+reason+')':''}.`);P.home=null;}
function vCiudad(){const id=P.club,k=club(id),s=citySize(id),h=hasHome()?P.home:null,lvl=homeLevel(h),price=plotPrice(id);
  const kind=s>.75?'Gran metrópoli':s>.5?'Ciudad grande':s>.25?'Ciudad mediana':'Pueblo';
  const rows=h?Object.keys(HOUSE).map(p=>{const L=h.parts[p],max=L>=3,cost=max?0:upCost(id,p,L),can=!max&&P.money>=cost&&(p==='estructura'||h.parts.estructura>=1);
    return `<div class="j-hrow"><div><b>${HPART[p]}</b><small>${HOUSE[p][L]}${max?'':` → ${HOUSE[p][L+1]}`}</small></div><span class="j-pips" aria-label="Nivel ${L} de 3">${[1,2,3].map(i=>`<i class="${i<=L?'on':''}"></i>`).join('')}</span>${max?'<em class="j-neon">Al máximo</em>':`<button class="btn small${can?' primary':''}" data-act="jHouseUp" data-k="${p}" ${can?'':'disabled'}>${eur(cost)}</button>`}</div>`;}).join(''):'';
  return `<div class="j-eyebrow">${kind} · ${esc(LG[k.league].country)}</div><h2 class="j-h">Ciudad de ${esc(cityName(id))}</h2>
  <p class="muted" style="max-width:64ch">La ciudad de tu club, con su estadio y todas sus instalaciones. Tu parcela está en el barrio del club: arrastra para girar, usa la rueda para acercarte. ${P.squad==='cantera'?'Si subes al primer equipo te quedas en la misma casa.':'Si cambias de equipo, venderás tu casa y empezarás de cero en la nueva ciudad.'}</p>
  <div class="j-city"><div class="j-city3d"><div class="j-city-slot" id="jcity-slot"></div><div class="j-city-fb" hidden><p class="muted">Tu dispositivo no puede mostrar la ciudad en 3D.</p></div>
    <div class="j-city-ui"><button class="btn small" data-act="jCityView" data-k="city">Ver la ciudad</button><button class="btn small" data-act="jCityView" data-k="home">Ver mi parcela</button><button class="btn small" data-act="jCityView" data-k="stadium">Ver el estadio</button></div></div>
  <div class="j-col"><div class="j-panel j-house">${h?`<h3>Tu casa</h3><div class="j-kv"><div><small>Nivel</small><b class="num">${lvl} / 18</b></div><div><small>Invertido</small><b class="num">${eur(h.spent)}</b></div><div><small>Ahorros</small><b class="num">${eur(P.money)}</b></div></div>
    ${lvl>=18?'<p class="j-neon" style="margin:12px 0 0;font-weight:700">Casa moderna terminada.</p>':`<p class="j-hint">Mejora cada parte hasta tener una casa moderna. Primero la estructura: sin casa no hay piscina.</p>`}<div class="j-hlist">${rows}</div>`
    :`<h3>Tu parcela</h3><p>Una parcela en el barrio residencial de ${esc(cityName(id))}, con una casa sencilla para empezar.</p><div class="j-kv"><div><small>Precio</small><b class="num">${eur(price)}</b></div><div><small>Ahorros</small><b class="num">${eur(P.money)}</b></div></div>
    <div class="j-acts"><button class="btn primary" data-act="jHouseBuy" ${P.money>=price?'':'disabled'}>Comprar parcela y casa</button></div>${P.money<price?`<p class="j-hint">Te faltan ${eur(price-P.money)}. El salario entra cada semana.</p>`:''}<p class="j-hint">Sin casa propia vives de alquiler: tu moral lo nota.</p>`}</div>
   ${P.homes&&P.homes.length?`<div class="j-panel"><h3>Casas anteriores</h3>${P.homes.map(x=>`<p class="j-n"><b class="num">${x.s}</b>${esc(x.c)} · nivel ${x.lvl} · vendida por ${eur(x.v)}</p>`).join('')}</div>`:''}</div></div>`;}

/* ---------- ciudad 3D: la misma ciudad del modo Clubes (todo al máximo) y tu parcela en el barrio del club ----------
   Dirección de arte: atardecer cálido del modo Clubes; tu casa es el único acento morado (neón de la parcela y
   detalles de domótica), para que el ojo la encuentre entre el resto de la ciudad. */
const HOME_PLOT='residencial';
let C3D=null,_cityCache=null;
function cityState(cid){if(_cityCache&&_cityCache.cid===cid)return _cityCache.st;
  const prev=S;let st=null;try{newGame(cid);st=S;if(typeof ensureFac==='function')ensureFac();}finally{S=prev;}
  st.fac=st.fac||{};
  Object.keys(FAC).forEach(k=>{st.fac[k]=FAC[k].lv.length-1;});st.fac[HOME_PLOT]=0;st.build={};st.lastAtt=st.cap;st.proj=null;
  _cityCache={cid,st};return st;}
const withCityS=(st,fn)=>{const p=S;S=st;try{return fn();}finally{S=p;}};
function unmountCity(){}
function mountCity(){const slot=document.getElementById('jcity-slot');if(!slot)return;
  const fb=()=>{const f=slot.parentElement.querySelector('.j-city-fb');if(f)f.hidden=false;};
  if(typeof view15!=='function'||typeof hasGL15!=='function'||!hasGL15()){fb();return;}
  const go=()=>{try{buildCity(slot);}catch(e){console.error(e);fb();}};
  if(!window.THREE){loadThree().then(ok=>{if(ok&&document.body.contains(slot))go();else fb();});return;}go();}
function buildCity(slot){const cid=P.club,st=cityState(cid);
  const w=view15('jcity',slot,{label:`Ciudad de ${cname(cid)} en 3D. Arrastra para girar, rueda para acercar.`,orbit:{r:240,th:.72,ph:.95,min:28,max:640,pan:340},exp:1.12});
  w.canvas.classList.add('cx-canvas');
  if(!w.jcity){const up=w.update;w.update=(dt,t)=>{const s=w.jcity&&w.jcity.st;if(!s)return up(dt,t);withCityS(s,()=>up(dt,t));};}
  if(!w.jcity||w.jcity.cid!==cid){withCityS(st,()=>{buildComplex(w);applyTod(w,'tarde');});w.jcity={cid,st,house:null};}
  const [cc,rr]=PLOT7[HOME_PLOT],[px,pz]=cellC(cc,rr);
  const fly=k=>{if(k==='home')w.ctl.fly(px,2,pz,46);else if(k==='stadium')w.ctl.fly(0,4,0,105);else w.ctl.reset();};
  const rebuildHouse=()=>{const J=w.jcity;if(J.house){w.root.remove(J.house);J.house.traverse(o=>{o.geometry&&o.geometry.dispose();if(o.material){o.material.map&&o.material.map.dispose();o.material.dispose();}});}
    const g=new w.T.Group();g.position.set(px,0,pz);w.root.add(g);J.house=g;buildHome(w.T,g,hasHome()?P.home.parts:null,P.cars);if(hasHome()&&P.pet)petMesh(w.T,g,P.pet.k);
    if(!J.petA&&w.anim){J.petA=1;w.anim.push((dt,t)=>{const hs=w.jcity&&w.jcity.house,p=hs&&hs.getObjectByName('pet');if(!p)return;const a=t/2600,dx=-Math.sin(a)*1.4,dz=Math.cos(a)*1.8;p.position.set(-2+Math.cos(a)*1.4,.2+Math.abs(Math.sin(t/160))*.04,3.5+Math.sin(a)*1.8);p.rotation.y=Math.atan2(-dz,dx);});}};
  rebuildHouse();C3D={fly,rebuildHouse};if(!w.jcity.flown){w.jcity.flown=true;w.ctl.st.r=300;fly('city');}w.W=0;if(typeof kick==='function')kick();}

/* ---- tu casa: de solar a mansión moderna (unidades del mundo: la parcela mide 19 × 19) ---- */
function buildHome(T,g,parts,cars){
  const M=(c,o={})=>new T.MeshStandardMaterial({color:new T.Color(c),roughness:.8,metalness:0,...o});
  const glow=(c,i=1.2)=>new T.MeshStandardMaterial({color:new T.Color(c),emissive:new T.Color(c),emissiveIntensity:i,roughness:.4});
  const box=(w_,h,d,m,x,y,z,ry)=>{const o=new T.Mesh(new T.BoxGeometry(w_,h,d),m);o.position.set(x,y,z);if(ry)o.rotation.y=ry;o.castShadow=o.receiveShadow=true;g.add(o);return o;};
  const cyl=(rt,rb,h,m,x,y,z,seg=12)=>{const o=new T.Mesh(new T.CylinderGeometry(rt,rb,h,seg),m);o.position.set(x,y,z);o.castShadow=true;g.add(o);return o;};
  const tree=(x,z,s=1,kind=0)=>{cyl(.12*s,.16*s,1.3*s,M('#5b3d27'),x,.65*s,z,6);const top=new T.Mesh(kind?new T.ConeGeometry(.9*s,2.4*s,8):new T.IcosahedronGeometry(1.05*s,1),M(kind?'#2d6b45':'#3f8a4f',{roughness:.9}));top.position.set(x,(kind?2.3:2.05)*s,z);top.castShadow=true;g.add(top);};
  /* base de la parcela: bordillo de piedra y neón morado discreto */
  box(18.6,.18,18.6,M('#b9b2a6'),0,.09,0);
  const edge=new T.LineSegments(new T.EdgesGeometry(new T.BoxGeometry(18.2,.02,18.2)),new T.LineBasicMaterial({color:0xC99BFF}));edge.position.y=.22;g.add(edge);
  if(!parts){box(17.6,.06,17.6,M('#7a6448',{roughness:1}),0,.2,0);
    for(let i=0;i<14;i++){const a=i/14*Math.PI*2;box(.12,1.1,.12,M('#9a8f80'),Math.cos(a)*8.4,.75,Math.sin(a)*8.4);}
    cyl(.07,.07,2.6,M('#8d8d8d'),0,1.3,6.8,6);const sign=box(3.4,1.5,.12,glow('#7b3fe0',.8),0,2.7,6.8);
    const cv=document.createElement('canvas');cv.width=256;cv.height=112;const x=cv.getContext('2d');x.fillStyle='#14082a';x.fillRect(0,0,256,112);x.strokeStyle='#C99BFF';x.lineWidth=6;x.strokeRect(6,6,244,100);x.fillStyle='#F1E3FF';x.font='900 40px Impact,sans-serif';x.textAlign='center';x.fillText('TU PARCELA',128,52);x.font='700 22px sans-serif';x.fillText('Compra y construye',128,86);
    const tex=new T.CanvasTexture(cv);const face=new T.Mesh(new T.PlaneGeometry(3.3,1.45),new T.MeshBasicMaterial({map:tex}));face.position.set(0,2.7,6.87);g.add(face);return;}
  const st=parts.estructura,fa=parts.fachada,ja=parts.jardin,pi=parts.piscina,ga=parts.garaje,te=parts.tecnologia;
  /* suelo: tierra → césped → jardín → paisajismo */
  box(17.6,.06,17.6,M(ja>=1?'#4f8f45':'#7a6448',{roughness:1}),0,.2,0);
  box(2,.07,7.5,M('#d8d2c6'),1.5,.24,5.4);
  /* materiales de fachada por nivel */
  const wall=[M('#a65a44',{roughness:.95}),M('#efe9df',{roughness:.85}),M('#8a6142',{roughness:.7}),M('#f4f4f2',{roughness:.5})][fa];
  const trim=[M('#e8e0d2'),M('#c9c1b4'),M('#5e646b',{metalness:1,roughness:.4}),M('#26292e',{metalness:1,roughness:.35})][fa];
  const glass=new T.MeshStandardMaterial({color:new T.Color('#9fc4e8'),roughness:.05,metalness:.9,emissive:new T.Color('#ffd8a0'),emissiveIntensity:fa>=3?.55:.35,transparent:true,opacity:.85});
  const win=(x,y,z,w_,h,ry=0)=>{const o=box(w_,h,.08,glass,x,y,z,ry);o.castShadow=false;box(w_+.16,.12,.14,trim,x,y-h/2-.04,z+(ry?0:.02),ry);};
  if(st===1){/* casa básica: una planta y tejado a dos aguas */
    box(7,2.8,5.4,wall,-1,1.65,-2.4);
    const sh=new T.Shape();sh.moveTo(-3.9,0);sh.lineTo(3.9,0);sh.lineTo(0,2);sh.lineTo(-3.9,0);
    const roof=new T.Mesh(new T.ExtrudeGeometry(sh,{depth:6.2,bevelEnabled:false}),M('#7a3b2e',{roughness:.9}));roof.position.set(-1,3.05,-5.5);roof.castShadow=true;g.add(roof);
    box(.6,1.6,.6,M('#8c8279'),.6,4.2,-3);win(-3.1,1.8,.32,1.4,1.1);win(1.2,1.8,.32,1.4,1.1);box(1.1,2.1,.1,M('#4a2f22'),-1,1.3,.33);
    box(2.4,.18,1.4,M('#bfb6a8'),-1,.33,1.1);}
  else if(st===2){/* dos plantas, tejado a cuatro aguas y balcón */
    box(8.4,2.8,6,wall,-1,1.65,-2.4);box(8.4,2.8,6,wall,-1,4.45,-2.4);box(8.8,.22,6.4,trim,-1,3.05,-2.4);
    const hip=new T.Mesh(new T.ConeGeometry(6.4,2.3,4,1),M('#4a4f57',{roughness:.7}));hip.rotation.y=Math.PI/4;hip.scale.set(1,1,.72);hip.position.set(-1,7.0,-2.4);hip.castShadow=true;g.add(hip);
    [-3.6,-1,1.6].forEach(x=>{win(x,1.8,.62,1.5,1.3);win(x,4.6,.62,1.5,1.3);});box(1.2,2.2,.1,M('#2e2a28'),-1,1.3,.64);
    box(4,.16,1.4,trim,-1,3.2,1.3);box(4,.9,.06,new T.MeshStandardMaterial({color:'#cfe2ff',transparent:true,opacity:.35,roughness:.05}),-1,3.7,1.98);}
  else if(st>=3){/* mansión moderna: volúmenes en voladizo, cristal, madera y cubiertas planas */
    box(11,3,7,wall,-1.2,1.7,-2.6);
    win(-1.2,1.75,.94,9.4,2.4);
    box(9.4,3,5.6,M(fa>=2?'#3b2a20':'#e8e6e2',{roughness:.6}),.6,4.85,-3.6);
    for(let i=0;i<14;i++)box(.18,2.8,.1,M('#a8754e',{roughness:.65}),-3.9+i*.6,4.85,-.77);
    win(3.6,4.85,-.75,2.6,2.4);box(12.2,.26,8.2,trim,-1.2,3.3,-2.4);box(10.4,.26,6.8,trim,.6,6.45,-3.4);
    box(3.6,.08,3.6,M('#d9d3c8'),-4.6,6.62,-4.4);box(3.6,.9,.06,new T.MeshStandardMaterial({color:'#cfe2ff',transparent:true,opacity:.35}),-4.6,7.05,-2.62);
    for(let s=0;s<6;s++)box(1.4,.2,.5,M('#cfc8bc'),5.3,.4+s*.5,-1.2-s*.5);
    box(1.6,6.2,1.6,M('#2b2e33',{metalness:1,roughness:.4}),-6.4,3.2,-2.4);}
  if(st>=1){/* luz interior para el atardecer */const L=new T.PointLight(0xffc98a,.9,18);L.position.set(-1,2.5,-1);g.add(L);}
  /* jardín */
  if(ja>=2){[[-7,-7.5],[-4,-7.8],[3,-7.6],[6.5,-7],[7.5,-3]].forEach(([x,z],i)=>tree(x,z,1,i%2));for(let i=0;i<12;i++)box(1.3,.7,.7,M('#2f6b3f',{roughness:.95}),-7.6+i*1.38,.55,7.9);}
  if(ja>=3){for(let i=0;i<7;i++){const p=new T.Mesh(new T.SphereGeometry(.09,8,6),glow('#ffe2a8',2));p.position.set(.6,.32,1.6+i*.9);g.add(p);const q=p.clone();q.position.x=2.4;g.add(q);}
    tree(7.3,6.8,1.3,0);tree(-7.4,6.6,1.2,1);}
  /* piscina */
  if(pi>=1){const w_=pi>=3?7:4.2,d=pi>=3?3:2.6,x=pi>=3?4.2:5,z=pi>=3?4.6:4.8;
    box(w_+.6,.24,d+.6,M('#e9e4da'),x,.3,z);
    const water=new T.Mesh(new T.BoxGeometry(w_,.1,d),new T.MeshStandardMaterial({color:'#2fc0e6',emissive:new T.Color('#1aa6d6'),emissiveIntensity:pi>=3?.9:.45,roughness:.05,metalness:.1}));water.position.set(x,.43,z);g.add(water);
    if(pi>=2){box(w_+3,.12,1.6,M('#a8754e',{roughness:.7}),x,.32,z-d/2-1.2);for(let i=0;i<3;i++)box(.7,.25,1.6,M('#f2efe8'),x-w_/2+1+i*1.6,.52,z-d/2-1.2);
      cyl(.05,.05,2,M('#d9d3c8'),x+w_/2,1.3,z-d/2-1.2,6);const um=new T.Mesh(new T.ConeGeometry(1.2,.5,8),M('#f2efe8'));um.position.set(x+w_/2,2.3,z-d/2-1.2);g.add(um);}
    if(pi>=3){const spa=new T.Mesh(new T.CylinderGeometry(1,1,.3,20),new T.MeshStandardMaterial({color:'#5fd6f2',emissive:new T.Color('#3ab8e0'),emissiveIntensity:.9}));spa.position.set(x-w_/2-1.4,.45,z);g.add(spa);
      const L=new T.PointLight(0x7fe0ff,1,9);L.position.set(x,1.2,z);g.add(L);}}
  /* garaje */
  const car=(x,z,col)=>{const b=box(1.9,.62,4,M(col,{roughness:.25,metalness:1}),x,.62,z);const c=box(1.6,.5,2,M('#1a1c20',{roughness:.1,metalness:1}),x,1.15,z-.2);[[-.9,-1.3],[.9,-1.3],[-.9,1.3],[.9,1.3]].forEach(([dx,dz])=>{const wh=new T.Mesh(new T.CylinderGeometry(.34,.34,.24,14),M('#111'));wh.rotation.z=Math.PI/2;wh.position.set(x+dx,.36,z+dz);g.add(wh);});};
  if(ga===1){box(3.6,.16,5,M('#6c7078'),-6.3,2.6,2.4);[[-7.9,.2],[-4.7,.2],[-7.9,4.6],[-4.7,4.6]].forEach(([x,z])=>cyl(.08,.08,2.5,M('#9a9a9a'),x,1.3,z,6));}
  if(ga>=2){box(ga>=3?7.2:4,2.8,5.4,wall,ga>=3?-5.6:-6.3,1.6,3.4);box(ga>=3?6.4:3.4,2.2,.08,M('#3b3f46',{metalness:1,roughness:.5}),ga>=3?-5.6:-6.3,1.4,6.12);if(!(cars&&cars.length)){car(-6.3,9.2-0.6*0,ga>=3?'#7a2ee0':'#d7d9dd');if(ga>=3)car(-3,8.9,'#111216');}}
  if(cars&&cars.length)homeCars(T,g,M,glow,cars);
  /* tecnología */
  const roofTop=st===1?4.1:st===2?6.1:6.6;
  if(te>=1&&st>=1){for(let i=0;i<4;i++){const p=box(1.3,.06,1.9,M('#1c2c5a',{metalness:1,roughness:.25}),(st>=3?2:-2.6)+i*1.45,roofTop+.15,st>=3?-4.4:-3.4);p.rotation.x=st>=3?-.2:0;}}
  if(te>=2){[[-6,6.6],[1.5,1],[7,1]].forEach(([x,z])=>{const L=new T.SpotLight(0xffe0b0,1.2,10,.6,.6);L.position.set(x,.3,z);L.target.position.set(x,5,z-2);g.add(L);g.add(L.target);});}
  if(te>=3&&st>=1){const n=glow('#b57bff',2.2);box(st>=3?12.2:8.8,.08,.08,n,st>=3?-1.2:-1,st>=3?3.46:3.2,st>=3?1.72:.65);if(st>=3)box(10.4,.08,.08,n,.6,6.6,-.02);
    const L=new T.PointLight(0xb57bff,1.1,14);L.position.set(-1,2,3);g.add(L);box(.4,1.4,.4,M('#e8e8e8'),-2.8,.9,6.6);box(.3,.3,.06,glow('#7bff9a',1.5),-2.8,1.3,6.82);}
}

/* ====== ampliación: equipaciones, celebraciones, álbum de cartas, química, rasgos, posiciones, momentos en primera
   persona, familia (y tu hijo futbolista), garaje, inversiones y carrera de entrenador tras la retirada ====== */

/* ---------- equipaciones ---------- */
const KITS={local:'Local',visitante:'Visitante',tercera:'Tercera',seleccion:'Selección'};
const NATK={'España':['#C8102E','#FFC72C','#0B2A6B'],'Argentina':['#75AADB','#FFFFFF','#14141A'],'Brasil':['#FFDC02','#009739','#1C3F94'],'Francia':['#14256B','#FFFFFF','#FFFFFF'],'Inglaterra':['#F4F4F6','#0B1E5B','#0B1E5B'],'Portugal':['#A2192D','#0B6B3A','#A2192D'],'Alemania':['#F4F4F6','#141414','#141414'],'Italia':['#1E5BC6','#FFFFFF','#FFFFFF'],'Países Bajos':['#F36C21','#14256B','#F36C21'],'Bélgica':['#C8102E','#FFD100','#C8102E'],'Croacia':['#F4F4F6','#D7141A','#1C3F94'],'Uruguay':['#5CB3E6','#FFFFFF','#14141A'],'Colombia':['#FCD116','#003893','#003893'],'Marruecos':['#C1272D','#006233','#006233'],'Senegal':['#F4F4F6','#00853F','#F4F4F6'],'México':['#006847','#FFFFFF','#FFFFFF'],'Estados Unidos':['#F4F4F6','#0A3161','#0A3161'],'Japón':['#1B2C6B','#FFFFFF','#1B2C6B'],'Chile':['#D52B1E','#0039A6','#0039A6'],'Arabia Saudí':['#F4F4F6','#006C35','#006C35']};
function kitOf(L){if(L.kitC)return L.kitC;const c=L.club&&club(L.club),k=L.kit||'local';
  if(k==='seleccion'&&NATK[L.nat]){const n=NATK[L.nat];return{s:n[0],t:n[1],p:n[2],m:n[0]};}
  if(!c)return{s:'#6B2BD9',t:'#E4CCFF',p:'#1A0F33',m:'#F1E9FF'};
  if(k==='visitante')return{s:c.c2,t:c.c1,p:c.c1,m:c.c2};
  if(k==='tercera')return{s:'#16101F',t:'#C99BFF',p:'#16101F',m:'#2A1A45'};
  return{s:c.c1,t:c.c2,p:c.c2,m:c.c1};}

/* ---------- celebraciones: se eligen en Aspecto, se ven en el modelo 3D y aparecen en cada gol ---------- */
const CELEB=[['Puño al cielo',0],['De rodillas',0],['Corazón con las manos',0],['El avión',0],['Silencio a la grada',20],['El baile',35],['Salto y giro',50],['Voltereta',70]];
const celebName=()=>CELEB[(P&&P.celeb)||0][0];
function celebPose(G,fig,id,u){const aL=fig.getObjectByName('armL'),aR=fig.getObjectByName('armR'),s=Math.sin,e=Math.min(1,u/.3),k=e*(u>2.7?Math.max(0,1-(u-2.7)/.5):1);
  let py=0,pz=0,rx=0,rz=0,L=[0,-.05],Rr=[0,.05];
  switch(id){
    case 0:L=[0,-.2];Rr=[-2.95,.12];py=Math.abs(s(u*6))*.14;break;
    case 1:L=[-.35,-1.3];Rr=[-.35,1.3];rx=-.3;py=-.3;pz=Math.min(u,.7)*.7;break;
    case 2:L=[-2.15,.45];Rr=[-2.15,-.45];py=Math.abs(s(u*3))*.04;break;
    case 3:L=[0,-1.5];Rr=[0,1.5];rz=s(u*4)*.25;G.rotY+=.035*k;break;
    case 4:L=[0,-.1];Rr=[-2.55,-.6];break;
    case 5:{const b=s(u*9);L=[-1.3-b*.9,-.5];Rr=[-1.3+b*.9,.5];py=Math.abs(b)*.09;G.rotY+=s(u*4.5)*.02;break;}
    case 6:{const q=clamp(u/1.1,0,1);py=u<1.1?s(q*Math.PI)*.65:0;if(u<1.1)G.rotY+=Math.PI*2/66;L=[0,u<1.1?-.4:-.8];Rr=[0,u<1.1?.4:.8];break;}
    case 7:{const q=clamp((u-.15)/.85,0,1),th=-q*Math.PI*2;fig.position.set(0,s(q*Math.PI)*.9+1-Math.cos(th),-Math.sin(th));fig.rotation.x=th;fig.rotation.z=0;
      if(aL){aL.rotation.x=-2.6*k;aL.rotation.z=-.2*k;}if(aR){aR.rotation.x=-2.6*k;aR.rotation.z=.2*k;}return;}}
  fig.position.set(0,py*k,pz*k);fig.rotation.x=rx*k;fig.rotation.z=rz*k;
  if(aL){aL.rotation.x=L[0]*k;aL.rotation.z=L[1]*k;}if(aR){aR.rotation.x=Rr[0]*k;aR.rotation.z=Rr[1]*k;}}
function playCeleb(){if(G3D){G3D.rotY=0;G3D.celeb={id:(lookSrc().celeb)||0,t0:performance.now()};}}
function celebFx(e){const id=P.celeb||0;if(id===4&&!e.home){P.rep.polemico+=.4;P.fame=clamp(P.fame+.6,0,100);}else if(id===2)P.rep.humilde+=.15;else if(id>=5)P.rep.mediatico+=.2;}
function lookExtra(src){
  return `<div class="j-grp"><h4>Equipación</h4><div class="j-chips" role="radiogroup" aria-label="Equipación">${Object.entries(KITS).map(([k,l])=>{const dis=k==='seleccion'&&!P.sel.caps,on=(src.kit||'local')===k;return `<button class="j-chip${on?' on':''}" role="radio" aria-checked="${on}" data-act="jKit" data-k="${k}" ${dis?'disabled title="Debuta con la absoluta para desbloquearla"':''}>${l}${dis?' · al debutar':''}</button>`;}).join('')}</div></div>
   <div class="j-grp"><h4>Celebración de gol</h4><div class="j-chips" role="radiogroup" aria-label="Celebración de gol">${CELEB.map(([l,f],i)=>{const lock=P.fame<f,on=(src.celeb||0)===i;return `<button class="j-chip${on?' on':''}" role="radio" aria-checked="${on}" data-act="jCelebSet" data-k="${i}" ${lock?'disabled':''}>${l}${lock?` · fama ${f}`:''}</button>`;}).join('')}</div>
   <button class="btn small" data-act="jCeleb" style="margin-top:10px">Ver celebración en 3D</button></div>`;}
function chipOn(el){const g=el&&el.closest('[role=radiogroup]');if(g)g.querySelectorAll('[role=radio]').forEach(b=>{const on=b===el;b.classList.toggle('on',on);b.setAttribute('aria-checked',String(on));});}

/* ---------- álbum de cartas de temporada ---------- */
const CARDT={debut:'Debut',bronce:'Bronce',plata:'Plata',oro:'Oro',forma:'En forma',campeon:'Campeón',tots:'Equipo de la temporada',balon:'Balón de Oro',icono:'Icono'};
function snap(){return{name:P.name,last:P.last,num:P.num,pos:P.pos,club:P.club,nat:P.nat,at:{...P.at},skin:P.skin,hair:P.hair,hairc:P.hairc,beard:P.beard,boots:P.boots,acc:P.acc,kit:P.kit};}
function addCard(type,label){P.cards=P.cards||[];const c={t:type,s:label||seasonLabel(P.season),o:ovr(),p:snap()};P.cards.push(c);news(`Nueva carta para tu álbum: ${CARDT[type]} · ${c.o}.`,type==='bronce'||type==='plata'?'':'hot');return c;}
function seasonCard(n,o){const sl=seasonLabel(P.season),aw=P.awards.filter(a=>a.s===sl).map(a=>a.n),tt=P.titles.filter(t=>t.s===sl).length;
  addCard(aw.includes('Balón de Oro')?'balon':aw.includes('Once ideal de la temporada')?'tots':tt?'campeon':n>=7.3?'forma':o>=75?'oro':o>=65?'plata':'bronce');}
function cardBox(c){return `<figure class="j-cc v-${c.t}">${card(c.p,false)}<figcaption><b>${CARDT[c.t]}</b><small>${esc(c.s)} · ${esc(cname(c.p.club))}</small></figcaption></figure>`;}
function vAlbum(){const C=P.cards||[],counts={};C.forEach(c=>{counts[c.t]=(counts[c.t]||0)+1;});
  return `<div class="j-eyebrow">Colección</div><h2 class="j-h">Álbum de cartas</h2><p class="muted" style="max-width:64ch">Cada temporada ganas una carta: bronce, plata u oro según tu media, o una especial si estás en forma, ganas un título, entras en el once ideal o te llevas el Balón de Oro. Al retirarte llega la carta Icono.</p>
  <div class="j-bigs"><div><b class="num">${C.length}</b>cartas</div>${Object.keys(CARDT).filter(k=>counts[k]).map(k=>`<div><b class="num">${counts[k]}</b>${CARDT[k]}</div>`).join('')}</div>
  ${C.length?`<div class="j-album">${C.slice().reverse().map(cardBox).join('')}</div>`:'<p class="muted">Tu primera carta llega al firmar con un club.</p>'}`;}

/* ---------- química con compañeros ---------- */
function ensureMates(){if(!P.club)return;if(P.matesClub===P.club&&P.mates&&P.mates.length>=5)return;const pool=squadNames(P.club,P.last).filter(n=>n!=='un compañero');while(pool.length<5){const n=pk(FIRSTN)+' '+pk(LASTN);if(!pool.includes(n))pool.push(n);}P.mates=[];
  for(let i=0;i<5&&pool.length;i++)P.mates.push({n:pool.splice(R(0,pool.length-1),1)[0],c:R(25,45)});P.matesClub=P.club;}
function pickMate(){ensureMates();const m=P.mates||[];if(!m.length)return{n:'un compañero',c:50};let r=Math.random()*m.reduce((s,x)=>s+x.c+10,0);for(const x of m){r-=x.c+10;if(r<=0)return x;}return m[0];}
const topChem=()=>{ensureMates();return (P.mates||[]).reduce((a,x)=>Math.max(a,x.c),0);};
function chemAfterMatch(){ensureMates();const M=P.mates||[],on=new Set([pk(M),pk(M)]);M.forEach(x=>{x.c=clamp(x.c+(on.has(x)?R(1,2):-.25),0,100);if(x.c>=80&&!x.duo){x.duo=true;news(`${P.last} y ${x.n} forman una dupla letal: se entienden con la mirada.`,'hot');}});
  P.chem=clamp(P.chem+(hasT('lider')?1:.4),0,100);}
function chemPanel(){ensureMates();return `<div class="j-panel"><h3>Química con compañeros</h3>${(P.mates||[]).map(m=>meter(esc(m.n)+(m.duo?' · dupla':''),m.c)).join('')}<p class="j-hint">Cuanta más química, más fácil es el pase de gol, y tus asistencias buscan a quien mejor te entiende. Se gana jugando juntos.</p></div>`;}

/* ---------- rasgos que evolucionan ---------- */
const TRAITS={grandes:['Jugador de grandes partidos',1,'+5 % de acierto en Copa y Champions.'],killer:['Asesino del área',1,'+4 % en los disparos.'],seda:['Pie de seda',1,'+5 % en los regates.'],pulmon:['Pulmón',1,'Acumulas menos fatiga cada semana.'],lider:['Líder nato',1,'La química del vestuario sube más rápido.'],veterano:['Veteranía',1,'+3 % de acierto en todo.'],mediatico:['Imán mediático',1,'Tus patrocinadores pagan un 20 % más.'],cristal:['Cristal',-1,'Te lesionas con más facilidad.'],nervios:['Se le encoge el brazo',-1,'-5 % de acierto en Copa y Champions.'],irregular:['Irregular',-1,'Tu forma sube y baja más de la cuenta.']};
const hasT=k=>!!(P&&P.traits&&P.traits[k]);
function traitsTick(){P.traits=P.traits||{};const S=P.sea,n=S.rt.length?avg(S.rt):0,big=S.big||[],bn=big.length?avg(big):0;
  const set=(k,on)=>{if(on&&!P.traits[k]){P.traits[k]=seasonLabel(P.season);news(`${P.last} gana un rasgo: ${TRAITS[k][0]}.`,TRAITS[k][1]>0?'hot':'bad');}else if(!on&&P.traits[k]){delete P.traits[k];news(`${P.last} pierde el rasgo «${TRAITS[k][0]}».`,TRAITS[k][1]>0?'bad':'hot');}};
  if(big.length>=3){set('grandes',bn>=7.4||(hasT('grandes')&&bn>=6.8));set('nervios',bn<5.9||(hasT('nervios')&&bn<6.5));}
  set('killer',S.g>=20||(hasT('killer')&&S.g>=12));set('seda',P.at.reg>=78&&P.sk>=4);
  set('pulmon',(P.at.fis>=78&&S.min>=2400)||(hasT('pulmon')&&P.at.fis>=74));set('lider',P.captain||P.rep.lider>=6);
  set('veterano',P.age>=30&&P.st.pj>=250);set('mediatico',P.fame>=70);set('cristal',(S.inj||0)>=2||(hasT('cristal')&&(S.inj||0)>=1));
  const sd=S.rt.length>5?Math.sqrt(avg(S.rt.map(x=>(x-n)**2))):0;set('irregular',sd>1.35||(hasT('irregular')&&sd>1.1));}
function traitPanel(){const t=Object.keys(P.traits||{});return `<div class="j-panel"><h3>Rasgos</h3>${t.length?`<div class="j-skills">${t.map(k=>`<div class="${TRAITS[k][1]>0?'pos':'neg'}"><b>${TRAITS[k][0]}</b><small>${TRAITS[k][2]}</small></div>`).join('')}</div>`:''}<p class="j-hint">Aparecen y desaparecen al final de cada temporada según cómo juegues: grandes noches, goles, lesiones, regularidad…</p></div>`;}
/* bonificaciones de rasgos, química y posición en cada jugada */
function xBonus(k){const e=UI.jm&&UI.jm.e,big=!!e&&(e.type==='copa'||e.type==='eur');
  return (big&&hasT('grandes')?.05:0)-(big&&hasT('nervios')?.05:0)+(k==='tir'&&hasT('killer')?.04:0)+(k==='reg'&&hasT('seda')?.05:0)+(hasT('veterano')?.03:0)
    +(k==='pas'&&P.club?(topChem()-50)/600:0)-(100-(posF()[P.pos]??100))/500;}

/* ---------- posiciones y reconversión ---------- */
function posF(){P.posf=P.posf||{};if(P.posf[P.pos]==null)P.posf[P.pos]=100;if(P.posf[P.pos2]==null)P.posf[P.pos2]=60;return P.posf;}
function setPos(np,why){const f=posF();if(np===P.pos)return;const old=P.pos;P.pos=np;if(P.pos2===np)P.pos2=old;f[np]=f[np]??30;news(`${P.last} pasa a jugar de ${POS[np].toLowerCase()}${why?' '+why:''}.`,'hot');}
function posPanel(){const f=posF(),gk=P.pos==='POR';
  return `<div class="j-panel"><h3>Posiciones</h3><p class="j-hint">Jugar fuera de tu sitio resta acierto hasta que te adaptas. Elige una posición para aprenderla en los entrenamientos y pide jugar en ella cuando la domines.</p>
  ${Object.keys(POS).filter(k=>(k==='POR')===gk).map(k=>{const v=Math.round(f[k]||0),cur=k===P.pos;return `<div class="j-pos${cur?' on':''}"><span>${POS[k]}${cur?' · actual':P.learn===k?' · aprendiendo':''}</span><i><u style="width:${v}%"></u></i><b class="num">${v}</b>${cur?'':`<div class="j-pos-b"><button class="btn small" data-act="jLearn" data-k="${k}" ${P.learn===k?'disabled':''}>Aprender</button><button class="btn small" data-act="jPosSet" data-k="${k}" ${v>=50?'':'disabled'}>Jugar aquí</button></div>`}</div>`;}).join('')}</div>`;}

/* ---------- momentos clave en primera persona: penalti, falta, mano a mano y penalti en contra ---------- */
const ZN=['Arriba a la izquierda','Arriba al centro','Arriba a la derecha','Abajo a la izquierda','Abajo al centro','Abajo a la derecha'];
const zc=z=>[[16.7,28],[50,28],[83.3,28],[16.7,74],[50,74],[83.3,74]][z];
function fpHTML(kind){return `<div class="fp fp-${kind}"><div class="fp-scene" aria-hidden="false"><div class="fp-sky"></div><div class="fp-stand"></div><div class="fp-turf"></div>
  <div class="fp-goal"><div class="fp-net"></div><div class="fp-gk"><i class="h"></i><i class="b"></i></div><div class="fp-zones">${ZN.map((l,i)=>`<button class="fp-z" data-act="jFpAim" data-z="${i}" aria-label="${l}"></button>`).join('')}</div></div>
  ${kind==='fk'?'<div class="fp-wall"><i></i><i></i><i></i><i></i></div>':''}<div class="fp-ball"></div></div>
  <div class="fp-ui"><p class="fp-step">${kind==='gk'?'Eres el portero: elige hacia dónde te lanzas':'1 · Elige dónde apuntar'}</p><div class="j-bar fp-pow" hidden></div><div><button class="btn primary fp-go" data-act="jFpShoot" hidden>¡Chuta!</button></div></div></div>`;}
function startFp(box,kind,cb){const oppS=UI.jm?UI.jm.oppS:70,opp=UI.jm&&UI.jm.e&&UI.jm.e.opp&&club(UI.jm.e.opp);box.innerHTML=fpHTML(kind);const root=box.querySelector('.fp');
  const gk=root.querySelector('.fp-gk');gk.style.setProperty('--gk',kind==='gk'?'#B57BFF':opp?opp.c2:'#FFD24A');const wall=root.querySelector('.fp-wall');if(wall&&opp)wall.style.setProperty('--wall',opp.c1);
  UI.fp={kind,cb,aim:null,oppS,root,w:clamp(12+P.at.tir/5,14,32),c:R(45,70),done:false};try{fp3D(UI.fp);}catch(e){console.error(e);}root.querySelector('.fp-z').focus({preventScroll:true});}
function fpAim(z){const F=UI.fp;if(!F||F.aim!=null||!document.body.contains(F.root))return;F.aim=z;F.root.querySelectorAll('.fp-z').forEach((b,i)=>b.classList.toggle('sel',i===z));
  if(F.kind==='gk'){fpFinish(null);return;}
  F.root.querySelector('.fp-step').textContent='2 · Para la potencia dentro de la zona morada';
  const bar=F.root.querySelector('.fp-pow');bar.hidden=false;bar.innerHTML=`<i class="z" style="left:${F.c-F.w/2}%;width:${F.w}%"></i><span style="--dur:${clamp(1.25-P.at.tir/220,.7,1.1)}s"></span>`;
  const go=F.root.querySelector('.fp-go');go.hidden=false;go.focus({preventScroll:true});}
function fpShoot(){const F=UI.fp;if(!F||F.aim==null||F.done)return;const bar=F.root.querySelector('.fp-pow'),mk=bar.querySelector('span'),b=bar.getBoundingClientRect(),m=mk.getBoundingClientRect();
  const pw=(m.left+m.width/2-b.left)/b.width*100;mk.style.animation='none';mk.style.left=`calc(${pw}% - 3px)`;fpFinish(pw);}
function fpFinish(pw){const F=UI.fp;F.done=true;F.root.classList.add('done');F.root.querySelector('.fp-go').hidden=true;
  const z=F.aim,top=z<3,k=F.kind;let out,kz,bz=z;
  if(k==='gk'){const wts=[.12,.08,.12,.3,.08,.3];let r=Math.random();bz=5;for(let i=0;i<6;i++){r-=wts[i];if(r<0){bz=i;break;}}kz=z;
    out=ch(.07)?'miss':bz===z?(ch(.82+P.at.def/1000)?'save':'goal'):bz%3===z%3?(ch(.3)?'save':'goal'):'goal';}
  else{const d=pw-F.c,over=d>F.w/2,weak=d<-F.w/2,guess={pen:.3,fk:.22,uno:.4}[k]+(F.oppS-65)/250;
    kz=ch(guess)?z:pk([0,1,2,3,4,5].filter(i=>i!==z));
    if(k==='fk'&&(z===3||z===4)&&!over&&ch(z===4?.8:.5))out='wall';
    else if(over)out=top||ch(.5)?'miss':kz===z&&ch(.4)?'save':'goal';
    else if(weak)out=kz===z?'save':ch(k==='fk'?.35:.55)?'goal':'save';
    else out=kz===z?(ch(top?.3:.65)?'save':'goal'):(k==='fk'&&ch(.15)?'miss':'goal');}
  if(F.g3)F.g3.anim(out,kz,bz);else{const gk=F.root.querySelector('.fp-gk'),ball=F.root.querySelector('.fp-ball'),[gx,gy]=zc(kz),[bx,by]=zc(bz);
  gk.style.left=gx+'%';gk.style.top=gy+'%';gk.style.transform=`translate(-50%,-50%) rotate(${gx<40?-72:gx>60?72:0}deg)`;
  let sx=18+64*bx/100,sy=18+44*by/100;if(out==='miss'){sy=4;sx+=bx<40?-6:bx>60?6:0;}if(out==='wall'){sx=48;sy=52;}
  ball.style.left=sx+'%';ball.style.top=sy+'%';ball.style.transform='translate(-50%,-50%) scale(.55)';
  if(out==='save')setTimeout(()=>{ball.style.top=(sy+20)+'%';ball.style.left=(sx+(sx<50?8:-8))+'%';},480);}
  const label=k==='gk'?{save:'¡PARADÓN!',miss:'¡FUERA!',goal:'Gol del rival'}[out]:{goal:'¡GOL!',save:'¡Para el portero!',miss:'¡Fuera!',wall:'¡Barrera!'}[out];
  const showL=()=>{F.root.querySelector('.fp-step').innerHTML=`<span class="fp-res ${(k==='gk'?out!=='goal':out==='goal')?'ok':'ko'}">${label}</span>`;};
  if(F.g3){F.root.querySelector('.fp-step').textContent='…';setTimeout(showL,k==='fk'?1000:k==='gk'?1200:700);}else showL();
  const cb=F.cb;setTimeout(()=>{if(UI.fp===F)UI.fp=null;cb&&cb(out);},reduced()?700:F.g3?2400:1500);}
function fpAuto(k){if(k==='gk')return ch(.24+P.at.def/500)?'save':'goal';return ch(clamp({pen:.7+P.at.tir/500,fk:.08+P.at.tir/550,uno:.32+P.at.tir/320}[k],.05,.92))?'goal':pk(['save','miss']);}
function fpResolve(mo,R0){const out=mo.out||fpAuto(mo.fk);if(mo.out){if(mo.fk==='gk'&&out==='save')flag('save');if(out==='goal'&&(mo.fk==='pen'||mo.fk==='fk'))flag(mo.fk);}let t,ok;
  if(mo.fk==='gk'){ok=out!=='goal';if(ok){R0.saves++;R0.ok++;t=out==='save'?'¡Paradón! Adivinas el lado y detienes el penalti.':'El lanzador manda el penalti fuera.';}else{R0.ko+=.5;R0.conc=(R0.conc||0)+1;t='Penalti en contra: el lanzador te engaña.';}}
  else{ok=out==='goal';if(ok){R0.g++;t={pen:`¡GOL de penalti! ${P.last} no perdona.`,fk:`¡GOLAZO de falta! ${P.last} la clava lejos del portero.`,uno:`¡GOL! ${P.last} gana el mano a mano.`}[mo.fk]+` Lo celebra: ${celebName()}.`;}
    else{R0.ko+=.5;t=out==='save'?'El portero adivina tu disparo y lo detiene.':out==='wall'?'El balón se estrella en la barrera.':'El disparo se marcha fuera.';}}
  R0.log.push(`${mo.m}' ${t}`);return{ok,t};}
function fpMoment(m,att){if(P.pos==='POR'&&ch(.22))return{m,kind:'fp',fk:'gk',text:'Penalti en contra. Estás bajo palos: elige hacia dónde te lanzas.',opts:[['Lanzarse','def',0]]};
  if(att&&ch(.24)){const fk=pk(['pen','fk','uno','uno']);return{m,kind:'fp',fk,text:{pen:'¡Penalti a favor! Coges el balón: lo tiras tú.',fk:'Falta directa al borde del área. La barrera se coloca.',uno:'Te quedas solo delante del portero.'}[fk],opts:[['Tirar','tir',0]]};}
  return null;}

/* ---------- familia y tu hijo futbolista ---------- */
const PARTN=['Lucía','Álex','Sara','Noa','Inés','Dani','Carla','Andrea','Maya','Sam','Elena','Martina'];
const KIDN=['Leo','Hugo','Martín','Lucas','Mateo','Pablo','Álvaro','Nico','Bruno','Iker','Marco','Teo','Gael','Thiago'];
function fam(){return P.family||(P.family={partner:null,married:false,kids:[]});}
const kidAge=k=>P.season-k.b;
function kidStatus(k){const a=kidAge(k);if(!k.fb)return a<3?'En casa':a<18?'Estudia':'Hace su vida';
  return a<5?'Aún no da patadas':a<10?'Juega en el equipo del barrio':a<18?`Cantera de ${cname(k.club)}`:k.pro?`Profesional en ${cname(k.club)}`:'Estudia';}
function familyTick(){const F=fam(),cid=(P.coach&&P.coach.club)||P.club||P.origin0;
  F.kids.forEach(k=>{if(!k.fb)return;k.ms=k.ms||[];const a=kidAge(k),say=(m,t,h)=>{if(a>=m&&!k.ms.includes(m)){k.ms.push(m);news(t,h);}};
    say(5,`${k.n} da sus primeras patadas al balón en el jardín de casa.`);
    say(8,`${k.n} se apunta al equipo del barrio. Dicen que tiene tu zancada.`);
    if(a>=10&&!k.club&&cid)k.club=cid;
    if(k.club)say(10,`${k.n} entra en la cantera de ${cname(k.club)}.`,'hot');
    say(13,`Los ojeadores dan a ${k.n} un potencial de ${k.pot} estrellas.`);
    say(16,k.pot>=3?`${k.n} es convocado con la ${P.nat} sub-17.`:`${k.n} sigue formándose en el juvenil de ${cname(k.club)}.`,k.pot>=3?'hot':'');
    if(a>=18&&!k.ms.includes(18)){k.pro=k.pot>=2;}
    say(18,k.pot>=2?`${k.n} firma su primer contrato profesional con ${cname(k.club)}.`:`${k.n} decide estudiar y aparcar el fútbol.`,'hot');
    if(a>=19&&k.pro&&P.coach&&P.coach.club===k.club&&!k.ms.includes(99)){k.ms.push(99);news(`${k.n} debuta en el primer equipo de ${cname(k.club)} bajo tus órdenes.`,'hot');}});}
function famPanel(){const F=fam();
  return `<div class="j-panel"><h3>Familia</h3>${F.partner?`<p class="j-n"><b>${F.married?'Matrimonio':'Pareja'}</b>${esc(F.partner.n)}</p>`:'<p class="muted">Sin pareja por ahora. La vida fuera del campo también tiene sus momentos.</p>'}
  ${F.kids.map(k=>{const a=kidAge(k);return `<div class="j-kid"><b>${esc(k.n)}${k.fb?' · futbolista':''}</b><small>${a<1?'Recién nacido':a+' año'+(a>1?'s':'')} · ${kidStatus(k)}</small>${k.fb?`<span>${a>=13?stars(k.pot):'<em class="muted">Potencial ¿?</em>'}</span>`:''}</div>`;}).join('')}
  ${F.kids.some(k=>k.fb)?'<p class="j-hint">Tu hijo crece temporada a temporada: barrio, cantera, selección… Su potencial se descubre a los 13 años.</p>':''}</div>`;}

/* ---------- garaje ---------- */
const CARS=[['urbano','Utilitario eléctrico',28000,'#7FD1FF'],['suv','SUV familiar',75000,'#3A3F4A'],['gt','Deportivo GT',190000,'#E8283C'],['clasico','Clásico de colección',340000,'#E6C068'],['todo','Todoterreno de lujo',460000,'#F2F2F2'],['hiper','Hiperdeportivo',1900000,'#B57BFF']];
const garageCap=()=>hasHome()?[1,2,3,5][P.home.parts.garaje]:1;
function garagePanel(){const cars=P.cars||[],cap=garageCap();
  return `<div class="j-panel"><h3>Garaje · <span class="num">${cars.length}/${cap}</span> plazas</h3><p class="j-hint">${hasHome()?'Tus coches aparcan en tu parcela de la Ciudad. Mejora el garaje de tu casa para tener más plazas.':'Sin casa propia solo tienes una plaza alquilada. Compra tu parcela en la Ciudad para verlos aparcados.'}</p>
  ${CARS.map(([k,l,price,col])=>{const own=cars.includes(k),can=P.money>=price&&cars.length<cap;return `<div class="j-car"><i style="background:${col}"></i><span>${l}</span>${own?`<button class="btn small" data-act="jCarSell" data-k="${k}">Vender · ${eur(price*.6)}</button>`:`<button class="btn small${can?' primary':''}" data-act="jCarBuy" data-k="${k}" ${can?'':'disabled'}>${eur(price)}</button>`}</div>`;}).join('')}</div>`;}
function homeCars(T,g,M,glow,cars){const SL=[[-6.3,8.4,0],[-3.1,8.4,0],[1.5,6.4,0],[-.9,8.4,0],[5.6,8.2,Math.PI/2]];
  cars.slice(0,5).forEach((kind,i)=>{const [x,z,ry]=SL[i],col=(CARS.find(c=>c[0]===kind)||CARS[0])[3],G=new T.Group();G.position.set(x,.2,z);G.rotation.y=ry;g.add(G);
    const b=(w_,h,d,m,X,Y,Z)=>{const o=new T.Mesh(new T.BoxGeometry(w_,h,d),m);o.position.set(X,Y,Z);o.castShadow=true;G.add(o);return o;};
    const [w_,h,d,ch_,cl]={urbano:[1.7,.7,3.3,.62,1.7],suv:[2,.95,4.3,.78,2.3],gt:[1.95,.55,4.4,.48,1.7],clasico:[1.85,.62,4.5,.55,1.9],todo:[2.1,1.05,4.6,.85,2.6],hiper:[2.05,.42,4.5,.4,1.5]}[kind]||[1.9,.6,4,.5,2];
    const paint=M(col,{roughness:.22,metalness:.85}),gl=M('#12141a',{roughness:.06,metalness:1});
    b(w_,h,d,paint,0,.32+h/2,0);b(w_*.86,ch_,cl,gl,0,.32+h+ch_/2,kind==='gt'||kind==='hiper'?-.35:-.15);
    [[-1,-1],[1,-1],[-1,1],[1,1]].forEach(([sx,sz])=>{const wh=new T.Mesh(new T.CylinderGeometry(.36,.36,.26,14),M('#121212'));wh.rotation.z=Math.PI/2;wh.position.set(sx*w_/2,.36,sz*d*.32);G.add(wh);});
    [-1,1].forEach(sx=>{b(.34,.12,.05,glow('#fff4d6',1.6),sx*w_*.3,.32+h*.72,d/2+.02);b(.34,.1,.05,glow('#ff2a3a',1.2),sx*w_*.3,.32+h*.72,-d/2-.02);});
    if(kind==='gt'){b(w_*.9,.06,.42,paint,0,.32+h+.32,-d/2+.25);[-.6,.6].forEach(sx=>b(.06,.3,.06,gl,sx,.32+h+.15,-d/2+.25));}
    if(kind==='hiper')[-1,1].forEach(sx=>b(.04,.06,d*.8,glow('#C99BFF',2.2),sx*(w_/2+.01),.5,0));
    if(kind==='clasico')[-1,1].forEach(sz=>b(w_+.04,.12,.12,M('#dcdcdc',{metalness:1,roughness:.18}),0,.42,sz*(d/2+.04)));
    if(kind==='todo'){b(w_*.8,.08,cl*.9,M('#222'),0,.32+h+ch_+.06,-.15);const sp=new T.Mesh(new T.CylinderGeometry(.38,.38,.24,14),M('#121212'));sp.rotation.x=Math.PI/2;sp.position.set(0,.32+h*.6,-d/2-.14);G.add(sp);}
    if(kind==='suv')[-1,1].forEach(sx=>b(.06,.06,cl,M('#9a9a9a',{metalness:1}),sx*w_*.38,.32+h+ch_+.04,-.15));});}

/* ---------- inversiones ---------- */
const INV=[['restaurante','Restaurante en tu ciudad',150000,.12,.22],['academia','Academia de fútbol base',300000,.07,.08],['ropa','Marca de ropa',500000,.2,.35],['inmo','Promoción inmobiliaria',1000000,.09,.12],['esports','Club de eSports',250000,.25,.45],['bodega','Bodega y viñedos',400000,.08,.14]];
function investTick(){const I=P.inv||{};Object.entries(I).forEach(([id,x])=>{const d=INV.find(v=>v[0]===id);if(!d)return;let r=d[3]+(Math.random()*2-1)*d[4];
    if(ch(.04+d[4]*.12)){r=-.45;news(`Mal año para tu inversión «${d[1]}»: pierde casi la mitad de su valor.`,'bad');}else if(r>.3)news(`Tu inversión «${d[1]}» se dispara: +${Math.round(r*100)} %.`,'hot');
    x.v=Math.max(0,Math.round(x.v*(1+r)));const div=Math.round(x.v*.04);P.money+=div;x.div=(x.div||0)+div;x.last=r;
    if(id==='academia'){P.rep.humilde+=.5;P.fame=clamp(P.fame+.5,0,100);}if(id==='ropa'&&r>0)P.fame=clamp(P.fame+1,0,100);});}
function investPanel(){const I=P.inv||{};
  return `<div class="j-panel"><h3>Inversiones</h3><p class="j-hint">Cada temporada tus negocios suben o bajan de valor y te pagan un dividendo del 4 %. Más rentabilidad, más riesgo.</p>
  ${INV.map(([id,l,cost,ret,vol])=>{const x=I[id];return `<div class="j-iv"><div><b>${l}</b><small>Riesgo ${vol>=.3?'alto':vol>=.15?'medio':'bajo'} · rentabilidad esperada ${Math.round(ret*100)} % al año</small></div>${x?`<div class="j-ivr"><b class="num ${x.v>=x.in?'up':'dn'}">${eur(x.v)}</b><small class="num">${x.v>=x.in?'+':''}${Math.round((x.v/x.in-1)*100)} % · dividendos ${eur(x.div||0)}</small><button class="btn small" data-act="jInvSell" data-k="${id}">Vender</button></div>`:`<button class="btn small${P.money>=cost?' primary':''}" data-act="jInvBuy" data-k="${id}" ${P.money>=cost?'':'disabled'}>Invertir ${eur(cost)}</button>`}</div>`;}).join('')}</div>`;}
function vFam(){return `<div class="j-eyebrow">Fuera del campo</div><h2 class="j-h">Familia y patrimonio</h2><div class="j-two"><div class="j-col">${famPanel()}${garagePanel()}</div><div class="j-col">${petPanel()}${investPanel()}</div></div>`;}

/* ---------- eventos nuevos (familia y reconversión) ---------- */
Object.assign(EV,{
  pareja:{t:ev=>`En un evento benéfico conoces a ${ev.n}. Hay química desde el primer minuto.`,o:[['Empezar una relación',ev=>{fam().partner={n:ev.n,s:P.season};P.mor+=8;news(`${P.last} confirma su relación con ${ev.n}.`);}],['Centrarte en el fútbol',()=>{P.lp+=.5;}]]},
  boda:{t:()=>`Llevas tiempo con ${fam().partner.n}. ¿Dais el paso?`,o:[['Casaros este verano',()=>{P.money-=Math.min(250000,Math.round(Math.max(P.money,0)*.15)+20000);fam().married=true;P.mor+=12;P.fame+=2;news(`${P.last} y ${fam().partner.n} se casan.`,'hot');}],['Esperar un poco más',()=>{}]]},
  bebe:{t:()=>`¡${fam().partner.n} y tú vais a tener un bebé! ¿Cómo se llamará?`,o:ev=>ev.names.map(n=>[`Llamarle ${n}`,()=>{const F=fam(),first=!F.kids.some(k=>k.fb);F.kids.push({n,b:P.season,fb:first||ch(.3),pot:clamp(Math.round((ceil()-80)/3.5)+R(-1,1),1,5),ms:[]});P.mor+=15;news(`¡Nace ${n}, hijo de ${P.name} ${P.last}!`,'hot');}])},
  mudanza:{t:()=>`Te vas a otro país y tu familia duda si mudarse contigo.`,o:[['Mudaros todos juntos',()=>{P.adapt+=25;P.mor-=2;}],['Ir solo la primera temporada',()=>{P.mor-=10;P.adapt+=5;}]]},
  reconversion:{t:ev=>`Con ${P.age} años, el míster cree que rendirías más como ${POS[ev.to].toLowerCase()}.`,o:[['Aceptar el cambio',ev=>{posF()[ev.to]=Math.max(posF()[ev.to]||0,65);setPos(ev.to,'por decisión del míster');P.tru+=6;P.lp+=1;}],['Seguir en tu posición',()=>{P.tru-=3;}]]},
});
function famCands(c){const F=fam();if(!F.partner&&P.age>=20)c.push('pareja');if(F.partner&&!F.married&&P.season-F.partner.s>=1)c.push('boda');
  if(F.partner&&F.kids.length<3&&P.age>=23&&(!F.kids.length||P.season-F.kids[F.kids.length-1].b>=2))c.push('bebe','bebe');
  if(P.age>=29&&(P.pos==='EXT'||P.pos==='DEL')&&P.at.rit<80&&P.squad!=='cantera')c.push('reconversion');}
function mkEv(id){const ev={id};if(id==='pareja')ev.n=pk(PARTN);if(id==='reconversion')ev.to='MED';
  if(id==='bebe'){const used=fam().kids.map(k=>k.n),pool=KIDN.filter(n=>!used.includes(n));ev.names=[];while(ev.names.length<3&&pool.length)ev.names.push(pool.splice(R(0,pool.length-1),1)[0]);}return ev;}

/* ---------- carrera de entrenador tras la retirada ---------- */
const TACT={equilibrio:'Equilibrio',posesion:'Posesión',presion:'Presión alta',contra:'Contragolpe',defensivo:'Bloque bajo'};
const prefT=id=>['posesion','presion','contra','defensivo'][[...id].reduce((x,c)=>(x*31+c.charCodeAt(0))>>>0,3)%4];
const coachWage=id=>Math.round(Math.pow(Math.max(clubStr(id)-40,5),2.2)*120/1000)*1000;
function coachObj(id){const k=club(id),ids=LG[k.league].pyr[k.tier],n=ids.length,rank=ids.map(clubStr).sort((a,b)=>b-a).indexOf(k.base)+1;
  if(k.tier>0&&rank<=3)return{t:'Subir de categoría (acabar entre los 2 primeros)',pos:2};
  return rank<=1?{t:'Ganar la liga',pos:1}:rank<=4?{t:'Acabar entre los 4 primeros',pos:4}:rank<=Math.ceil(n/2)?{t:`Acabar entre los ${Math.ceil(n/2)} primeros`,pos:Math.ceil(n/2)}:{t:`Evitar el descenso (puesto ${n-3} o mejor)`,pos:n-3};}
function coachOffers(fired){const C=P.coach,t=50+C.lvl*.38-(fired?5:0),pool=ALL().filter(k=>Math.abs(k.base-t)<=5&&k.id!==C.club),out=[];
  if(!C.hist.length&&P.origin0&&club(P.origin0)&&club(P.origin0).base<=t+8)out.push(P.origin0);
  while(out.length<3&&pool.length){const k=pool.splice(R(0,pool.length-1),1)[0];if(!out.includes(k.id))out.push(k.id);}
  C.offers=out.map(id=>({club:id,years:R(2,3),obj:coachObj(id)}));}
function coachStart(){P.coach={lvl:clamp(Math.round(40+(P.peak-80)*.8+P.fame/12+(P.captain?3:0)+Math.min(4,P.rep.lider)),38,66),trust:60,club:null,tactic:'equilibrio',rot:'rotar',youth:false,hist:[],titles:[],offers:[],years:0,done:false};
  coachOffers();news(`${P.name} ${P.last} se saca el título de entrenador.`,'hot');}
function coachSeason(){const C=P.coach,k=club(C.club);C.tbl={};LG[k.league].pyr[k.tier].forEach(id=>{C.tbl[id]=0;});C.block=0;C.pld=0;C.obj=coachObj(C.club);C.eur=eurQualifiedId(C.club);C.tired=0;C.last=null;}
function coachSign(i){const C=P.coach,o=C.offers[i];if(!o)return;if(C.club)news(`${P.last} deja el banquillo de ${cname(C.club)}.`);
  C.club=o.club;C.years=o.years;C.trust=60;C.offers=[];coachSeason();news(`${P.name} ${P.last}, nuevo entrenador de ${cname(o.club)}.`,'hot');}
const coachGames=()=>(Object.keys(P.coach.tbl).length-1)*2;
const coachPos=()=>{const C=P.coach;return Object.entries(C.tbl).sort((a,b)=>b[1]-a[1]).findIndex(x=>x[0]===C.club)+1;};
function coachStr(){const C=P.coach,k=club(C.club),pf=prefT(C.club);return k.base+(C.lvl-60)*.1+(C.tactic===pf?1.5:C.tactic==='equilibrio'?.5:-1)+(C.rot==='fijo'?1:0)-C.tired-(C.youth?1:0)+(C.trust-50)/90;}
function coachBlock(){const C=P.coach,ids=Object.keys(C.tbl),avgB=avg(ids.map(clubStr)),G=coachGames(),n=C.block<3?Math.round(G/4):G-C.pld,s=coachStr();let w=0,d=0,l=0;
  for(let i=0;i<n;i++){const opp=clubStr(pk(ids.filter(x=>x!==C.club))),pw=clamp(.33+(s-opp)*.025,.06,.8),r=Math.random();if(r<pw)w++;else if(r<pw+.26)d++;else l++;}
  C.tbl[C.club]+=w*3+d;ids.forEach(id=>{if(id!==C.club)C.tbl[id]+=Math.round(n*clamp(1.35+(clubStr(id)-avgB)*.055+(Math.random()-.5)*.5,.3,2.6));});
  C.pld+=n;C.block++;C.tired=C.rot==='fijo'?Math.min(4,C.tired+1.2):Math.max(0,C.tired-1.2);if(C.youth)C.lvl=Math.min(99,C.lvl+.3);
  const exp=1.35+(clubStr(C.club)-avgB)*.055;C.trust=clamp(C.trust+((w*3+d)/Math.max(1,n)-exp)*22,0,100);
  C.last={n,w,d,l,pos:coachPos(),txt:C.tactic===prefT(C.club)?'El equipo entiende a la perfección tu idea de juego.':C.tactic==='equilibrio'?'El equipo cumple con un planteamiento equilibrado.':'A la plantilla le cuesta adaptarse a esa táctica.'};
  news(`Bloque ${C.block}: ${w}V ${d}E ${l}D. ${cname(C.club)} va ${C.last.pos}.º`);
  if(C.trust<12&&C.block<4){coachFired(false);return 'fired';}
  if(C.block>=4)return coachEndSeason();return 'block';}
function coachEndSeason(){const C=P.coach,k=club(C.club),pos=coachPos(),sl=seasonLabel(P.season),tit=[],s=coachStr();
  if(pos===1)tit.push(k.tier===0?LG[k.league].name:`${LG[k.league].name} · ascenso`);
  let cup='';for(let r=0;r<5;r++){if(Math.random()<clamp(.5+(s-(55+r*6+R(-4,8)))*.03,.1,.9)){if(r===4){cup='Campeón';tit.push('Copa');}}else{cup=CUPN[r];break;}}
  let eu='';if(C.eur)for(let r=0;r<6;r++){if(Math.random()<clamp(.5+(s-(78+r*2.2))*.035,.05,.85)){if(r===5){eu='Campeón';tit.push('Champions League');}}else{eu=EURN[r];break;}}
  tit.forEach(t=>{C.titles.push({n:t,s:sl,c:k.name});news(`¡${k.name} de ${P.last} gana la ${t}!`,'hot');});
  const met=pos<=C.obj.pos;C.trust=clamp(C.trust+(met?18:-22)+tit.length*8,0,100);
  C.lvl=clamp(Math.round(C.lvl+clamp(((C.obj.pos-pos)/Math.max(3,C.obj.pos)+tit.length*.4)*2.5+(met?1:-1),-3,3)),30,95);
  C.hist.push({s:sl,c:k.name,pos,cup:cup||'—',eu:eu||'—',obj:C.obj.t,met,lvl:C.lvl});P.money+=coachWage(C.club);
  C.years--;P.age++;P.season++;familyTick();investTick();C.report={s:sl,pos,met,tit,c:k.name};
  if(C.trust<25){coachFired(true);return 'season';}
  C.offers=[];if(met&&(pos<=2||tit.length)&&ch(.6)){coachOffers();C.offers=C.offers.filter(o=>clubStr(o.club)>k.base);}
  if(C.years<=0){if(C.trust>=50){C.years=R(2,3);news(`${k.name} renueva a ${P.last} como entrenador.`);}else{news(`${k.name} no renueva a ${P.last}.`,'bad');C.club=null;coachOffers();}}
  if(C.club)coachSeason();return 'season';}
function coachFired(seasonOver){const C=P.coach;news(`${cname(C.club)} destituye a ${P.last}.`,'bad');
  if(!seasonOver){C.hist.push({s:seasonLabel(P.season),c:cname(C.club),pos:coachPos(),cup:'—',eu:'—',obj:C.obj.t,met:false,lvl:C.lvl,fired:true});P.season++;P.age++;familyTick();investTick();}
  else C.hist[C.hist.length-1].fired=true;
  C.lvl=Math.max(30,C.lvl-2);C.club=null;C.firedMsg=true;coachOffers(true);}
function coachHist(C){return C.hist.length?`<table class="j-t"><thead><tr><th>Temporada</th><th>Club</th><th>Puesto</th><th>Copa</th><th>Champions</th><th>Objetivo</th></tr></thead><tbody>${C.hist.map(x=>`<tr><td class="num">${x.s}</td><td>${esc(x.c)}</td><td class="num">${x.pos}.º${x.fired?' · destituido':''}</td><td>${esc(x.cup)}</td><td>${esc(x.eu)}</td><td>${x.met?'Cumplido':'No'}</td></tr>`).join('')}</tbody></table>`:'<p class="muted">Aún no has completado ninguna temporada.</p>';}
function vCoach(){const C=P.coach,k=C.club&&club(C.club);
  const hd=`<header class="j-hud"><div class="j-hud-in"><button class="back" data-act="jExit">← Modos</button><div class="j-brand">PALCO<span>ENTRENADOR</span></div>
   <div class="j-ind"><div class="j-big"><b class="num">${Math.round(C.lvl)}</b><small>Nivel</small></div><div><small>Directiva</small><b class="num ${C.trust<35?'bad':''}">${Math.round(C.trust)}</b></div><div><small>Títulos</small><b class="num">${C.titles.length}</b></div><div><small>Edad</small><b class="num">${P.age}</b></div><div><small>Ahorros</small><b class="num">${eur(P.money)}</b></div></div>
   <div class="j-hclub">${k?crest(k,28):''}<span>${k?esc(k.name):'Sin banquillo'}<small class="num">${seasonLabel(P.season)}${k?` · bloque ${Math.min(4,C.block+1)} de 4`:''}</small></span></div></div></header>`;
  const offers=C.offers.map((o,i)=>`<button class="j-offer" data-act="jCoachSign" data-i="${i}">${crest(club(o.club),58)}<div><h3>${esc(cname(o.club))}</h3><p class="muted">${esc(LG[club(o.club).league].name)} · ${esc(LG[club(o.club).league].country)} · Objetivo: ${esc(o.obj.t)}</p></div><div class="j-offer-r"><b class="num">${o.years} años</b><small>${eur(coachWage(o.club))} por temporada</small></div></button>`).join('');
  let body;
  if(!k)body=`<div class="j-eyebrow">Banquillo libre</div><h2 class="j-h">${C.hist.length?'Buscas equipo':'Tu primer banquillo'}</h2><p class="muted" style="max-width:62ch">${C.hist.length?'Los clubes que te llaman dependen de tu nivel como entrenador.':'Colgaste las botas, pero el fútbol sigue. Tu nivel de partida depende de la carrera que hiciste como jugador.'}</p>
    <div class="j-offers">${offers||'<p class="muted">Nadie llama… de momento.</p>'}</div><div class="j-acts">${C.offers.length?'':'<button class="btn" data-act="jCoachWait">Esperar una temporada</button>'}<button class="btn" data-act="jCoachRetire">Retirarte de los banquillos</button></div>
    <div class="j-two"><div class="j-panel"><h3>Historial</h3>${coachHist(C)}</div>${famPanel()}</div>`;
  else{const t=Object.entries(C.tbl).sort((a,b)=>b[1]-a[1]),me=t.findIndex(x=>x[0]===C.club),G=coachGames(),per=Math.round(G/4),from=C.pld+1,to=C.block<3?C.pld+per:G;
    body=`<div class="j-two j-coach"><div class="j-col">
     <div><div class="j-eyebrow">${esc(LG[k.league].name)} · ${seasonLabel(P.season)}</div><h2 class="j-h">${esc(k.name)}</h2><p class="muted">Objetivo de la directiva: <b>${esc(C.obj.t)}</b>${C.eur?' · juegas la Champions':''} · contrato: ${C.years} año${C.years>1?'s':''}</p></div>
     <div class="j-next"><div class="j-eyebrow">Bloque ${C.block+1} de 4 · jornadas ${from}–${to}</div><h3>Prepara el bloque</h3>
      <div class="j-grp"><h4>Táctica</h4><div class="j-chips">${Object.entries(TACT).map(([x,l])=>`<button class="j-chip${C.tactic===x?' on':''}" data-act="jCoachT" data-k="${x}">${l}</button>`).join('')}</div></div>
      <div class="j-grp"><h4>Gestión de la plantilla</h4><div class="j-chips"><button class="j-chip${C.rot==='rotar'?' on':''}" data-act="jCoachRot" data-k="rotar">Rotar y llegar frescos</button><button class="j-chip${C.rot==='fijo'?' on':''}" data-act="jCoachRot" data-k="fijo">Once de gala (rinde más, cansa más)</button></div></div>
      <label class="j-check"><input type="checkbox" data-in="coachYouth" ${C.youth?'checked':''}> Dar minutos a la cantera (subes como formador, el equipo rinde algo menos)</label>
      <div class="j-acts"><button class="btn primary" data-act="jCoachBlock">Jugar el bloque</button></div></div>
     ${C.last?`<div class="j-panel"><h3>Último bloque</h3><p class="j-n"><b class="num">${C.last.w}V · ${C.last.d}E · ${C.last.l}D</b>${esc(C.last.txt)}</p></div>`:''}
     <div class="j-panel"><h3>Clasificación</h3><table class="j-t"><tbody>${t.slice(0,Math.max(6,me+1)).map(([id,pts],i)=>`<tr class="${id===C.club?'me':''}"><td class="num">${i+1}</td><td>${esc(cname(id))}</td><td class="num">${pts}</td></tr>`).join('')}</tbody></table></div></div>
    <div class="j-col"><div class="j-panel"><h3>Estado</h3>${meter('Confianza de la directiva',C.trust,1)}${meter('Nivel como entrenador',C.lvl)}</div>
     ${C.offers.length?`<div class="j-panel j-alert"><h3>Otros clubes te quieren</h3><div class="j-offers">${offers}</div></div>`:''}
     <div class="j-panel"><h3>Historial</h3>${coachHist(C)}</div>${famPanel()}${investPanel()}
     <div class="j-acts"><button class="btn" data-act="jCoachRetire">Retirarte de los banquillos</button></div></div></div>`;}
  return hd+`<div class="j-shell"><main class="j-main" id="jmain" tabindex="-1">${body}</main></div>`;}
function legendExtra(){const C=P.coach;let h='';
  if(C&&C.hist.length)h+=`<div class="j-panel"><h3>Carrera en los banquillos</h3><div class="j-kv"><div><small>Temporadas</small><b class="num">${C.hist.length}</b></div><div><small>Títulos</small><b class="num">${C.titles.length}</b></div><div><small>Nivel máximo</small><b class="num">${Math.max(...C.hist.map(x=>x.lvl))}</b></div></div>${coachHist(C)}</div>`;
  return h+famPanel();}

/* ---------- acciones nuevas ---------- */
Object.assign(ACT,{
  jKit(d,el){P.kit=d.k;chipOn(el);save();const hc=document.querySelector('.j-hero .j-card');if(hc)hc.outerHTML=card(P,true);const fb=document.querySelector('.j-3d-fb');if(fb)fb.innerHTML=avatar(P,170);if(G3D)G3D.rebuild();},
  jCelebSet(d,el){P.celeb=+d.k;chipOn(el);save();playCeleb();},
  jCeleb(){playCeleb();},
  jFpAim(d){fpAim(+d.z);},jFpShoot(){fpShoot();},
  jLearn(d){P.learn=d.k;save();rr();},
  jPosSet(d){const v=posF()[d.k]||0;if(v>=75||ch(.55+P.tru/300)){setPos(d.k,'tras hablar con el míster');P.tru=clamp(P.tru-2,0,100);toast(`Jugarás de ${POS[d.k].toLowerCase()}.`);}else{P.tru=clamp(P.tru-5,0,100);toast('El míster prefiere que sigas en tu sitio.');}save();rr();},
  jCarBuy(d){const c=CARS.find(x=>x[0]===d.k);P.cars=P.cars||[];if(!c||P.money<c[2]||P.cars.includes(c[0])||P.cars.length>=garageCap())return;P.money-=c[2];P.cars.push(c[0]);P.mor=clamp(P.mor+2,0,100);if(c[2]>1e6)P.rep.mediatico+=1;if(P.age<22&&c[2]>2e5)P.lp-=1;news(`${P.last} estrena coche: ${c[1].toLowerCase()}.`);save();rr();C3D&&C3D.rebuildHouse();},
  jCarSell(d){const c=CARS.find(x=>x[0]===d.k);if(!c||!(P.cars||[]).includes(c[0]))return;P.cars=P.cars.filter(x=>x!==c[0]);P.money+=Math.round(c[2]*.6);save();rr();C3D&&C3D.rebuildHouse();},
  jInvBuy(d){const v=INV.find(x=>x[0]===d.k);P.inv=P.inv||{};if(!v||P.inv[v[0]]||P.money<v[2])return;P.money-=v[2];P.inv[v[0]]={v:v[2],in:v[2],s:seasonLabel(P.season),div:0};news(`${P.last} invierte en: ${v[1].toLowerCase()}.`);save();rr();},
  jInvSell(d){const x=P.inv&&P.inv[d.k];if(!x)return;P.money+=x.v;delete P.inv[d.k];toast(`Vendes por ${eur(x.v)}.`);save();rr();},
  jCoachStart(){coachStart();save();render();scrollTo(0,0);},
  jCoachSign(d){coachSign(+d.i);save();render();scrollTo(0,0);},
  jCoachT(d){P.coach.tactic=d.k;save();rr();},jCoachRot(d){P.coach.rot=d.k;save();rr();},
  jCoachWait(){P.season++;P.age++;familyTick();investTick();coachOffers();save();render();},
  jCoachRetire(){P.coach.done=true;news(`${P.name} ${P.last} se retira de los banquillos.`);save();render();scrollTo(0,0);},
  jCoachBlock(){const r=coachBlock();save();render();const C=P.coach;
    if(r==='season'||r==='fired'){const R0=C.report;const head=r==='fired'||C.firedMsg?'Destituido':R0?`Fin de la temporada ${R0.s}`:'Fin de temporada';C.firedMsg=false;
      modal(`<div class="hd j-mhd"><h3>${head}</h3></div><div class="bd">${R0&&r==='season'?`<div class="j-kv"><div><small>Puesto</small><b class="num">${R0.pos}.º</b></div><div><small>Objetivo</small><b>${R0.met?'Cumplido':'No cumplido'}</b></div><div><small>Títulos</small><b class="num">${R0.tit.length}</b></div><div><small>Nivel</small><b class="num">${Math.round(C.lvl)}</b></div></div>${R0.tit.length?`<p class="j-neon" style="font-weight:700">${R0.tit.map(esc).join(' · ')}</p>`:''}`:'<p class="j-sit">La directiva ha perdido la confianza en tu proyecto. Toca buscar banquillo.</p>'}
        <p class="j-hint">${C.club?(C.offers.length?'Otros clubes llaman a tu puerta.':'Sigues al frente del equipo.'):'Estás sin equipo: revisa las ofertas.'}</p><button class="btn primary" data-act="jClose" data-focus>Seguir</button></div>`);}},
});

const css2=document.createElement('style');css2.textContent=`
.j-album{display:grid;grid-template-columns:repeat(auto-fill,minmax(180px,1fr));gap:20px;margin-top:20px}
.j-cc{margin:0;display:grid;gap:8px;justify-items:center}
.j-cc .j-card{max-width:220px;padding:14px;gap:8px}
.j-cc figcaption{display:grid;text-align:center;gap:2px}
.j-cc figcaption b{font-family:var(--mono);font-size:11px;letter-spacing:.16em;text-transform:uppercase;color:var(--neon)}
.j-cc figcaption small{color:var(--muted);font-size:12px}
.j-newcard{display:flex;justify-content:center;margin:14px 0}
.j-newcard .j-cc .j-card{max-width:200px}
.v-bronce .j-card{background:radial-gradient(120% 70% at 72% 0%,#D9925C,transparent 60%),linear-gradient(160deg,#7A4526,#3A2214 55%,#1C0F08);box-shadow:inset 0 0 0 1px rgba(255,200,160,.5)}
.v-plata .j-card{background:radial-gradient(120% 70% at 72% 0%,#E9EDF5,transparent 60%),linear-gradient(160deg,#8D94A6,#454B5A 55%,#1E2129);box-shadow:inset 0 0 0 1px rgba(235,240,255,.55)}
.v-oro .j-card{background:radial-gradient(120% 70% at 72% 0%,#FFE7A0,transparent 60%),linear-gradient(160deg,#C8952E,#6E4E12 55%,#2A1C05);box-shadow:inset 0 0 0 1px rgba(255,226,150,.65),0 0 30px -12px #FFD24A}
.v-forma .j-card{box-shadow:inset 0 0 0 2px #E4CCFF,0 0 36px -6px #B57BFF}
.v-campeon .j-card{background:radial-gradient(120% 70% at 72% 0%,#5CF2D2,transparent 60%),linear-gradient(160deg,#127A68,#0B3D36 55%,#061A17);box-shadow:inset 0 0 0 1px rgba(120,255,225,.6)}
.v-tots .j-card{background:radial-gradient(120% 70% at 72% 0%,#4D6BFF,transparent 60%),linear-gradient(160deg,#16236B,#0B1240 55%,#050820);box-shadow:inset 0 0 0 2px #FFD24A}
.v-balon .j-card{background:radial-gradient(120% 70% at 72% 0%,#FFF6D8,transparent 55%),linear-gradient(160deg,#E2B347,#8A6316 55%,#2E1F04);box-shadow:inset 0 0 0 2px #FFF1C2,0 0 40px -6px #FFD24A}
.v-debut .j-card{background:radial-gradient(120% 70% at 72% 0%,#FF7DB5,transparent 60%),linear-gradient(160deg,#8A1F55,#3E0B27 55%,#1A0410)}
.v-icono .j-card{background:radial-gradient(120% 70% at 72% 0%,#F7EFD9,transparent 55%),linear-gradient(160deg,#BBA779,#5A4C2E 55%,#211A0C);box-shadow:inset 0 0 0 2px #F7EFD9,0 0 40px -8px #F7EFD9}
.j-skills .neg b{color:var(--loss)}
.j-kid{display:grid;grid-template-columns:1fr auto;gap:2px 12px;padding:10px 0;border-top:1px solid var(--line)}
.j-kid small{color:var(--muted)}.j-kid span{grid-row:1/3;grid-column:2;align-self:center}
.j-car{display:grid;grid-template-columns:38px 1fr auto;gap:12px;align-items:center;padding:9px 0;border-top:1px solid var(--line)}
.j-car i{display:block;width:38px;height:16px;border-radius:4px 10px 3px 3px;box-shadow:inset 0 -6px 0 rgba(0,0,0,.4)}
.j-iv{display:grid;grid-template-columns:1fr auto;gap:12px;align-items:center;padding:10px 0;border-top:1px solid var(--line)}
.j-iv small{display:block;color:var(--muted);font-size:12px}
.j-ivr{display:grid;justify-items:end;gap:3px}.j-ivr .up{color:var(--win)}.j-ivr .dn{color:var(--loss)}
.j-pos{display:grid;grid-template-columns:minmax(110px,1fr) minmax(90px,2fr) 34px;gap:6px 12px;align-items:center;padding:9px 0;border-top:1px solid var(--line)}
.j-pos i{display:block;height:8px;border-radius:4px;background:#1A0D33;overflow:hidden}.j-pos u{display:block;height:100%;background:linear-gradient(90deg,#7B3FE0,#D2A8FF)}
.j-pos.on>span:first-child{color:var(--neon);font-weight:700}.j-pos-b{grid-column:1/-1;display:flex;gap:6px;justify-content:flex-end}

.j-dec.fp-on{max-height:none}.j-dec-3d.fp-on{top:6px;overflow:auto}
.fp{display:grid;gap:10px}
.fp-scene{position:relative;width:100%;aspect-ratio:16/9;max-height:min(46vh,380px);overflow:hidden;border-radius:8px;border:1px solid rgba(201,155,255,.45);background:linear-gradient(180deg,#0b0518 0%,#1a0d36 24%,#2a1652 36%,#0e3d24 36.4%,#145a33 70%,#1b7040 100%)}
.fp-stand{position:absolute;left:0;right:0;top:10%;height:26%;background:repeating-linear-gradient(90deg,rgba(255,255,255,.06) 0 5px,transparent 5px 13px),linear-gradient(180deg,#22104a,#3a2070)}
.fp-sky::before,.fp-sky::after{content:"";position:absolute;top:1%;width:24%;height:11%;border-radius:50%;background:radial-gradient(closest-side,rgba(255,255,240,.95),rgba(201,155,255,.25) 60%,transparent)}
.fp-sky::before{left:5%}.fp-sky::after{right:5%}
.fp-turf{position:absolute;left:0;right:0;top:62%;bottom:0;background:repeating-linear-gradient(90deg,rgba(255,255,255,.04) 0 9%,transparent 9% 18%);border-top:2px solid rgba(255,255,255,.55)}
.fp-goal{position:absolute;left:18%;width:64%;top:18%;height:44%;border:6px solid #F4F1FA;border-bottom:none;box-shadow:0 0 18px rgba(201,155,255,.55);z-index:2}
.fp-net{position:absolute;inset:0;background:repeating-linear-gradient(0deg,rgba(255,255,255,.2) 0 1px,transparent 1px 9px),repeating-linear-gradient(90deg,rgba(255,255,255,.2) 0 1px,transparent 1px 9px),rgba(10,4,24,.4)}
.fp-zones{position:absolute;inset:0;display:grid;grid-template-columns:repeat(3,1fr);grid-template-rows:repeat(2,1fr);z-index:4}
.fp-z{background:transparent;border:1px dashed rgba(201,155,255,.3);cursor:crosshair;transition:background .15s}
.fp-z:hover,.fp-z:focus-visible{background:rgba(181,123,255,.24);outline:none}
.fp-z.sel{background:rgba(181,123,255,.4);box-shadow:inset 0 0 0 2px #E4CCFF}
.fp.done .fp-z{pointer-events:none}
.fp-gk{position:absolute;left:50%;top:100%;width:11%;height:64%;transform:translate(-50%,-100%);transition:left .42s cubic-bezier(.2,.8,.2,1),top .42s cubic-bezier(.2,.8,.2,1),transform .42s;z-index:3}
.fp-gk .h{position:absolute;left:26%;width:48%;top:0;height:22%;background:#E8B48A;box-shadow:inset 0 -3px 0 rgba(0,0,0,.2)}
.fp-gk .b{position:absolute;left:0;right:0;top:22%;bottom:0;background:linear-gradient(180deg,var(--gk,#FFD24A) 0 56%,#1b1b24 56% 74%,var(--gk,#FFD24A) 74%);box-shadow:inset 0 0 0 2px rgba(0,0,0,.18)}
.fp-wall{position:absolute;left:37%;width:24%;top:43%;height:23%;display:flex;gap:4%;z-index:5}
.fp-wall i{flex:1;background:linear-gradient(180deg,#E8B48A 0 18%,var(--wall,#2B2F8A) 18% 68%,#14141c 68%);box-shadow:inset 0 0 0 1px rgba(0,0,0,.25)}
.fp-ball{position:absolute;left:50%;top:86%;width:5%;aspect-ratio:1;transform:translate(-50%,-50%) scale(1.5);background:radial-gradient(circle at 35% 35%,#fff,#d8d4e4 60%,#9b95ad);border-radius:30%;box-shadow:0 4px 8px rgba(0,0,0,.45);z-index:6;transition:left .5s cubic-bezier(.3,.7,.3,1),top .5s cubic-bezier(.3,.7,.3,1),transform .5s}
.fp-ui{display:grid;gap:6px}.fp-step{margin:0;font-weight:700}
.fp-res{font-family:var(--display);font-size:30px;letter-spacing:.02em}.fp-res.ok{color:#E4CCFF;text-shadow:0 0 18px rgba(201,155,255,.9)}.fp-res.ko{color:var(--loss)}
.j-dec-3d .fp-scene{max-height:32vh}
@media(prefers-reduced-motion:reduce){.fp-gk,.fp-ball{transition:none}}
`;document.head.appendChild(css2);

/* ====== ampliación 2: tu futbolista cúbico en el partido 3D, momentos clave en 3D, capitán en el campo,
   pretemporada, sanciones, votaciones del vestuario, redes sociales, documental, mascota y logros ====== */

/* ---------- tu futbolista en el partido 3D: sustituye a su muñeco y celebra tus goles ---------- */
function myFigure(M,idx){const w=M.w,T=w.T,outer=new T.Group(),inner=new T.Group();outer.add(inner);
  buildFigure(T,inner,{...P,kit:'local'});inner.traverse(o=>{if(o.isMesh)o.castShadow=true;});outer.scale.setScalar(.3);w.root.add(outer);
  const fake={rotY:0},tick=w.tick;
  w.tick=(dt,t)=>{tick(dt,t);const L=UI.jl,p=M.P&&M.P[idx],on=!!(p&&L&&L.on&&!p.gone);outer.visible=on;if(!on)return;
    M.F.set(idx,0,-300,0,false,0);M.F.done();outer.position.set(p.x,0,p.z);
    const now=performance.now(),aL=inner.getObjectByName('armL'),aR=inner.getObjectByName('armR');
    if(L.cel&&now>L.cel&&now<L.cel+2600){if(!L.celOn){L.celOn=1;fake.rotY=0;}celebPose(fake,inner,P.celeb||0,(now-L.cel)/1000);
      const c=w.cam.position;outer.rotation.y=Math.atan2(c.x-p.x,c.z-p.z)+fake.rotY;return;}
    L.celOn=0;inner.rotation.set(0,0,0);const k=t/1000,run=p.run?1:0;inner.position.set(0,run*Math.abs(Math.sin(k*12))*.08,0);
    outer.rotation.y=p.ry+Math.PI/2;if(aL){aL.rotation.x=Math.sin(k*12)*.8*run;aL.rotation.z=-.05;}if(aR){aR.rotation.x=-Math.sin(k*12)*.8*run;aR.rotation.z=.05;}};}
function goalIdx(side,name,assist){const L=UI.jl;if(!L||side!==L.mySide||!L.on||P.pos==='POR')return{};const idx=MYIDX[P.pos]+(L.mySide==='h'?0:11);
  if(name===P.last){L.cel=performance.now()+2400;return{sc:idx,cel:1};}if(assist===P.last)return{as:idx};return{};}

/* ---------- momentos clave en 3D: césped, portería con red, grada, portero y barrera cúbicos ---------- */
function fp3D(F){const T=window.THREE;if(!T||typeof hasGL15!=='function'||!hasGL15()||reduced())return false;
  const scn=F.root.querySelector('.fp-scene');
  const k=F.kind,opp=UI.jm&&UI.jm.e&&UI.jm.e.opp&&club(UI.jm.e.opp),oc1=opp?opp.c1:'#2B2F8A',oc2=opp?opp.c2:'#F2F2F2';
  scn.classList.add('fp-3d');scn.innerHTML=`<canvas class="fp-cv" role="img" aria-label="Vista en 3D de la portería"></canvas><div class="fp-zones">${ZN.map((l,i)=>`<button class="fp-z" data-act="jFpAim" data-z="${i}" aria-label="${l}"></button>`).join('')}</div>`;
  const cv=scn.querySelector('canvas'),zones=scn.querySelector('.fp-zones');let r;
  try{r=new T.WebGLRenderer({canvas:cv,antialias:true});}catch(e){return false;}
  r.setPixelRatio(Math.min(devicePixelRatio||1,2));if('outputEncoding' in r)r.outputEncoding=T.sRGBEncoding;r.shadowMap.enabled=true;
  const sc=new T.Scene(),sky=pixTex(T,4,64,g=>{const gr=g.createLinearGradient(0,0,0,64);gr.addColorStop(0,'#05020c');gr.addColorStop(.55,'#1a0b3a');gr.addColorStop(1,'#3b1f6e');g.fillStyle=gr;g.fillRect(0,0,4,64);});
  sky.magFilter=T.LinearFilter;sc.background=sky;sc.fog=new T.Fog('#24113f',48,100);
  sc.add(new T.HemisphereLight(0xd8ccff,0x16351f,.8));const sun=new T.DirectionalLight(0xffffff,1.05);sun.position.set(-10,22,18);sun.castShadow=true;sun.shadow.mapSize.set(1024,1024);
  Object.assign(sun.shadow.camera,{left:-16,right:16,top:16,bottom:-16,near:1,far:80});sc.add(sun);const rim=new T.DirectionalLight(0xb57bff,.7);rim.position.set(12,8,-20);sc.add(rim);
  const Mt=(c,o={})=>new T.MeshStandardMaterial({color:new T.Color(c),roughness:.8,...o});
  const add=(geo,m,x,y,z,sh)=>{const o=new T.Mesh(geo,m);o.position.set(x,y,z);if(sh){o.castShadow=true;o.receiveShadow=true;}sc.add(o);return o;};
  const bx=(w_,h,d,m,x,y,z,sh)=>add(new T.BoxGeometry(w_,h,d),m,x,y,z,sh);
  /* césped a franjas y líneas del área */
  const gtx=pixTex(T,8,64,g=>{for(let i=0;i<8;i++){g.fillStyle=i%2?'#1d7039':'#238446';g.fillRect(0,i*8,8,8);}});gtx.wrapS=gtx.wrapT=T.RepeatWrapping;gtx.repeat.set(10,3);
  const gr=add(new T.PlaneGeometry(90,70),Mt('#ffffff',{map:gtx,roughness:.95}),0,0,15);gr.rotation.x=-Math.PI/2;gr.receiveShadow=true;
  const wl=Mt('#f4f4f4',{roughness:.6}),ln=(w_,d,x,z)=>bx(w_,.02,d,wl,x,.011,z);
  ln(60,.12,0,0);ln(18.32,.12,0,5.5);ln(.12,5.5,-9.16,2.75);ln(.12,5.5,9.16,2.75);ln(40.32,.12,0,16.5);ln(.12,16.5,-20.16,8.25);ln(.12,16.5,20.16,8.25);
  add(new T.CircleGeometry(.12,16),wl,0,.012,11).rotation.x=-Math.PI/2;
  /* portería y red */
  const pm=Mt('#ffffff',{roughness:.35});[-3.72,3.72].forEach(x=>bx(.12,2.5,.12,pm,x,1.25,0,true));bx(7.56,.12,.12,pm,0,2.5,0,true);
  const netM=(rx,ry)=>{const t=pixTex(T,32,32,g=>{g.fillStyle='rgba(255,255,255,.8)';for(let i=0;i<32;i+=8){g.fillRect(i,0,1,32);g.fillRect(0,i,32,1);}});t.wrapS=t.wrapT=T.RepeatWrapping;t.repeat.set(rx,ry);return new T.MeshBasicMaterial({map:t,transparent:true,side:T.DoubleSide,depthWrite:false});};
  const back=add(new T.PlaneGeometry(7.44,2.44),netM(18,6),0,1.22,-2);const roof=add(new T.PlaneGeometry(7.44,2),netM(18,5),0,2.44,-1);roof.rotation.x=-Math.PI/2;
  [-3.72,3.72].forEach(x=>{add(new T.PlaneGeometry(2,2.44),netM(5,6),x,1.22,-1).rotation.y=Math.PI/2;});
  /* grada con público, publicidad y focos */
  const stm=Mt('#24124a',{roughness:.9});for(let i=0;i<7;i++)bx(84,1.1,2.4,stm,0,.55+i*1.1,-7-i*2.4);
  const ad=pixTex(T,256,16,g=>{g.fillStyle='#12062a';g.fillRect(0,0,256,16);g.fillStyle='#C99BFF';g.font='bold 12px sans-serif';g.textBaseline='middle';for(let x=4;x<256;x+=128)g.fillText('PALCO DE HONOR',x,8.5);});
  ad.wrapS=T.RepeatWrapping;ad.repeat.set(4,1);bx(64,.9,.12,new T.MeshBasicMaterial({map:ad}),0,.45,-4.2);
  const n=900,im=new T.InstancedMesh(new T.BoxGeometry(.38,.55,.3),Mt('#ffffff',{roughness:.9}),n),d0=new T.Object3D(),col=new T.Color(),cb=[];
  for(let i=0;i<n;i++){const row=i%7,x=-40+Math.random()*80,y=1.1+row*1.1+.3,z=-7-row*2.4+(Math.random()-.5)*.5;cb.push([x,y,z]);d0.position.set(x,y,z);d0.updateMatrix();im.setMatrixAt(i,d0.matrix);col.set(pk([oc1,oc1,oc2,'#b57bff','#e8e0ff','#2a2a33']));im.setColorAt(i,col);}
  sc.add(im);[-30,30].forEach(x=>{bx(.5,24,.5,Mt('#3a3a46'),x,12,-27);bx(5,2,.6,new T.MeshBasicMaterial({color:'#fff6dc'}),x,24,-26.6);});
  /* jugadores cúbicos */
  const fig=(L,x,z,ry,s=.86)=>{const o=new T.Group(),inner=new T.Group();o.add(inner);buildFigure(T,inner,L);inner.traverse(m=>{if(m.isMesh)m.castShadow=true;});o.scale.setScalar(s);o.position.set(x,0,z);o.rotation.y=ry;sc.add(o);return{o,inner};};
  const rl=()=>({skin:R(0,6),hair:R(0,15),hairc:R(0,6),beard:R(0,3),boots:R(0,4),acc:0,num:R(2,24),last:pk(LASTN).toUpperCase(),height:R(176,192)});
  const gkL=k==='gk'?{...P,acc:4,num:1,kitC:{s:'#B57BFF',t:'#2A1450',p:'#2A1450',m:'#B57BFF'}}:{...rl(),acc:4,num:1,kitC:{s:'#F2C200',t:'#14141c',p:'#14141c',m:'#F2C200'}};
  const kz0=k==='uno'?3.4:.45,gk=fig(gkL,0,kz0,0,.88),B0={pen:[0,11],gk:[0,11],fk:[-4,18],uno:[.4,8]}[k];
  const btx=pixTex(T,16,16,g=>{g.fillStyle='#f4f4f4';g.fillRect(0,0,16,16);g.fillStyle='#1a1a22';[[2,2],[10,4],[5,9],[12,12],[1,13]].forEach(([x,y])=>g.fillRect(x,y,3,3));});
  const ball=add(new T.SphereGeometry(.12,18,14),Mt('#ffffff',{map:btx,roughness:.5}),B0[0],.12,B0[1],true);
  const wall=[];if(k==='fk'){const dx=-B0[0],dz=-B0[1],len=Math.hypot(dx,dz),wx=B0[0]+dx/len*9.15,wz=B0[1]+dz/len*9.15;F.wallAt=[wx,wz];
    for(let i=0;i<4;i++)wall.push(fig({...rl(),kitC:{s:oc1,t:oc2,p:oc2,m:oc1}},wx-.35+i*.6,wz,0,.86));}
  const shooter=k==='gk'?fig({...rl(),kitC:{s:oc1,t:oc2,p:oc2,m:oc1}},.35,12.3,Math.PI,.88):null;
  const camP={pen:[0,1.45,14.8],gk:[2.6,2.4,16.2],fk:[-4.6,1.6,21.6],uno:[.4,1.45,11.6]}[k],look={pen:[0,.75,0],gk:[0,1.1,2],fk:[0,.8,0],uno:[0,.8,0]}[k];
  const cam=new T.PerspectiveCamera({pen:40,fk:44,uno:40,gk:38}[k],16/9,.1,220);cam.position.set(...camP);cam.lookAt(...look);
  const place=()=>{const w_=scn.clientWidth||600,h=scn.clientHeight||338;r.setSize(w_,h,false);cam.aspect=w_/h;cam.updateProjectionMatrix();
    const a=new T.Vector3(-3.66,2.44,0).project(cam),b=new T.Vector3(3.66,0,0).project(cam),L_=(a.x+1)/2*100,Tp=(1-a.y)/2*100,R_=(b.x+1)/2*100,Bt=(1-b.y)/2*100;
    Object.assign(zones.style,{left:L_+'%',top:Tp+'%',width:(R_-L_)+'%',height:(Bt-Tp)+'%'});};
  place();const ro=window.ResizeObserver?new ResizeObserver(place):null;ro&&ro.observe(scn);
  const Z3=[[-2.45,1.78],[0,1.85],[2.45,1.78],[-2.45,.5],[0,.45],[2.45,.5]],ease=u=>1-Math.pow(1-u,3),t0=performance.now();let A=null,raf=0,dead=false;
  const arms=(f,l,rr,x)=>{const aL=f.inner.getObjectByName('armL'),aR=f.inner.getObjectByName('armR');if(aL){aL.rotation.z=l;aL.rotation.x=x||0;}if(aR){aR.rotation.z=rr;aR.rotation.x=x||0;}};
  const disp=()=>{if(dead)return;dead=true;cancelAnimationFrame(raf);ro&&ro.disconnect();sc.traverse(o=>{o.geometry&&o.geometry.dispose();if(o.material)(Array.isArray(o.material)?o.material:[o.material]).forEach(m=>{m.map&&m.map.dispose();m.dispose();});});sky.dispose();r.dispose();try{r.forceContextLoss();}catch(e){}};
  const loop=now=>{if(!document.body.contains(cv)){disp();return;}raf=requestAnimationFrame(loop);const t=(now-t0)/1000;
    if(!A){gk.o.position.x=Math.sin(t*1.7)*.35;gk.inner.position.y=Math.abs(Math.sin(t*3.4))*.04;arms(gk,-.5,.5);wall.forEach((w,i)=>{w.inner.position.y=Math.abs(Math.sin(t*2+i))*.02;});}
    else A();r.render(sc,cam);};
  raf=requestAnimationFrame(loop);
  F.g3={anim(out,kz,bz){const s0=performance.now(),[kx,ky]=Z3[kz];let [tx,ty]=Z3[bz],tz=-.15;tx+=(Math.random()-.5)*.5;ty+=(Math.random()-.5)*.2;
    if(out==='miss'){if(bz<3||ch(.5))ty=2.95;else tx=(Math.sign(tx)||1)*4.4;tz=-1.5;}
    if(out==='wall'){tx=F.wallAt[0];ty=1.45;tz=F.wallAt[1]+.3;}
    if(out==='save'){tx=kx*.86;ty=Math.max(.4,ky*.95);tz=kz0+.15;}
    const p0=ball.position.clone(),curve=k==='fk'?(tx>p0.x?-2.4:2.4):0,p1=new T.Vector3((p0.x+tx)/2+curve,Math.max(p0.y,ty)+(k==='fk'?2.4:.5),(p0.z+tz)/2),run=k==='gk'?.5:0,fl=k==='fk'?1:.7,gx0=gk.o.position.x,dir=Math.sign(kx),top=kz<3;
    A=()=>{const e=(performance.now()-s0)/1000;if(shooter)shooter.o.position.z=12.3-Math.min(1,e/Math.max(run,.01))*1;
      if(e<run)return;const u=clamp((e-run)/fl,0,1),q=1-u;
      if(u<1)ball.position.set(q*q*p0.x+2*q*u*p1.x+u*u*tx,q*q*p0.y+2*q*u*p1.y+u*u*ty,q*q*p0.z+2*q*u*p1.z+u*u*tz);ball.rotation.x-=.3;
      const g=ease(clamp((e-run-.1)/(fl*.75),0,1));gk.o.position.x=gx0+(kx-gx0)*g*.92;gk.o.position.y=top?g*.55:0;gk.o.position.z=kz0+(k==='uno'?g*.7:0);
      gk.inner.rotation.z=-dir*g*(top?1.05:1.35);if(!dir&&top)arms(gk,-.3,.3,-2.8*g);else arms(gk,-.5-g*(dir<0?2.3:1.5),.5+g*(dir>0?2.3:1.5));
      wall.forEach(w=>{w.o.position.y=Math.sin(clamp((e-run)/.5,0,1)*Math.PI)*.45;arms(w,-.1,.1,-2.6*Math.sin(clamp((e-run)/.5,0,1)*Math.PI));});
      if(u>=1){const a=e-run-fl;
        if(out==='goal'){back.position.z=-2-Math.sin(clamp(a/.45,0,1)*Math.PI)*.4;ball.position.set(tx,Math.max(.12,ty-a*2.6),Math.max(-1.85,tz-a*3));
          if(a<2.6)for(let i=0;i<n;i+=2){const c=cb[i];d0.position.set(c[0],c[1]+Math.abs(Math.sin(a*11+i))*.35,c[2]);d0.updateMatrix();im.setMatrixAt(i,d0.matrix);}im.instanceMatrix.needsUpdate=true;}
        else if(out==='save'||out==='wall')ball.position.set(tx+(tx>=0?1:-1)*a*4,Math.max(.12,ty+a*2.2-a*a*6),tz+a*7);
        else ball.position.set(tx+(tx-p0.x)*a*.3,ty+a*.5,tz-a*6);}
      cam.position.x+=(camP[0]*.85-cam.position.x)*.02;cam.position.z+=(camP[2]-1.3-cam.position.z)*.02;cam.lookAt(...look);};}};
  return true;}

/* ---------- capitán en el campo ---------- */
const CAPO=[['Calmar el partido','Pides al equipo replegarse y tocar.'],['Presión arriba','Ordenas adelantar líneas y apretar.'],['Protestar al árbitro','Te encaras con el árbitro por una falta no pitada.']];
function showCap(){const L=UI.jl,d=document.getElementById('jdec');if(!d){liveRun();return;}const my=L.mySide==='h'?L.hg:L.ag,th=L.mySide==='h'?L.ag:L.hg;L.capOpen=true;
  L.M&&L.M.l3&&L.M.l3(`<span class="l3-tag">Capitán</span><b>${esc(P.last)}</b><em>${L.m}'</em>`,2200);
  d.innerHTML=`<p class="j-sit"><b class="num">${L.m}'</b> Llevas el brazalete. ${my<th?'Vais por detrás en el marcador.':my>th?'Vais ganando y el rival aprieta.':'Partido igualado.'} ¿Qué ordenas?</p><div class="j-opts">${CAPO.map((o,j)=>`<button class="j-op" data-act="jCap" data-j="${j}"><b>${o[0]}</b><small>${o[1]}</small></button>`).join('')}</div>`;d.hidden=false;d.querySelector('button').focus({preventScroll:true});}
function capDecide(j){const L=UI.jl;if(!L||!L.capOpen)return;L.capOpen=false;const d=document.getElementById('jdec');if(d){d.hidden=true;d.innerHTML='';}
  const mine=L.mySide,rival=mine==='h'?'a':'h',mates=squadNames(P.club,P.last),later=()=>clamp(L.m+R(3,12),L.m+1,89);
  if(j===0){const ix=L.ev.findIndex(x=>x.kind==='goal'&&x.side===rival);if(ix>=0&&ch(.6))L.ev.splice(ix,1);const ox=L.ev.findIndex(x=>x.kind==='goal'&&x.side===mine);if(ox>=0&&ch(.3))L.ev.splice(ox,1);feed('El capitán pide calma: el equipo controla el balón.');P.chem=clamp(P.chem+1,0,100);}
  else if(j===1){if(ch(.55))L.ev.push({m:later(),kind:'goal',side:mine,n:pk(mates)});if(ch(.35))L.ev.push({m:later(),kind:'goal',side:rival,n:pk(squadNames(L.mySide==='h'?L.aId:L.hId))});feed('El capitán ordena presión arriba: el equipo se lanza.');P.chem=clamp(P.chem+1,0,100);}
  else{if(ch(.4+P.rep.polemico/40)){UI.jm.res.yel=(UI.jm.res.yel||0)+1;feed(`Amarilla para ${P.last} por protestar.`);if(UI.jm.res.yel>=2){UI.jm.res.redMin=L.m;L.on=false;L.ev=L.ev.filter(x=>x.kind!=='moment'&&x.kind!=='cap');feed(`¡Segunda amarilla! ${P.last} se va a la caseta.`,true);}}
    else{feed('El árbitro toma nota de la protesta.');if(ch(.25))L.ev.push({m:later(),kind:'goal',side:mine,n:pk(mates)});}P.rep.polemico+=.2;}
  P.rep.lider+=.3;L.ev.sort((a,b)=>a.m-b.m);liveRun();}

/* ---------- votaciones del vestuario ---------- */
function lockerVotes(n){ensureMates();const M=P.mates||[],nm=()=>(pk(M)||{n:'un compañero'}).n;
  const best=n>=7.1&&P.sea.pj>=10&&(avg(M.map(m=>m.c))>=40||ch(.5)),hard=(P.sea.hard||0)>=12||(P.intensity==='intensa'&&ch(.5)),pes=(P.rep.polemico>=4&&ch(.6))||(P.sea.party||0)>=4;
  const v=[['Mejor jugador del vestuario',best?'tú':nm()],['El más trabajador',hard?'tú':nm()],['El más pesado',pes?'tú':nm()]];
  P.votes=P.votes||[];P.votes.push({s:seasonLabel(P.season),v});P.votes=P.votes.slice(-25);
  if(best)award('MVP del vestuario');if(hard){P.tru=clamp(P.tru+4,0,100);P.chem=clamp(P.chem+3,0,100);}
  if(pes){P.chem=clamp(P.chem-4,0,100);news('El vestuario te elige «el más pesado» de la temporada. Risas… y algún mensaje en el grupo.');}}
function votesBlock(s){const v=(P.votes||[]).slice(-1)[0];return v&&v.s===s?`<div class="j-votes"><h4>Votaciones del vestuario</h4>${v.v.map(([k,w])=>`<p class="j-n"><b>${k}</b>${w==='tú'?'<span class="j-neon">¡Tú!</span>':esc(w)}</p>`).join('')}</div>`:'';}

/* ---------- redes sociales ---------- */
const handle=()=>'@'+(P.name+P.last).toLowerCase().normalize('NFD').replace(/[^a-z0-9]/g,'');
function postOpts(won,g){return[['equipo',won?'Tres puntos que valen oro. Equipo.':'Toca levantarse. Juntos.'],['yo',g?`${g>1?g+' goles':'Gol'} y a seguir. Esto no ha hecho más que empezar.`:'Trabajo, trabajo y más trabajo.'],['pique',won?'Que sigan hablando.':'Ya hablaremos en la vuelta.'],['casa','Recuperando en casa. Mañana, más.']];}
const COMS={bien:['¡Qué partidazo!','Crack, sigue así.','El mejor del equipo, sin discusión.','Te mereces la selección.','Orgulloso de ti.'],mal:['Hoy no era el día…','A levantarse, campeón.','Más intensidad, por favor.','Se te ha visto cansado.'],pique:['Uff, se viene polémica.','Eso no se dice, hombre.','¡Con dos narices!','El rival no va a olvidar esto.'],casa:['¡Qué casa!','Descansa, que lo necesitas.','Esa vida, quién la pillara.']};
function socialBlock(F,won){if(!F.min)return'';const R0=UI.jm.res;
  return `<div class="j-social" id="jsoc"><h4>Publicar en redes</h4><div class="j-chips">${postOpts(won,R0.g).map(([k,t])=>`<button class="j-chip" data-act="jPost" data-k="${k}">«${esc(t)}»</button>`).join('')}<button class="j-chip" data-act="jPost" data-k="no">No publicar</button></div></div>`;}
function doPost(k){const M=UI.jm;if(!M||M.posted||!M.final)return;M.posted=true;const box=document.getElementById('jsoc');if(k==='no'){if(box)box.remove();return;}
  const F=M.final,won=F.pens?F.won:F.gf>F.ga,g=M.res.g,cap=(postOpts(won,g).find(x=>x[0]===k)||[])[1]||'';
  const likes=Math.round(P.followers*(.02+F.rt/220)*(won?1.3:.8)*({pique:1.7,yo:1.2,equipo:1,casa:.9}[k])*(.8+Math.random()*.4));
  const pool=k==='pique'?COMS.pique:k==='casa'?COMS.casa:F.rt>=6.5?COMS.bien:COMS.mal,com=[...pool].sort(()=>Math.random()-.5).slice(0,3);
  P.fame=clamp(P.fame+({pique:.8,yo:.5,equipo:.4,casa:.3}[k])*(won?1:.5),0,100);
  if(k==='equipo'){P.rep.humilde+=.3;P.chem=clamp(P.chem+1,0,100);}else if(k==='yo')P.rep.mediatico+=.3;else if(k==='casa')P.rep.mediatico+=.2;
  else{P.rep.polemico+=.6;if(!won){P.tru=clamp(P.tru-3,0,100);P.mor=clamp(P.mor-3,0,100);com[0]='Perder y encima provocar…';}}
  if(likes>=1e6)flag('viral');P.posts=P.posts||[];P.posts.unshift({s:P.season,w:P.week,cap,likes,com});P.posts=P.posts.slice(0,15);save();
  if(box)box.innerHTML=postCard(P.posts[0]);}
function postCard(p){return `<div class="j-post"><div class="j-post-h">${avatar(P,36)}<div><b>${esc(P.name)} ${esc(P.last)}</b><small>${handle()}</small></div></div><p>${esc(p.cap)}</p><small class="num">${p.likes.toLocaleString('es-ES')} me gusta</small>${p.com.map(c=>`<p class="j-com"><b>@aficionado${R(10,999)}</b> ${esc(c)}</p>`).join('')}</div>`;}
function postsBlock(){const L=P.posts||[];return `<h3 style="margin-top:20px">Tus publicaciones</h3>${L.length?L.slice(0,4).map(p=>`<p class="j-n"><b class="num">${p.likes.toLocaleString('es-ES')} ♥</b>«${esc(p.cap)}» · ${esc(p.com[0]||'')}</p>`).join(''):'<p class="muted">Publica después de cada partido desde el resumen.</p>'}`;}

/* ---------- documental de tu carrera ---------- */
function docChapters(){const C=[],cards=P.cards||[],F=fam();
  C.push({e:'Capítulo 1 · Los inicios',h:`${P.name} ${P.last}`,b:`${P.nat}, ${P.startAge} años. ${P.origin}: así empezó todo. Primera parada, ${cname(P.origin0)}. Sueño: ${DREAMS[P.dream].toLowerCase()}.`,c:cards.find(c=>c.t==='debut')});
  P.hist.forEach((h,i)=>{const t=P.titles.filter(x=>x.s===h.s).map(x=>x.n),a=P.awards.filter(x=>x.s===h.s).map(x=>x.n),mv=P.moves.filter(x=>x.s===h.s).map(x=>`${x.t}: ${x.from} → ${x.to}`),kids=F.kids.filter(k=>seasonLabel(k.b)===h.s).map(k=>`Nace ${k.n}`);
    C.push({e:`Capítulo ${i+2} · ${h.s}`,h:h.c,st:[['Partidos',h.pj],['Goles',h.g],['Asist.',h.a],['Nota',h.n],['Media',h.o]],li:[...t.map(x=>'Título: '+x),...a.map(x=>'Premio: '+x),...mv,...kids],c:cards.find(c=>c.s===h.s&&c.t!=='debut')});});
  C.push({e:'Último capítulo · El adiós',h:'Leyenda',b:`${P.st.pj} partidos, ${P.st.g} goles y ${P.st.a} asistencias. ${P.titles.length} títulos, ${P.awards.length} premios y una media máxima de ${P.peak}.${P.coach&&P.coach.hist.length?` Después, ${P.coach.hist.length} temporadas en los banquillos y ${P.coach.titles.length} títulos más.`:''}`,c:cards.find(c=>c.t==='icono')});
  return C;}
function showDoc(i){const C=docChapters();i=clamp(i,0,C.length-1);clearTimeout(UI.docT);const c=C[i];UI.docI=i;
  modal(`<div class="hd j-mhd"><h3>Documental · ${esc(P.name)} ${esc(P.last)}</h3></div><div class="bd j-doc"><div class="j-doc-dots" aria-hidden="true">${C.map((_,j)=>`<i class="${j<=i?'on':''}"></i>`).join('')}</div>
   <div class="j-doc-ch" key="${i}"><div class="j-doc-tx"><div class="j-eyebrow">${esc(c.e)}</div><h2 class="j-h">${esc(c.h)}</h2>${c.b?`<p>${esc(c.b)}</p>`:''}${c.st?`<div class="j-kv">${c.st.map(([l,v])=>`<div><small>${l}</small><b class="num">${v}</b></div>`).join('')}</div>`:''}${c.li&&c.li.length?`<ul class="j-doc-li">${c.li.map(x=>`<li>${esc(x)}</li>`).join('')}</ul>`:''}</div>${c.c?`<div class="j-doc-card">${cardBox(c.c)}</div>`:''}</div>
   <div class="j-acts"><button class="btn" data-act="jDoc" data-i="${i-1}" ${i?'':'disabled'}>← Anterior</button>${i<C.length-1?`<button class="btn primary" data-act="jDoc" data-i="${i+1}" data-focus>Siguiente →</button>`:'<button class="btn primary" data-act="jClose" data-focus>Fin</button>'}<button class="btn" data-act="jDocAuto">${UI.docAuto?'Pausa':'Reproducción automática'}</button></div></div>`);
  if(UI.docAuto&&i<C.length-1&&!reduced())UI.docT=setTimeout(()=>{if(document.querySelector('.j-doc'))showDoc(i+1);},5200);}

/* ---------- mascota (solo una) ---------- */
const PETS=[['perro','Perro',1200,'Te saca a pasear: recuperas algo más de energía.'],['gato','Gato',600,'Te recibe ronroneando: más moral.'],['hamster','Hámster',80,'Pequeño y gracioso: un poco más de moral.'],['conejo','Conejo',150,'Tranquilo y adorable: más moral.'],['loro','Loro',900,'Sus vídeos se hacen virales: algo más de fama.'],['tortuga','Tortuga',200,'Te enseña paciencia: mejores decisiones a largo plazo.']];
const PETN={perro:['Toby','Luna','Rocky','Kira','Thor'],gato:['Misi','Simba','Nala','Garfield','Mía'],hamster:['Bolita','Pipas','Nuez','Gofre'],conejo:['Copito','Tambor','Pelusa','Zanahoria'],loro:['Paco','Kiwi','Coco','Lola'],tortuga:['Manuelita','Rayo','Tortu','Sabia']};
const PET3={perro:{c:'#b07a3e',p:[[.9,.42,.38,0,0,.55,0],[.4,.38,.36,0,.6,.82,0],[.2,.16,.26,'#d9a46a',.86,.74,0],[.06,.06,.1,'#111',.97,.8,0],[.1,.24,.1,'#5a3a1e',.55,1.04,.17],[.1,.24,.1,'#5a3a1e',.55,1.04,-.17],[.32,.08,.08,0,-.58,.82,0]],legs:[.12,.36,.3,.12],eye:[.8,.9,.09]},
  gato:{c:'#f0a040',p:[[.7,.32,.3,0,0,.45,0],[.32,.3,.3,0,.45,.66,0],[.08,.12,.08,'#c87a28',.48,.87,.1],[.08,.12,.08,'#c87a28',.48,.87,-.1],[.08,.5,.08,0,-.4,.75,0]],legs:[.08,.3,.25,.1],eye:[.61,.7,.07]},
  hamster:{c:'#e8c08a',p:[[.42,.3,.34,0,0,.2,0],[.24,.24,.26,0,.26,.25,0],[.2,.12,.26,'#fff3df',.1,.12,0],[.06,.08,.06,'#c48a5a',.3,.4,.08],[.06,.08,.06,'#c48a5a',.3,.4,-.08]],legs:null,eye:[.39,.3,.07]},
  conejo:{c:'#f2f2f2',p:[[.55,.4,.35,0,0,.32,0],[.28,.28,.26,0,.36,.52,0],[.07,.38,.08,0,.34,.84,.07],[.07,.38,.08,0,.34,.84,-.07],[.14,.14,.14,'#ffffff',-.32,.4,0],[.04,.04,.04,'#ff8fb0',.51,.5,0]],legs:[.1,.12,.2,.12],eye:[.5,.58,.08]},
  loro:{c:'#2fbf4f',p:[[.3,.45,.3,0,0,.42,0],[.26,.26,.26,'#e23b3b',.06,.78,0],[.12,.1,.1,'#ffd24a',.24,.74,0],[.12,.36,.1,'#2a7bd8',-.2,.26,0],[.06,.14,.28,'#1f9a3c',0,.48,.17],[.06,.14,.28,'#1f9a3c',0,.48,-.17]],legs:[.05,.2,.06,.07],eye:[.19,.84,.08]},
  tortuga:{c:'#3d7a3a',p:[[.7,.3,.55,0,0,.3,0],[.5,.12,.4,'#4f9a4a',0,.5,0],[.22,.16,.18,'#9a8a5a',.45,.25,0]],legs:[.14,.14,.25,.22],legc:'#9a8a5a',eye:[.56,.29,.06]}};
function petMesh(T,g,kind){const D=PET3[kind];if(!D)return;const G=new T.Group();G.name='pet';G.scale.setScalar(1.7);g.add(G);
  const M=c=>new T.MeshStandardMaterial({color:new T.Color(c||D.c),roughness:.8});const b=(w_,h,d,c,x,y,z)=>{const o=new T.Mesh(new T.BoxGeometry(w_,h,d),M(c));o.position.set(x,y,z);o.castShadow=true;G.add(o);};
  D.p.forEach(([w_,h,d,c,x,y,z])=>b(w_,h,d,c||D.c,x,y,z));
  if(D.legs){const [lw,lh,lx,lz]=D.legs;[[1,1],[1,-1],[-1,1],[-1,-1]].forEach(([sx,sz])=>b(lw,lh,lw,D.legc||D.c,sx*lx,lh/2,sz*lz));}
  const [ex,ey,ez]=D.eye;[1,-1].forEach(s=>b(.04,.05,.04,'#111',ex,ey,s*ez));}
function petSVG(kind,size=44){const D=PET3[kind];if(!D)return'';const c=D.c;
  const shapes={perro:`<rect x="6" y="20" width="26" height="12" fill="${c}"/><rect x="28" y="12" width="12" height="12" fill="${c}"/><rect x="38" y="17" width="5" height="5" fill="#d9a46a"/><rect x="28" y="9" width="4" height="7" fill="#5a3a1e"/><rect x="2" y="18" width="5" height="3" fill="${c}"/><rect x="8" y="32" width="4" height="7" fill="${c}"/><rect x="26" y="32" width="4" height="7" fill="${c}"/><rect x="34" y="15" width="2" height="2" fill="#111"/>`,
    gato:`<rect x="8" y="22" width="22" height="10" fill="${c}"/><rect x="28" y="14" width="11" height="11" fill="${c}"/><rect x="28" y="10" width="3" height="5" fill="#c87a28"/><rect x="36" y="10" width="3" height="5" fill="#c87a28"/><rect x="4" y="10" width="3" height="14" fill="${c}"/><rect x="10" y="32" width="3" height="7" fill="${c}"/><rect x="25" y="32" width="3" height="7" fill="${c}"/><rect x="34" y="18" width="2" height="2" fill="#111"/>`,
    hamster:`<rect x="10" y="20" width="22" height="16" fill="${c}"/><rect x="26" y="16" width="12" height="14" fill="${c}"/><rect x="14" y="30" width="14" height="6" fill="#fff3df"/><rect x="28" y="13" width="3" height="4" fill="#c48a5a"/><rect x="34" y="20" width="2" height="2" fill="#111"/>`,
    conejo:`<rect x="8" y="22" width="22" height="14" fill="${c}"/><rect x="26" y="16" width="12" height="12" fill="${c}"/><rect x="27" y="2" width="3" height="15" fill="${c}"/><rect x="32" y="2" width="3" height="15" fill="${c}"/><rect x="4" y="24" width="5" height="5" fill="#ffffff"/><rect x="34" y="20" width="2" height="2" fill="#111"/>`,
    loro:`<rect x="16" y="16" width="12" height="18" fill="${c}"/><rect x="17" y="6" width="11" height="11" fill="#e23b3b"/><rect x="28" y="10" width="5" height="4" fill="#ffd24a"/><rect x="12" y="30" width="5" height="10" fill="#2a7bd8"/><rect x="24" y="9" width="2" height="2" fill="#111"/>`,
    tortuga:`<rect x="8" y="18" width="26" height="12" fill="${c}"/><rect x="12" y="14" width="18" height="5" fill="#4f9a4a"/><rect x="33" y="22" width="8" height="6" fill="#9a8a5a"/><rect x="10" y="30" width="5" height="5" fill="#9a8a5a"/><rect x="27" y="30" width="5" height="5" fill="#9a8a5a"/><rect x="38" y="23" width="2" height="2" fill="#111"/>`};
  return `<svg viewBox="0 0 44 44" width="${size}" height="${size}" aria-hidden="true" shape-rendering="crispEdges">${shapes[kind]||''}</svg>`;}
function petPanel(){const p=P.pet;
  if(p){const d=PETS.find(x=>x[0]===p.k);return `<div class="j-panel"><h3>Tu mascota</h3><div class="j-pet on">${petSVG(p.k,64)}<div><b>${esc(p.n)}</b><small>${d[1]} · desde ${esc(p.s)}</small><small>${d[3]}</small></div></div><p class="j-hint">${hasHome()?'Vive en tu casa: la verás paseando por la parcela en la Ciudad.':'Cuando tengas casa propia la verás paseando por tu parcela en la Ciudad.'}</p><div class="j-acts"><button class="btn small" data-act="jPetName">Cambiar el nombre</button><button class="btn small" data-act="jPetGive">Buscarle otro hogar</button></div></div>`;}
  return `<div class="j-panel"><h3>Mascota</h3><p class="j-hint">Solo puedes tener una. Elige con calma: cada una te ayuda a su manera.</p><div class="j-pets">${PETS.map(([k,l,price,txt])=>`<button class="j-pet" data-act="jPetAdopt" data-k="${k}" ${P.money<price?'disabled':''}>${petSVG(k,48)}<div><b>${l}</b><small>${txt}</small><small class="num">${eur(price)}</small></div></button>`).join('')}</div></div>`;}

/* ---------- logros ---------- */
const flag=k=>{(P.flags=P.flags||{})[k]=1;},F_=k=>!!(P.flags&&P.flags[k]);
const ACH=[
  ['gol1','Primer gol','Marca tu primer gol oficial.',()=>P.st.g>=1],['g100','Centenario','Llega a 100 goles.',()=>P.st.g>=100],['g300','Goleador histórico','Llega a 300 goles.',()=>P.st.g>=300],
  ['a100','Asistente de lujo','Da 100 asistencias.',()=>P.st.a>=100],['pj500','Incombustible','Juega 500 partidos.',()=>P.st.pj>=500],['hat','Hat-trick','Marca tres goles en un partido.',()=>F_('hat')],
  ['perfect','Partido perfecto','Saca un 9,5 o más en un partido.',()=>F_('perfect')],['pen','Sangre fría','Marca un penalti en primera persona.',()=>F_('pen')],['fk','Guante en el pie','Marca un gol de falta directa en primera persona.',()=>F_('fk')],
  ['save','Muro','Para un penalti en primera persona.',()=>F_('save')],['titulo','Primer título','Gana tu primer título.',()=>P.titles.length>=1],['champions','Noches de Champions','Gana la Champions League.',()=>P.titles.some(t=>t.n==='Champions League')],
  ['mundial','Campeón del mundo','Gana el Mundial.',()=>P.titles.some(t=>t.n==='Mundial')],['balon','Balón de Oro','Gana el Balón de Oro.',()=>P.awards.some(a=>a.n==='Balón de Oro')],
  ['tres','Trotamundos ganador','Gana títulos con 3 clubes distintos.',()=>new Set(P.titles.filter(t=>t.c!==P.nat).map(t=>t.c)).size>=3],['capitan','El brazalete','Sé capitán de tu club o de tu selección.',()=>P.captain||P.sel.captain],
  ['media90','Élite mundial','Alcanza 90 de media.',()=>(P.peak||0)>=90],['dupla','Dupla letal','Forma una dupla letal con un compañero.',()=>(P.mates||[]).some(m=>m.duo)],['album','Coleccionista','Reúne 15 cartas en tu álbum.',()=>(P.cards||[]).length>=15],
  ['limpio','Juego limpio','Termina una temporada de 30 partidos o más sin tarjetas.',()=>F_('clean')],['roja','Cabeza caliente','Ve tu primera tarjeta roja.',()=>F_('red')],['mvp','El vestuario habla','Gana la votación al mejor jugador del vestuario.',()=>P.awards.some(a=>a.n==='MVP del vestuario')],
  ['viral','Viral','Consigue un millón de me gusta en una publicación.',()=>F_('viral')],['padre','Padre','Ten tu primer hijo.',()=>fam().kids.length>0],['hijo','De tal palo…','Tu hijo firma como profesional.',()=>fam().kids.some(k=>k.pro)],
  ['mansion','Casa de revista','Termina tu casa moderna.',()=>!!(P.home&&homeLevel(P.home)>=18)],['hiper','Garaje de ensueño','Ten un hiperdeportivo en tu garaje.',()=>(P.cars||[]).includes('hiper')],
  ['inversor','Inversor','Ten inversiones por valor de 3 M€.',()=>Object.values(P.inv||{}).reduce((s,x)=>s+x.v,0)>=3e6],['mascota','Mejor amigo','Adopta una mascota.',()=>!!P.pet],
  ['fiel','Un club, una vida','Retírate en tu primer club.',()=>P.retired&&P.club===P.origin0],['mister','Título desde el banquillo','Gana un título como entrenador.',()=>!!(P.coach&&P.coach.titles.length)],
];
function achCheck(){if(!P||!P.st)return;P.ach=P.ach||{};let got=0;ACH.forEach(([id,n,,fn])=>{if(P.ach[id])return;let ok=false;try{ok=fn();}catch(e){}if(ok){P.ach[id]=seasonLabel(P.season);got++;news(`Logro desbloqueado: ${n}.`,'hot');if(got<=2&&typeof toast==='function')toast(`Logro desbloqueado: ${n}`);}});}
function achPanel(){const A=P.ach||{},n=ACH.filter(a=>A[a[0]]).length;
  return `<div class="j-panel"><h3>Logros · <span class="num">${n}/${ACH.length}</span></h3><div class="j-ach">${ACH.map(([id,l,d])=>`<div class="${A[id]?'on':''}"><b>${l}</b><small>${esc(d)}${A[id]?` · ${esc(A[id])}`:''}</small></div>`).join('')}</div></div>`;}

/* ---------- eventos y acciones nuevas ---------- */
Object.assign(EV,{
  pretemporada:{t:()=>`Arranca la pretemporada. El club te deja elegir cómo prepararla.`,o:[
    ['Gira por Asia (fama y dinero, mucho cansancio)',()=>{P.fame+=4;P.money+=Math.round(wageWeek()*3+20000);P.fat+=18;news(`Gira por Asia: estadios llenos y miles de camisetas de ${P.last} vendidas.`,'hot');}],
    ['Gira por Estados Unidos (fama, algo de cansancio)',()=>{P.fame+=3;P.money+=Math.round(wageWeek()*2+15000);P.fat+=10;news(`Gira por Estados Unidos: ${P.last} brilla en los amistosos.`);}],
    ['Pretemporada en casa (llegas a tope)',()=>{P.fat=Math.max(0,P.fat-20);P.form=clamp(P.form+10,10,99);P.tru+=4;P.lp+=.5;news(`${P.last} hace una pretemporada impecable en la ciudad deportiva.`);}]]},
});
Object.assign(ACT,{
  jCap(d){capDecide(+d.j);},
  jPost(d){doPost(d.k);},
  jDoc(d){showDoc(+d.i);},jDocAuto(){UI.docAuto=!UI.docAuto;showDoc(UI.docI||0);},
  jPetAdopt(d){const p=PETS.find(x=>x[0]===d.k);if(!p||P.pet||P.money<p[2])return;P.money-=p[2];P.pet={k:p[0],n:pk(PETN[p[0]]),s:seasonLabel(P.season)};P.mor=clamp(P.mor+6,0,100);news(`${P.last} adopta a ${P.pet.n}, su nuevo ${p[1].toLowerCase()}.`,'hot');save();rr();C3D&&C3D.rebuildHouse();},
  jPetName(){if(!P.pet)return;const L=PETN[P.pet.k],i=L.indexOf(P.pet.n);P.pet.n=L[(i+1)%L.length];save();rr();},
  jPetGive(){if(!P.pet)return;news(`${P.pet.n} encuentra un nuevo hogar con una familia amiga.`);P.pet=null;P.mor=clamp(P.mor-6,0,100);save();rr();C3D&&C3D.rebuildHouse();},
});

const css3=document.createElement('style');css3.textContent=`
.fp-3d{background:#0f0722}.fp-3d .fp-cv{position:absolute;inset:0;width:100%;height:100%;display:block}
.fp-3d .fp-zones{position:absolute;inset:auto;z-index:4}
.fp-3d .fp-z{border-color:rgba(228,204,255,.28)}
.j-social{margin-top:14px;padding-top:12px;border-top:1px solid var(--line)}.j-social h4{margin:0 0 8px}
.j-social .j-chip{text-align:left;white-space:normal}
.j-post{padding:12px 14px;border:1px solid rgba(201,155,255,.4);border-radius:10px;background:#160a2c}
.j-post-h{display:flex;gap:10px;align-items:center;margin-bottom:6px}.j-post-h svg{border-radius:8px}.j-post-h small{display:block;color:var(--muted)}
.j-post>p{margin:4px 0 6px}.j-com{margin:4px 0 0;font-size:13px;color:var(--muted)}.j-com b{color:var(--neon);font-weight:600}
.j-votes{margin:10px 0}.j-votes h4{margin:0 0 4px}
.j-ach{display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:10px}
.j-ach>div{padding:10px 12px;border:1px solid var(--line);border-radius:8px;opacity:.5}
.j-ach>div.on{opacity:1;border-color:rgba(201,155,255,.6);box-shadow:inset 0 0 0 1px rgba(201,155,255,.25),0 0 22px -12px #B57BFF}
.j-ach b{display:block}.j-ach small{color:var(--muted);font-size:12px}
.j-doc-dots{display:flex;gap:4px;margin-bottom:14px}.j-doc-dots i{flex:1;height:3px;border-radius:2px;background:rgba(214,190,255,.18)}.j-doc-dots i.on{background:#C99BFF}
.j-doc-ch{display:grid;grid-template-columns:1fr auto;gap:20px;align-items:center;animation:jdoc .6s cubic-bezier(.16,1,.3,1)}
.j-doc-card .j-cc .j-card{max-width:190px}.j-doc-li{margin:10px 0 0;padding-left:18px}.j-doc-li li{margin:3px 0}
@keyframes jdoc{from{opacity:0;transform:translateY(14px)}}
@media(max-width:640px){.j-doc-ch{grid-template-columns:1fr}}
.j-pets{display:grid;gap:8px}
.j-pet{display:grid;grid-template-columns:auto 1fr;gap:12px;align-items:center;text-align:left;padding:8px 10px;border:1px solid var(--line);border-radius:8px;background:transparent;color:inherit;cursor:pointer}
.j-pet:hover:not(:disabled){border-color:#C99BFF}.j-pet:disabled{opacity:.45;cursor:not-allowed}.j-pet small{display:block;color:var(--muted);font-size:12px}
.j-pet.on{cursor:default;border-color:rgba(201,155,255,.55)}.j-pet svg{background:#1A0D33;border-radius:8px;padding:4px}
@media(prefers-reduced-motion:reduce){.j-doc-ch{animation:none}}
`;document.head.appendChild(css3);

/* tarjetas y sanciones tras el partido; efectos semanales de la mascota */
function cardsAfter(R0){if(R0.yel){P.sea.yel=(P.sea.yel||0)+R0.yel;P.st.yel=(P.st.yel||0)+R0.yel;if(!R0.redMin&&P.sea.yel%5===0){P.ban=1;P.banNew=true;news(`${P.last} ve la quinta amarilla: un partido de sanción.`,'bad');}}
  if(R0.redMin){P.sea.red=(P.sea.red||0)+1;P.st.red=(P.st.red||0)+1;P.ban=R(1,3);P.banNew=true;P.tru=clamp(P.tru-6,0,100);P.rep.polemico+=1;flag('red');news(`Roja a ${P.last}: ${P.ban} partido${P.ban>1?'s':''} de sanción.`,'bad');}}
function petWeek(){if(!P.pet)return;const k=P.pet.k;if(k==='perro')P.fat=clamp(P.fat-1.5,0,100);if(k==='loro')P.fame=clamp(P.fame+.08,0,100);if(k==='tortuga')P.lp+=.02;
  P.mor=clamp(P.mor+({gato:.45,conejo:.3,perro:.2,hamster:.2,loro:.15,tortuga:.15}[k]||0),0,100);}

/* ---------- acciones ---------- */
function rr(){if(typeof keepY==='function')keepY(render);else render();}
Object.assign(ACT,{
  jStart(){if(!PLAYER_MODE_ON)return;if(P){UI.screen='jgame';}else UI.screen='jcreate';render();scrollTo(0,0);},
  jExit(){UI.screen='modes';render();scrollTo(0,0);},
  jcf(d,el){if(LOOK.includes(d.k)){setLook(UI.jc,d,el);return;}UI.jc[d.k]=d.n||['age'].includes(d.k)?+d.v:d.v;rr();},
  jLook(d,el){setLook(P,d,el);save();},
  jFound(){const c=UI.jc;if(!c.name.trim()||!c.last.trim()){toast('Escribe nombre y apellido.');return;}
    P=build(c);P.at0=ovr();P.peak=ovr();genRivals();
    const big=ALL().filter(k=>k.tier===0&&k.base>=80),mid=ALL().filter(k=>k.tier===0&&k.base>=70&&k.base<79),low=ALL().filter(k=>k.tier>=1&&k.tier<=2);
    const home=ALL().filter(k=>LG[k.league].country===c.nat);
    const pick3=[pk(home.filter(k=>k.base>=76).length?home.filter(k=>k.base>=76):big),pk(mid),pk(low)];
    P.offers=pick3.map((k,i)=>({...contractFor(k.id,i<2?'cantera':'primer'),squad:i<2?'cantera':'primer',note:['Cantera de élite: debut difícil, techo alto','Filial con opciones reales de subir','Minutos desde el primer día'][i]}));
    save();UI.screen='jgame';UI.jt='despacho';render();scrollTo(0,0);},
  jSign(d){const o=P.offers[+d.i];P.club=o.club;P.origin0=o.club;P.squad=o.squad;P.contract={...o};delete P.contract.note;P.offers=[];P.tru=o.squad==='cantera'?42:48;
    P.agent=null;newSeason();addCard('debut','Debut');news(`${P.name} ${P.last} firma por ${cname(o.club)}${o.squad==='cantera'?' y se incorpora a la cantera':''}.`,'hot');checkCallup();save();render();scrollTo(0,0);},
  jTab(d){UI.jt=d.id;render();document.getElementById('jmain')?.focus({preventScroll:true});scrollTo(0,0);},
  jObj(d){UI.jobj=d.k;rr();},
  jPlay(){liveMatch();},
  jLiveMo(d){const L=UI.jl;if(!L||!L.decide)return;liveResolve(L.decide,+d.j);},
  jLiveSpeed(d,el){const L=UI.jl;if(!L)return;L.speed=L.speed===1?2:1;if(el)el.textContent=L.speed===1?'Velocidad ×2':'Velocidad normal';if(L.timer)liveRun();},
  jLiveSim(){const L=UI.jl;if(!L||L.ended)return;L.fast=true;livePause();if(L.M&&L.M.busy&&L.M.endSeq)L.M.endSeq();if(L.capOpen){L.capOpen=false;const dd=document.getElementById('jdec');if(dd){dd.hidden=true;dd.innerHTML='';}}if(L.decide){const mo=L.decide;L.decide=null;autoMoment(mo);}let g=0;while(!L.ended&&g++<400){if(L.M)L.M.busy=false;liveStep();}},jSim(){startMatch(false);},
  jMo(d){const M=UI.jm,r=resolveMoment(M.mom[M.i],+d.j);M.last=r.t;M.i++;if(M.i<M.mom.length)showMoment();else finishMatch();},
  jPen(d){const F=UI.jm.final,keeper=R(0,2),p=+d.j===keeper?.22:clamp(.72+P.at.tir/400,.7,.95),scored=ch(p);F.won=ch(scored?.62:.32);UI.jm.res.log.push(scored?'Tu penalti: ¡dentro!':'Tu penalti: parado.');applyMatch();},
  jAfter(){closeModal();week();render();if(UI.jEnd){UI.jEnd=false;seasonModal();}else if(P.pending.length)showEvent();},
  jWeek(){week();render();if(UI.jEnd){UI.jEnd=false;seasonModal();}else if(P.pending.length)showEvent();},
  jNat(){natMatch();},
  jAfterNat(){closeModal();week();render();if(UI.jEnd){UI.jEnd=false;seasonModal();}else if(P.pending.length)showEvent();},
  jEvent(){showEvent();},
  jDecide(d){const ev=P.pending.shift();if(!ev||!EV[ev.id]){closeModal();render();return;}{const E=EV[ev.id],EO=typeof E.o==='function'?E.o(ev):E.o;EO[+d.j][1](ev);}['tru','mor','chem','fame','fat'].forEach(k=>P[k]=clamp(P[k],0,100));P.lp=clamp(P.lp,0,100);save();render();if(P.pending.length)showEvent();else closeModal();},
  jFocus(d){P.focus=d.k;save();rr();},jInt(d){P.intensity=d.k;save();rr();},jFree(d){P.free=d.k;save();rr();},
  jMini(d){if(!P.miniDone)mini(d.k);},jMiniHit(){miniHit();},jClose(){closeModal();render();},
  jAgent(){P.agent=pk(['Marta Ríos','Jorge Bel','Ana Sáez','Kofi Mensah','Lucas Prado']);news(`${P.last} contrata a ${P.agent} como agente.`);save();rr();},
  jLeave(){P.tru=clamp(P.tru-15,0,100);P.mor=clamp(P.mor-3,0,100);if(role()==='Titular'||role()==='Capitán')P.lp-=1.5;else P.lp+=.5;window_(false);if(!P.offers.length)toast('De momento nadie llama. Tu agente sigue buscando.');save();rr();},
  jTalk(){const r=role();const good=P.tru>=50;modal(`<div class="hd j-mhd"><h3>Reunión con el entrenador</h3></div><div class="bd"><p class="j-sit">«${r==='Titular'||r==='Capitán'?'Eres pieza clave. Sigue así.':r==='Rotación'?'Vas a tener minutos si mantienes el nivel en los entrenamientos.':r==='Cantera'?'Te seguimos de cerca. Entrena con nosotros y gánatelo.':'Ahora mismo hay otros por delante. Demuéstrame que me equivoco.'}»</p><div class="j-opts col"><button class="j-op" data-act="jTalkOk"><b>Entendido, trabajaré más</b></button><button class="j-op" data-act="jTalkDemand"><b>Exigir más minutos</b></button>${P.pos2!==P.pos?'<button class="j-op" data-act="jTalkPos"><b>Pedir jugar de '+POS[P.pos2].toLowerCase()+'</b></button>':''}</div></div>`);},
  jTalkOk(){P.tru=clamp(P.tru+3,0,100);P.lp+=.5;save();closeModal();rr();},
  jTalkDemand(){if(ovr()>=clubStr(P.club)-3&&P.tru>=45){P.promise='minutos';P.tru+=2;toast('El míster te promete minutos.');}else{P.tru=clamp(P.tru-8,0,100);P.lp-=1;toast('Al míster no le sienta bien.');}save();closeModal();rr();},
  jTalkPos(){if(ch(.5)){const a=P.pos;P.pos=P.pos2;P.pos2=a;toast('Probarás en tu nueva posición.');}else{P.tru=clamp(P.tru-3,0,100);toast('De momento, no.');}save();closeModal();rr();},
  jAccept(d){const o=P.offers.splice(+d.i,1)[0];
    if(o.renew){P.contract={...P.contract,...o,club:P.club};news(`${P.last} renueva con ${cname(P.club)}.`);P.lp+=1;}
    else if(o.loan){P.loan={from:P.club,contract:P.contract,wage:o.wage};P.moves.push({s:seasonLabel(P.season),from:cname(P.club),to:cname(o.club),t:'Cesión',wage:o.wage});const fromC=P.club;move(o.club,o,'Cesión');P.moves.pop();P.loan.from=fromC;P.lp+=2;news(`${P.last} se marcha cedido a ${cname(o.club)}.`);}
    else{const r=role(),money=o.wage>(P.contract?P.contract.wage*1.5:0);news(`${P.last} se despide de su afición tras confirmar su salida a ${cname(o.club)}.`);
      if(o.role==='Suplente'&&money)P.lp-=2;else if(o.role!=='Suplente'&&(r==='Suplente'||r==='Descartado'))P.lp+=2;move(o.club,o,'Traspaso');P.offers=[];}
    P.promise=o.promise||P.promise;save();render();},
  jNeg(d){const o=P.offers[+d.i];o.neg=true;const odds=P.agent?.7:.45;
    if(ch(odds)){o.wage=Math.round(o.wage*(1.1+Math.random()*.15)/100)*100;if(!o.promise&&ch(.5))o.promise='minutos';toast('Mejoran la oferta.');}
    else if(ch(.4)){P.offers.splice(+d.i,1);toast('El club retira la oferta.');}else toast('No se mueven de su propuesta.');save();rr();},
  jReject(d){const o=P.offers.splice(+d.i,1)[0];if(o.renew){P.tru-=5;news(`${P.last} rechaza renovar con ${cname(P.club)}.`,'bad');}save();rr();},
  jBuy(d){const it=SHOP.find(s=>s[0]===d.k);if(!it||P.money<it[2])return;P.money-=it[2];P.assets.push(it[0]);P.mor=clamp(P.mor+it[3],0,100);P.rep.mediatico+=it[2]>1e6?1:0;if(it[2]>P.money*2&&P.age<22)P.lp-=1;news(`${P.last} se compra: ${it[1].toLowerCase()}.`);save();rr();},
  jHouseBuy(){const price=plotPrice(P.club);if(P.money<price||hasHome())return;P.money-=price;
    P.home={club:P.club,spent:price,since:seasonLabel(P.season),parts:{estructura:1,fachada:0,jardin:0,piscina:0,garaje:0,tecnologia:0}};
    news(`${P.last} se compra una casa en ${cname(P.club)}.`,'hot');P.mor=clamp(P.mor+6,0,100);save();rr();C3D&&C3D.rebuildHouse();},
  jHouseUp(d){if(!hasHome())return;const h=P.home,L=h.parts[d.k];if(L>=3)return;const cost=upCost(P.club,d.k,L);if(P.money<cost)return;
    P.money-=cost;h.spent+=cost;h.parts[d.k]=L+1;if(homeLevel(h)>=18)news(`${P.last} termina su casa moderna en ${cname(P.club)}.`,'hot');
    P.mor=clamp(P.mor+2,0,100);save();rr();C3D&&C3D.rebuildHouse();},
  jCityView(d){if(C3D)C3D.fly(d.k);},
  jRetire(){retire();render();scrollTo(0,0);},
  jNew(){P=null;try{localStorage.removeItem(KEY);}catch(e){}UI.screen='jcreate';render();scrollTo(0,0);},
});
function seasonModal(){const h=P.hist[P.hist.length-1];if(!h)return;const nc=(P.cards||[]).slice(-1)[0];
  modal(`<div class="hd j-mhd"><h3>Fin de la temporada ${h.s}</h3></div><div class="bd"><div class="j-kv"><div><small>Media</small><b class="num">${ovr()}</b></div><div><small>Partidos</small><b class="num">${h.pj}</b></div><div><small>Goles</small><b class="num">${h.g}</b></div><div><small>Asist.</small><b class="num">${h.a}</b></div><div><small>Nota</small><b class="num">${h.n}</b></div></div>
   ${nc&&nc.s===h.s?`<div class="j-newcard">${cardBox(nc)}</div>`:''}${votesBlock(h.s)}<p class="j-hint">Potencial estimado: ${potText()}. ${P.offers.length?`Tienes ${P.offers.length} oferta${P.offers.length>1?'s':''} en la mesa de tu agente.`:''}</p><button class="btn primary" data-act="jClose" data-focus>Empezar la nueva temporada</button></div>`);}
/* inputs (nombre, fecha, altura…) sin inline handlers */
document.addEventListener('input',e=>{const t=e.target;if(!(t instanceof HTMLElement)||!t.dataset.in)return;const k=t.dataset.in;
  if(UI.screen==='jcreate'){let v=t.value;if(['day','month','num','height'].includes(k))v=+v||1;if(k==='day')v=clamp(v,1,28);if(k==='month')v=clamp(v,1,12);if(k==='num')v=clamp(v,1,99);UI.jc[k]=v;
    if(k==='height'){const b=t.closest('.j-range')?.querySelector('b');if(b)b.textContent=v+' cm';G3D&&G3D.rebuild();}
    const prev=document.getElementById('jc-prev');if(prev)prev.innerHTML=card({...build(UI.jc),club:null},true);}
  else if(P&&k==='firstTrain'){P.firstTrain=t.checked;save();}else if(P&&P.coach&&k==='coachYouth'){P.coach.youth=t.checked;save();}});
document.addEventListener('change',e=>{const t=e.target;if(t instanceof HTMLSelectElement&&t.dataset.in==='nat'&&UI.screen==='jcreate'){UI.jc.nat=t.value;}});

/* ---------- integración con el juego ---------- */
const _r=render,_vm=vModes,_vi=vIntro;
render=function(){const p=UI.screen==='jcreate'||UI.screen==='jgame';document.body.dataset.mode=p?'player':'';if(!p){unmount3D();unmountCity();return _r();}{const m=()=>{mountAspect();mountCity();};requestAnimationFrame(m);setTimeout(m,150);}
  const bg=document.getElementById('bg');if(bg)bg.className='off';try{setAnim(false);}catch(e){}app.innerHTML=UI.screen==='jcreate'?vCreate():vGame();};
vModes=function(){let h=_vm();if(!PLAYER_MODE_ON)return h;h=h.replace('class="mode locked" aria-disabled="true" data-act="locked"','class="mode pm" data-act="jStart"').replace('En desarrollo','Disponible').replace('class="tag ','class="tag on ').replace('Próximamente','Empezar').replace('<span aria-hidden="true"></span>','<span aria-hidden="true">→</span>');return h;};
vIntro=function(){const h=_vi();const co=P&&P.retired&&P.coach&&!P.coach.done;if(!PLAYER_MODE_ON||!P||!P.club||(P.retired&&!co))return h;return h.replace('<div class="facts',`<div class="j-cont"><button class="btn" data-act="jStart">${co?'Continuar como entrenador':'Continuar carrera'} · ${esc(P.name)} ${esc(P.last)}</button></div>\n    <div class="facts`);};

const css=document.createElement('style');css.textContent=`
body[data-mode=player]{--night:#08040F;--turf:#140927;--turf-2:#1C0E36;--turf-3:#2A1650;--chalk:#F3ECFF;--muted:#B3A0D6;--faint:#8571AC;--line:rgba(214,190,255,.13);--line-2:rgba(214,190,255,.28);--sodium:#B57BFF;--sodium-soft:rgba(181,123,255,.16);--sodium-ink:#13062B;--win:#7CE0B0;--loss:#FF7A9A;--neon:#C99BFF;accent-color:#B57BFF;caret-color:#D2A8FF;scrollbar-color:#5B3A9E #08040F}
body[data-mode=player] ::selection{background:#B57BFF;color:#13062B}
body[data-mode=player] #app{background:radial-gradient(1000px 560px at 88% -10%,rgba(150,80,255,.32),transparent 62%),radial-gradient(760px 520px at -8% 108%,rgba(110,50,210,.26),transparent 60%),#08040F;min-height:100vh}
body[data-mode=player] .btn.primary{background:linear-gradient(180deg,#CFA6FF,#9D62F2);color:#13062B;border-color:#D2A8FF;box-shadow:0 0 0 1px rgba(210,168,255,.35),0 10px 30px -10px rgba(170,100,255,.85)}
body[data-mode=player] .btn.primary:hover{background:linear-gradient(180deg,#DDBDFF,#AE78F7)}
body[data-mode=player] .modal .sheet{background:#120824;border:1px solid rgba(210,168,255,.35);box-shadow:0 0 0 1px rgba(181,123,255,.2),0 0 60px -10px rgba(160,90,255,.55)}
.mode.pm{border-color:rgba(181,123,255,.55)}.mode.pm:hover{border-color:#C99BFF;box-shadow:0 0 0 1px #B57BFF,0 24px 60px -24px rgba(160,90,255,.85)}
.j-cont{margin-top:10px}
.j-eyebrow{font-family:var(--mono);font-size:11px;letter-spacing:.18em;text-transform:uppercase;color:var(--neon);margin-bottom:8px}
.j-h{font-size:clamp(36px,5.4vw,68px);letter-spacing:-.005em;margin-bottom:10px;text-shadow:0 0 28px rgba(181,123,255,.35)}
.j-neon{color:#E4CCFF;text-shadow:0 0 12px rgba(201,155,255,.9),0 0 30px rgba(160,90,255,.6)}
.j-hud{position:sticky;top:0;z-index:20;background:rgba(9,4,18,.9);backdrop-filter:blur(12px);border-bottom:1px solid rgba(181,123,255,.35);box-shadow:0 1px 0 rgba(181,123,255,.15),0 10px 30px -18px rgba(160,90,255,.7)}
.j-hud-in{max-width:1320px;margin:0 auto;padding:10px max(16px,env(safe-area-inset-left));display:flex;align-items:center;gap:18px}
.j-hud .back{margin:0}.j-brand{font-family:var(--display);font-weight:900;font-size:22px;letter-spacing:.04em;white-space:nowrap}.j-brand span{margin-left:8px;color:var(--neon);text-shadow:0 0 14px rgba(201,155,255,.8)}
.j-ind{display:flex;align-items:center;gap:clamp(10px,1.6vw,22px);margin-left:auto}.j-ind>div{display:grid;line-height:1.05}.j-ind small{font-family:var(--mono);font-size:9.5px;letter-spacing:.12em;text-transform:uppercase;color:var(--muted)}.j-ind b{font-size:16px}.j-ind b.bad{color:var(--loss)}
.j-big{padding:4px 12px;border:1px solid rgba(201,155,255,.6);border-radius:4px;box-shadow:0 0 18px -4px rgba(181,123,255,.7),inset 0 0 14px -6px rgba(181,123,255,.7)}.j-big b{font-family:var(--display);font-size:30px!important;color:#F1E3FF;text-shadow:0 0 14px rgba(201,155,255,.9)}
.j-hclub{display:flex;align-items:center;gap:10px;font-weight:600;white-space:nowrap}.j-hclub span{display:grid;line-height:1.1}.j-hclub small{color:var(--muted);font-size:11.5px}
.j-shell{max-width:1320px;margin:0 auto;display:grid;grid-template-columns:220px minmax(0,1fr);gap:clamp(20px,3vw,40px);padding:28px max(16px,env(safe-area-inset-left)) 90px}
.j-rail{position:sticky;top:86px;align-self:start;display:grid;gap:4px}
.j-rl{display:flex;align-items:center;gap:12px;text-align:left;padding:11px 12px;border:1px solid transparent;border-radius:4px;background:transparent;font-weight:600;color:var(--muted);transition:background .15s,color .15s,border-color .15s}
.j-rl span{font-size:11px;color:var(--faint)}.j-rl:hover{color:var(--chalk);background:rgba(181,123,255,.08)}
.j-rl.on{color:#F6EEFF;border-color:rgba(201,155,255,.55);background:linear-gradient(90deg,rgba(181,123,255,.22),rgba(181,123,255,.04));box-shadow:inset 3px 0 0 #C99BFF,0 0 22px -10px rgba(181,123,255,.9)}
.j-rl.on span{color:var(--neon)}.j-dot{margin-left:auto;font-style:normal;font-family:var(--mono);font-size:11px;min-width:20px;height:20px;display:grid;place-items:center;border-radius:10px;background:#B57BFF;color:#13062B;box-shadow:0 0 10px rgba(181,123,255,.9)}
.j-main{min-width:0;outline:0;animation:jin .5s cubic-bezier(.16,1,.3,1)}@keyframes jin{from{opacity:0;transform:translateY(10px)}}
.j-dg{display:grid;grid-template-columns:minmax(250px,330px) minmax(0,1fr);gap:clamp(20px,3vw,44px);align-items:start}
.j-hero{position:sticky;top:96px;display:grid;gap:12px;justify-items:center}.j-cap{margin:0;font-family:var(--mono);font-size:12px;letter-spacing:.14em;text-transform:uppercase;color:var(--neon)}
.j-col{display:grid;gap:18px;min-width:0}.j-two{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,340px),1fr));gap:18px;margin-top:18px;align-items:start}
.j-panel{background:linear-gradient(180deg,rgba(28,14,54,.92),rgba(18,9,36,.92));border:1px solid var(--line-2);border-radius:6px;padding:18px 20px}
.j-panel h3{font-size:22px;margin-bottom:12px}.j-alert{border-color:#C99BFF;box-shadow:0 0 0 1px rgba(201,155,255,.35),0 0 32px -10px rgba(181,123,255,.85)}
.j-next{position:relative;overflow:hidden;padding:22px 24px;border-radius:6px;border:1px solid rgba(201,155,255,.5);background:radial-gradient(600px 220px at 85% 0%,rgba(181,123,255,.28),transparent 70%),#160A2D;box-shadow:0 0 40px -18px rgba(181,123,255,.9)}
.j-next h3{font-size:clamp(26px,3.4vw,40px);margin:6px 0 8px}.j-inj{border-color:rgba(255,122,154,.55)}
.j-vs{display:flex;align-items:center;gap:18px;margin:8px 0}.j-vs>b{font-family:var(--display);font-size:32px;color:var(--neon);text-shadow:0 0 14px rgba(201,155,255,.9)}.j-yt{font-family:var(--mono);font-size:12px;letter-spacing:.1em;text-transform:uppercase;color:var(--muted);border:1px dashed var(--line-2);padding:10px 12px;border-radius:4px}
.j-role{color:var(--muted);margin:4px 0 14px}.j-role b{color:var(--chalk)}
.j-acts{display:flex;gap:10px;flex-wrap:wrap;margin-top:14px}
.j-grp{display:grid;gap:8px}.j-grp h4{font-family:var(--mono);font-size:11px;letter-spacing:.14em;text-transform:uppercase;color:var(--muted);margin:0;font-weight:600}
.j-chips{display:flex;flex-wrap:wrap;gap:6px}.j-chip{border:1px solid var(--line-2);background:transparent;padding:8px 13px;border-radius:999px;font-weight:600;font-size:13.5px;transition:background .15s,border-color .15s,box-shadow .15s}
.j-chip:hover{border-color:#E4CCFF}.j-chip.on{background:#B57BFF;border-color:#D2A8FF;color:#13062B;box-shadow:0 0 16px -2px rgba(181,123,255,.9)}.j-chip[disabled]{opacity:.4;cursor:not-allowed}
.j-hint{font-size:13px;color:var(--muted);margin:6px 0 0}
.j-m{display:grid;grid-template-columns:minmax(110px,170px) 1fr 34px;gap:12px;align-items:center;font-size:13.5px;color:var(--muted);padding:5px 0}
.j-m i{height:6px;background:var(--turf-3);border-radius:3px;overflow:hidden}.j-m u{display:block;height:100%;background:linear-gradient(90deg,#7F45E0,#D2A8FF);border-radius:3px;box-shadow:0 0 10px rgba(181,123,255,.8);transition:width .8s cubic-bezier(.16,1,.3,1)}.j-m u.lo{background:var(--loss);box-shadow:none}.j-m b{color:var(--chalk);text-align:right}
.j-n{margin:0;padding:9px 0;border-top:1px solid var(--line);display:flex;gap:10px;align-items:baseline}.j-n:first-of-type{border-top:0}.j-n>b{color:var(--neon);font-size:12px;white-space:nowrap}.j-n.hot>b{text-shadow:0 0 10px rgba(201,155,255,.9)}.j-n.bad>b{color:var(--loss)}
.j-t{width:100%;border-collapse:collapse;font-size:14px}.j-t th{font-family:var(--mono);font-size:10.5px;letter-spacing:.12em;text-transform:uppercase;color:var(--muted);text-align:left;padding:8px 6px;border-bottom:1px solid var(--line-2)}.j-t td{padding:8px 6px;border-bottom:1px solid var(--line)}.j-t tr.me td{color:#F1E3FF;background:rgba(181,123,255,.14)}
.j-kv{display:grid;grid-template-columns:repeat(auto-fit,minmax(110px,1fr));gap:14px}.j-kv>div{display:grid;gap:3px}.j-kv small{font-family:var(--mono);font-size:10px;letter-spacing:.12em;text-transform:uppercase;color:var(--muted)}.j-kv b{font-size:17px}
.j-card{position:relative;overflow:hidden;width:100%;max-width:330px;aspect-ratio:3/4.3;padding:22px;display:flex;flex-direction:column;justify-content:flex-end;gap:12px;background:radial-gradient(120% 70% at 72% 0%,#9551F0,transparent 60%),linear-gradient(160deg,#4B26A0,#1E0F45 55%,#120828);clip-path:polygon(0 7%,7% 0,100% 0,100% 93%,93% 100%,0 100%);box-shadow:inset 0 0 0 1px rgba(214,190,255,.45),inset 0 0 40px -10px rgba(201,155,255,.7)}
.j-card.big{animation:jpin .9s cubic-bezier(.16,1,.3,1) backwards}@keyframes jpin{from{opacity:0;transform:translateY(24px) rotate(-2deg)}}
.j-sheen{position:absolute;inset:0;background:linear-gradient(115deg,transparent 35%,rgba(255,255,255,.2) 48%,transparent 60%);background-size:260% 100%;background-position:130% 0;animation:jsh 5.5s 1s ease-in-out infinite;pointer-events:none}@keyframes jsh{0%,55%{background-position:130% 0}100%{background-position:-60% 0}}
.j-dorsal{position:absolute;right:-8px;top:4px;font-family:var(--display);font-weight:900;font-size:220px;line-height:.8;color:transparent;-webkit-text-stroke:2px rgba(226,205,255,.25);pointer-events:none}
.j-ovr{position:absolute;left:22px;top:24px;display:grid;font-family:var(--display);font-weight:900;line-height:.85}.j-ovr b{font-family:var(--display);font-size:74px;color:#F6EEFF;text-shadow:0 0 18px rgba(201,155,255,.95)}.j-ovr span{font-size:20px;letter-spacing:.14em;color:#E0C9FF}
.j-cl{position:absolute;left:22px;top:122px}.j-free{font-family:var(--mono);font-size:10px;letter-spacing:.14em;color:#E0C9FF;border:1px solid rgba(214,190,255,.4);padding:3px 6px}
.j-av{position:absolute;right:16px;top:70px;filter:drop-shadow(0 0 18px rgba(181,123,255,.55))}.j-av svg path:first-of-type{stroke:var(--boot)}
.j-nm{position:relative;border-top:1px solid rgba(226,205,255,.35);padding-top:12px}.j-nm small{font-size:13px;color:#E0C9FF}.j-nm h3{font-size:42px;overflow-wrap:anywhere}
.j-six{position:relative;display:grid;grid-template-columns:repeat(6,1fr);gap:4px;text-align:center}.j-six b{display:block;font-size:18px}.j-six small{font-family:var(--mono);font-size:9.5px;letter-spacing:.1em;color:#CDB5F5;text-transform:uppercase}
.j-radar{display:flex;gap:26px;align-items:center;flex-wrap:wrap}.j-attrs{flex:1;min-width:240px}.j-rad{transform-origin:100px 100px;animation:jrd 1.1s .2s cubic-bezier(.16,1,.3,1) backwards}@keyframes jrd{from{transform:scale(.15);opacity:0}}
.j-stars{display:inline-flex;gap:3px}.j-stars i{width:12px;height:12px;clip-path:polygon(50% 0,62% 36%,100% 38%,70% 60%,80% 100%,50% 76%,20% 100%,30% 60%,0 38%,38% 36%);background:var(--turf-3)}.j-stars i.on{background:#D2A8FF;filter:drop-shadow(0 0 4px rgba(201,155,255,.9))}
.j-skills{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:10px}.j-skills>div{padding:12px;border:1px solid rgba(201,155,255,.45);border-radius:4px;display:grid;gap:4px;box-shadow:inset 0 0 18px -10px rgba(181,123,255,.9)}.j-skills small{color:var(--muted)}
.j-foc{display:grid;gap:8px}.j-fo{display:grid;grid-template-columns:1fr 44px;gap:4px 12px;text-align:left;padding:12px 14px;background:var(--turf);border:1px solid var(--line);border-radius:4px}.j-fo.on{border-color:#C99BFF;background:var(--turf-2);box-shadow:0 0 18px -8px rgba(181,123,255,.9)}.j-fo span{font-weight:600}.j-fo b{text-align:right}.j-fo i{grid-column:1/-1;height:4px;background:var(--turf-3);border-radius:2px}.j-fo u{display:block;height:100%;background:#B57BFF;border-radius:2px}
.j-check{display:flex;gap:10px;align-items:center;margin-top:14px;font-size:14px}
.j-cal{display:grid;margin-top:16px;max-width:820px}.j-cr{display:grid;grid-template-columns:48px 96px 28px minmax(0,1fr) auto;gap:14px;align-items:center;padding:12px 8px;border-top:1px solid var(--line)}.j-cr.now{background:var(--sodium-soft);border:1px solid #C99BFF;border-radius:4px;box-shadow:0 0 20px -10px rgba(181,123,255,.9)}.j-cr b{color:var(--neon)}.j-cr em{font-style:normal;color:var(--muted);font-size:13px;white-space:nowrap}
.j-tag{font-family:var(--mono);font-size:10px;letter-spacing:.12em;text-transform:uppercase;padding:3px 8px;border-radius:999px;border:1px solid var(--line-2);text-align:center}.t-copa{border-color:#FFD24A;color:#FFE08A}.t-eur{border-color:#C99BFF;color:#E4CCFF;box-shadow:0 0 10px -2px rgba(181,123,255,.8)}.t-sel{border-color:#3DE0C2;color:#9CF2E2}
.j-offers{display:grid;gap:12px;margin-top:22px;max-width:860px}.j-offer{display:grid;grid-template-columns:58px 1fr auto;gap:18px;align-items:center;text-align:left;padding:18px 20px;background:var(--turf);border:1px solid var(--line-2);border-radius:6px;transition:transform .2s cubic-bezier(.16,1,.3,1),border-color .2s,box-shadow .2s}
.j-offer:hover,.j-offer:focus-visible{transform:translateX(6px);border-color:#C99BFF;box-shadow:0 0 30px -12px rgba(181,123,255,.95)}.j-offer h3{font-size:28px}.j-offer p{margin:2px 0 0}.j-offer-r{display:grid;text-align:right}.j-offer-r small{font-size:11.5px;color:var(--muted)}
.j-of{display:grid;grid-template-columns:44px 1fr;gap:12px 14px;align-items:center;padding:12px 0;border-top:1px solid var(--line)}.j-of:first-of-type{border-top:0}.j-of small{display:block;color:var(--muted);font-size:12.5px}.j-ofb{grid-column:1/-1;display:flex;gap:8px;flex-wrap:wrap}
.j-bigs{display:flex;flex-wrap:wrap;gap:clamp(18px,4vw,54px);margin:14px 0 6px}.j-bigs>div{display:grid;font-size:13px;color:var(--muted)}.j-bigs b{font-family:var(--display);font-size:clamp(44px,6vw,84px);line-height:.9;color:#F6EEFF;text-shadow:0 0 22px rgba(181,123,255,.55)}
.j-bars{width:100%;max-width:520px}
.j-feed{max-height:420px;overflow:auto;margin-top:14px}
.j-shop{display:grid;gap:8px}.j-buy{display:flex;justify-content:space-between;gap:12px;padding:11px 14px;border:1px solid var(--line-2);border-radius:4px;background:transparent;text-align:left}.j-buy:not([disabled]):hover{border-color:#C99BFF}.j-buy[disabled]{opacity:.5;cursor:not-allowed}
.j-gal{display:grid;grid-template-columns:repeat(auto-fill,minmax(130px,1fr));gap:12px}.j-tro{display:grid;justify-items:center;text-align:center;gap:6px;padding:16px 10px;border:1px solid var(--line-2);border-radius:6px;color:#FFD24A}.j-tro.a{color:#D2A8FF}.j-tro svg{filter:drop-shadow(0 0 10px currentColor)}.j-tro b{color:var(--chalk);font-size:13.5px}.j-tro small{color:var(--muted);font-size:11.5px}
.j-riv{display:grid;grid-template-columns:30px 1fr auto;gap:12px;align-items:center;padding:10px 0;border-top:1px solid var(--line)}.j-riv small{display:block;color:var(--muted);font-size:12px}.j-riv>b{font-family:var(--display);font-size:28px;color:var(--neon)}
.j-mhd h3{font-size:24px}.j-sit{font-size:17px;margin:0 0 14px}.j-opts{display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:10px}.j-opts.col{grid-template-columns:1fr}
.j-op{display:grid;gap:4px;text-align:left;padding:14px 16px;border:1px solid rgba(201,155,255,.45);border-radius:6px;background:#1A0D33;transition:border-color .15s,box-shadow .15s,transform .15s}.j-op:hover,.j-op:focus-visible{border-color:#E4CCFF;box-shadow:0 0 24px -8px rgba(181,123,255,.95);transform:translateY(-2px)}.j-op b{font-size:16px}.j-op small{font-family:var(--mono);font-size:11.5px;color:var(--muted)}
.j-last{margin:14px 0 0;padding:10px 12px;border-left:2px solid #C99BFF;background:rgba(181,123,255,.08);font-size:14px}
.j-note{display:flex;align-items:baseline;gap:16px;margin-bottom:16px}.j-note b{font-family:var(--display);font-size:84px;line-height:.85;color:#F1E3FF;text-shadow:0 0 22px rgba(201,155,255,.95)}.j-note span{display:grid;font-weight:600}.j-note small{color:var(--muted);font-weight:400}
.j-log{max-height:190px;overflow:auto;margin-top:14px;border-top:1px solid var(--line);padding-top:8px}.j-log p{margin:0;padding:4px 0;font-size:13.5px;color:var(--muted)}
.j-bar{position:relative;height:38px;border-radius:6px;background:#1A0D33;border:1px solid rgba(201,155,255,.4);overflow:hidden;margin:6px 0 10px}.j-bar .z{position:absolute;top:0;bottom:0;background:rgba(181,123,255,.35);box-shadow:inset 0 0 14px rgba(201,155,255,.9)}.j-bar .c{position:absolute;top:0;bottom:0;width:2px;background:#F1E3FF}
.j-bar span{position:absolute;top:4px;bottom:4px;width:6px;border-radius:3px;background:#FFD24A;box-shadow:0 0 12px #FFD24A;animation:jmk var(--dur) ease-in-out infinite alternate}@keyframes jmk{from{left:0}to{left:calc(100% - 6px)}}
.j-create .j-cgrid{display:grid;grid-template-columns:minmax(0,1fr) minmax(260px,360px);gap:clamp(24px,5vw,70px);align-items:start;padding-bottom:80px}.j-form{display:grid;gap:22px}
.j-fs{border:1px solid var(--line-2);border-radius:6px;padding:16px 18px 18px;display:grid;gap:16px;margin:0;background:rgba(20,9,39,.7)}.j-fs legend{font-family:var(--display);font-weight:800;text-transform:uppercase;font-size:20px;padding:0 6px;color:var(--neon)}
.j-row2{display:grid;grid-template-columns:1fr 1fr;gap:12px}.j-row3{display:grid;grid-template-columns:1.2fr 1.4fr .7fr;gap:12px}.j-form label{display:grid;gap:6px;font-size:12.5px;color:var(--muted)}
.j-form input:not([type=range]):not([type=checkbox]),.j-form select{background:var(--turf);border:1px solid var(--line-2);color:var(--chalk);padding:11px 12px;border-radius:4px;font:inherit;font-size:16px;min-width:0}
.j-form input:focus,.j-form select:focus{outline:2px solid #C99BFF;border-color:transparent;box-shadow:0 0 18px -4px rgba(181,123,255,.9)}
.j-date{display:flex;align-items:center;gap:6px;color:var(--muted)}.j-date input{width:64px}
.j-range{display:grid;gap:8px}.j-range input{width:100%}
.j-sw{display:flex;gap:8px}.j-sw button{width:34px;height:34px;border-radius:50%;border:2px solid transparent}.j-sw button.on{border-color:#F1E3FF;box-shadow:0 0 14px rgba(201,155,255,.9)}
.j-go{justify-self:start;padding:14px 24px;font-size:16px}
.j-stage{position:sticky;top:24px;display:grid;place-items:center;padding:30px 10px;background:radial-gradient(closest-side,rgba(150,80,255,.35),transparent)}
.j-legend{padding-block:40px 90px}
.j-city{display:grid;grid-template-columns:minmax(0,1fr);gap:18px;margin-top:18px}
.j-city3d{position:relative;height:clamp(420px,74vh,880px);border-radius:8px;overflow:hidden;border:1px solid rgba(201,155,255,.45);box-shadow:0 0 44px -16px rgba(170,100,255,.9);cursor:grab;touch-action:pan-y;background:#0B0518}
.j-city3d:active{cursor:grabbing}.j-city-slot{position:absolute;inset:0}.j-city3d canvas{position:absolute;inset:0;width:100%!important;height:100%!important;display:block}
.j-city-fb{position:absolute;inset:0;display:grid;place-items:center}
.j-city-ui{position:absolute;left:12px;bottom:12px;display:flex;gap:6px;flex-wrap:wrap}.j-city-ui .btn{background:rgba(14,6,30,.82);backdrop-filter:blur(6px)}
.j-hlist{display:grid;grid-template-columns:repeat(auto-fill,minmax(min(100%,300px),1fr));column-gap:28px;margin-top:14px}.j-hrow{display:grid;grid-template-columns:1fr auto auto;gap:12px;align-items:center;padding:10px 0;border-top:1px solid var(--line)}
.j-hrow small{display:block;color:var(--muted);font-size:12.5px}.j-hrow em{font-style:normal;font-size:12.5px}
.j-pips{display:flex;gap:4px}.j-pips i{width:14px;height:6px;border-radius:3px;background:var(--turf-3)}.j-pips i.on{background:#C99BFF;box-shadow:0 0 8px rgba(201,155,255,.9)}
.j-house>.j-kv{max-width:620px}
.j-dec{margin:14px 0 4px;padding:14px 16px;border:1px solid #C99BFF;border-radius:8px;background:radial-gradient(500px 160px at 50% 0%,rgba(181,123,255,.25),transparent 70%),#170A2E;box-shadow:0 0 30px -10px rgba(181,123,255,.95);animation:jdec .35s cubic-bezier(.16,1,.3,1)}
@keyframes jdec{from{opacity:0;transform:translateY(10px)}}
.j-dec .j-sit b{color:var(--neon);margin-right:6px}
.j-dec-3d{position:absolute;left:12px;right:12px;bottom:12px;margin:0;z-index:6;background:rgba(18,8,38,.9);backdrop-filter:blur(6px)}
@media(max-width:640px){.j-dec-3d{left:6px;right:6px;bottom:6px;padding:10px}.j-dec-3d .j-opts{grid-template-columns:repeat(3,1fr);gap:6px}.j-dec-3d .j-op{padding:8px}.j-dec-3d .j-op small{font-size:10px}.j-dec-3d .j-sit{font-size:13.5px;margin-bottom:8px}}
.j-star-k{color:#E4CCFF;text-shadow:0 0 10px rgba(201,155,255,.95)}
body[data-mode=player] .feed p.j-hot{color:#F1E3FF;text-shadow:0 0 10px rgba(201,155,255,.8)}
.j-stage{position:static;display:grid;gap:22px;justify-items:center;align-content:start;min-width:0;width:100%}.j-stage>*{max-width:100%;min-width:0}#jc-prev{width:100%;display:grid;justify-items:center}
.j-aspect{width:100%;max-width:min(100%,380px);box-sizing:border-box;border:1px solid rgba(201,155,255,.5);border-radius:8px;background:radial-gradient(420px 260px at 50% 0%,rgba(150,80,255,.28),transparent 70%),#110722;box-shadow:0 0 0 1px rgba(181,123,255,.15),0 0 44px -16px rgba(170,100,255,.9);padding:16px 16px 18px;display:grid;gap:14px}
.j-panel .j-aspect{max-width:none;border:0;box-shadow:none;background:none;padding:0}
.j-asp-h{display:flex;align-items:baseline;justify-content:space-between;gap:12px}.j-asp-h h3{font-size:26px;text-shadow:0 0 16px rgba(201,155,255,.6)}.j-asp-h small{font-family:var(--mono);font-size:10.5px;letter-spacing:.12em;text-transform:uppercase;color:var(--muted)}
.j-3d{position:relative;height:340px;border-radius:6px;overflow:hidden;background:radial-gradient(closest-side at 50% 72%,rgba(181,123,255,.32),transparent),linear-gradient(180deg,#1a0c33,#0b0518);cursor:grab;touch-action:pan-y}
.j-3d:active{cursor:grabbing}.j-3d canvas{display:block;width:100%!important;height:100%!important;max-width:100%;position:absolute;inset:0}.j-3d-fb{position:absolute;inset:0;display:grid;place-items:center}
.j-asp-c{display:grid;gap:12px}.j-asp-c .j-grp h4{font-size:10.5px}
.j-sw.sm button{width:28px;height:28px}
.j-asp-row{display:grid;grid-template-columns:minmax(0,1fr);gap:12px}.j-aspect{grid-template-columns:minmax(0,1fr)}.j-sw{flex-wrap:wrap}
@media(max-width:980px){.j-ind>div:not(.j-big):nth-child(n+5){display:none}.j-brand{display:none}}
@media(max-width:820px){.j-shell{grid-template-columns:1fr;padding-top:0}.j-rail{position:sticky;top:62px;z-index:10;display:flex;overflow-x:auto;gap:4px;margin:0 calc(-1*max(16px,env(safe-area-inset-left)));padding:8px max(16px,env(safe-area-inset-left));background:rgba(9,4,18,.94);border-bottom:1px solid var(--line);scrollbar-width:none}.j-rl{white-space:nowrap;padding:8px 12px}.j-rl span{display:none}.j-rl.on{box-shadow:inset 0 -2px 0 #C99BFF}
 .j-dg,.j-create .j-cgrid{grid-template-columns:1fr}.j-hero,.j-stage{position:static}.j-stage{order:-1;padding:6px}.j-row3{grid-template-columns:1fr 1fr}.j-cr{grid-template-columns:40px 80px 26px 1fr}.j-cr em{display:none}.j-hclub span{display:none}.j-ind{gap:12px}.j-ind>div:not(.j-big):nth-child(n+4){display:none}.j-m{grid-template-columns:110px 1fr 30px}.j-offer{grid-template-columns:44px 1fr}.j-offer-r{grid-column:2;text-align:left}}
@media(prefers-reduced-motion:reduce){.j-sheen,.j-card.big,.j-main,.j-rad{animation:none}.j-bar span{animation-duration:2.4s!important}}`;
document.head.appendChild(css);
if(UI.screen==='intro')render();
})();
